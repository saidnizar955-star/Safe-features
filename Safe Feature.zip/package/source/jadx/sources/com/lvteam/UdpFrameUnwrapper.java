package com.lvteam;

import android.os.SystemClock;
import android.util.Log;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public final class UdpFrameUnwrapper {
    public long compressedFrames;
    public long datagramsOffered;
    public long decryptFailures;
    public long encryptedFrames;
    public long invalidCrcs;
    public long invalidHeaders;
    public long invalidLengths;
    public long lastTelemetryMs;
    public long unconfiguredFrames;
    public final Map verifiedTags = new HashMap();

    public enum Field {
        SEND_OPTION(1, false),
        TAG(2, false),
        ORDER_ID(2, true),
        FLAGS(1, false),
        DATA_LENGTH(2, false);

        public final boolean reliableOnly;
        public final int width;

        Field(int width, boolean reliableOnly) {
            this.width = width;
            this.reliableOnly = reliableOnly;
        }
    }

    public static Configuration configuration(int mask, byte[] key, Field... order) {
        return new Configuration(mask, key, order);
    }

    public static final class Configuration {
        public final byte[] key;
        public final int mask;
        public final int[] reliableOffsets;
        public final int[] unreliableOffsets;

        public Configuration(int mask, byte[] key, Field... order) {
            this.reliableOffsets = new int[Field.values().length];
            this.unreliableOffsets = new int[Field.values().length];
            if (order == null || order.length != Field.values().length) {
                throw new IllegalArgumentException("Header order must name all five fields");
            }
            if (key != null && key.length != 16) {
                throw new IllegalArgumentException("Session key must contain 16 bytes");
            }
            this.mask = mask & 255;
            this.key = key == null ? null : Arrays.copyOf(key, key.length);
            Arrays.fill(this.reliableOffsets, -1);
            Arrays.fill(this.unreliableOffsets, -1);
            int reliableOffset = 2;
            int unreliableOffset = 2;
            for (Field field : order) {
                if (field == null || this.reliableOffsets[field.ordinal()] != -1) {
                    throw new IllegalArgumentException("Header order must be a field permutation");
                }
                this.reliableOffsets[field.ordinal()] = reliableOffset;
                reliableOffset += field.width;
                if (!field.reliableOnly) {
                    this.unreliableOffsets[field.ordinal()] = unreliableOffset;
                    unreliableOffset += field.width;
                }
            }
            if (reliableOffset != 10 || unreliableOffset != 8) {
                throw new IllegalArgumentException("Invalid legacy header layout");
            }
        }
    }

    public synchronized void recordDatagramOffered() {
        this.datagramsOffered++;
        reportTelemetryIfDue();
    }

    public synchronized int peekTag(byte[] datagram, int offset, int length, Configuration configuration) {
        if (configuration != null && datagram != null && offset >= 0 && length >= 8) {
            try {
                if (offset <= datagram.length - length) {
                    int headerLength = headerLength(datagram[offset] & 255);
                    if (headerLength != -1 && length >= headerLength) {
                        if ((datagram[offset + 1] & 255) != crc8(datagram, offset, length)) {
                            return -1;
                        }
                        boolean reliable = headerLength == 10;
                        int[] offsets = reliable ? configuration.reliableOffsets : configuration.unreliableOffsets;
                        return readShort(datagram, offset, offsets[Field.TAG.ordinal()], configuration.mask);
                    }
                    return -1;
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        return -1;
    }

    public synchronized UdpDecodedFrame unwrap(byte[] datagram, int offset, int length, Configuration configuration) {
        int tag;
        try {
            if (configuration == null) {
                this.unconfiguredFrames++;
                reportTelemetryIfDue();
                return null;
            }
            if (datagram == null || offset < 0 || length < 8 || offset > datagram.length - length) {
                this.invalidLengths++;
                reportTelemetryIfDue();
                return null;
            }
            int headerLength = headerLength(datagram[offset] & 255);
            if (headerLength == -1) {
                this.invalidHeaders++;
                reportTelemetryIfDue();
                return null;
            }
            boolean reliable = headerLength == 10;
            if (length < headerLength) {
                this.invalidLengths++;
                reportTelemetryIfDue();
                return null;
            }
            if ((datagram[offset + 1] & 255) != crc8(datagram, offset, length)) {
                this.invalidCrcs++;
                reportTelemetryIfDue();
                return null;
            }
            int[] offsets = reliable ? configuration.reliableOffsets : configuration.unreliableOffsets;
            int sendOption = readByte(datagram, offset, offsets[Field.SEND_OPTION.ordinal()], configuration.mask);
            int i = readShort(datagram, offset, offsets[Field.TAG.ordinal()], configuration.mask);
            int orderId = reliable ? readShort(datagram, offset, offsets[Field.ORDER_ID.ordinal()], configuration.mask) : -1;
            int flags = readByte(datagram, offset, offsets[Field.FLAGS.ordinal()], configuration.mask);
            int declaredPayloadLength = readShort(datagram, offset, offsets[Field.DATA_LENGTH.ordinal()], configuration.mask);
            if ((flags & 1) != 0) {
                this.encryptedFrames++;
            }
            if ((flags & 2) != 0) {
                this.compressedFrames++;
            }
            int payloadLength = length - headerLength;
            if (declaredPayloadLength > payloadLength) {
                this.invalidLengths++;
                reportTelemetryIfDue();
                return null;
            }
            byte[] payload = Arrays.copyOfRange(datagram, offset + headerLength, offset + headerLength + declaredPayloadLength);
            if ((flags & 2) != 0) {
                reportTelemetryIfDue();
                return null;
            }
            if ((flags & 1) != 0 && (payload = decryptLegacy(payload, configuration.key)) == null) {
                this.decryptFailures++;
                reportTelemetryIfDue();
                return null;
            }
            if (this.verifiedTags.size() < 32 || this.verifiedTags.containsKey(Integer.valueOf(tag))) {
                tag = i;
                Long count = (Long) this.verifiedTags.get(Integer.valueOf(tag));
                this.verifiedTags.put(Integer.valueOf(tag), Long.valueOf(count == null ? 1L : count.longValue() + 1));
            }
            tag = i;
            reportTelemetryIfDue();
            return new UdpDecodedFrame(tag, payload, reliable, sendOption, orderId, flags, declaredPayloadLength);
        } catch (Throwable th) {
            throw th;
        }
    }

    public synchronized byte[] rebuild(byte[] datagram, int offset, int length, Configuration configuration, UdpDecodedFrame decoded, byte[] plainPayload) {
        if (decoded != null && plainPayload != null && configuration != null) {
            try {
                if ((decoded.flags & 2) == 0 && datagram != null && offset >= 0 && length >= 8 && offset <= datagram.length - length) {
                    int headerLength = headerLength(datagram[offset] & 255);
                    if (headerLength != -1 && length >= headerLength && (datagram[offset + 1] & 255) == crc8(datagram, offset, length)) {
                        boolean reliable = headerLength == 10;
                        int[] offsets = reliable ? configuration.reliableOffsets : configuration.unreliableOffsets;
                        int tag = readShort(datagram, offset, offsets[Field.TAG.ordinal()], configuration.mask);
                        int flags = readByte(datagram, offset, offsets[Field.FLAGS.ordinal()], configuration.mask);
                        int declaredLength = readShort(datagram, offset, offsets[Field.DATA_LENGTH.ordinal()], configuration.mask);
                        if (reliable != decoded.reliable || tag != decoded.tag || flags != decoded.flags || declaredLength != decoded.declaredPayloadLength || declaredLength > length - headerLength) {
                            return null;
                        }
                        byte[] encoded = (flags & 1) == 0 ? plainPayload : encryptLegacy(plainPayload, configuration.key);
                        if (encoded == null || encoded.length > 65535) {
                            return null;
                        }
                        int tailLength = (length - headerLength) - declaredLength;
                        byte[] rebuilt = new byte[encoded.length + headerLength + tailLength];
                        System.arraycopy(datagram, offset, rebuilt, 0, headerLength);
                        System.arraycopy(encoded, 0, rebuilt, headerLength, encoded.length);
                        if (tailLength > 0) {
                            System.arraycopy(datagram, offset + headerLength + declaredLength, rebuilt, encoded.length + headerLength, tailLength);
                        }
                        writeShort(rebuilt, offsets[Field.DATA_LENGTH.ordinal()], encoded.length, configuration.mask);
                        rebuilt[1] = (byte) crc8(rebuilt, 0, rebuilt.length);
                        return rebuilt;
                    }
                    return null;
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        return null;
    }

    public final void reportTelemetryIfDue() {
        long now = SystemClock.elapsedRealtime();
        if (now - this.lastTelemetryMs < 5000 || this.datagramsOffered == 0) {
            return;
        }
        Log.i("UdpFrameUnwrapper", "udp offered=" + this.datagramsOffered + " unconfigured=" + this.unconfiguredFrames + " invalidHeader=" + this.invalidHeaders + " invalidCrc=" + this.invalidCrcs + " invalidLength=" + this.invalidLengths + " encrypted=" + this.encryptedFrames + " compressed=" + this.compressedFrames + " decryptFailed=" + this.decryptFailures + " verifiedTags=" + formatTags());
        this.datagramsOffered = 0L;
        this.unconfiguredFrames = 0L;
        this.invalidHeaders = 0L;
        this.invalidCrcs = 0L;
        this.invalidLengths = 0L;
        this.encryptedFrames = 0L;
        this.compressedFrames = 0L;
        this.decryptFailures = 0L;
        this.verifiedTags.clear();
        this.lastTelemetryMs = now;
    }

    public final String formatTags() {
        if (this.verifiedTags.isEmpty()) {
            return "{}";
        }
        StringBuilder result = new StringBuilder("{");
        for (Map.Entry<Integer, Long> entry : this.verifiedTags.entrySet()) {
            if (result.length() > 1) {
                result.append(',');
            }
            result.append("0x");
            result.append(Integer.toHexString(entry.getKey().intValue()));
            result.append('=');
            result.append(entry.getValue());
        }
        result.append('}');
        return result.toString();
    }

    public static int headerLength(int sendOption) {
        if (sendOption < 90 || sendOption >= 100) {
            return (sendOption < 100 || sendOption > 110) ? -1 : 8;
        }
        return 10;
    }

    public static int readByte(byte[] data, int base, int fieldOffset, int mask) {
        return (data[base + fieldOffset] & 255) ^ mask;
    }

    public static int readShort(byte[] data, int base, int fieldOffset, int mask) {
        return readByte(data, base, fieldOffset, mask) | (readByte(data, base, fieldOffset + 1, mask) << 8);
    }

    public static void writeShort(byte[] data, int fieldOffset, int value, int mask) {
        data[fieldOffset] = (byte) ((value & 255) ^ mask);
        data[fieldOffset + 1] = (byte) (((value >>> 8) & 255) ^ mask);
    }

    public static byte[] decryptLegacy(byte[] encrypted, byte[] key) {
        if (key == null || encrypted.length < 16 || (encrypted.length & 7) != 0) {
            return null;
        }
        int[] words = new int[4];
        for (int index = 0; index < words.length; index++) {
            words[index] = readIntLe(key, index * 4);
        }
        int index2 = encrypted.length;
        byte[] decoded = new byte[index2];
        byte[] previousDecoded = new byte[8];
        byte[] previousCiphertext = new byte[8];
        byte[] block = new byte[8];
        byte[] decryptedBlock = new byte[8];
        for (int offset = 0; offset < encrypted.length; offset += 8) {
            for (int index3 = 0; index3 < 8; index3++) {
                block[index3] = (byte) (encrypted[offset + index3] ^ previousDecoded[index3]);
            }
            decryptTeaBlock(words, block, decryptedBlock);
            for (int index4 = 0; index4 < 8; index4++) {
                decoded[offset + index4] = (byte) (decryptedBlock[index4] ^ previousCiphertext[index4]);
            }
            System.arraycopy(decryptedBlock, 0, previousDecoded, 0, 8);
            System.arraycopy(encrypted, offset, previousCiphertext, 0, 8);
        }
        int start = (decoded[0] & 7) + 3;
        int end = decoded.length - 7;
        if (end < start) {
            return null;
        }
        for (int index5 = end; index5 < decoded.length; index5++) {
            if (decoded[index5] != 0) {
                return null;
            }
        }
        return Arrays.copyOfRange(decoded, start, end);
    }

    public static byte[] encryptLegacy(byte[] plain, byte[] key) {
        if (key == null) {
            return null;
        }
        int padding = (8 - ((plain.length + 10) & 7)) & 7;
        byte[] padded = new byte[plain.length + padding + 10];
        padded[0] = (byte) padding;
        System.arraycopy(plain, 0, padded, padding + 3, plain.length);
        int[] words = new int[4];
        for (int index = 0; index < words.length; index++) {
            words[index] = readIntLe(key, index * 4);
        }
        int index2 = padded.length;
        byte[] encrypted = new byte[index2];
        byte[] previousPlain = new byte[8];
        byte[] previousCiphertext = new byte[8];
        byte[] block = new byte[8];
        byte[] encryptedBlock = new byte[8];
        for (int offset = 0; offset < padded.length; offset += 8) {
            for (int index3 = 0; index3 < 8; index3++) {
                block[index3] = (byte) (padded[offset + index3] ^ previousCiphertext[index3]);
            }
            encryptTeaBlock(words, block, encryptedBlock);
            for (int index4 = 0; index4 < 8; index4++) {
                encrypted[offset + index4] = (byte) (encryptedBlock[index4] ^ previousPlain[index4]);
            }
            System.arraycopy(block, 0, previousPlain, 0, 8);
            System.arraycopy(encrypted, offset, previousCiphertext, 0, 8);
        }
        return encrypted;
    }

    public static void decryptTeaBlock(int[] key, byte[] input, byte[] output) {
        int y = readIntLe(input, 0);
        int z = readIntLe(input, 4);
        int sum = -478700656;
        for (int round = 0; round < 16; round++) {
            z -= (((y << 4) + key[2]) ^ (y + sum)) ^ ((y >>> 5) + key[3]);
            y -= (((z << 4) + key[0]) ^ (z + sum)) ^ ((z >>> 5) + key[1]);
            sum += 1640531527;
        }
        writeIntLe(output, 0, y);
        writeIntLe(output, 4, z);
    }

    public static void encryptTeaBlock(int[] key, byte[] input, byte[] output) {
        int y = readIntLe(input, 0);
        int z = readIntLe(input, 4);
        int sum = 0;
        for (int round = 0; round < 16; round++) {
            sum -= 1640531527;
            y += (((z << 4) + key[0]) ^ (z + sum)) ^ ((z >>> 5) + key[1]);
            z += (((y << 4) + key[2]) ^ (y + sum)) ^ ((y >>> 5) + key[3]);
        }
        writeIntLe(output, 0, y);
        writeIntLe(output, 4, z);
    }

    public static int readIntLe(byte[] data, int offset) {
        return (data[offset] & 255) | ((data[offset + 1] & 255) << 8) | ((data[offset + 2] & 255) << 16) | ((data[offset + 3] & 255) << 24);
    }

    public static void writeIntLe(byte[] data, int offset, int value) {
        data[offset] = (byte) value;
        data[offset + 1] = (byte) (value >>> 8);
        data[offset + 2] = (byte) (value >>> 16);
        data[offset + 3] = (byte) (value >>> 24);
    }

    public static int crc8(byte[] data, int offset, int length) {
        int crc = 0;
        int end = offset + length;
        for (int i = offset + 2; i < end; i++) {
            crc = crcTable((crc << 1) ^ (data[i] & 255));
        }
        return crc;
    }

    public static int crcTable(int value) {
        int value2 = value & 255;
        for (int bit = 0; bit < 8; bit++) {
            int highBit = value2 & 128;
            value2 = (value2 << 1) & 255;
            if (highBit != 0) {
                value2 ^= 18;
            }
        }
        int bit2 = value2 >>> 1;
        return bit2;
    }
}
