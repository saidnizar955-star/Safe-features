package com.lvteam;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.view.View;

/* JADX INFO: loaded from: classes.dex */
public final class GetKeyClick implements View.OnClickListener {
    private final Activity activity;

    public GetKeyClick(Activity activity) {
        this.activity = activity;
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        this.activity.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(ObfStrings.channel())));
    }
}
