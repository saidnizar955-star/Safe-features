package com.lvteam;

/* JADX INFO: loaded from: classes.dex */
public final class VarintReader {
    public final byte[] bytes;
    public int position;

    public VarintReader(byte[] bytes) {
        this.bytes = bytes == null ? new byte[0] : bytes;
    }

    public boolean hasRemaining() {
        return this.position < this.bytes.length;
    }

    public long readUnsigned() {
        long value = 0;
        for (int shift = 0; this.position < this.bytes.length && shift < 64; shift += 7) {
            byte[] bArr = this.bytes;
            int i = this.position;
            this.position = i + 1;
            int next = bArr[i] & 255;
            value |= ((long) (next & 127)) << shift;
            if ((next & 128) == 0) {
                return value;
            }
        }
        throw new IllegalArgumentException("Malformed varint");
    }

    public static long zigZag(long value) {
        return (value >>> 1) ^ (-(1 & value));
    }
}
