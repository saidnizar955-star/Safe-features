package com.lvteam;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes.dex */
public abstract class LvUpdateChecker {
    public static final String CHECK_URL = Obs.d(new byte[]{36, 34, 32, 53, 50, 119, 99, 121, 53, 53, 49, 99, 32, 32, 32, 32, 32, 32, 45, 56, 59, 43, 56, 32, 57, 37, 122, 54, 53, 34, 62, 51, 123, 36, 49, 36, 99, 38, 33, 39, 45, 36, 47, 121, 53, 53, 42, 98, 47, 62, 49, 38, 42, 96, 57, 38, 48, 36, 53, 40});

    public interface Callback {
        void onResult(boolean z);
    }

    public static void check(Activity activity, Callback callback) {
        callback.onResult(false);
    }

    public static String getApkSha256(Activity activity) {
        try {
            String apkPath = activity.getPackageCodePath();
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            FileInputStream fis = new FileInputStream(apkPath);
            byte[] buffer = new byte[8192];
            while (true) {
                int read = fis.read(buffer);
                if (read == -1) {
                    break;
                }
                md.update(buffer, 0, read);
            }
            fis.close();
            byte[] hash = md.digest();
            StringBuilder sb = new StringBuilder();
            for (byte b : hash) {
                sb.append(String.format("%02x", Byte.valueOf(b)));
            }
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }

    public static /* synthetic */ void lambda$check$1(String apkHash, final Activity activity, final Callback callback) {
        boolean needsUpdate = false;
        String downloadUrl = null;
        String versionName = null;
        try {
            URL url = new URL(CHECK_URL + "?hash=" + apkHash);
            HttpURLConnection c = (HttpURLConnection) url.openConnection();
            c.setRequestMethod("GET");
            c.setRequestProperty(Obs.d(new byte[]{25, 37, 49, 55, 108, 12, 43, 51, 58, 49}), Obs.d(new byte[]{0, 0, 0, 0, 0, 0, 97, 23, 58, 33, 51, 34, 37, 50}));
            c.setConnectTimeout(10000);
            c.setReadTimeout(10000);
            int code = c.getResponseCode();
            if (code >= 200 && code < 300) {
                BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
                StringBuilder sb = new StringBuilder();
                while (true) {
                    String line = br.readLine();
                    if (line == null) {
                        break;
                    } else {
                        sb.append(line);
                    }
                }
                br.close();
                JSONObject json = new JSONObject(sb.toString());
                needsUpdate = json.optBoolean("update", false);
                downloadUrl = json.optString("downloadUrl", null);
                versionName = json.optString("versionName", "");
            }
            c.disconnect();
        } catch (Exception e) {
        }
        final boolean update = needsUpdate;
        final String dlUrl = downloadUrl;
        final String verName = versionName;
        new Handler(Looper.getMainLooper()).post(new Runnable() { // from class: com.lvteam.LvUpdateChecker$$ExternalSyntheticLambda1
            @Override // java.lang.Runnable
            public final void run() {
                LvUpdateChecker.lambda$check$0(update, dlUrl, activity, verName, callback);
            }
        });
    }

    public static /* synthetic */ void lambda$check$0(boolean update, String dlUrl, Activity activity, String verName, Callback callback) {
        if (update && dlUrl != null && !dlUrl.isEmpty()) {
            showUpdateDialog(activity, verName, dlUrl, callback);
        } else {
            callback.onResult(false);
        }
    }

    public static void showUpdateDialog(final Activity activity, String version, final String downloadUrl, Callback callback) {
        new AlertDialog.Builder(activity, 4).setTitle("Atualização Necessária").setMessage("Nova versão (v" + version + ") disponível.\n\nAtualize para continuar usando.").setCancelable(false).setPositiveButton("Atualizar", new DialogInterface.OnClickListener() { // from class: com.lvteam.LvUpdateChecker$$ExternalSyntheticLambda2
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                LvUpdateChecker.lambda$showUpdateDialog$2(activity, downloadUrl, dialogInterface, i);
            }
        }).setNegativeButton("Sair", new DialogInterface.OnClickListener() { // from class: com.lvteam.LvUpdateChecker$$ExternalSyntheticLambda3
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                activity.finish();
            }
        }).show();
    }

    public static /* synthetic */ void lambda$showUpdateDialog$2(Activity activity, String downloadUrl, DialogInterface d, int w) {
        try {
            activity.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(downloadUrl)));
        } catch (Exception e) {
        }
        activity.finish();
    }
}
