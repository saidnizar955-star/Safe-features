package com.lvteam;

import android.os.SystemClock;
import android.util.Log;
import java.io.ByteArrayOutputStream;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public final class RawFrameDecoder {
    public volatile UdpFrameUnwrapper.Configuration lastLearnedConfig;
    public long lastShiftReportAt;
    public long rawPositionsAccepted;
    public long rawPositionsMalformed;
    public long rawTelemetryAt;
    public long shiftApplied;
    public long shiftLocalPreserved;
    public long shiftRejected;
    public long shiftTargets;
    public final EntityState state;
    public final UdpFrameUnwrapper unwrapper = new UdpFrameUnwrapper();
    public final Map tcpScannerStates = new HashMap();
    public final Map endpointConfigurations = new HashMap();

    public RawFrameDecoder(EntityState state) {
        this.state = state;
    }

    public boolean isGameEndpoint(InetAddress address, int port) {
        return this.endpointConfigurations.containsKey(new EndpointKey(address, port));
    }

    public void accept(byte[] frame, int length) {
        int udpLength;
        if (frame == null || length < 20 || length > frame.length) {
            return;
        }
        int ihl = (frame[0] & 15) * 4;
        if ((frame[0] >>> 4) != 4 || ihl < 20 || length < ihl + 8 || (frame[9] & 255) != 17 || (udpLength = unsignedShort(frame, ihl + 4)) < 8 || ihl + udpLength > length || this.lastLearnedConfig == null) {
            return;
        }
        decodeCamera(frame, ihl + 8, udpLength - 8);
        observeLocalSlot(frame, ihl, udpLength);
    }

    public synchronized void acceptTcpPayload(PacketCaptureService.FlowKey flowKey, byte[] payload, int length) {
        if (payload != null && length >= 0) {
            try {
                if (length <= payload.length) {
                    TcpScannerState scannerState = (TcpScannerState) this.tcpScannerStates.get(flowKey);
                    if (scannerState == null) {
                        scannerState = new TcpScannerState();
                        this.tcpScannerStates.put(flowKey, scannerState);
                    }
                    byte[] data = new byte[scannerState.tail.length + length];
                    System.arraycopy(scannerState.tail, 0, data, 0, scannerState.tail.length);
                    System.arraycopy(payload, 0, data, scannerState.tail.length, length);
                    for (int index = 0; index < data.length; index++) {
                        if (index + 8 <= data.length && data[index] == -46 && data[index + 1] == 2 && data[index + 2] == 5) {
                            UdpFrameUnwrapper.Field[] order = new UdpFrameUnwrapper.Field[5];
                            for (int field = 0; field < order.length; field++) {
                                int digit = data[(index + 3) + field] - 48;
                                if (digit < 0 || digit >= order.length || contains(order, digit)) {
                                    break;
                                }
                                order[field] = UdpFrameUnwrapper.Field.values()[digit];
                            }
                            int field2 = 1;
                            int length2 = order.length;
                            for (int i = 0; i < length2; i++) {
                                UdpFrameUnwrapper.Field field3 = order[i];
                                field2 &= field3 != null ? 1 : 0;
                            }
                            if (field2 != 0) {
                                scannerState.pendingOrder = new String(data, index + 3, 5, StandardCharsets.US_ASCII);
                            }
                        }
                        if (index + 2 + 34 <= data.length && data[index] == 18) {
                            int addressLength = data[index + 1] & 255;
                            int suffix = index + 2 + addressLength;
                            if (addressLength >= 9 && addressLength <= 24 && suffix + 34 <= data.length && data[suffix] == 26 && data[suffix + 1] == 32 && isIpv4Port(data, index + 2, addressLength)) {
                                int mask = hexByte(data[suffix + 2], data[suffix + 3]);
                                if (mask >= 0 && isHex(data, suffix + 2, 32)) {
                                    scannerState.pendingMask = mask;
                                    scannerState.pendingKey = hexBytes(data, suffix + 2, 16);
                                    scannerState.pendingEndpoint = endpoint(data, index + 2, addressLength);
                                }
                            }
                        }
                    }
                    configurePending(scannerState);
                    int retained = Math.min(64, data.length);
                    scannerState.tail = Arrays.copyOfRange(data, data.length - retained, data.length);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void configurePending(TcpScannerState scannerState) {
        if (scannerState.pendingMask < 0 || scannerState.pendingKey == null || scannerState.pendingOrder == null || scannerState.pendingEndpoint == null) {
            return;
        }
        UdpFrameUnwrapper.Field[] order = new UdpFrameUnwrapper.Field[5];
        for (int field = 0; field < order.length; field++) {
            order[field] = UdpFrameUnwrapper.Field.values()[scannerState.pendingOrder.charAt(field) - '0'];
        }
        int field2 = scannerState.pendingMask;
        UdpFrameUnwrapper.Configuration configuration = UdpFrameUnwrapper.configuration(field2, scannerState.pendingKey, order);
        if (scannerState.pendingMask != scannerState.configuredMask || !Arrays.equals(scannerState.pendingKey, scannerState.configuredKey) || !scannerState.pendingOrder.equals(scannerState.configuredOrder) || !scannerState.pendingEndpoint.equals(scannerState.configuredEndpoint)) {
            scannerState.configuredMask = scannerState.pendingMask;
            scannerState.configuredKey = Arrays.copyOf(scannerState.pendingKey, scannerState.pendingKey.length);
            scannerState.configuredOrder = scannerState.pendingOrder;
            scannerState.configuredEndpoint = scannerState.pendingEndpoint;
            Log.i("RawFrameDecoder", "UDP frame configuration verified");
        }
        this.endpointConfigurations.put(scannerState.pendingEndpoint, configuration);
        this.lastLearnedConfig = configuration;
    }

    public synchronized void acceptUdpPayload(byte[] data, int length, InetAddress destinationAddress, int destinationPort) {
        Ipv4UdpPacket packet;
        if (data != null && length >= 0) {
            if (length <= data.length) {
                UdpFrameUnwrapper.Configuration configuration = (UdpFrameUnwrapper.Configuration) this.endpointConfigurations.get(new EndpointKey(destinationAddress, destinationPort));
                if (configuration == null && this.lastLearnedConfig == null) {
                    return;
                }
                decodeCamera(data, 0, length);
                this.unwrapper.recordDatagramOffered();
                if (configuration != null && length >= 20 && length <= 1024) {
                    decodeRawPositions(data, 0, length);
                }
                UdpDecodedFrame decoded = this.unwrapper.unwrap(data, 0, length, configuration);
                if (decoded == null && configuration != null && (packet = Ipv4UdpPacket.parse(data, length)) != null) {
                    decoded = this.unwrapper.unwrap(packet.payload, 0, packet.payload.length, (UdpFrameUnwrapper.Configuration) this.endpointConfigurations.get(new EndpointKey(packet.destinationAddress, packet.destinationPort)));
                }
                if (decoded != null) {
                    decodeVerified(decoded);
                }
            }
        }
    }

    public synchronized byte[] shiftUplink(byte[] data, int length, InetAddress destinationAddress, int destinationPort) {
        long[] slot;
        if (data != null && length >= 0) {
            try {
                if (length <= data.length) {
                    UdpFrameUnwrapper.Configuration configuration = (UdpFrameUnwrapper.Configuration) this.endpointConfigurations.get(new EndpointKey(destinationAddress, destinationPort));
                    if (configuration == null) {
                        return data;
                    }
                    int peekedTag = this.unwrapper.peekTag(data, 0, length, configuration);
                    if (peekedTag >= 0) {
                        LvTeamShift.observeCommand(peekedTag);
                    }
                    UdpDecodedFrame decoded = this.unwrapper.unwrap(data, 0, length, configuration);
                    if (decoded != null && decoded.tag == 2001 && (slot = readVarint(decoded.payload, 0)) != null && slot[0] > 0 && slot[0] <= 127) {
                        this.state.setLocalSlot((int) slot[0]);
                    }
                    if (!LvTeamShift.isUplinkActive()) {
                        return data;
                    }
                    if (decoded == null || (decoded.flags & 2) != 0) {
                        return data;
                    }
                    if (decoded.tag != 2001) {
                        return data;
                    }
                    byte[] shifted = LvTeamShift.transformUp(decoded.payload);
                    if (shifted == null) {
                        return data;
                    }
                    byte[] rebuilt = this.unwrapper.rebuild(data, 0, length, configuration, decoded, shifted);
                    return rebuilt != null ? rebuilt : data;
                }
            } catch (RuntimeException e) {
                return data;
            } catch (Throwable th) {
                throw th;
            }
        }
        return data;
    }

    public synchronized byte[] shiftDownlink(byte[] data, int length, InetAddress destinationAddress, int destinationPort) {
        UdpFrameUnwrapper.Configuration configuration;
        UdpDecodedFrame decoded;
        byte[] rewritten;
        byte[] shifted;
        Ipv4UdpPacket inner;
        try {
            boolean lateralActive = LateralShift.direction() != LateralShift.Direction.NONE;
            boolean lvShiftActive = LvTeamShift.isAnyActive();
            if (!lateralActive && !lvShiftActive) {
                return data;
            }
            if (data == null || length < 0 || length > data.length) {
                return data;
            }
            try {
                UdpFrameUnwrapper.Configuration configuration2 = (UdpFrameUnwrapper.Configuration) this.endpointConfigurations.get(new EndpointKey(destinationAddress, destinationPort));
                if (configuration2 == null && (configuration2 = latestConfiguration()) == null) {
                    return data;
                }
                UdpDecodedFrame decoded2 = this.unwrapper.unwrap(data, 0, length, configuration2);
                byte[] frameData = data;
                int frameOff = 0;
                int frameLen = length;
                if (decoded2 == null && (inner = Ipv4UdpPacket.parse(data, length)) != null) {
                    UdpFrameUnwrapper.Configuration configuration3 = configuration2;
                    UdpFrameUnwrapper.Configuration innerCfg = (UdpFrameUnwrapper.Configuration) this.endpointConfigurations.get(new EndpointKey(inner.destinationAddress, inner.destinationPort));
                    if (innerCfg == null) {
                        innerCfg = latestConfiguration();
                    }
                    decoded = this.unwrapper.unwrap(inner.payload, 0, inner.payload.length, innerCfg);
                    if (decoded == null) {
                        configuration = configuration3;
                    } else {
                        configuration = innerCfg;
                        frameData = inner.payload;
                        frameOff = 0;
                        frameLen = inner.payload.length;
                    }
                } else {
                    configuration = configuration2;
                    decoded = decoded2;
                }
                if (decoded != null && ((decoded.tag == 2001 || decoded.tag == 2002 || decoded.tag == 2012) && (decoded.flags & 2) == 0)) {
                    byte[] payload = decoded.payload;
                    boolean anyRewrite = false;
                    if (lvShiftActive && (shifted = LvTeamShift.transformDown(payload)) != null) {
                        payload = shifted;
                        anyRewrite = true;
                    }
                    if (lateralActive && (rewritten = rewriteShiftBatch(payload)) != null) {
                        payload = rewritten;
                        anyRewrite = true;
                    }
                    if (!anyRewrite) {
                        reportShiftTelemetry(false);
                        return data;
                    }
                    byte[] rebuilt = this.unwrapper.rebuild(frameData, frameOff, frameLen, configuration, decoded, payload);
                    if (rebuilt == null) {
                        reportShiftTelemetry(false);
                        return data;
                    }
                    if (frameData == data || (rebuilt = Ipv4UdpPacket.replacePayload(data, length, rebuilt)) != null) {
                        reportShiftTelemetry(true);
                        return rebuilt;
                    }
                    reportShiftTelemetry(false);
                    return data;
                }
                return data;
            } catch (Exception e) {
            }
        } catch (Exception e2) {
        }
        reportShiftTelemetry(false);
        return data;
    }

    public final void reportShiftTelemetry(boolean applied) {
        if (applied) {
            this.shiftApplied++;
        } else {
            this.shiftRejected++;
        }
        long now = SystemClock.elapsedRealtime();
        if (now - this.lastShiftReportAt >= 5000) {
            this.lastShiftReportAt = now;
            Log.i("RawFrameDecoder", "lateral shift packets=" + this.shiftApplied + " targets=" + this.shiftTargets + " localPreserved=" + this.shiftLocalPreserved + " rejected=" + this.shiftRejected);
            this.shiftApplied = 0L;
            this.shiftRejected = 0L;
            this.shiftTargets = 0L;
            this.shiftLocalPreserved = 0L;
        }
    }

    public final byte[] rewriteShiftBatch(byte[] body) {
        long[] leading;
        long[] encodedCount;
        long[] y;
        long[] encodedCount2;
        long[] trailing;
        int position;
        float[] forward = this.state.horizontalForward();
        if (forward == null) {
            return null;
        }
        float lateralX = -forward[1];
        float lateralZ = forward[0];
        float lateralLength = (float) Math.sqrt((lateralX * lateralX) + (lateralZ * lateralZ));
        if (!EntityState$$ExternalSyntheticBackport4.m(lateralLength) || lateralLength <= 0.05f) {
            return null;
        }
        float amount = (LateralShift.direction() == LateralShift.Direction.RIGHT || LateralShift.direction() == LateralShift.Direction.FREE) ? -5000.0f : 5000.0f;
        long deltaX = Math.round((lateralX / lateralLength) * amount);
        long deltaZ = Math.round((lateralZ / lateralLength) * amount);
        if ((deltaX == 0 && deltaZ == 0) || (leading = readVarint(body, 0)) == null || (encodedCount = readVarint(body, (int) leading[1])) == null) {
            return null;
        }
        long count = VarintReader.zigZag(encodedCount[0]);
        if (count < 0 || count > 128) {
            return null;
        }
        int position2 = (int) encodedCount[1];
        int localSlot = this.state.localSlot();
        boolean changed = false;
        ByteArrayOutputStream rewritten = new ByteArrayOutputStream(body.length + 64);
        rewritten.write(body, 0, position2);
        int targets = 0;
        int localPreserved = 0;
        int position3 = 0;
        int position4 = position2;
        while (true) {
            float lateralZ2 = lateralZ;
            float lateralLength2 = lateralLength;
            if (position3 < count) {
                if (position4 >= body.length) {
                    return null;
                }
                ByteArrayOutputStream rewritten2 = rewritten;
                int slot = body[position4] & 255;
                int recordStart = position4;
                long[] x = readVarint(body, position4 + 1);
                if (x == null || (y = readVarint(body, (int) x[1])) == null) {
                    return null;
                }
                float[] forward2 = forward;
                int index = position3;
                long[] z = readVarint(body, (int) y[1]);
                if (z == null) {
                    return null;
                }
                long[] encodedCount3 = encodedCount;
                int poseEnd = (int) z[1];
                int position5 = poseEnd;
                int field = 0;
                while (true) {
                    encodedCount2 = encodedCount3;
                    if (field < 3) {
                        long[] value = readVarint(body, position5);
                        if (value == null) {
                            return null;
                        }
                        position5 = (int) value[1];
                        field++;
                        encodedCount3 = encodedCount2;
                        poseEnd = poseEnd;
                    }
                }
                int poseEnd2 = poseEnd;
                if (position5 <= body.length - 5 && (trailing = readVarint(body, position5 + 5)) != null && trailing[1] < body.length) {
                    int position6 = ((int) trailing[1]) + 1;
                    if (localSlot >= 1 && slot == localSlot) {
                        rewritten2.write(body, recordStart, position6 - recordStart);
                        localPreserved++;
                        position = position6;
                    } else {
                        try {
                            position = position6;
                            try {
                                long shiftedX = RawFrameDecoder$$ExternalSyntheticBackport0.m(VarintReader.zigZag(x[0]), deltaX);
                                try {
                                    long shiftedZ = RawFrameDecoder$$ExternalSyntheticBackport0.m(VarintReader.zigZag(z[0]), deltaZ);
                                    rewritten2.write(slot);
                                    try {
                                        writeVarint(rewritten2, zigZagEncode(shiftedX));
                                        long shiftedX2 = y[0];
                                        writeVarint(rewritten2, shiftedX2);
                                        writeVarint(rewritten2, zigZagEncode(shiftedZ));
                                        try {
                                            rewritten2.write(body, poseEnd2, position - poseEnd2);
                                            targets++;
                                            changed = true;
                                        } catch (ArithmeticException e) {
                                            return null;
                                        }
                                    } catch (ArithmeticException e2) {
                                        return null;
                                    }
                                } catch (ArithmeticException e3) {
                                    return null;
                                }
                            } catch (ArithmeticException e4) {
                                return null;
                            }
                        } catch (ArithmeticException e5) {
                            return null;
                        }
                    }
                    position3 = index + 1;
                    rewritten = rewritten2;
                    lateralZ = lateralZ2;
                    position4 = position;
                    lateralLength = lateralLength2;
                    encodedCount = encodedCount2;
                    forward = forward2;
                    amount = amount;
                }
                return null;
            }
            ByteArrayOutputStream rewritten3 = rewritten;
            int targets2 = targets;
            long[] tail = readVarint(body, position4);
            if (tail == null || tail[1] != body.length || !changed) {
                return null;
            }
            rewritten3.write(body, position4, body.length - position4);
            this.shiftTargets += (long) targets2;
            this.shiftLocalPreserved += (long) localPreserved;
            return rewritten3.toByteArray();
        }
    }

    public final void observeLocalSlot(byte[] packet, int ipHeaderLength, int udpLength) {
        long[] slot;
        try {
            InetAddress destination = InetAddress.getByAddress(Arrays.copyOfRange(packet, 16, 20));
            int destinationPort = unsignedShort(packet, ipHeaderLength + 2);
            UdpFrameUnwrapper.Configuration configuration = (UdpFrameUnwrapper.Configuration) this.endpointConfigurations.get(new EndpointKey(destination, destinationPort));
            if (configuration == null) {
                configuration = latestConfiguration();
            }
            if (configuration == null) {
                return;
            }
            int payloadOff = ipHeaderLength + 8;
            int payloadLen = udpLength - 8;
            int peekedTag = this.unwrapper.peekTag(packet, payloadOff, payloadLen, configuration);
            if (peekedTag >= 0) {
                LvTeamShift.observeCommand(peekedTag);
            }
            UdpDecodedFrame frame = this.unwrapper.unwrap(packet, payloadOff, payloadLen, configuration);
            if (frame != null && frame.tag == 2001 && (slot = readVarint(frame.payload, 0)) != null && slot[0] > 0 && slot[0] <= 127) {
                this.state.setLocalSlot((int) slot[0]);
            }
        } catch (RuntimeException e) {
        } catch (UnknownHostException e2) {
        }
    }

    public final UdpFrameUnwrapper.Configuration latestConfiguration() {
        return this.lastLearnedConfig;
    }

    public static long[] readVarint(byte[] data, int position) {
        if (position < 0 || position >= data.length) {
            return null;
        }
        long value = 0;
        int shift = 0;
        while (shift < 64 && position != data.length) {
            int position2 = position + 1;
            int next = data[position] & 255;
            value |= ((long) (next & 127)) << shift;
            if ((next & 128) == 0) {
                return new long[]{value, position2};
            }
            shift += 7;
            position = position2;
        }
        return null;
    }

    public static void writeVarint(ByteArrayOutputStream output, long value) {
        while (((-128) & value) != 0) {
            output.write(((int) (127 & value)) | 128);
            value >>>= 7;
        }
        output.write((int) value);
    }

    public static long zigZagEncode(long value) {
        return (value << 1) ^ (value >> 63);
    }

    public final void decodeRawPositions(byte[] data, int offset, int length) {
        boolean accepted = decodeRawPrimary(data, offset, length);
        if (accepted) {
            this.rawPositionsAccepted++;
        } else {
            this.rawPositionsMalformed++;
        }
        reportRawTelemetryIfDue();
    }

    public final boolean decodeRawPrimary(byte[] data, int offset, int length) {
        RawCursor cursor;
        RawFrameDecoder rawFrameDecoder = this;
        int end = offset + length;
        if ((data[offset + 8] & 255) != 0) {
            return false;
        }
        int encodedCount = data[offset + 9] & 255;
        if ((encodedCount & 1) != 0) {
            return false;
        }
        int count = encodedCount / 2;
        int i = 1;
        if (count >= 1) {
            int i2 = 64;
            if (count <= 64) {
                if (length < (count * 16) + 10) {
                    return false;
                }
                try {
                    RawCursor cursor2 = new RawCursor(data, offset + 8, end);
                    int[] slots = new int[count];
                    float[] xs = new float[count];
                    float[] ys = new float[count];
                    float[] zs = new float[count];
                    cursor2.readUnsigned();
                    cursor2.readUnsigned();
                    int index = 0;
                    while (index < count) {
                        int encodedCount2 = encodedCount;
                        try {
                            int slot = (int) cursor2.readUnsigned();
                            if (slot >= i && slot <= i2) {
                                try {
                                    float x = VarintReader.zigZag(cursor2.readUnsigned());
                                    int count2 = count;
                                    try {
                                        float y = VarintReader.zigZag(cursor2.readUnsigned());
                                        RawCursor cursor3 = cursor2;
                                        float z = VarintReader.zigZag(cursor2.readUnsigned());
                                        if (!isSaneCoordinate(x) || !isSaneCoordinate(y)) {
                                            return false;
                                        }
                                        if (!isSaneCoordinate(z)) {
                                            return false;
                                        }
                                        try {
                                            if (slot == this.state.localSlot()) {
                                                for (int field = 0; field < 16; field++) {
                                                    cursor3.readUnsigned();
                                                }
                                                cursor = cursor3;
                                            } else {
                                                for (int field2 = 0; field2 < 3; field2++) {
                                                    cursor3.readUnsigned();
                                                }
                                                cursor = cursor3;
                                                cursor.skip(3);
                                                for (int field3 = 0; field3 < 4; field3++) {
                                                    cursor.readUnsigned();
                                                }
                                            }
                                            slots[index] = slot;
                                            xs[index] = x;
                                            ys[index] = y;
                                            zs[index] = z;
                                            index++;
                                            encodedCount = encodedCount2;
                                            i = 1;
                                            i2 = 64;
                                            RawCursor rawCursor = cursor;
                                            count = count2;
                                            rawFrameDecoder = this;
                                            cursor2 = rawCursor;
                                        } catch (IllegalArgumentException e) {
                                            return false;
                                        }
                                    } catch (IllegalArgumentException e2) {
                                        return false;
                                    }
                                } catch (IllegalArgumentException e3) {
                                    return false;
                                }
                            }
                            return false;
                        } catch (IllegalArgumentException e4) {
                        }
                    }
                    RawCursor cursor4 = cursor2;
                    RawFrameDecoder rawFrameDecoder2 = rawFrameDecoder;
                    int count3 = count;
                    int trailing = end - cursor4.position();
                    if (trailing < 1 || trailing > 3) {
                        return false;
                    }
                    for (int index2 = 0; index2 < count3; index2++) {
                        rawFrameDecoder2.state.updatePosition(slots[index2], xs[index2], ys[index2], zs[index2]);
                    }
                    return true;
                } catch (IllegalArgumentException e5) {
                    return false;
                }
            }
        }
        return false;
    }

    public final void reportRawTelemetryIfDue() {
        long now = SystemClock.elapsedRealtime();
        if (now - this.rawTelemetryAt < 5000) {
            return;
        }
        Log.i("RawFrameDecoder", "raw positions accepted=" + this.rawPositionsAccepted + " malformed=" + this.rawPositionsMalformed);
        this.rawPositionsAccepted = 0L;
        this.rawPositionsMalformed = 0L;
        this.rawTelemetryAt = now;
    }

    public static boolean isSaneCoordinate(float value) {
        return (Float.isNaN(value) || Float.isInfinite(value) || Math.abs(value) > 1000000.0f) ? false : true;
    }

    public final void decodeVerified(UdpDecodedFrame frame) {
        try {
            Cursor cursor = new Cursor(frame.payload);
            switch (frame.tag) {
                case 101:
                    cursor.readUnsigned();
                    cursor.readUnsigned();
                    this.state.putName((int) cursor.readUnsigned(), cursor.readString());
                    break;
                case 102:
                    this.state.removeName((int) cursor.readUnsigned());
                    break;
                case 107:
                case 139:
                    cursor.readUnsigned();
                    this.state.putName((int) cursor.readUnsigned(), cursor.readString());
                    break;
                case 125:
                    decodeRelation(cursor, true);
                    break;
                case 126:
                    decodeRelation(cursor, false);
                    break;
                case 2002:
                    decodePositions(cursor);
                    break;
            }
        } catch (IllegalArgumentException e) {
        }
    }

    public final void decodeRelation(Cursor cursor, boolean install) {
        long relation = cursor.readUnsigned();
        int entityId = (int) cursor.readUnsigned();
        int slot = ((int) relation) & 255;
        int team = (int) ((relation >>> 8) & 255);
        if (team == 0) {
            team = (int) ((relation >>> 16) & 255);
        }
        if (team == 0) {
            team = (int) (relation >>> 24);
        }
        if (!install) {
            this.state.removeRelation(entityId, slot);
        } else {
            this.state.installRelation(entityId, slot, team);
        }
    }

    public final void decodePositions(Cursor cursor) {
        try {
            cursor.readUnsigned();
            long encodedCount = cursor.readUnsigned();
            long decodedCount = VarintReader.zigZag(encodedCount);
            if (decodedCount < 0 || decodedCount > 128) {
                throw new IllegalArgumentException("Invalid position count");
            }
            int count = (int) decodedCount;
            for (int index = 0; index < count; index++) {
                int slot = cursor.readByte();
                float x = cursor.readZigZag();
                float y = cursor.readZigZag();
                float z = cursor.readZigZag();
                cursor.readUnsigned();
                cursor.readUnsigned();
                cursor.readUnsigned();
                for (int field = 0; field < 5; field++) {
                    cursor.readByte();
                }
                cursor.readUnsigned();
                cursor.readByte();
                this.state.updatePosition(slot, x, y, z);
            }
            cursor.readUnsigned();
            cursor.requireEnd();
        } catch (IllegalArgumentException e) {
        }
    }

    public final void decodeCamera(byte[] data, int offset, int length) {
        if (length < 32 || length > 96 || offset + length > data.length || (data[offset + 9] & 255) != 128 || (data[offset + 10] & 255) != 128 || (data[offset + 8] & 128) == 0) {
            return;
        }
        VarintReader reader = new VarintReader(slice(data, offset + 8, length - 8));
        try {
            reader.readUnsigned();
            ArrayList<Long> values = new ArrayList<>(23);
            while (reader.hasRemaining()) {
                values.add(Long.valueOf(reader.readUnsigned()));
            }
            if (values.size() != 23) {
                return;
            }
            float x = VarintReader.zigZag(values.get(0).longValue());
            float y = VarintReader.zigZag(values.get(1).longValue());
            float z = VarintReader.zigZag(values.get(2).longValue());
            float directionX = Float.intBitsToFloat(values.get(13).intValue());
            float directionY = Float.intBitsToFloat(values.get(14).intValue());
            float directionZ = Float.intBitsToFloat(values.get(15).intValue());
            this.state.updateCamera(x, y, z, directionX, directionY, directionZ);
        } catch (IllegalArgumentException e) {
        }
    }

    public static boolean isIpv4Port(byte[] data, int offset, int length) {
        int end = offset + length;
        int value = 0;
        int digits = 0;
        int dots = 0;
        boolean port = false;
        int index = offset;
        while (true) {
            if (index >= end) {
                return port && dots == 3 && digits > 0;
            }
            int character = data[index] & 255;
            if (character >= 48 && character <= 57) {
                int value2 = ((value * 10) + character) - 48;
                digits++;
                if (digits <= (port ? 5 : 3)) {
                    if (value2 <= (port ? 65535 : 255)) {
                        value = value2;
                    }
                }
                return false;
            }
            if (!port && character == 46 && digits > 0 && (dots = dots + 1) <= 3) {
                value = 0;
                digits = 0;
            } else {
                if (port || character != 58 || dots != 3 || digits <= 0) {
                    return false;
                }
                port = true;
                value = 0;
                digits = 0;
            }
            index++;
        }
    }

    public static EndpointKey endpoint(byte[] data, int offset, int length) {
        String value = new String(data, offset, length, StandardCharsets.US_ASCII);
        int separator = value.lastIndexOf(58);
        try {
            return new EndpointKey(InetAddress.getByName(value.substring(0, separator)), Integer.parseInt(value.substring(separator + 1)));
        } catch (NumberFormatException | UnknownHostException e) {
            return null;
        }
    }

    public static final class TcpScannerState {
        public EndpointKey configuredEndpoint;
        public byte[] configuredKey;
        public int configuredMask;
        public String configuredOrder;
        public EndpointKey pendingEndpoint;
        public byte[] pendingKey;
        public int pendingMask;
        public String pendingOrder;
        public byte[] tail;

        public TcpScannerState() {
            this.tail = new byte[0];
            this.pendingMask = -1;
            this.configuredMask = -1;
        }
    }

    public static final class EndpointKey {
        public final InetAddress address;
        public final int port;

        public EndpointKey(InetAddress address, int port) {
            this.address = address;
            this.port = port;
        }

        public boolean equals(Object other) {
            if (!(other instanceof EndpointKey)) {
                return false;
            }
            EndpointKey that = (EndpointKey) other;
            return this.port == that.port && this.address.equals(that.address);
        }

        public int hashCode() {
            return (this.address.hashCode() * 31) + this.port;
        }
    }

    public static boolean contains(UdpFrameUnwrapper.Field[] fields, int ordinal) {
        for (UdpFrameUnwrapper.Field field : fields) {
            if (field != null && field.ordinal() == ordinal) {
                return true;
            }
        }
        return false;
    }

    public static boolean isHex(byte[] data, int offset, int length) {
        for (int index = offset; index < offset + length; index++) {
            if (hex(data[index]) < 0) {
                return false;
            }
        }
        return true;
    }

    public static int hexByte(byte high, byte low) {
        int highValue = hex(high);
        int lowValue = hex(low);
        if (highValue < 0 || lowValue < 0) {
            return -1;
        }
        return (highValue << 4) | lowValue;
    }

    public static byte[] hexBytes(byte[] data, int offset, int length) {
        byte[] bytes = new byte[length];
        for (int index = 0; index < length; index++) {
            bytes[index] = (byte) hexByte(data[(index * 2) + offset], data[(index * 2) + offset + 1]);
        }
        return bytes;
    }

    public static int hex(byte value) {
        int character = value & 255;
        if (character >= 48 && character <= 57) {
            return character - 48;
        }
        if (character >= 65 && character <= 70) {
            return (character - 65) + 10;
        }
        if (character < 97 || character > 102) {
            return -1;
        }
        return (character - 97) + 10;
    }

    public static byte[] slice(byte[] source, int offset, int length) {
        byte[] result = new byte[length];
        System.arraycopy(source, offset, result, 0, length);
        return result;
    }

    public static int unsignedShort(byte[] data, int offset) {
        return ((data[offset] & 255) << 8) | (data[offset + 1] & 255);
    }

    public static final class Cursor {
        public final byte[] bytes;
        public int position;

        public Cursor(byte[] bytes) {
            this.bytes = bytes;
        }

        public long readUnsigned() {
            long value = 0;
            for (int shift = 0; shift < 64; shift += 7) {
                if (this.position == this.bytes.length) {
                    throw new IllegalArgumentException("Truncated varint");
                }
                byte[] bArr = this.bytes;
                int i = this.position;
                this.position = i + 1;
                int next = bArr[i] & 255;
                value |= ((long) (next & 127)) << shift;
                if ((next & 128) == 0) {
                    return value;
                }
            }
            throw new IllegalArgumentException("Malformed varint");
        }

        public float readZigZag() {
            return VarintReader.zigZag(readUnsigned());
        }

        public int readByte() {
            if (this.position == this.bytes.length) {
                throw new IllegalArgumentException("Truncated byte");
            }
            byte[] bArr = this.bytes;
            int i = this.position;
            this.position = i + 1;
            return bArr[i] & 255;
        }

        public String readString() {
            long encodedLength = readUnsigned();
            long length = VarintReader.zigZag(encodedLength);
            if (length < 0 || length > 64 || this.position > ((long) this.bytes.length) - length) {
                throw new IllegalArgumentException("Invalid string");
            }
            String value = new String(this.bytes, this.position, (int) length, StandardCharsets.UTF_8);
            this.position += (int) length;
            return value;
        }

        public void requireEnd() {
            if (this.position != this.bytes.length) {
                throw new IllegalArgumentException("Trailing data");
            }
        }
    }

    public static final class RawCursor {
        public final byte[] bytes;
        public final int end;
        public int position;

        public RawCursor(byte[] bytes, int position, int end) {
            this.bytes = bytes;
            this.position = position;
            this.end = end;
        }

        public long readUnsigned() {
            long value = 0;
            for (int shift = 0; shift < 64; shift += 7) {
                if (this.position == this.end) {
                    throw new IllegalArgumentException("Truncated varint");
                }
                byte[] bArr = this.bytes;
                int i = this.position;
                this.position = i + 1;
                int next = bArr[i] & 255;
                value |= ((long) (next & 127)) << shift;
                if ((next & 128) == 0) {
                    return value;
                }
            }
            throw new IllegalArgumentException("Malformed varint");
        }

        public void skip(int count) {
            if (count < 0 || this.position > this.end - count) {
                throw new IllegalArgumentException("Truncated bytes");
            }
            this.position += count;
        }

        public int position() {
            return this.position;
        }
    }
}
