package com.lvteam;

import android.os.SystemClock;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.BiFunction;
import java.util.function.Predicate;

/* JADX INFO: loaded from: classes.dex */
public final class EntityState {
    public static final EntityState SHARED = new EntityState();
    public volatile boolean cameraValid;
    public volatile float cameraX;
    public volatile float cameraY;
    public volatile float cameraZ;
    public volatile float forwardX;
    public volatile float forwardY;
    public long lastPruneAt;
    public long lastSweepAt;
    public final Map entities = new ConcurrentHashMap();
    public final Map names = new ConcurrentHashMap();
    public final Map slotToEntity = new ConcurrentHashMap();
    public final Map entityToSlot = new ConcurrentHashMap();
    public final Map slotTeams = new ConcurrentHashMap();
    public final Map rawSlotPositions = new ConcurrentHashMap();
    public final HashSet publishedIds = new HashSet();
    public volatile int localSlot = -1;
    public volatile float forwardZ = 1.0f;

    public static EntityState shared() {
        return SHARED;
    }

    public void updateCamera(float x, float y, float z, float forwardX, float forwardY, float forwardZ) {
        float directionLength = (float) Math.sqrt((forwardX * forwardX) + (forwardY * forwardY) + (forwardZ * forwardZ));
        if (!EntityState$$ExternalSyntheticBackport4.m(x) || !EntityState$$ExternalSyntheticBackport4.m(y) || !EntityState$$ExternalSyntheticBackport4.m(z) || !EntityState$$ExternalSyntheticBackport4.m(directionLength) || directionLength < 0.1f) {
            return;
        }
        this.cameraX = x;
        this.cameraY = y;
        this.cameraZ = z;
        this.forwardX = forwardX;
        this.forwardY = forwardY;
        this.forwardZ = forwardZ;
        this.cameraValid = true;
        LvTeamShift.setDir(forwardX, forwardZ);
        LvTeamShift.setDir3D(forwardX, forwardY, forwardZ);
        LvTeamShift.localX = x;
        LvTeamShift.localY = y;
        LvTeamShift.localZ = z;
        LvTeamShift.localTs = System.currentTimeMillis();
    }

    public void putName(int entityId, final String name) {
        if (name == null || name.isEmpty()) {
            return;
        }
        int id = 16777215 & entityId;
        this.names.put(Integer.valueOf(id), name);
        this.entities.computeIfPresent(Integer.valueOf(id), new BiFunction() { // from class: com.lvteam.EntityState$$ExternalSyntheticLambda8
            @Override // java.util.function.BiFunction
            public final Object apply(Object obj, Object obj2) {
                return EntityState.lambda$putName$0(name, (Integer) obj, (EntityState.Record) obj2);
            }
        });
    }

    public static /* synthetic */ Record lambda$putName$0(String name, Integer key, Record record) {
        return record.withName(name);
    }

    public void removeName(int entityId) {
        int id = 16777215 & entityId;
        this.names.remove(Integer.valueOf(id));
        this.entities.computeIfPresent(Integer.valueOf(id), new BiFunction() { // from class: com.lvteam.EntityState$$ExternalSyntheticLambda9
            @Override // java.util.function.BiFunction
            public final Object apply(Object obj, Object obj2) {
                return EntityState.lambda$removeName$1((Integer) obj, (EntityState.Record) obj2);
            }
        });
    }

    public static /* synthetic */ Record lambda$removeName$1(Integer key, Record record) {
        return record.withName(null);
    }

    public void installRelation(int entityId, final int slot, final int team) {
        final int id = entityId & 16777215;
        if (slot < 1 || slot > 127 || id == 0) {
            return;
        }
        Integer previousEntity = (Integer) this.slotToEntity.put(Integer.valueOf(slot), Integer.valueOf(id));
        if (previousEntity != null && previousEntity.intValue() != id) {
            this.entityToSlot.remove(previousEntity, Integer.valueOf(slot));
        }
        Integer previousSlot = (Integer) this.entityToSlot.put(Integer.valueOf(id), Integer.valueOf(slot));
        if (previousSlot != null && previousSlot.intValue() != slot) {
            this.slotToEntity.remove(previousSlot, Integer.valueOf(id));
        }
        this.slotTeams.put(Integer.valueOf(slot), Integer.valueOf(team));
        final Position position = (Position) this.rawSlotPositions.remove(Integer.valueOf(slot));
        final boolean local = slot == this.localSlot;
        this.entities.compute(Integer.valueOf(id), new BiFunction() { // from class: com.lvteam.EntityState$$ExternalSyntheticLambda10
            @Override // java.util.function.BiFunction
            public final Object apply(Object obj, Object obj2) {
                return this.f$0.lambda$installRelation$2(id, position, local, slot, team, (Integer) obj, (EntityState.Record) obj2);
            }
        });
    }

    public final /* synthetic */ Record lambda$installRelation$2(int id, Position position, boolean local, int slot, int team, Integer key, Record record) {
        if (record != null) {
            return record.withMetadata((String) this.names.get(Integer.valueOf(id)), local, isAlly(slot, Integer.valueOf(team)), Integer.valueOf(team));
        }
        return new Record(id, (String) this.names.get(Integer.valueOf(id)), position == null ? 0.0f : position.x, position == null ? 0.0f : position.y, position != null ? position.z : 0.0f, Float.NaN, local, isAlly(slot, Integer.valueOf(team)), team, position == null ? 0L : position.updatedAt);
    }

    public void removeRelation(int entityId, int slot) {
        int id = 16777215 & entityId;
        if (slot < 1 || slot > 127 || !this.slotToEntity.remove(Integer.valueOf(slot), Integer.valueOf(id))) {
            return;
        }
        this.slotTeams.remove(Integer.valueOf(slot));
        this.entityToSlot.remove(Integer.valueOf(id), Integer.valueOf(slot));
        this.entities.remove(Integer.valueOf(id));
    }

    public int updatePosition(int slot, final float x, final float y, final float z) {
        if (slot < 1 || slot > 127) {
            return -1;
        }
        Integer id = (Integer) this.slotToEntity.get(Integer.valueOf(slot));
        final long now = SystemClock.elapsedRealtime();
        if (id == null || !Integer.valueOf(slot).equals(this.entityToSlot.get(id))) {
            this.rawSlotPositions.compute(Integer.valueOf(slot), new BiFunction() { // from class: com.lvteam.EntityState$$ExternalSyntheticLambda6
                @Override // java.util.function.BiFunction
                public final Object apply(Object obj, Object obj2) {
                    return EntityState.lambda$updatePosition$3(x, y, z, now, (Integer) obj, (EntityState.Position) obj2);
                }
            });
            return -1;
        }
        this.entities.computeIfPresent(id, new BiFunction() { // from class: com.lvteam.EntityState$$ExternalSyntheticLambda7
            @Override // java.util.function.BiFunction
            public final Object apply(Object obj, Object obj2) {
                return EntityState.lambda$updatePosition$4(x, y, z, now, (Integer) obj, (EntityState.Record) obj2);
            }
        });
        return id.intValue();
    }

    public static /* synthetic */ Position lambda$updatePosition$3(float x, float y, float z, long now, Integer key, Position position) {
        return (position == null || isPlausibleMove(position.x, position.y, position.z, position.updatedAt, x, y, z, now)) ? new Position(x, y, z, now) : position;
    }

    public static /* synthetic */ Record lambda$updatePosition$4(float x, float y, float z, long now, Integer key, Record record) {
        if (!isPlausibleMove(record.x, record.y, record.z, record.updatedAt, x, y, z, now)) {
            return record;
        }
        return record.withPosition(x, y, z, now);
    }

    public void setLocalSlot(final int slot) {
        this.localSlot = slot;
        for (Map.Entry<Integer, Integer> entry : this.entityToSlot.entrySet()) {
            int entityId = entry.getKey().intValue();
            final int entitySlot = entry.getValue().intValue();
            this.entities.computeIfPresent(Integer.valueOf(entityId), new BiFunction() { // from class: com.lvteam.EntityState$$ExternalSyntheticLambda5
                @Override // java.util.function.BiFunction
                public final Object apply(Object obj, Object obj2) {
                    return this.f$0.lambda$setLocalSlot$5(entitySlot, slot, (Integer) obj, (EntityState.Record) obj2);
                }
            });
        }
    }

    public final /* synthetic */ Record lambda$setLocalSlot$5(int entitySlot, int slot, Integer key, Record record) {
        return record.withMetadata(record.name, entitySlot == slot, isAlly(entitySlot, (Integer) this.slotTeams.get(Integer.valueOf(entitySlot))), (Integer) this.slotTeams.get(Integer.valueOf(entitySlot)));
    }

    public int localSlot() {
        return this.localSlot;
    }

    public float[] horizontalForward() {
        float x = this.forwardX;
        float z = this.forwardZ;
        if (!EntityState$$ExternalSyntheticBackport4.m(x) || !EntityState$$ExternalSyntheticBackport4.m(z) || Math.sqrt((x * x) + (z * z)) <= 0.05000000074505806d) {
            return null;
        }
        return new float[]{x, z};
    }

    public void publishTo(EspEngine engine) {
        pruneStalePositions();
        if (this.cameraValid) {
            engine.updateCamera(this.cameraX, this.cameraY, this.cameraZ, this.forwardX, this.forwardY, this.forwardZ, 70.0f);
            long now = SystemClock.elapsedRealtime();
            boolean sweep = now - this.lastSweepAt >= 400;
            if (sweep) {
                this.lastSweepAt = now;
                this.publishedIds.clear();
            }
            Iterator it = this.entities.values().iterator();
            while (it.hasNext()) {
                Record record = (Record) it.next();
                Integer slot = (Integer) this.entityToSlot.get(Integer.valueOf(record.id));
                if (record.updatedAt != 0) {
                    int id = slot == null ? record.id : renderId(slot.intValue());
                    Iterator it2 = it;
                    boolean live = publish(engine, id, record.name, record.x, record.y, record.z, record.health, record.local, record.ally, record.updatedAt);
                    if (sweep && live) {
                        this.publishedIds.add(Integer.valueOf(id));
                    }
                    it = it2;
                }
            }
            int ls = this.localSlot;
            Integer localTeam = ls >= 1 ? (Integer) this.slotTeams.get(Integer.valueOf(ls)) : null;
            long rawCutoff = SystemClock.elapsedRealtime() - 3000;
            for (Map.Entry<Integer, Position> entry : this.rawSlotPositions.entrySet()) {
                int slot2 = entry.getKey().intValue();
                if (slot2 != ls && (localTeam == null || localTeam.intValue() == 0 || !localTeam.equals(this.slotTeams.get(Integer.valueOf(slot2))))) {
                    Position position = entry.getValue();
                    if (position.updatedAt >= rawCutoff) {
                        int id2 = renderId(slot2);
                        long now2 = now;
                        boolean live2 = publish(engine, id2, null, position.x, position.y, position.z, Float.NaN, false, false, position.updatedAt);
                        if (sweep && live2) {
                            this.publishedIds.add(Integer.valueOf(id2));
                        }
                        now = now2;
                    }
                }
            }
            if (sweep) {
                engine.retainOnly(this.publishedIds);
                return;
            }
            return;
        }
        engine.clearCamera();
    }

    public static boolean publish(EspEngine engine, int id, String name, float x, float y, float z, float health, boolean local, boolean ally, long updatedAt) {
        if (SystemClock.elapsedRealtime() - updatedAt > 8000) {
            return false;
        }
        engine.updateEntity(id, name, x, y, z, 1750.0f, Float.isNaN(health) ? Float.NaN : health / 200.0f, local, ally, updatedAt);
        return (local || ally) ? false : true;
    }

    public final void pruneStalePositions() {
        final long now = SystemClock.elapsedRealtime();
        if (now - this.lastPruneAt < 5000) {
            return;
        }
        this.lastPruneAt = now;
        this.rawSlotPositions.entrySet().removeIf(new Predicate() { // from class: com.lvteam.EntityState$$ExternalSyntheticLambda11
            @Override // java.util.function.Predicate
            public final boolean test(Object obj) {
                return EntityState.lambda$pruneStalePositions$6(now, (Map.Entry) obj);
            }
        });
    }

    public static /* synthetic */ boolean lambda$pruneStalePositions$6(long now, Map.Entry entry) {
        return now - ((Position) entry.getValue()).updatedAt > 3000;
    }

    public static int renderId(int slot) {
        return 16777216 | slot;
    }

    public static int slotOfRenderId(int id) {
        if (((-16777216) & id) == 16777216) {
            return id & 255;
        }
        return -1;
    }

    public final boolean isAlly(int slot, Integer team) {
        Integer localTeam = (Integer) this.slotTeams.get(Integer.valueOf(this.localSlot));
        return (slot == this.localSlot || team == null || team.intValue() == 0 || !team.equals(localTeam)) ? false : true;
    }

    public static boolean isPlausibleMove(float fromX, float fromY, float fromZ, long previousAt, float x, float y, float z, long now) {
        if (previousAt == 0) {
            return true;
        }
        float dx = x - fromX;
        float dy = y - fromY;
        float dz = z - fromZ;
        float travelled = (float) Math.sqrt((dx * dx) + (dy * dy) + (dz * dz));
        long elapsed = Math.max(1L, now - previousAt);
        return travelled <= ((((float) elapsed) * 60000.0f) / 1000.0f) + 5000.0f;
    }

    public static final class Record {
        public final boolean ally;
        public final float health;
        public final int id;
        public final boolean local;
        public final String name;
        public final int team;
        public final long updatedAt;
        public final float x;
        public final float y;
        public final float z;

        public Record(int id, String name, float x, float y, float z, float health, boolean local, boolean ally, int team, long updatedAt) {
            this.id = id;
            this.name = name;
            this.x = x;
            this.y = y;
            this.z = z;
            this.health = health;
            this.local = local;
            this.ally = ally;
            this.team = team;
            this.updatedAt = updatedAt;
        }

        public Record withName(String name) {
            return new Record(this.id, name, this.x, this.y, this.z, this.health, this.local, this.ally, this.team, this.updatedAt);
        }

        public Record withPosition(float x, float y, float z, long updatedAt) {
            return new Record(this.id, this.name, x, y, z, this.health, this.local, this.ally, this.team, updatedAt);
        }

        public Record withMetadata(String name, boolean local, boolean ally, Integer team) {
            return new Record(this.id, name == null ? this.name : name, this.x, this.y, this.z, this.health, local, ally, team == null ? this.team : team.intValue(), this.updatedAt);
        }
    }

    public static final class Position {
        public final long updatedAt;
        public final float x;
        public final float y;
        public final float z;

        public Position(float x, float y, float z, long updatedAt) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.updatedAt = updatedAt;
        }
    }
}
