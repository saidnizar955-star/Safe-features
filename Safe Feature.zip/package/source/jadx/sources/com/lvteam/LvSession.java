package com.lvteam;

import java.security.MessageDigest;

/* JADX INFO: loaded from: classes.dex */
public final class LvSession {
    public static final LvSession INSTANCE = new LvSession();
    public volatile long activationTime;
    public volatile int authDays;
    public volatile long authTimestamp;
    public volatile String authToken;

    public static LvSession get() {
        return INSTANCE;
    }

    public void activate(String key, int days, String serverResponse) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(key.getBytes("UTF-8"));
            md.update(serverResponse.getBytes("UTF-8"));
            md.update(String.valueOf(System.currentTimeMillis()).getBytes("UTF-8"));
            byte[] hash = md.digest();
            StringBuilder sb = new StringBuilder();
            for (byte b : hash) {
                sb.append(String.format("%02x", Byte.valueOf(b)));
            }
            this.authToken = sb.toString();
            this.authTimestamp = System.currentTimeMillis();
            this.activationTime = System.currentTimeMillis();
            this.authDays = days;
        } catch (Exception e) {
            this.authToken = null;
        }
    }

    public void invalidate() {
        this.authToken = null;
        this.authTimestamp = 0L;
        this.authDays = 0;
    }

    public boolean isActive() {
        if (this.authToken == null) {
            return false;
        }
        if (System.currentTimeMillis() - this.authTimestamp > 43200000) {
            invalidate();
            return false;
        }
        if (this.authDays > 0 && this.activationTime > 0) {
            long elapsed = System.currentTimeMillis() - this.activationTime;
            if (elapsed > ((long) this.authDays) * 24 * 60 * 60 * 1000) {
                invalidate();
                return false;
            }
            return true;
        }
        return true;
    }
}
