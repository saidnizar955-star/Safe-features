package com.lvteam;

/* JADX INFO: loaded from: classes.dex */
public abstract class LateralShift {
    public static volatile Direction direction = Direction.NONE;

    public enum Direction {
        NONE,
        LEFT,
        RIGHT,
        FREE
    }

    public static Direction direction() {
        return direction;
    }
}
