package com.lvteam;

/* JADX INFO: loaded from: classes.dex */
public abstract class SslPinning {
    public static boolean isProxySet() {
        try {
            String host = System.getProperty("http.proxyHost");
            System.getProperty("http.proxyPort");
            if (host != null && !host.isEmpty()) {
                return true;
            }
            String host2 = System.getProperty("https.proxyHost");
            if (host2 != null && !host2.isEmpty()) {
                return true;
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }
}
