package com.lvteam;

import android.content.Context;
import android.graphics.Point;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.ToneGenerator;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

/* JADX INFO: loaded from: classes.dex */
public abstract class LvShiftOverlay {
    public static Context ctx;
    public static float density;
    public static volatile boolean wantGhost;
    public static volatile boolean wantMagnet;
    public static volatile boolean wantTatu;
    public static volatile boolean wantTpBase;
    public static volatile boolean wantWall;
    public static WindowManager wm;
    public static final int[] COL = {0, -1, 1, 0, 1};
    public static final int[] ROW = {-1, 0, 0, 1, 1};
    public static final TextView[] btns = new TextView[5];
    public static final WindowManager.LayoutParams[] lps = new WindowManager.LayoutParams[5];
    public static final GradientDrawable[] bgs = new GradientDrawable[5];
    public static final boolean[] active = new boolean[5];
    public static final String[] LABELS = {"🧲", "👻", "🦔", "⚡", "🧱"};

    public static void init(Context c) {
        ctx = c.getApplicationContext();
        wm = (WindowManager) ctx.getSystemService("window");
        density = ctx.getResources().getDisplayMetrics().density;
        for (int i = 0; i < 5; i++) {
            hideBtn(i);
            setActive(i, false);
        }
        for (int i2 = 0; i2 < 5; i2++) {
            if (wanted(i2)) {
                showBtn(i2);
            }
        }
    }

    public static void setMagnetVisible(boolean on) {
        wantMagnet = on;
        setVisible(0, on);
    }

    public static void setGhostVisible(boolean on) {
        wantGhost = on;
        setVisible(1, on);
    }

    public static void setTatuVisible(boolean on) {
        wantTatu = on;
        setVisible(2, on);
    }

    public static void setTpBaseVisible(boolean on) {
        wantTpBase = on;
        setVisible(3, on);
    }

    public static void setWallVisible(boolean on) {
        wantWall = on;
        setVisible(4, on);
    }

    public static boolean wanted(int id) {
        switch (id) {
            case 0:
                return wantMagnet;
            case 1:
                return wantGhost;
            case 2:
                return wantTatu;
            case 3:
                return wantTpBase;
            case 4:
                return wantWall;
            default:
                return false;
        }
    }

    public static void setVisible(int id, boolean on) {
        if (!on) {
            setActive(id, false);
        }
        if (ctx == null) {
            return;
        }
        if (on) {
            showBtn(id);
        } else {
            hideBtn(id);
        }
    }

    public static void setActive(int id, boolean on) {
        active[id] = on;
        switch (id) {
            case 0:
                LvTeamShift.magnetOn = on;
                break;
            case 1:
                LvTeamShift.setLocalFreeze(on);
                break;
            case 2:
                LvTeamShift.setTatu(on);
                break;
            case 3:
                LvTeamShift.setTeleportBase(on);
                break;
            case 4:
                LvTeamShift.setWallPass(on);
                break;
        }
    }

    public static void showBtn(int id) {
        if (ctx == null || wm == null || btns[id] != null) {
            return;
        }
        boolean wide = id == 0 || id == 2 || id == 3 || id == 4;
        int size = dp(wide ? 68 : 58);
        TextView tv = new TextView(ctx);
        tv.setTextColor(-1);
        tv.setTextSize(2, wide ? 11.0f : 18.0f);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setGravity(17);
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(2), -10432513);
        tv.setBackground(bg);
        int wtype = Build.VERSION.SDK_INT >= 26 ? 2038 : 2002;
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(size, size, wtype, 8, -3);
        p.gravity = 17;
        p.x = COL[id] * dp(33);
        p.y = ROW[id] * dp(33);
        clampInto(p);
        btns[id] = tv;
        lps[id] = p;
        bgs[id] = bg;
        paint(id);
        tv.setOnTouchListener(new BtnTouch(id));
        try {
            wm.addView(tv, p);
        } catch (Exception e) {
        }
    }

    public static void hideBtn(int id) {
        if (btns[id] == null) {
            return;
        }
        try {
            wm.removeView(btns[id]);
        } catch (Exception e) {
        }
        btns[id] = null;
        lps[id] = null;
        bgs[id] = null;
    }

    public static void toggle(int id) {
        if (id == 3) {
            LvTeamShift.toggleTeleportBase();
            active[3] = LvTeamShift.teleportBaseState != 0;
            paintTpBase();
            playBeep(active[3]);
            return;
        }
        if (id == 4) {
            LvTeamShift.setWallPass(true ^ active[4]);
            active[4] = LvTeamShift.wallPassOn;
            paint(4);
            playBeep(active[4]);
            return;
        }
        setActive(id, true ^ active[id]);
        paint(id);
        playBeep(active[id]);
    }

    public static void playBeep(final boolean on) {
        new Thread(new Runnable() { // from class: com.lvteam.LvShiftOverlay$$ExternalSyntheticLambda1
            @Override // java.lang.Runnable
            public final void run() {
                LvShiftOverlay.lambda$playBeep$0(on);
            }
        }).start();
    }

    public static /* synthetic */ void lambda$playBeep$0(boolean on) {
        try {
            ToneGenerator tg = new ToneGenerator(5, 80);
            tg.startTone(on ? 25 : 26, 100);
            Thread.sleep(200L);
            tg.release();
        } catch (Exception e) {
        }
    }

    public static void paint(int id) {
        if (id == 3) {
            paintTpBase();
            return;
        }
        if (btns[id] == null || bgs[id] == null) {
            return;
        }
        if (active[id]) {
            if (id == 0) {
                btns[id].setText("MAGNET\nKILL ON");
            } else if (id == 2) {
                btns[id].setText("UNDER\nPLAYER\nON");
            } else {
                if (id == 4) {
                    boolean engaged = LvTeamShift.wallEngaged;
                    btns[id].setText(engaged ? "ATRAVESSAR\nPRONTO" : "ATRAVESSAR\nINDO...");
                    bgs[id].setColor(engaged ? -13730510 : -30720);
                    btns[id].invalidate();
                    return;
                }
                btns[id].setText(LABELS[id] + "\nON");
            }
            bgs[id].setColor(-15053940);
        } else {
            if (id == 0) {
                btns[id].setText("MAGNET\nKILL");
            } else if (id == 2) {
                btns[id].setText("UNDER\nPLAYER\nOFF");
            } else if (id == 4) {
                btns[id].setText("ATRAVESSAR\nPAREDE");
            } else {
                btns[id].setText(LABELS[id] + "\nOFF");
            }
            bgs[id].setColor(-15460578);
        }
        btns[id].invalidate();
    }

    public static void paintTpBase() {
        if (btns[3] == null || bgs[3] == null) {
            return;
        }
        int state = LvTeamShift.teleportBaseState;
        if (state == 1) {
            btns[3].setText("TP BASE\nREC");
            bgs[3].setColor(-14043402);
        } else if (state == 2) {
            btns[3].setText("TP BASE\nPLAY");
            bgs[3].setColor(-30720);
        } else {
            btns[3].setText("TP BASE");
            bgs[3].setColor(-15460578);
        }
        btns[3].invalidate();
    }

    public static void refreshWall() {
        if (ctx == null) {
            return;
        }
        new Handler(Looper.getMainLooper()).post(new Runnable() { // from class: com.lvteam.LvShiftOverlay$$ExternalSyntheticLambda2
            @Override // java.lang.Runnable
            public final void run() {
                LvShiftOverlay.paint(4);
            }
        });
    }

    public static void refreshTpBase() {
        if (ctx == null) {
            return;
        }
        new Handler(Looper.getMainLooper()).post(new Runnable() { // from class: com.lvteam.LvShiftOverlay$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                LvShiftOverlay.lambda$refreshTpBase$2();
            }
        });
    }

    public static /* synthetic */ void lambda$refreshTpBase$2() {
        active[3] = LvTeamShift.teleportBaseState != 0;
        paintTpBase();
    }

    public static void clampInto(WindowManager.LayoutParams p) {
        Point s = new Point();
        try {
            wm.getDefaultDisplay().getRealSize(s);
        } catch (Exception e) {
        }
        if (s.x <= 0 || s.y <= 0) {
            s.x = ctx.getResources().getDisplayMetrics().widthPixels;
            s.y = ctx.getResources().getDisplayMetrics().heightPixels;
        }
        int limX = Math.max(0, (s.x - p.width) / 2);
        int limY = Math.max(0, (s.y - p.height) / 2);
        p.x = Math.max(-limX, Math.min(limX, p.x));
        p.y = Math.max(-limY, Math.min(limY, p.y));
    }

    public static int dp(int v) {
        return (int) ((v * density) + 0.5f);
    }

    public static class BtnTouch implements View.OnTouchListener {
        public float dx;
        public float dy;
        public final int id;
        public boolean moved;
        public int sx;
        public int sy;

        public BtnTouch(int id) {
            this.id = id;
        }

        @Override // android.view.View.OnTouchListener
        public boolean onTouch(View v, MotionEvent e) {
            WindowManager.LayoutParams p = LvShiftOverlay.lps[this.id];
            if (p == null) {
                return false;
            }
            int act = e.getAction();
            if (act == 0) {
                this.dx = e.getRawX();
                this.dy = e.getRawY();
                this.sx = p.x;
                this.sy = p.y;
                this.moved = false;
                return true;
            }
            if (act == 2) {
                float mx = e.getRawX() - this.dx;
                float my = e.getRawY() - this.dy;
                if ((mx * mx) + (my * my) > 36.0f) {
                    this.moved = true;
                }
                p.x = this.sx + Math.round(mx);
                p.y = this.sy + Math.round(my);
                LvShiftOverlay.clampInto(p);
                try {
                    LvShiftOverlay.wm.updateViewLayout(v, p);
                } catch (Exception e2) {
                }
                return true;
            }
            if (act != 1) {
                return false;
            }
            if (!this.moved) {
                LvShiftOverlay.toggle(this.id);
            }
            return true;
        }
    }
}
