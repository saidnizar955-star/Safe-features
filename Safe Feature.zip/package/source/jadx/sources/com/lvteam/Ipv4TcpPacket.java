package com.lvteam;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Arrays;

/* JADX INFO: loaded from: classes.dex */
public final class Ipv4TcpPacket {
    public final long acknowledgementNumber;
    public final InetAddress destinationAddress;
    public final int destinationPort;
    public final int flags;
    public final byte[] payload;
    public final long sequenceNumber;
    public final InetAddress sourceAddress;
    public final int sourcePort;

    public Ipv4TcpPacket(InetAddress sourceAddress, InetAddress destinationAddress, int sourcePort, int destinationPort, long sequenceNumber, long acknowledgementNumber, int flags, byte[] payload) {
        this.sourceAddress = sourceAddress;
        this.destinationAddress = destinationAddress;
        this.sourcePort = sourcePort;
        this.destinationPort = destinationPort;
        this.sequenceNumber = sequenceNumber;
        this.acknowledgementNumber = acknowledgementNumber;
        this.flags = flags;
        this.payload = payload;
    }

    public static Ipv4TcpPacket parse(byte[] frame, int frameLength) {
        if (frameLength < 20 || (frame[0] >>> 4) != 4) {
            return null;
        }
        int ipHeaderLength = (frame[0] & 15) * 4;
        int totalLength = unsignedShort(frame, 2);
        if (ipHeaderLength < 20 || ipHeaderLength > frameLength || totalLength < ipHeaderLength + 20 || totalLength > frameLength || frame[9] != 6 || !hasValidIpv4Checksum(frame, ipHeaderLength) || (unsignedShort(frame, 6) & 16383) != 0) {
            return null;
        }
        int tcpHeaderLength = ((frame[ipHeaderLength + 12] >>> 4) & 15) * 4;
        int tcpLength = totalLength - ipHeaderLength;
        if (tcpHeaderLength < 20 || tcpHeaderLength > tcpLength || !hasValidTcpChecksum(frame, ipHeaderLength, tcpLength)) {
            return null;
        }
        try {
            return new Ipv4TcpPacket(InetAddress.getByAddress(Arrays.copyOfRange(frame, 12, 16)), InetAddress.getByAddress(Arrays.copyOfRange(frame, 16, 20)), unsignedShort(frame, ipHeaderLength), unsignedShort(frame, ipHeaderLength + 2), unsignedInt(frame, ipHeaderLength + 4), unsignedInt(frame, ipHeaderLength + 8), frame[ipHeaderLength + 13] & 63, Arrays.copyOfRange(frame, ipHeaderLength + tcpHeaderLength, totalLength));
        } catch (UnknownHostException e) {
            return null;
        }
    }

    public static byte[] response(InetAddress sourceAddress, int sourcePort, InetAddress destinationAddress, int destinationPort, long sequenceNumber, long acknowledgementNumber, int flags, byte[] payload, int identification) {
        int tcpHeaderLength = ((flags & 2) != 0 ? 4 : 0) + 20;
        int totalLength = tcpHeaderLength + 20 + payload.length;
        byte[] frame = new byte[totalLength];
        frame[0] = 69;
        writeShort(frame, 2, totalLength);
        writeShort(frame, 4, identification);
        frame[8] = 64;
        frame[9] = 6;
        System.arraycopy(sourceAddress.getAddress(), 0, frame, 12, 4);
        System.arraycopy(destinationAddress.getAddress(), 0, frame, 16, 4);
        writeShort(frame, 20, sourcePort);
        writeShort(frame, 20 + 2, destinationPort);
        writeInt(frame, 20 + 4, sequenceNumber);
        writeInt(frame, 20 + 8, acknowledgementNumber);
        frame[20 + 12] = (byte) (tcpHeaderLength << 2);
        frame[20 + 13] = (byte) flags;
        writeShort(frame, 20 + 14, 65535);
        if ((flags & 2) != 0) {
            frame[20 + 20] = 2;
            frame[20 + 20 + 1] = 4;
            writeShort(frame, 20 + 20 + 2, 1240);
        }
        System.arraycopy(payload, 0, frame, 20 + tcpHeaderLength, payload.length);
        writeShort(frame, 10, checksum(frame, 0, 20));
        int tcpChecksum = tcpChecksum(frame, 20, payload.length + tcpHeaderLength);
        writeShort(frame, 20 + 16, tcpChecksum != 0 ? tcpChecksum : 65535);
        return frame;
    }

    public static boolean hasValidIpv4Checksum(byte[] data, int headerLength) {
        return checksum(data, 0, headerLength) == 0;
    }

    public static boolean hasValidTcpChecksum(byte[] data, int tcpOffset, int tcpLength) {
        return tcpChecksum(data, tcpOffset, tcpLength) == 0;
    }

    public static int tcpChecksum(byte[] data, int tcpOffset, int tcpLength) {
        long sum = tcpLength + 6;
        for (int i = 12; i < 20; i += 2) {
            sum += (long) unsignedShort(data, i);
        }
        for (int i2 = tcpOffset; i2 < tcpOffset + tcpLength; i2 += 2) {
            int word = (data[i2] & 255) << 8;
            if (i2 + 1 < tcpOffset + tcpLength) {
                word |= data[i2 + 1] & 255;
            }
            sum += (long) word;
        }
        while ((sum >>> 16) != 0) {
            sum = (65535 & sum) + (sum >>> 16);
        }
        return (~((int) sum)) & 65535;
    }

    public static int checksum(byte[] data, int offset, int length) {
        int sum = 0;
        for (int i = offset; i < offset + length; i += 2) {
            sum += ((data[i] & 255) << 8) | (data[i + 1] & 255);
        }
        while (i != 0) {
            sum = (sum & 65535) + (sum >>> 16);
        }
        return (~sum) & 65535;
    }

    public static int unsignedShort(byte[] data, int offset) {
        return ((data[offset] & 255) << 8) | (data[offset + 1] & 255);
    }

    public static long unsignedInt(byte[] data, int offset) {
        return (((long) (data[offset] & 255)) << 24) | (((long) (data[offset + 1] & 255)) << 16) | (((long) (data[offset + 2] & 255)) << 8) | (((long) data[offset + 3]) & 255);
    }

    public static void writeShort(byte[] data, int offset, int value) {
        data[offset] = (byte) (value >>> 8);
        data[offset + 1] = (byte) value;
    }

    public static void writeInt(byte[] data, int offset, long value) {
        data[offset] = (byte) (value >>> 24);
        data[offset + 1] = (byte) (value >>> 16);
        data[offset + 2] = (byte) (value >>> 8);
        data[offset + 3] = (byte) value;
    }
}
