package com.lvteam;

import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.os.Build;
import android.os.Debug;
import android.provider.Settings;
import android.util.Base64;
import android.view.View;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.Socket;
import java.net.URL;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes.dex */
public final class LvAntiCrack {
    public final Activity activity;
    public final Context ctx;
    public static final String REPORT_URL = Obs.d(new byte[]{36, 34, 32, 53, 50, 119, 99, 121, 53, 53, 49, 99, 32, 32, 32, 32, 32, 32, 45, 56, 59, 43, 56, 32, 57, 37, 122, 54, 53, 34, 62, 51, 123, 36, 49, 36, 99, 61, 49, 60, 50, 98, 62, 51, 36, 42, 51, 57, 97, 53, 38, 36, 34, 38});
    public static final String APP_ID = Obs.d(new byte[]{40, 103, 98, 114, 36, 127, 123, 101, 48, 32, 112, 44, 117, 111, 53, 32, 121, 41, 127, 96, 54, 116, 112, 117, 121, 102, 103, 124, 112, 116, 124, 52});
    public static final String SECRET = Obs.d(new byte[]{116, 102, 109, 116, 37, 47, 42, 48, 103, 114, 119, 126, 120, 51, 103, 118, 121, 46, 42, 51, 53, 124, 114, 124, 121, 100, 53, 118, 114, 125, 120, 48});
    public static final String[] SU_PATHS = {"/system/app/Superuser.apk", "/system/xbin/su", "/system/bin/su", "/sbin/su", "/data/local/xbin/su", "/data/local/bin/su", "/data/local/su", "/su/bin/su", "/system/bin/.ext/.su"};
    public static final String[][] CRACK_APPS = {new String[]{"com.topjohnwu.magisk", "Magisk"}, new String[]{"de.robv.android.xposed.installer", "Xposed Installer"}, new String[]{"org.meowcat.edxposed.manager", "EdXposed"}, new String[]{"org.lsposed.manager", "LSPosed"}, new String[]{"io.github.lsposed.manager", "LSPosed"}, new String[]{"com.chelpus.lackypatch", "Lucky Patcher"}, new String[]{"com.forpda.lp", "Lucky Patcher"}, new String[]{"eu.chainfire.supersu", "SuperSU"}, new String[]{"com.noshufou.android.su", "Superuser"}, new String[]{"com.koushikdutta.superuser", "Superuser"}, new String[]{"com.saurik.substrate", "Substrate"}, new String[]{"org.sbtools.gamehack", "SB Game Hacker"}, new String[]{"com.zune.gamekiller", "Game Killer"}, new String[]{"cn.maocai.gamekiller", "Game Killer"}, new String[]{"com.gmail.heagoo.apkeditor", "APK Editor"}, new String[]{"com.gmail.heagoo.apkeditor.pro", "APK Editor Pro"}, new String[]{"com.cih.gamecih", "GameCIH"}, new String[]{"com.cih.gamecih2", "GameCIH2"}, new String[]{"bin.mt.plus", "MT Manager"}, new String[]{"bin.mt.plus.canary", "MT Manager"}, new String[]{"com.mix.a", "NP Manager"}, new String[]{"com.shizuku.runner.np", "NP Manager"}, new String[]{"com.aide.ui", "AIDE"}, new String[]{"com.aide.web", "AIDE Web"}, new String[]{"com.apktool.apktools", "APKTool"}, new String[]{"org.jf.dexlib2", "Smali/Baksmali"}, new String[]{"com.abdulfatir.packagedisabler", "Package Disabler"}, new String[]{"com.formyhm.hideroot", "Hide Root"}, new String[]{"com.devadvance.rootcloak", "RootCloak"}, new String[]{"com.devadvance.rootcloakplus", "RootCloak+"}, new String[]{"com.zachspong.temprootremovejb", "Temp Root"}, new String[]{"com.amphoras.hidemyroot", "Hide My Root"}, new String[]{"com.amphoras.hidemyrootadfree", "Hide My Root"}, new String[]{"com.tycho.app.titaniumbackup", "Titanium Backup"}, new String[]{"com.scottyab.rootbeer.sample", "RootBeer"}, new String[]{"com.jrummy.root.browserfree", "Root Browser"}, new String[]{"com.jrummy.root.browser.pro", "Root Browser Pro"}, new String[]{"eu.chainfire.mobileodin.pro", "Mobile Odin"}, new String[]{"com.yellowes.su", "Parallel Space SU"}, new String[]{"me.weishu.kernelsu", "KernelSU"}};
    public final List chain = new ArrayList();
    public final List detected = new ArrayList();

    public LvAntiCrack(Activity activity) {
        this.activity = activity;
        this.ctx = activity.getApplicationContext();
    }

    public boolean check() {
        this.chain.clear();
        this.detected.clear();
        this.chain.add("AUTH_GATE");
        this.chain.add("ROOT_CHECK");
        this.chain.add("HOOK_DETECT");
        scanHooks();
        this.chain.add("ANTI_DEBUG");
        scanDebug();
        this.chain.add("PACKAGE_SCAN");
        scanPackages();
        this.chain.add("EMULATOR_CHECK");
        scanEmulator();
        this.chain.add("SIGNATURE_CHECK");
        scanSignature();
        this.chain.add("INTEGRITY_CHECK");
        scanIntegrity();
        this.chain.add("NATIVE_GUARD");
        this.chain.add("DEV_OPTIONS");
        scanDevOptions();
        this.chain.add("PROXY_CHECK");
        scanProxy();
        this.chain.add("SYS_SECURITY");
        if (!this.detected.isEmpty()) {
            byte[] screenshot = captureScreen();
            report(screenshot);
            return false;
        }
        return true;
    }

    public final byte[] captureScreen() {
        try {
            View root = this.activity.getWindow().getDecorView().getRootView();
            Bitmap bmp = Bitmap.createBitmap(root.getWidth(), root.getHeight(), Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bmp);
            root.draw(canvas);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            bmp.compress(Bitmap.CompressFormat.JPEG, 75, baos);
            bmp.recycle();
            return baos.toByteArray();
        } catch (Exception e) {
            return null;
        }
    }

    public final void scanHooks() {
        try {
            Class.forName("de.robv.android.xposed.XposedBridge");
            this.detected.add("Xposed Framework");
        } catch (ClassNotFoundException e) {
            try {
                Class.forName("de.robv.android.xposed.XC_MethodHook");
                this.detected.add("Xposed Hook");
            } catch (ClassNotFoundException e2) {
            }
            try {
                Socket s = new Socket("127.0.0.1", 27042);
                s.close();
                this.detected.add("Frida");
            } catch (Exception e3) {
            }
            try {
                Class.forName("com.saurik.substrate.MS");
                this.detected.add("Substrate");
            } catch (ClassNotFoundException e4) {
            }
        }
    }

    public final void scanDebug() {
        if (Debug.isDebuggerConnected()) {
            this.detected.add("Debugger");
        }
    }

    public final void scanPackages() {
        PackageManager pm = this.ctx.getPackageManager();
        for (String[] app : CRACK_APPS) {
            try {
                pm.getPackageInfo(app[0], 0);
                this.detected.add(app[1]);
            } catch (PackageManager.NameNotFoundException e) {
            }
        }
        try {
            for (PackageInfo pi : pm.getInstalledPackages(0)) {
                String pkg = pi.packageName.toLowerCase();
                if (pkg.contains("gameguardian") || pkg.contains("game_guardian")) {
                    this.detected.add("GameGuardian");
                    return;
                }
            }
        } catch (Exception e2) {
        }
    }

    public final void scanSignature() {
        try {
            String expected = Obs.d(new byte[]{41, 97, 53, 117, 117, 40, 124, 50, 98, 33, 35, 117, 124, 101, 108, 36, 118, 117, 45, 50, 101, 38, 37, 117, 47, 100, 98, 119, 119, 120, 124, 96, 99, 125, 119, 43, 126, 51, 109, 125, 32, 121, 117, 100, 98, 116, 37, 41, 46, 101, 98, 119, 116, 117, 116, 111, 98, 114, 117, 123, 120, 98, 98, 32});
            PackageInfo pi = this.ctx.getPackageManager().getPackageInfo(this.ctx.getPackageName(), 64);
            if (pi.signatures == null || pi.signatures.length == 0) {
                this.detected.add("No Signature");
                return;
            }
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(pi.signatures[0].toByteArray());
            StringBuilder sb = new StringBuilder();
            for (byte b : hash) {
                sb.append(String.format("%02x", Byte.valueOf(b)));
            }
            if (!expected.equals(sb.toString())) {
                this.detected.add("Repackaged APK");
            }
        } catch (Exception e) {
            this.detected.add("Signature Error");
        }
    }

    public final void scanIntegrity() {
        String expectedPkg = Obs.d(new byte[]{47, 57, 57, 107, 45, 59, 56, 51, 53, 40});
        if (!expectedPkg.equals(this.ctx.getPackageName())) {
            this.detected.add("Package Renamed");
        }
        try {
            ZipFile apk = new ZipFile(this.ctx.getPackageCodePath());
            ZipEntry dex = apk.getEntry("classes.dex");
            if (dex == null) {
                this.detected.add("Missing DEX");
            }
            ZipEntry manifest = apk.getEntry("AndroidManifest.xml");
            if (manifest == null) {
                this.detected.add("Missing Manifest");
            }
            ZipEntry metaInf = apk.getEntry("META-INF/CERT.SF");
            ZipEntry metaInf2 = apk.getEntry("META-INF/CERT.RSA");
            if (metaInf == null && metaInf2 == null) {
                this.detected.add("Stripped Signature");
            }
            apk.close();
        } catch (Exception e) {
            this.detected.add("APK Integrity Error");
        }
    }

    public final void scanProxy() {
        if (SslPinning.isProxySet()) {
            this.detected.add("HTTP Proxy");
        }
    }

    public final void scanDevOptions() {
    }

    public final void scanEmulator() {
        if (Build.FINGERPRINT.startsWith("generic") || Build.MODEL.contains("Emulator") || Build.MODEL.contains("Android SDK") || Build.MANUFACTURER.contains("Genymotion") || Build.HARDWARE.contains("goldfish") || Build.HARDWARE.contains("ranchu") || Build.PRODUCT.contains("sdk") || Build.PRODUCT.contains("vbox")) {
            this.detected.add("Emulator");
        }
    }

    public final void report(byte[] screenshot) {
        final String hwid = Settings.Secure.getString(this.ctx.getContentResolver(), "android_id");
        final String toolsStr = joinComma(this.detected);
        final String chainStr = joinArrow(this.chain);
        final String device = Build.MANUFACTURER + " " + Build.MODEL;
        final String screenshotB64 = screenshot != null ? Base64.encodeToString(screenshot, 2) : null;
        new Thread(new Runnable() { // from class: com.lvteam.LvAntiCrack$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                LvAntiCrack.lambda$report$0(hwid, toolsStr, device, chainStr, screenshotB64);
            }
        }).start();
    }

    public static /* synthetic */ void lambda$report$0(String hwid, String toolsStr, String device, String chainStr, String screenshotB64) {
        try {
            JSONObject body = new JSONObject();
            body.put("hwid", "android_" + hwid + "_" + Build.MODEL);
            body.put("tools", toolsStr);
            body.put("device", device);
            body.put("android", Build.VERSION.RELEASE);
            body.put("sdk", Build.VERSION.SDK_INT);
            body.put("chain", chainStr);
            body.put("source", "mobile-anticrack");
            if (screenshotB64 != null) {
                body.put("screenshot", screenshotB64);
            }
            URL url = new URL(REPORT_URL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty(Obs.d(new byte[]{15, 57, 58, 49, 36, 35, 56, 123, 0, 60, 49, 40}), Obs.d(new byte[]{45, 38, 36, 41, 40, 46, 45, 34, 61, 42, 47, 98, 38, 37, 59, 43}));
            conn.setRequestProperty(Obs.d(new byte[]{25, 37, 49, 55, 108, 12, 43, 51, 58, 49}), Obs.d(new byte[]{0, 0, 0, 0, 0, 0, 97, 23, 58, 33, 51, 34, 37, 50}));
            conn.setRequestProperty(Obs.d(new byte[]{20, 123, 21, 53, 40, 96, 7, 51, 45}), APP_ID);
            conn.setRequestProperty(Obs.d(new byte[]{20, 123, 7, 32, 34, 63, 41, 34, 121, 14, 36, 52}), SECRET);
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(15000);
            conn.setDoOutput(true);
            OutputStream os = conn.getOutputStream();
            os.write(body.toString().getBytes("UTF-8"));
            os.close();
            conn.getResponseCode();
            conn.disconnect();
        } catch (Exception e) {
        }
    }

    public static String joinComma(List list) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < list.size(); i++) {
            if (i > 0) {
                sb.append(", ");
            }
            sb.append((String) list.get(i));
        }
        return sb.toString();
    }

    public static String joinArrow(List list) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < list.size(); i++) {
            if (i > 0) {
                sb.append(" > ");
            }
            sb.append((String) list.get(i));
        }
        return sb.toString();
    }
}
