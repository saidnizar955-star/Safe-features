package com.lvteam;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class EntityState$$ExternalSyntheticBackport4 {
    public static /* synthetic */ boolean m(float f) {
        return (Float.isInfinite(f) || Float.isNaN(f)) ? false : true;
    }
}
