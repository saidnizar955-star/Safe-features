package com.lvteam;

import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.net.VpnService;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

/* JADX INFO: loaded from: classes.dex */
public class OverlayActivity extends Activity {
    public boolean fullRouteRequested;
    public boolean waitingForOverlayPermission;

    @Override // android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout screen = new LinearLayout(this);
        screen.setOrientation(1);
        screen.setGravity(17);
        screen.setPadding(dp(28), dp(28), dp(28), dp(28));
        screen.setBackgroundColor(-16777216);
        Button openOverlay = new Button(this);
        openOverlay.setText(R.string.action_open_overlay);
        openOverlay.setTextColor(-16777216);
        openOverlay.setTextSize(16.0f);
        openOverlay.setAllCaps(false);
        openOverlay.setBackground(buttonBackground());
        openOverlay.setOnClickListener(new View.OnClickListener() { // from class: com.lvteam.OverlayActivity$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.lambda$onCreate$0(view);
            }
        });
        screen.addView(openOverlay, new LinearLayout.LayoutParams(-1, dp(52)));
        Button enableCapture = new Button(this);
        enableCapture.setText("Ativar captura");
        enableCapture.setTextColor(-16777216);
        enableCapture.setTextSize(16.0f);
        enableCapture.setAllCaps(false);
        enableCapture.setBackground(buttonBackground());
        enableCapture.setOnClickListener(new View.OnClickListener() { // from class: com.lvteam.OverlayActivity$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.lambda$onCreate$1(view);
            }
        });
        LinearLayout.LayoutParams captureParams = new LinearLayout.LayoutParams(-1, dp(52));
        captureParams.topMargin = dp(12);
        screen.addView(enableCapture, captureParams);
        Button enableFullRoute = new Button(this);
        enableFullRoute.setText("Testar roteamento IPv4 completo");
        enableFullRoute.setTextColor(-16777216);
        enableFullRoute.setTextSize(16.0f);
        enableFullRoute.setAllCaps(false);
        enableFullRoute.setBackground(buttonBackground());
        enableFullRoute.setOnClickListener(new View.OnClickListener() { // from class: com.lvteam.OverlayActivity$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.lambda$onCreate$2(view);
            }
        });
        LinearLayout.LayoutParams fullRouteParams = new LinearLayout.LayoutParams(-1, dp(52));
        fullRouteParams.topMargin = dp(12);
        screen.addView(enableFullRoute, fullRouteParams);
        setContentView(screen);
    }

    public final /* synthetic */ void lambda$onCreate$0(View view) {
        requestOverlay();
    }

    public final /* synthetic */ void lambda$onCreate$1(View view) {
        requestVpn(false);
    }

    public final /* synthetic */ void lambda$onCreate$2(View view) {
        requestVpn(true);
    }

    @Override // android.app.Activity
    public void onResume() {
        super.onResume();
        if (this.waitingForOverlayPermission && Settings.canDrawOverlays(this)) {
            startOverlayService();
        }
        this.waitingForOverlayPermission = false;
    }

    public final void requestOverlay() {
        if (Settings.canDrawOverlays(this)) {
            startOverlayService();
            return;
        }
        this.waitingForOverlayPermission = true;
        Intent permission = new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION", Uri.parse("package:" + getPackageName()));
        startActivity(permission);
    }

    public final void startOverlayService() {
        Intent intent = new Intent(this, (Class<?>) OverlayService.class);
        if (Build.VERSION.SDK_INT < 26) {
            startService(intent);
        } else {
            startForegroundService(intent);
        }
    }

    public final void requestVpn(boolean enableFullRoute) {
        this.fullRouteRequested = enableFullRoute;
        Intent intent = VpnService.prepare(this);
        if (intent == null) {
            startCaptureService();
        } else {
            startActivityForResult(intent, 7);
        }
    }

    @Override // android.app.Activity
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 7 && resultCode == -1) {
            startCaptureService();
        }
    }

    public final void startCaptureService() {
        Intent service = new Intent(this, (Class<?>) PacketCaptureService.class);
        if (this.fullRouteRequested) {
            service.setAction(PacketCaptureService.ACTION_ENABLE_FULL_IPV4_ROUTE);
        }
        startService(service);
        this.fullRouteRequested = false;
    }

    public final GradientDrawable buttonBackground() {
        GradientDrawable background = new GradientDrawable();
        background.setColor(-1);
        background.setCornerRadius(dp(8));
        return background;
    }

    public final int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
