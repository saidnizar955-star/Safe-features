package com.lvteam;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Process;
import android.view.Choreographer;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public class OverlayService extends Service {
    private static final String CHANNEL_ID = "lv_team_overlay";
    private static final int EL_BOX = 0;
    private static final int EL_DIST = 3;
    private static final int EL_FOV = 4;
    private static final int EL_LINE = 1;
    private static final int EL_NAME = 2;
    private static final int TAB_AIM = 0;
    private static final int TAB_COUNT = 5;
    private static final int TAB_EXPLOIT = 3;
    private static final String[] TAB_ICONS = {"◉", "◉", "☰", "⚡", "⚙"};
    private static final String[] TAB_NAMES = {"Aim", "Views", "Players", "Exploit", "Settings"};
    private static final int TAB_PLAYERS = 2;
    private static final int TAB_SETTINGS = 4;
    private static final int TAB_VIEWS = 1;
    private static final int TH_ACCENT = -14043402;
    private static final int TH_BG = -267579113;
    private static final int TH_BORDER = -13353910;
    private static final int TH_CHECK_OFF = -15854564;
    private static final int TH_CONTENT = -15656928;
    private static final int TH_DIVIDER = -14933202;
    private static final int TH_HEADER = -15328478;
    private static final int TH_RED = -1754827;
    private static final int TH_SIDEBAR = -15920873;
    private static final int TH_SIDEBAR_ACTIVE = -15326668;
    private static final int TH_SURFACE = -14933197;
    private static final int TH_TEXT = -1643021;
    private static final int TH_TEXT_DIM = -8551024;
    private static final int TH_TOGGLE_OFF = -14801611;
    private static final int TH_TOGGLE_ON = -14575885;
    private ImageView appIcon;
    private LinearLayout bodyContainer;
    private boolean boxEnabled;
    private EspOverlayView boxOverlay;
    private View circleOverlay;
    private WindowManager.LayoutParams circleParams;
    private boolean drawDistance;
    private boolean drawLine;
    private boolean drawName;
    private boolean enemyCounterEnabled;
    private LinearLayout enemyCounterOverlay;
    private TextView enemyValue;
    private boolean espEnabled;
    private FrameLayout espMasterBox;
    private LinearLayout headerContainer;
    private float initialTouchX;
    private float initialTouchY;
    private int initialX;
    private int initialY;
    private boolean minimized;
    private View overlay;
    private GradientDrawable overlayBackground;
    private WindowManager.LayoutParams overlayParams;
    private TextView playerEmptyLabel;
    private LinearLayout playerListContainer;
    private Handler playerUpdateHandler;
    private Handler sessionCheckHandler;
    private TextView teamTitleOverlay;
    private TextView thicknessLabel;
    private WindowManager windowManager;
    private final LinearLayout[] tabPanels = new LinearLayout[TAB_COUNT];
    private final LinearLayout[] sidebarItems = new LinearLayout[TAB_COUNT];
    private final TextView[] sidebarIcons = new TextView[TAB_COUNT];
    private final TextView[] sidebarLabels = new TextView[TAB_COUNT];
    private final View[] sidebarAccents = new View[TAB_COUNT];
    private int activeTab = 0;
    private final EspEngine espEngine = new EspEngine();
    private final EntityState entityState = EntityState.shared();
    private int fovPercent = 110;
    private int maxDistanceM = 160;
    private final int[] elementColor = {TAB_COUNT, TAB_COUNT, TAB_COUNT, TAB_COUNT, TAB_COUNT};
    private int thicknessIndex = TAB_COUNT;
    private final int[] colors = {-65536, -16711936, -16776961, -256, -65281, -1};
    private final float[] thicknesses = {0.5f, 0.6f, 0.7f, 0.8f, 0.9f, 1.0f, 1.1f, 1.2f, 1.3f, 1.4f, 1.5f};
    private volatile List<EspOverlayView.Entity> lastProjected = new ArrayList();
    private final Set<Integer> ignoredIds = new HashSet();
    private final Choreographer.FrameCallback espFrame = new Choreographer.FrameCallback() { // from class: com.lvteam.OverlayService.1
        @Override // android.view.Choreographer.FrameCallback
        public void doFrame(long frameTimeNanos) {
            if (OverlayService.this.boxOverlay != null) {
                OverlayService.this.entityState.publishTo(OverlayService.this.espEngine);
                Collection<EspOverlayView.Entity> projected = OverlayService.this.espEngine.project(OverlayService.this.boxOverlay.getWidth(), OverlayService.this.boxOverlay.getHeight());
                Collection<EspOverlayView.Entity> visible = projected;
                if (!OverlayService.this.ignoredIds.isEmpty()) {
                    List<EspOverlayView.Entity> kept = new ArrayList<>(projected.size());
                    for (EspOverlayView.Entity e : projected) {
                        if (!OverlayService.this.ignoredIds.contains(Integer.valueOf(e.id))) {
                            kept.add(e);
                        }
                    }
                    visible = kept;
                }
                OverlayService.this.boxOverlay.submitEntities(visible);
                OverlayService.this.updateEnemyCounter(visible.size());
                if (!OverlayService.this.minimized && OverlayService.this.activeTab == 2) {
                    OverlayService.this.lastProjected = new ArrayList(projected);
                }
                Choreographer.getInstance().postFrameCallback(this);
            }
        }
    };

    public interface DropdownCallback {
        void onSelect(int i);
    }

    public interface SliderCallback {
        void onChange(int i);
    }

    public interface ToggleCallback {
        void onToggle(boolean z);
    }

    @Override // android.app.Service
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (!LvSession.get().isActive()) {
            stopSelf();
            return 2;
        }
        startAsForegroundService();
        showOverlay();
        showTeamTitle();
        startSessionCheck();
        startPlayerListUpdater();
        return 2;
    }

    private void startAsForegroundService() {
        NotificationChannel channel = OverlayService$$ExternalSyntheticApiModelOutline2.m(CHANNEL_ID, "LV Team overlay", 2);
        ((NotificationManager) getSystemService(NotificationManager.class)).createNotificationChannel(channel);
        Notification notification = OverlayService$$ExternalSyntheticApiModelOutline3.m(this, CHANNEL_ID).setSmallIcon(android.R.drawable.ic_menu_view).setContentTitle("LV Team").setContentText("Overlay ativo").build();
        startForeground(1, notification);
    }

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override // android.app.Service
    public void onDestroy() {
        if (this.sessionCheckHandler != null) {
            this.sessionCheckHandler.removeCallbacksAndMessages(null);
            this.sessionCheckHandler = null;
        }
        if (this.playerUpdateHandler != null) {
            this.playerUpdateHandler.removeCallbacksAndMessages(null);
            this.playerUpdateHandler = null;
        }
        removeCircle();
        removeBox();
        removeEnemyCounter();
        removeTeamTitle();
        for (int i = 0; i < TAB_COUNT; i++) {
            LvShiftOverlay.hideBtn(i);
        }
        if (this.overlay != null) {
            this.windowManager.removeView(this.overlay);
            this.overlay = null;
        }
        super.onDestroy();
    }

    @Override // android.app.Service
    public void onTaskRemoved(Intent rootIntent) {
        stopSelf();
        super.onTaskRemoved(rootIntent);
        Process.killProcess(Process.myPid());
    }

    @SuppressLint({"ClickableViewAccessibility"})
    private void showOverlay() {
        int type;
        if (this.overlay != null) {
            return;
        }
        this.windowManager = (WindowManager) getSystemService("window");
        DraggableLayout root = new DraggableLayout(this);
        this.overlayBackground = new GradientDrawable();
        this.overlayBackground.setColor(TH_BG);
        this.overlayBackground.setCornerRadius(dp(16));
        this.overlayBackground.setStroke(dp(1), TH_BORDER);
        root.setBackground(this.overlayBackground);
        root.setClipToOutline(true);
        LinearLayout column = new LinearLayout(this);
        column.setOrientation(1);
        this.headerContainer = buildHeader();
        column.addView(this.headerContainer, new LinearLayout.LayoutParams(-1, -2));
        this.bodyContainer = new LinearLayout(this);
        this.bodyContainer.setOrientation(0);
        LinearLayout sidebar = buildSidebar();
        this.bodyContainer.addView(sidebar, new LinearLayout.LayoutParams(dp(98), -1));
        View sep = new View(this);
        sep.setBackgroundColor(TH_BORDER);
        this.bodyContainer.addView(sep, new LinearLayout.LayoutParams(dp(1), -1));
        FrameLayout contentFrame = new FrameLayout(this);
        contentFrame.setBackgroundColor(TH_CONTENT);
        int i = 0;
        while (true) {
            int i2 = 8;
            if (i >= TAB_COUNT) {
                break;
            }
            this.tabPanels[i] = buildTabPanel(i);
            LinearLayout linearLayout = this.tabPanels[i];
            if (i == this.activeTab) {
                i2 = 0;
            }
            linearLayout.setVisibility(i2);
            contentFrame.addView(this.tabPanels[i], new FrameLayout.LayoutParams(-1, -1));
            i++;
        }
        this.bodyContainer.addView(contentFrame, new LinearLayout.LayoutParams(0, -1, 1.0f));
        column.addView(this.bodyContainer, new LinearLayout.LayoutParams(-1, 0, 1.0f));
        this.appIcon = new ImageView(this);
        this.appIcon.setImageDrawable(getApplicationInfo().loadIcon(getPackageManager()));
        this.appIcon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        this.appIcon.setVisibility(8);
        this.appIcon.setOnClickListener(new View.OnClickListener() { // from class: com.lvteam.OverlayService$$ExternalSyntheticLambda17
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.lambda$showOverlay$0(view);
            }
        });
        column.addView(this.appIcon, new LinearLayout.LayoutParams(-1, 0, 1.0f));
        root.addView(column, new FrameLayout.LayoutParams(-1, -1));
        this.overlay = root;
        highlightTab(this.activeTab);
        if (Build.VERSION.SDK_INT >= 26) {
            type = 2038;
        } else {
            type = 2002;
        }
        this.overlayParams = new WindowManager.LayoutParams(menuWidth(), menuHeight(), type, 8, -3);
        this.overlayParams.gravity = 8388659;
        this.overlayParams.x = dp(10);
        this.overlayParams.y = dp(40);
        this.windowManager.addView(this.overlay, this.overlayParams);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$showOverlay$0(View v) {
        setMinimized(false);
    }

    private int menuWidth() {
        int sw = getResources().getDisplayMetrics().widthPixels;
        return Math.min(dp(330), Math.max(dp(290), sw - dp(36)));
    }

    private int menuHeight() {
        int sh = getResources().getDisplayMetrics().heightPixels;
        return Math.min(dp(350), Math.max(dp(260), sh - dp(36)));
    }

    private LinearLayout buildHeader() {
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(1);
        linearLayout.setBackgroundColor(TH_HEADER);
        LinearLayout linearLayout2 = new LinearLayout(this);
        linearLayout2.setGravity(16);
        linearLayout2.setPadding(dp(16), dp(12), dp(10), dp(8));
        TextView lvText = new TextView(this);
        lvText.setText("LV ");
        lvText.setTextColor(TH_ACCENT);
        lvText.setTextSize(17.0f);
        lvText.setLetterSpacing(0.05f);
        lvText.setTypeface(Typeface.create("sans-serif-medium", 1));
        linearLayout2.addView(lvText, new LinearLayout.LayoutParams(-2, -2));
        TextView teamText = new TextView(this);
        teamText.setText("TEAM");
        teamText.setTextColor(TH_TEXT);
        teamText.setTextSize(17.0f);
        teamText.setLetterSpacing(0.05f);
        teamText.setTypeface(Typeface.create("sans-serif-medium", 1));
        linearLayout2.addView(teamText, new LinearLayout.LayoutParams(0, -2, 1.0f));
        TextView minBtn = new TextView(this);
        minBtn.setText("─");
        minBtn.setTextColor(TH_TEXT_DIM);
        minBtn.setTextSize(17.0f);
        minBtn.setGravity(17);
        GradientDrawable minBg = new GradientDrawable();
        minBg.setCornerRadius(dp(7));
        minBg.setColor(TH_SURFACE);
        minBg.setStroke(dp(1), TH_BORDER);
        minBtn.setBackground(minBg);
        minBtn.setOnClickListener(new View.OnClickListener() { // from class: com.lvteam.OverlayService$$ExternalSyntheticLambda21
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.lambda$buildHeader$1(view);
            }
        });
        linearLayout2.addView(minBtn, new LinearLayout.LayoutParams(dp(30), dp(30)));
        linearLayout.addView(linearLayout2);
        View line = new View(this);
        Drawable lineBg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{0, TH_ACCENT, TH_ACCENT, 0});
        line.setBackground(lineBg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(2));
        lp.setMargins(dp(16), 0, dp(16), 0);
        linearLayout.addView(line, lp);
        return linearLayout;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$buildHeader$1(View v) {
        setMinimized(true);
    }

    private LinearLayout buildSidebar() {
        LinearLayout sidebar = new LinearLayout(this);
        int i = 1;
        sidebar.setOrientation(1);
        sidebar.setBackgroundColor(TH_SIDEBAR);
        int i2 = 0;
        sidebar.setPadding(0, dp(8), 0, dp(8));
        int i3 = 0;
        while (i3 < TAB_COUNT) {
            final int tab = i3;
            LinearLayout item = new LinearLayout(this);
            item.setOrientation(i2);
            item.setGravity(16);
            GradientDrawable itemBg = new GradientDrawable();
            itemBg.setCornerRadius(dp(10));
            item.setBackground(itemBg);
            item.setTag(itemBg);
            View accent = new View(this);
            GradientDrawable accentBg = new GradientDrawable();
            accentBg.setCornerRadius(dp(2));
            accent.setBackground(accentBg);
            LinearLayout.LayoutParams accentLp = new LinearLayout.LayoutParams(dp(3), dp(20));
            accentLp.setMargins(dp(4), i2, dp(7), i2);
            item.addView(accent, accentLp);
            TextView icon = new TextView(this);
            icon.setText(TAB_ICONS[i3]);
            icon.setTextSize(13.0f);
            icon.setGravity(17);
            item.addView(icon, new LinearLayout.LayoutParams(dp(20), dp(20)));
            TextView label = new TextView(this);
            label.setText(TAB_NAMES[i3]);
            label.setTextSize(13.0f);
            label.setTypeface(Typeface.create("sans-serif-medium", i));
            label.setGravity(16);
            label.setPadding(dp(7), 0, 0, 0);
            item.addView(label, new LinearLayout.LayoutParams(0, -1, 1.0f));
            item.setOnClickListener(new View.OnClickListener() { // from class: com.lvteam.OverlayService$$ExternalSyntheticLambda4
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.lambda$buildSidebar$2(tab, view);
                }
            });
            LinearLayout.LayoutParams itemLp = new LinearLayout.LayoutParams(-1, dp(48));
            itemLp.setMargins(dp(TAB_COUNT), dp(3), dp(TAB_COUNT), dp(3));
            sidebar.addView(item, itemLp);
            this.sidebarItems[i3] = item;
            this.sidebarIcons[i3] = icon;
            this.sidebarLabels[i3] = label;
            this.sidebarAccents[i3] = accent;
            i3++;
            i = 1;
            i2 = 0;
        }
        return sidebar;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$buildSidebar$2(int tab, View v) {
        switchTab(tab);
    }

    private void switchTab(int tab) {
        if (tab == this.activeTab) {
            return;
        }
        this.tabPanels[this.activeTab].setVisibility(8);
        this.activeTab = tab;
        this.tabPanels[this.activeTab].setVisibility(0);
        highlightTab(tab);
    }

    private void highlightTab(int tab) {
        int i = 0;
        while (i < TAB_COUNT) {
            int i2 = 0;
            boolean on = i == tab;
            TextView textView = this.sidebarIcons[i];
            int i3 = TH_TEXT_DIM;
            textView.setTextColor(on ? TH_ACCENT : TH_TEXT_DIM);
            TextView textView2 = this.sidebarLabels[i];
            if (on) {
                i3 = TH_ACCENT;
            }
            textView2.setTextColor(i3);
            GradientDrawable bg = (GradientDrawable) this.sidebarItems[i].getTag();
            bg.setColor(on ? TH_SIDEBAR_ACTIVE : 0);
            bg.setStroke(on ? dp(1) : 0, on ? 1713477363 : 0);
            GradientDrawable gradientDrawable = (GradientDrawable) this.sidebarAccents[i].getBackground();
            if (on) {
                i2 = TH_ACCENT;
            }
            gradientDrawable.setColor(i2);
            i++;
        }
    }

    private LinearLayout buildTabPanel(int tab) {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setOnTouchListener(new View.OnTouchListener() { // from class: com.lvteam.OverlayService$$ExternalSyntheticLambda13
            @Override // android.view.View.OnTouchListener
            public final boolean onTouch(View view, MotionEvent motionEvent) {
                return OverlayService.lambda$buildTabPanel$3(view, motionEvent);
            }
        });
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(1);
        content.setPadding(0, dp(4), 0, dp(8));
        switch (tab) {
            case 0:
                buildAimTab(content);
                break;
            case 1:
                buildViewsTab(content);
                break;
            case 2:
                buildPlayersTab(content);
                break;
            case 3:
                buildExploitTab(content);
                break;
            case 4:
                buildSettingsTab(content);
                break;
        }
        scroll.addView(content, new FrameLayout.LayoutParams(-1, -2));
        LinearLayout wrapper = new LinearLayout(this);
        wrapper.setOrientation(1);
        wrapper.addView(scroll, new LinearLayout.LayoutParams(-1, -1));
        return wrapper;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ boolean lambda$buildTabPanel$3(View v, MotionEvent ev) {
        v.getParent().requestDisallowInterceptTouchEvent(true);
        return false;
    }

    private void buildAimTab(LinearLayout c) {
        addShiftToggle(c, "Enable Aim", 0);
        addDropdownRow(c, "Metodo Aim", new String[]{"Magnetic", "Silent"}, 0, null);
        addFeatureToggle(c, "Freeze Scop", new ToggleCallback() { // from class: com.lvteam.OverlayService$$ExternalSyntheticLambda5
            @Override // com.lvteam.OverlayService.ToggleCallback
            public final void onToggle(boolean z) {
                LvTeamShift.setFreezeScop(z);
            }
        });
        addFeatureToggle(c, "Freeze Fire", new ToggleCallback() { // from class: com.lvteam.OverlayService$$ExternalSyntheticLambda6
            @Override // com.lvteam.OverlayService.ToggleCallback
            public final void onToggle(boolean z) {
                LvTeamShift.setFreezeFire(z);
            }
        });
        addEspToggle(c, "Enable Fov", 4, new ToggleCallback() { // from class: com.lvteam.OverlayService$$ExternalSyntheticLambda7
            @Override // com.lvteam.OverlayService.ToggleCallback
            public final void onToggle(boolean z) {
                this.f$0.setCircleEnabled(z);
            }
        });
        addSliderRow(c, "Changed Fov", "%", 50, 200, this.fovPercent, new SliderCallback() { // from class: com.lvteam.OverlayService$$ExternalSyntheticLambda8
            @Override // com.lvteam.OverlayService.SliderCallback
            public final void onChange(int i) {
                this.f$0.lambda$buildAimTab$4(i);
            }
        });
        addFeatureToggle(c, "Aim Line", new ToggleCallback() { // from class: com.lvteam.OverlayService$$ExternalSyntheticLambda9
            @Override // com.lvteam.OverlayService.ToggleCallback
            public final void onToggle(boolean z) {
                OverlayService.lambda$buildAimTab$5(z);
            }
        });
        addFeatureToggle(c, "Ignore Derrubados", new ToggleCallback() { // from class: com.lvteam.OverlayService$$ExternalSyntheticLambda10
            @Override // com.lvteam.OverlayService.ToggleCallback
            public final void onToggle(boolean z) {
                OverlayService.lambda$buildAimTab$6(z);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$buildAimTab$4(int val) {
        this.fovPercent = val;
        updateCircleSize();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void lambda$buildAimTab$5(boolean enabled) {
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void lambda$buildAimTab$6(boolean enabled) {
    }

    private void buildViewsTab(LinearLayout c) {
        this.espMasterBox = addFeatureToggle(c, "Enable Esp", new ToggleCallback() { // from class: com.lvteam.OverlayService$$ExternalSyntheticLambda28
            @Override // com.lvteam.OverlayService.ToggleCallback
            public final void onToggle(boolean z) {
                this.f$0.lambda$buildViewsTab$7(z);
            }
        });
        addEspToggle(c, "Esp Line", 1, new ToggleCallback() { // from class: com.lvteam.OverlayService$$ExternalSyntheticLambda29
            @Override // com.lvteam.OverlayService.ToggleCallback
            public final void onToggle(boolean z) {
                this.f$0.lambda$buildViewsTab$8(z);
            }
        });
        addEspToggle(c, "Esp Box", 0, new ToggleCallback() { // from class: com.lvteam.OverlayService$$ExternalSyntheticLambda30
            @Override // com.lvteam.OverlayService.ToggleCallback
            public final void onToggle(boolean z) {
                this.f$0.lambda$buildViewsTab$9(z);
            }
        });
        addEspToggle(c, "Esp Name", 2, new ToggleCallback() { // from class: com.lvteam.OverlayService$$ExternalSyntheticLambda31
            @Override // com.lvteam.OverlayService.ToggleCallback
            public final void onToggle(boolean z) {
                this.f$0.lambda$buildViewsTab$10(z);
            }
        });
        addEspToggle(c, "Esp Distance", 3, new ToggleCallback() { // from class: com.lvteam.OverlayService$$ExternalSyntheticLambda32
            @Override // com.lvteam.OverlayService.ToggleCallback
            public final void onToggle(boolean z) {
                this.f$0.lambda$buildViewsTab$11(z);
            }
        });
        addSliderRow(c, "Max Distance", "m", 10, 200, this.maxDistanceM, new SliderCallback() { // from class: com.lvteam.OverlayService$$ExternalSyntheticLambda33
            @Override // com.lvteam.OverlayService.SliderCallback
            public final void onChange(int i) {
                this.f$0.lambda$buildViewsTab$12(i);
            }
        });
        addDropdownRow(c, "Box Style", new String[]{"Corner", "Full"}, 0, null);
        addFeatureToggle(c, "Enemy Count", new ToggleCallback() { // from class: com.lvteam.OverlayService$$ExternalSyntheticLambda34
            @Override // com.lvteam.OverlayService.ToggleCallback
            public final void onToggle(boolean z) {
                this.f$0.lambda$buildViewsTab$13(z);
            }
        });
        addSectionLabel(c, "ESPESSURA");
        buildThicknessPicker(c);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$buildViewsTab$7(boolean enabled) {
        this.espEnabled = enabled;
        updateEspOverlay();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$buildViewsTab$8(boolean enabled) {
        this.drawLine = enabled;
        if (enabled) {
            enableEspMaster();
        }
        updateEspOverlay();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$buildViewsTab$9(boolean enabled) {
        this.boxEnabled = enabled;
        if (enabled) {
            enableEspMaster();
        }
        updateEspOverlay();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$buildViewsTab$10(boolean enabled) {
        this.drawName = enabled;
        if (enabled) {
            enableEspMaster();
        }
        updateEspOverlay();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$buildViewsTab$11(boolean enabled) {
        this.drawDistance = enabled;
        if (enabled) {
            enableEspMaster();
        }
        updateEspOverlay();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$buildViewsTab$12(int val) {
        this.maxDistanceM = val;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$buildViewsTab$13(boolean enabled) {
        this.enemyCounterEnabled = enabled;
        updateEspOverlay();
    }

    private void buildPlayersTab(LinearLayout linearLayout) {
        LinearLayout linearLayout2 = new LinearLayout(this);
        linearLayout2.setGravity(16);
        linearLayout2.setPadding(dp(16), dp(8), dp(14), dp(8));
        TextView header = new TextView(this);
        header.setText("Players Detectados");
        header.setTextColor(TH_ACCENT);
        header.setTextSize(13.0f);
        header.setTypeface(Typeface.create("sans-serif-medium", 1));
        linearLayout2.addView(header, new LinearLayout.LayoutParams(0, -2, 1.0f));
        TextView clearBtn = new TextView(this);
        clearBtn.setText("LIMPAR");
        clearBtn.setTextColor(TH_TEXT_DIM);
        clearBtn.setTextSize(10.0f);
        clearBtn.setTypeface(Typeface.DEFAULT_BOLD);
        clearBtn.setGravity(17);
        clearBtn.setPadding(dp(10), 0, dp(10), 0);
        GradientDrawable clearBg = new GradientDrawable();
        clearBg.setCornerRadius(dp(6));
        clearBg.setColor(TH_SURFACE);
        clearBg.setStroke(dp(1), TH_BORDER);
        clearBtn.setBackground(clearBg);
        clearBtn.setOnClickListener(new View.OnClickListener() { // from class: com.lvteam.OverlayService$$ExternalSyntheticLambda19
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.lambda$buildPlayersTab$14(view);
            }
        });
        linearLayout2.addView(clearBtn, new LinearLayout.LayoutParams(-2, dp(24)));
        linearLayout.addView(linearLayout2);
        addRowLine(linearLayout);
        TextView hint = new TextView(this);
        hint.setText("Toque num player para o ESP e o Magnet ignorarem ele");
        hint.setTextColor(TH_TEXT_DIM);
        hint.setTextSize(10.0f);
        hint.setPadding(dp(16), dp(6), dp(14), dp(6));
        linearLayout.addView(hint);
        this.playerEmptyLabel = new TextView(this);
        this.playerEmptyLabel.setText("Nenhum player detectado");
        this.playerEmptyLabel.setTextColor(TH_TEXT_DIM);
        this.playerEmptyLabel.setTextSize(13.0f);
        this.playerEmptyLabel.setGravity(17);
        this.playerEmptyLabel.setPadding(dp(14), dp(50), dp(14), dp(50));
        linearLayout.addView(this.playerEmptyLabel);
        this.playerListContainer = new LinearLayout(this);
        this.playerListContainer.setOrientation(1);
        linearLayout.addView(this.playerListContainer, new LinearLayout.LayoutParams(-1, -2));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$buildPlayersTab$14(View v) {
        this.ignoredIds.clear();
        syncIgnoredSlots();
        refreshPlayerList();
    }

    private void buildExploitTab(LinearLayout c) {
        addShiftToggle(c, "Ghost Hacker", 1);
        addShiftToggle(c, "Teleporte", 3);
        addSliderRow(c, "Velocidade TP", "x", 1, 10, LvTeamShift.getTeleportSpeed(), new SliderCallback() { // from class: com.lvteam.OverlayService$$ExternalSyntheticLambda24
            @Override // com.lvteam.OverlayService.SliderCallback
            public final void onChange(int i) {
                LvTeamShift.setTeleportSpeed(i);
            }
        });
        addShiftToggle(c, "Under Player", 2);
    }

    private void buildSettingsTab(LinearLayout linearLayout) {
        TextView header = new TextView(this);
        header.setText("Informações");
        header.setTextColor(TH_ACCENT);
        header.setTextSize(13.0f);
        header.setTypeface(Typeface.create("sans-serif-medium", 1));
        header.setPadding(dp(16), dp(8), dp(14), dp(8));
        linearLayout.addView(header);
        addRowLine(linearLayout);
        addInfoRow(linearLayout, "Versão", appVersionName());
        addInfoRow(linearLayout, "Dispositivo", Build.MANUFACTURER + " " + Build.MODEL);
        StringBuilder sb = new StringBuilder();
        sb.append("API ");
        sb.append(Build.VERSION.SDK_INT);
        addInfoRow(linearLayout, "Android", sb.toString());
        View spacer = new View(this);
        linearLayout.addView(spacer, new LinearLayout.LayoutParams(-1, dp(24)));
        TextView exitBtn = new TextView(this);
        exitBtn.setText("EXIT");
        exitBtn.setTextColor(-1);
        exitBtn.setTextSize(15.0f);
        exitBtn.setTypeface(Typeface.DEFAULT_BOLD);
        exitBtn.setLetterSpacing(0.1f);
        exitBtn.setGravity(17);
        GradientDrawable exitBg = new GradientDrawable();
        exitBg.setColor(TH_RED);
        exitBg.setCornerRadius(dp(9));
        exitBtn.setBackground(exitBg);
        exitBtn.setPadding(0, dp(12), 0, dp(12));
        exitBtn.setOnClickListener(new View.OnClickListener() { // from class: com.lvteam.OverlayService$$ExternalSyntheticLambda23
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.lambda$buildSettingsTab$15(view);
            }
        });
        LinearLayout.LayoutParams elp = new LinearLayout.LayoutParams(-1, -2);
        elp.setMargins(dp(16), 0, dp(16), 0);
        linearLayout.addView(exitBtn, elp);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$buildSettingsTab$15(View v) {
        killApp("Saindo...");
    }

    private LinearLayout newRow(LinearLayout linearLayout, String name) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(16);
        row.setPadding(dp(16), 0, dp(14), 0);
        TextView label = new TextView(this);
        label.setText(name);
        label.setTextColor(TH_TEXT);
        label.setTextSize(14.0f);
        label.setGravity(16);
        row.addView(label, new LinearLayout.LayoutParams(0, dp(46), 1.0f));
        linearLayout.addView(row, new LinearLayout.LayoutParams(-1, dp(46)));
        return row;
    }

    private void addRowLine(LinearLayout parent) {
        View d = new View(this);
        d.setBackgroundColor(TH_DIVIDER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(1));
        lp.setMargins(dp(16), 0, dp(14), 0);
        parent.addView(d, lp);
    }

    private FrameLayout addFeatureToggle(LinearLayout parent, String name, final ToggleCallback cb) {
        LinearLayout row = newRow(parent, name);
        FrameLayout box = makeCheckbox();
        box.setOnClickListener(new View.OnClickListener() { // from class: com.lvteam.OverlayService$$ExternalSyntheticLambda18
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.lambda$addFeatureToggle$16(cb, view);
            }
        });
        row.addView(box, new LinearLayout.LayoutParams(dp(26), dp(26)));
        addRowLine(parent);
        return box;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$addFeatureToggle$16(ToggleCallback cb, View v) {
        if (LvSession.get().isActive()) {
            boolean on = !Boolean.TRUE.equals(v.getTag());
            v.setTag(Boolean.valueOf(on));
            applyCheckboxStyle((FrameLayout) v, on);
            cb.onToggle(on);
        }
    }

    private void enableEspMaster() {
        if (this.espEnabled) {
            return;
        }
        this.espEnabled = true;
        if (this.espMasterBox == null) {
            return;
        }
        this.espMasterBox.setTag(true);
        applyCheckboxStyle(this.espMasterBox, true);
    }

    private FrameLayout addEspToggle(LinearLayout parent, String name, int element, final ToggleCallback cb) {
        LinearLayout row = newRow(parent, name);
        row.addView(makeSwatch(element), swatchParams());
        FrameLayout box = makeCheckbox();
        box.setOnClickListener(new View.OnClickListener() { // from class: com.lvteam.OverlayService$$ExternalSyntheticLambda27
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.lambda$addEspToggle$17(cb, view);
            }
        });
        row.addView(box, new LinearLayout.LayoutParams(dp(26), dp(26)));
        addRowLine(parent);
        return box;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$addEspToggle$17(ToggleCallback cb, View v) {
        if (LvSession.get().isActive()) {
            boolean on = !Boolean.TRUE.equals(v.getTag());
            v.setTag(Boolean.valueOf(on));
            applyCheckboxStyle((FrameLayout) v, on);
            cb.onToggle(on);
        }
    }

    private View makeSwatch(final int element) {
        View swatch = new View(this);
        final GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(7));
        bg.setColor(this.colors[this.elementColor[element]]);
        bg.setStroke(dp(1), TH_BORDER);
        swatch.setBackground(bg);
        swatch.setOnClickListener(new View.OnClickListener() { // from class: com.lvteam.OverlayService$$ExternalSyntheticLambda20
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.lambda$makeSwatch$18(element, bg, view);
            }
        });
        return swatch;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$makeSwatch$18(int element, GradientDrawable bg, View v) {
        this.elementColor[element] = (this.elementColor[element] + 1) % this.colors.length;
        bg.setColor(this.colors[this.elementColor[element]]);
        if (element == 4) {
            if (this.circleOverlay != null) {
                this.circleOverlay.setBackground(circleBackground());
                return;
            }
            return;
        }
        updateBoxStyle();
    }

    private LinearLayout.LayoutParams swatchParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(26), dp(26));
        lp.setMargins(0, 0, dp(10), 0);
        return lp;
    }

    private void addShiftToggle(LinearLayout parent, String name, final int shiftId) {
        LinearLayout row = newRow(parent, name);
        FrameLayout box = makeCheckbox();
        box.setOnClickListener(new View.OnClickListener() { // from class: com.lvteam.OverlayService$$ExternalSyntheticLambda14
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.lambda$addShiftToggle$19(shiftId, view);
            }
        });
        row.addView(box, new LinearLayout.LayoutParams(dp(26), dp(26)));
        addRowLine(parent);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$addShiftToggle$19(int shiftId, View v) {
        if (LvSession.get().isActive()) {
            boolean on = !Boolean.TRUE.equals(v.getTag());
            v.setTag(Boolean.valueOf(on));
            applyCheckboxStyle((FrameLayout) v, on);
            initShiftOverlayIfNeeded();
            switch (shiftId) {
                case 0:
                    LvShiftOverlay.setMagnetVisible(on);
                    break;
                case 1:
                    LvShiftOverlay.setGhostVisible(on);
                    break;
                case 2:
                    LvShiftOverlay.setTatuVisible(on);
                    break;
                case 3:
                    LvShiftOverlay.setTpBaseVisible(on);
                    break;
                case 4:
                    LvShiftOverlay.setWallVisible(on);
                    break;
            }
        }
    }

    private void addDropdownRow(LinearLayout parent, String name, final String[] options, int initial, final DropdownCallback cb) {
        LinearLayout linearLayoutNewRow = newRow(parent, name);
        final TextView dd = new TextView(this);
        dd.setTag(Integer.valueOf(initial));
        dd.setText(options[initial] + "  ▼");
        dd.setTextColor(TH_TEXT);
        dd.setTextSize(12.0f);
        dd.setTypeface(Typeface.create("sans-serif-medium", 0));
        dd.setGravity(17);
        dd.setPadding(dp(12), 0, dp(12), 0);
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(7));
        bg.setColor(TH_SURFACE);
        bg.setStroke(dp(1), TH_BORDER);
        dd.setBackground(bg);
        dd.setOnClickListener(new View.OnClickListener(options, dd, cb) { // from class: com.lvteam.OverlayService$$ExternalSyntheticLambda22
            public final /* synthetic */ String[] f$0;
            public final /* synthetic */ TextView f$1;

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                OverlayService.lambda$addDropdownRow$20(this.f$0, this.f$1, null, view);
            }
        });
        linearLayoutNewRow.addView(dd, new LinearLayout.LayoutParams(-2, dp(32)));
        addRowLine(parent);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void lambda$addDropdownRow$20(String[] options, TextView dd, DropdownCallback cb, View v) {
        int idx = (((Integer) v.getTag()).intValue() + 1) % options.length;
        v.setTag(Integer.valueOf(idx));
        dd.setText(options[idx] + "  ▼");
        if (cb != null) {
            cb.onSelect(idx);
        }
    }

    @SuppressLint({"ClickableViewAccessibility"})
    private void addSliderRow(LinearLayout linearLayout, String name, final String suffix, final int min, int max, int initial, final SliderCallback cb) {
        LinearLayout labelRow = new LinearLayout(this);
        labelRow.setGravity(16);
        labelRow.setPadding(dp(16), dp(8), dp(14), 0);
        TextView label = new TextView(this);
        label.setText(name);
        label.setTextColor(TH_TEXT);
        label.setTextSize(14.0f);
        labelRow.addView(label, new LinearLayout.LayoutParams(0, dp(26), 1.0f));
        final TextView valueLabel = new TextView(this);
        valueLabel.setText(initial + suffix);
        valueLabel.setTextColor(TH_ACCENT);
        valueLabel.setTextSize(13.0f);
        valueLabel.setTypeface(Typeface.DEFAULT_BOLD);
        valueLabel.setGravity(8388629);
        labelRow.addView(valueLabel, new LinearLayout.LayoutParams(-2, dp(26)));
        linearLayout.addView(labelRow, new LinearLayout.LayoutParams(-1, dp(34)));
        SeekBar seekBar = new SeekBar(this);
        seekBar.setMax(max - min);
        seekBar.setProgress(initial - min);
        seekBar.setProgressTintList(ColorStateList.valueOf(TH_ACCENT));
        seekBar.setThumbTintList(ColorStateList.valueOf(TH_ACCENT));
        seekBar.setProgressBackgroundTintList(ColorStateList.valueOf(TH_TOGGLE_OFF));
        seekBar.setOnTouchListener(new View.OnTouchListener() { // from class: com.lvteam.OverlayService$$ExternalSyntheticLambda25
            @Override // android.view.View.OnTouchListener
            public final boolean onTouch(View view, MotionEvent motionEvent) {
                return OverlayService.lambda$addSliderRow$21(view, motionEvent);
            }
        });
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() { // from class: com.lvteam.OverlayService.2
            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                int val = min + progress;
                valueLabel.setText(val + suffix);
                if (cb != null) {
                    cb.onChange(val);
                }
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStartTrackingTouch(SeekBar sb) {
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStopTrackingTouch(SeekBar sb) {
            }
        });
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-1, dp(28));
        slp.setMargins(dp(10), 0, dp(10), dp(6));
        linearLayout.addView(seekBar, slp);
        addRowLine(linearLayout);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ boolean lambda$addSliderRow$21(View v, MotionEvent ev) {
        v.getParent().requestDisallowInterceptTouchEvent(true);
        return false;
    }

    private FrameLayout makeCheckbox() {
        FrameLayout cb = new FrameLayout(this);
        TextView check = new TextView(this);
        check.setText("✓");
        check.setTextSize(15.0f);
        check.setTypeface(Typeface.DEFAULT_BOLD);
        check.setGravity(17);
        cb.addView(check, new FrameLayout.LayoutParams(-1, -1));
        cb.setTag(false);
        applyCheckboxStyle(cb, false);
        return cb;
    }

    private void applyCheckboxStyle(FrameLayout cb, boolean on) {
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(8));
        if (on) {
            bg.setColor(TH_TOGGLE_ON);
            bg.setStroke(dp(1), -11549705);
        } else {
            bg.setColor(TH_CHECK_OFF);
            bg.setStroke(dp(1), TH_BORDER);
        }
        cb.setBackground(bg);
        ((TextView) cb.getChildAt(0)).setTextColor(on ? -1 : 16777215);
    }

    private void addInfoRow(LinearLayout linearLayout, String key, String value) {
        LinearLayout row = new LinearLayout(this);
        row.setPadding(dp(16), 0, dp(14), 0);
        row.setGravity(16);
        TextView kTv = new TextView(this);
        kTv.setText(key);
        kTv.setTextColor(TH_TEXT_DIM);
        kTv.setTextSize(13.0f);
        row.addView(kTv, new LinearLayout.LayoutParams(0, dp(38), 1.0f));
        TextView vTv = new TextView(this);
        vTv.setText(value);
        vTv.setTextColor(TH_TEXT);
        vTv.setTextSize(13.0f);
        vTv.setTypeface(Typeface.create("sans-serif-medium", 0));
        vTv.setGravity(8388629);
        row.addView(vTv, new LinearLayout.LayoutParams(-2, dp(38)));
        linearLayout.addView(row, new LinearLayout.LayoutParams(-1, dp(38)));
        addRowLine(linearLayout);
    }

    private void addSectionLabel(LinearLayout linearLayout, String text) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(16);
        row.setPadding(dp(16), dp(10), dp(14), dp(4));
        View l1 = new View(this);
        l1.setBackgroundColor(TH_DIVIDER);
        row.addView(l1, new LinearLayout.LayoutParams(0, dp(1), 1.0f));
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(TH_TEXT_DIM);
        tv.setTextSize(10.0f);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setLetterSpacing(0.18f);
        tv.setGravity(17);
        tv.setPadding(dp(10), 0, dp(10), 0);
        row.addView(tv);
        View l2 = new View(this);
        l2.setBackgroundColor(TH_DIVIDER);
        row.addView(l2, new LinearLayout.LayoutParams(0, dp(1), 1.0f));
        linearLayout.addView(row);
    }

    private void buildThicknessPicker(LinearLayout parent) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(16);
        row.setPadding(dp(16), dp(2), dp(14), dp(6));
        TextView prev = styledArrow("◂");
        prev.setOnClickListener(new View.OnClickListener() { // from class: com.lvteam.OverlayService$$ExternalSyntheticLambda11
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.lambda$buildThicknessPicker$22(view);
            }
        });
        row.addView(prev, new LinearLayout.LayoutParams(dp(32), dp(32)));
        this.thicknessLabel = new TextView(this);
        this.thicknessLabel.setText(String.valueOf(this.thicknesses[this.thicknessIndex]));
        this.thicknessLabel.setTextColor(TH_TEXT);
        this.thicknessLabel.setTextSize(12.0f);
        this.thicknessLabel.setTypeface(Typeface.DEFAULT_BOLD);
        this.thicknessLabel.setGravity(17);
        row.addView(this.thicknessLabel, new LinearLayout.LayoutParams(0, dp(32), 1.0f));
        TextView next = styledArrow("▸");
        next.setOnClickListener(new View.OnClickListener() { // from class: com.lvteam.OverlayService$$ExternalSyntheticLambda12
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.lambda$buildThicknessPicker$23(view);
            }
        });
        row.addView(next, new LinearLayout.LayoutParams(dp(32), dp(32)));
        parent.addView(row);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$buildThicknessPicker$22(View v) {
        changeThickness(-1);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$buildThicknessPicker$23(View v) {
        changeThickness(1);
    }

    private TextView styledArrow(String arrow) {
        TextView v = new TextView(this);
        v.setText(arrow);
        v.setTextColor(TH_ACCENT);
        v.setTextSize(15.0f);
        v.setGravity(17);
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(7));
        bg.setColor(TH_SURFACE);
        bg.setStroke(dp(1), TH_BORDER);
        v.setBackground(bg);
        return v;
    }

    private void setMinimized(boolean m) {
        this.minimized = m;
        if (m) {
            this.overlay.setBackground(null);
            this.overlay.setClipToOutline(false);
        } else {
            this.overlayBackground.setColor(TH_BG);
            this.overlayBackground.setCornerRadius(dp(16));
            this.overlayBackground.setStroke(dp(1), TH_BORDER);
            this.overlay.setBackground(this.overlayBackground);
            this.overlay.setClipToOutline(true);
        }
        this.headerContainer.setVisibility(m ? 8 : 0);
        this.bodyContainer.setVisibility(m ? 8 : 0);
        this.appIcon.setVisibility(m ? 0 : 8);
        this.overlayParams.width = m ? dp(56) : menuWidth();
        this.overlayParams.height = m ? dp(56) : menuHeight();
        this.windowManager.updateViewLayout(this.overlay, this.overlayParams);
    }

    private void changeThickness(int dir) {
        int next = this.thicknessIndex + dir;
        if (next < 0 || next >= this.thicknesses.length) {
            return;
        }
        this.thicknessIndex = next;
        this.thicknessLabel.setText(String.valueOf(this.thicknesses[this.thicknessIndex]));
        if (this.circleOverlay != null) {
            this.circleOverlay.setBackground(circleBackground());
        }
        updateBoxStyle();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setCircleEnabled(boolean enabled) {
        int type;
        if (!enabled || this.circleOverlay != null) {
            if (!enabled) {
                removeCircle();
                return;
            }
            return;
        }
        this.circleOverlay = new View(this);
        this.circleOverlay.setBackground(circleBackground());
        int size = (dp(120) * this.fovPercent) / 100;
        if (Build.VERSION.SDK_INT >= 26) {
            type = 2038;
        } else {
            type = 2002;
        }
        this.circleParams = new WindowManager.LayoutParams(size, size, type, 792, -3);
        this.circleParams.gravity = 17;
        this.windowManager.addView(this.circleOverlay, this.circleParams);
    }

    private void updateCircleSize() {
        if (this.circleOverlay != null && this.circleParams != null) {
            int size = (dp(120) * this.fovPercent) / 100;
            this.circleParams.width = size;
            this.circleParams.height = size;
            this.circleOverlay.setBackground(circleBackground());
            this.windowManager.updateViewLayout(this.circleOverlay, this.circleParams);
        }
    }

    private void removeCircle() {
        if (this.circleOverlay != null) {
            this.windowManager.removeView(this.circleOverlay);
            this.circleOverlay = null;
            this.circleParams = null;
        }
    }

    private void updateEspOverlay() {
        int type;
        boolean needed = this.espEnabled || this.enemyCounterEnabled;
        if (needed && this.boxOverlay == null) {
            this.boxOverlay = new EspOverlayView(this);
            updateBoxStyle();
            updateBoxOptions();
            if (Build.VERSION.SDK_INT >= 26) {
                type = 2038;
            } else {
                type = 2002;
            }
            WindowManager.LayoutParams p = new WindowManager.LayoutParams(-1, -1, type, 792, -3);
            p.gravity = 8388659;
            if (Build.VERSION.SDK_INT >= 28) {
                p.layoutInDisplayCutoutMode = 1;
            }
            this.windowManager.addView(this.boxOverlay, p);
            Choreographer.getInstance().postFrameCallback(this.espFrame);
        } else if (!needed) {
            removeBox();
        }
        updateBoxOptions();
        if (!this.enemyCounterEnabled) {
            removeEnemyCounter();
        } else {
            setEnemyCounterEnabled(true);
        }
    }

    private void updateBoxStyle() {
        if (this.boxOverlay == null) {
            return;
        }
        this.boxOverlay.setColors(this.colors[this.elementColor[0]], this.colors[this.elementColor[1]], this.colors[this.elementColor[2]], this.colors[this.elementColor[3]]);
        this.boxOverlay.setThickness(this.thicknesses[this.thicknessIndex]);
    }

    private void updateBoxOptions() {
        if (this.boxOverlay != null) {
            EspOverlayView espOverlayView = this.boxOverlay;
            boolean z = false;
            boolean z2 = this.espEnabled && this.boxEnabled;
            boolean z3 = this.espEnabled && this.drawLine;
            boolean z4 = this.espEnabled && this.drawDistance;
            if (this.espEnabled && this.drawName) {
                z = true;
            }
            espOverlayView.setDrawOptions(z2, z3, z4, z);
        }
    }

    private void removeBox() {
        Choreographer.getInstance().removeFrameCallback(this.espFrame);
        if (this.boxOverlay != null) {
            this.windowManager.removeView(this.boxOverlay);
            this.boxOverlay = null;
        }
    }

    private void startPlayerListUpdater() {
        this.playerUpdateHandler = new Handler(Looper.getMainLooper());
        this.playerUpdateHandler.postDelayed(new Runnable() { // from class: com.lvteam.OverlayService.3
            @Override // java.lang.Runnable
            public void run() {
                if (!OverlayService.this.minimized && OverlayService.this.activeTab == 2) {
                    OverlayService.this.refreshPlayerList();
                }
                if (OverlayService.this.playerUpdateHandler != null) {
                    OverlayService.this.playerUpdateHandler.postDelayed(this, 500L);
                }
            }
        }, 500L);
    }

    private void syncIgnoredSlots() {
        List<Integer> slots = new ArrayList<>(this.ignoredIds.size());
        for (Integer id : this.ignoredIds) {
            int slot = EntityState.slotOfRenderId(id.intValue());
            if (slot > 0) {
                slots.add(Integer.valueOf(slot));
            }
        }
        LvTeamShift.setIgnoredSlots(slots);
    }

    private void toggleIgnored(int entityId) {
        if (!this.ignoredIds.remove(Integer.valueOf(entityId))) {
            this.ignoredIds.add(Integer.valueOf(entityId));
        }
        syncIgnoredSlots();
        refreshPlayerList();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void refreshPlayerList() {
        if (this.playerListContainer == null) {
            return;
        }
        List<EspOverlayView.Entity> entities = this.lastProjected;
        this.playerListContainer.removeAllViews();
        int i = 0;
        if (entities == null || entities.isEmpty()) {
            if (this.playerEmptyLabel != null) {
                this.playerEmptyLabel.setVisibility(0);
                return;
            }
            return;
        }
        if (this.playerEmptyLabel != null) {
            this.playerEmptyLabel.setVisibility(8);
        }
        int idx = 0;
        for (EspOverlayView.Entity e : entities) {
            idx++;
            if (idx <= 20) {
                final int entityId = e.id;
                boolean ignored = this.ignoredIds.contains(Integer.valueOf(entityId));
                LinearLayout row = new LinearLayout(this);
                row.setGravity(16);
                row.setPadding(dp(16), i, dp(14), i);
                row.setOnClickListener(new View.OnClickListener() { // from class: com.lvteam.OverlayService$$ExternalSyntheticLambda15
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        this.f$0.lambda$refreshPlayerList$24(entityId, view);
                    }
                });
                TextView nameTv = new TextView(this);
                nameTv.setText(e.name != null ? e.name : "Enemy " + idx);
                int i2 = TH_TEXT_DIM;
                nameTv.setTextColor(ignored ? TH_TEXT_DIM : TH_TEXT);
                nameTv.setTextSize(12.0f);
                nameTv.setSingleLine(true);
                row.addView(nameTv, new LinearLayout.LayoutParams(i, dp(38), 1.0f));
                TextView distTv = new TextView(this);
                distTv.setText(Math.round(e.distanceMeters) + "m");
                if (!ignored) {
                    i2 = TH_ACCENT;
                }
                distTv.setTextColor(i2);
                distTv.setTextSize(12.0f);
                distTv.setTypeface(Typeface.DEFAULT_BOLD);
                distTv.setGravity(8388629);
                LinearLayout.LayoutParams distLp = new LinearLayout.LayoutParams(dp(42), dp(38));
                distLp.setMargins(i, i, dp(12), i);
                row.addView(distTv, distLp);
                FrameLayout box = makeCheckbox();
                box.setTag(Boolean.valueOf(ignored));
                applyCheckboxStyle(box, ignored);
                box.setOnClickListener(new View.OnClickListener() { // from class: com.lvteam.OverlayService$$ExternalSyntheticLambda16
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        this.f$0.lambda$refreshPlayerList$25(entityId, view);
                    }
                });
                row.addView(box, new LinearLayout.LayoutParams(dp(22), dp(22)));
                this.playerListContainer.addView(row, new LinearLayout.LayoutParams(-1, dp(38)));
                addRowLine(this.playerListContainer);
                i = 0;
            } else {
                return;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$refreshPlayerList$24(int entityId, View v) {
        toggleIgnored(entityId);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$refreshPlayerList$25(int entityId, View v) {
        toggleIgnored(entityId);
    }

    private void setEnemyCounterEnabled(boolean enabled) {
        int type;
        if (enabled && this.boxOverlay == null) {
            return;
        }
        if (!enabled || this.enemyCounterOverlay != null) {
            if (!enabled) {
                removeEnemyCounter();
                return;
            }
            return;
        }
        this.enemyCounterOverlay = new LinearLayout(this);
        this.enemyCounterOverlay.setOrientation(1);
        this.enemyCounterOverlay.setGravity(17);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(-1441787864);
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), 1073800703);
        this.enemyCounterOverlay.setBackground(bg);
        this.enemyCounterOverlay.setPadding(dp(10), dp(2), dp(10), dp(2));
        this.enemyValue = new TextView(this);
        this.enemyValue.setText("Enemy 0");
        this.enemyValue.setTextColor(-1);
        this.enemyValue.setTextSize(13.0f);
        this.enemyValue.setTypeface(Typeface.DEFAULT_BOLD);
        this.enemyValue.setGravity(17);
        this.enemyCounterOverlay.addView(this.enemyValue, new LinearLayout.LayoutParams(-2, dp(22)));
        if (Build.VERSION.SDK_INT >= 26) {
            type = 2038;
        } else {
            type = 2002;
        }
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(-2, dp(26), type, 792, -3);
        p.gravity = 49;
        p.y = dp(58);
        this.windowManager.addView(this.enemyCounterOverlay, p);
    }

    private void removeEnemyCounter() {
        if (this.enemyCounterOverlay != null) {
            this.windowManager.removeView(this.enemyCounterOverlay);
            this.enemyCounterOverlay = null;
            this.enemyValue = null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updateEnemyCounter(int count) {
        if (this.enemyValue != null) {
            this.enemyValue.setText("Enemy " + count);
        }
    }

    private void showTeamTitle() {
        int type;
        if (this.teamTitleOverlay != null) {
            return;
        }
        FrameLayout frame = new FrameLayout(this);
        this.teamTitleOverlay = new TextView(this);
        this.teamTitleOverlay.setText(R.string.title_lv_team);
        this.teamTitleOverlay.setTextColor(-1157569025);
        this.teamTitleOverlay.setTextSize(11.0f);
        this.teamTitleOverlay.setTypeface(Typeface.create("sans-serif-medium", 1));
        this.teamTitleOverlay.setLetterSpacing(0.2f);
        this.teamTitleOverlay.setGravity(17);
        this.teamTitleOverlay.setShadowLayer(4.0f, 0.0f, 1.0f, Integer.MIN_VALUE);
        frame.addView(this.teamTitleOverlay, new FrameLayout.LayoutParams(-1, -1));
        if (Build.VERSION.SDK_INT >= 26) {
            type = 2038;
        } else {
            type = 2002;
        }
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(dp(140), dp(20), type, 792, -3);
        p.gravity = 49;
        p.y = dp(16);
        this.windowManager.addView(frame, p);
    }

    private void removeTeamTitle() {
        if (this.teamTitleOverlay != null) {
            this.windowManager.removeView((View) this.teamTitleOverlay.getParent());
            this.teamTitleOverlay = null;
        }
    }

    private void initShiftOverlayIfNeeded() {
        if (LvShiftOverlay.ctx == null) {
            LvShiftOverlay.init(this);
        }
    }

    private void startSessionCheck() {
        this.sessionCheckHandler = new Handler(Looper.getMainLooper());
        this.sessionCheckHandler.postDelayed(new Runnable() { // from class: com.lvteam.OverlayService.4
            @Override // java.lang.Runnable
            public void run() {
                if (!LvSession.get().isActive()) {
                    OverlayService.this.killApp("Sessao expirada.");
                    return;
                }
                try {
                    int bits = NativeGuard.pulse();
                    if (bits != 0) {
                        LvSession.get().invalidate();
                        OverlayService.this.killApp("Sessao encerrada.");
                        return;
                    }
                } catch (UnsatisfiedLinkError e) {
                }
                if (OverlayService.this.sessionCheckHandler != null) {
                    OverlayService.this.sessionCheckHandler.postDelayed(this, 120000L);
                }
            }
        }, 120000L);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void killApp(String message) {
        try {
            Toast.makeText(getApplicationContext(), message, 1).show();
        } catch (Exception e) {
        }
        stopSelf();
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() { // from class: com.lvteam.OverlayService$$ExternalSyntheticLambda26
            @Override // java.lang.Runnable
            public final void run() {
                OverlayService.lambda$killApp$26();
            }
        }, 1500L);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void lambda$killApp$26() {
        Process.killProcess(Process.myPid());
        System.exit(0);
    }

    public EspEngine espEngine() {
        return this.espEngine;
    }

    public EntityState entityState() {
        return this.entityState;
    }

    private GradientDrawable circleBackground() {
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(1);
        bg.setColor(0);
        bg.setStroke(Math.round(this.thicknesses[this.thicknessIndex] * getResources().getDisplayMetrics().density), this.colors[this.elementColor[4]]);
        return bg;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private String appVersionName() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "-";
        }
    }

    public class DraggableLayout extends FrameLayout {
        public DraggableLayout(Context context) {
            super(context);
        }

        @Override // android.view.ViewGroup
        public boolean onInterceptTouchEvent(MotionEvent ev) {
            switch (ev.getAction()) {
                case 0:
                    OverlayService.this.initialX = OverlayService.this.overlayParams.x;
                    OverlayService.this.initialY = OverlayService.this.overlayParams.y;
                    OverlayService.this.initialTouchX = ev.getRawX();
                    OverlayService.this.initialTouchY = ev.getRawY();
                    return false;
                case 1:
                default:
                    return false;
                case 2:
                    if (Math.abs(ev.getRawX() - OverlayService.this.initialTouchX) > OverlayService.this.dp(6) || Math.abs(ev.getRawY() - OverlayService.this.initialTouchY) > OverlayService.this.dp(6)) {
                        return true;
                    }
                    return false;
            }
        }

        @Override // android.view.View
        public boolean onTouchEvent(MotionEvent ev) {
            switch (ev.getAction()) {
                case 1:
                case 3:
                    return true;
                case 2:
                    OverlayService.this.overlayParams.x = OverlayService.this.initialX + ((int) (ev.getRawX() - OverlayService.this.initialTouchX));
                    OverlayService.this.overlayParams.y = OverlayService.this.initialY + ((int) (ev.getRawY() - OverlayService.this.initialTouchY));
                    OverlayService.this.windowManager.updateViewLayout(this, OverlayService.this.overlayParams);
                    return true;
                default:
                    return super.onTouchEvent(ev);
            }
        }
    }
}
