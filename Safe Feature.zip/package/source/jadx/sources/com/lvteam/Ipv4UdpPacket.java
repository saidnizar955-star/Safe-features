package com.lvteam;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Arrays;

/* JADX INFO: loaded from: classes.dex */
public final class Ipv4UdpPacket {
    public final InetAddress destinationAddress;
    public final int destinationPort;
    public final byte[] payload;
    public final InetAddress sourceAddress;
    public final int sourcePort;

    public Ipv4UdpPacket(InetAddress sourceAddress, InetAddress destinationAddress, int sourcePort, int destinationPort, byte[] payload) {
        this.sourceAddress = sourceAddress;
        this.destinationAddress = destinationAddress;
        this.sourcePort = sourcePort;
        this.destinationPort = destinationPort;
        this.payload = payload;
    }

    public static Ipv4UdpPacket parse(byte[] frame, int frameLength) {
        int udpLength;
        if (frameLength < 20 || (frame[0] >>> 4) != 4) {
            return null;
        }
        int headerLength = (frame[0] & 15) * 4;
        int totalLength = unsignedShort(frame, 2);
        if (headerLength < 20 || headerLength > frameLength || totalLength < headerLength + 8 || totalLength > frameLength || frame[9] != 17 || !hasValidIpv4Checksum(frame, headerLength)) {
            return null;
        }
        int fragmentField = unsignedShort(frame, 6);
        if ((fragmentField & 16383) != 0 || (udpLength = unsignedShort(frame, headerLength + 4)) < 8 || udpLength > totalLength - headerLength || (unsignedShort(frame, headerLength + 6) != 0 && !hasValidUdpChecksum(frame, headerLength, udpLength))) {
            return null;
        }
        try {
            InetAddress source = InetAddress.getByAddress(Arrays.copyOfRange(frame, 12, 16));
            InetAddress destination = InetAddress.getByAddress(Arrays.copyOfRange(frame, 16, 20));
            int sourcePort = unsignedShort(frame, headerLength);
            int destinationPort = unsignedShort(frame, headerLength + 2);
            byte[] payload = Arrays.copyOfRange(frame, headerLength + 8, headerLength + udpLength);
            return new Ipv4UdpPacket(source, destination, sourcePort, destinationPort, payload);
        } catch (UnknownHostException e) {
            return null;
        }
    }

    public static byte[] response(InetAddress sourceAddress, int sourcePort, InetAddress destinationAddress, int destinationPort, byte[] payload, int identification) {
        int totalLength = payload.length + 28;
        byte[] frame = new byte[totalLength];
        frame[0] = 69;
        writeShort(frame, 2, totalLength);
        writeShort(frame, 4, identification);
        frame[8] = 64;
        frame[9] = 17;
        System.arraycopy(sourceAddress.getAddress(), 0, frame, 12, 4);
        System.arraycopy(destinationAddress.getAddress(), 0, frame, 16, 4);
        writeShort(frame, 20, sourcePort);
        writeShort(frame, 22, destinationPort);
        writeShort(frame, 24, payload.length + 8);
        System.arraycopy(payload, 0, frame, 28, payload.length);
        writeShort(frame, 10, checksum(frame, 0, 20));
        return frame;
    }

    public static byte[] replacePayload(byte[] originalFrame, int originalLength, byte[] newPayload) {
        int headerLength;
        if (originalLength < 20 || (originalFrame[0] >>> 4) != 4 || (headerLength = (originalFrame[0] & 15) * 4) < 20 || headerLength + 8 > originalLength) {
            return null;
        }
        int payloadStart = headerLength + 8;
        int newTotalLength = newPayload.length + payloadStart;
        byte[] result = new byte[newTotalLength];
        System.arraycopy(originalFrame, 0, result, 0, payloadStart);
        System.arraycopy(newPayload, 0, result, payloadStart, newPayload.length);
        writeShort(result, 2, newTotalLength);
        writeShort(result, headerLength + 4, newPayload.length + 8);
        writeShort(result, headerLength + 6, 0);
        writeShort(result, 10, 0);
        writeShort(result, 10, checksum(result, 0, headerLength));
        return result;
    }

    public static boolean hasValidIpv4Checksum(byte[] data, int headerLength) {
        return checksum(data, 0, headerLength) == 0;
    }

    public static boolean hasValidUdpChecksum(byte[] data, int udpOffset, int udpLength) {
        long sum = udpLength + 17;
        for (int i = 12; i < 20; i += 2) {
            sum += (long) unsignedShort(data, i);
        }
        for (int i2 = udpOffset; i2 < udpOffset + udpLength; i2 += 2) {
            int word = (data[i2] & 255) << 8;
            if (i2 + 1 < udpOffset + udpLength) {
                word |= data[i2 + 1] & 255;
            }
            sum += (long) word;
        }
        while ((sum >>> 16) != 0) {
            sum = (sum & 65535) + (sum >>> 16);
        }
        return (sum & 65535) == 65535;
    }

    public static int checksum(byte[] data, int offset, int length) {
        int sum = 0;
        for (int i = offset; i < offset + length; i += 2) {
            sum += ((data[i] & 255) << 8) | (data[i + 1] & 255);
        }
        while (i != 0) {
            sum = (sum & 65535) + (sum >>> 16);
        }
        return (~sum) & 65535;
    }

    public static int unsignedShort(byte[] data, int offset) {
        return ((data[offset] & 255) << 8) | (data[offset + 1] & 255);
    }

    public static void writeShort(byte[] data, int offset, int value) {
        data[offset] = (byte) (value >>> 8);
        data[offset + 1] = (byte) value;
    }
}
