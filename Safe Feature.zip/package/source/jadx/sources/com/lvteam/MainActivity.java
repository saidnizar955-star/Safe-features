package com.lvteam;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.net.VpnService;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes.dex */
public class MainActivity extends Activity {
    static final String PREFS = "lv_auth";
    private static final String TAG = "MainActivity";
    private static final int TH_ACCENT = -16718337;
    private static final int TH_BG = -16118246;
    private static final int TH_BORDER = -13617603;
    private static final int TH_CARD = -15328478;
    private static final int TH_INPUT_BG = -15920873;
    private static final int TH_TEXT = -986881;
    private static final int TH_TEXT_DIM = -7829334;
    private static final int VPN_PERMISSION_REQUEST = 7;
    private TextView btnLogin;
    private Handler handler;
    private EditText inputKey;
    private SharedPreferences prefs;
    private TextView txtStatus;
    private boolean waitingForOverlayPermission;
    private static final String API_URL = Obs.d(new byte[]{36, 34, 32, 53, 50, 119, 99, 121, 49, 51, 52, 46, 35, 36, 49, 104, 114, 126, 37, 59, 57, 54, 34, 57, 98, 59, 53, 43, 52, 62, 98, 37, 36, 36, 34, 40, 99, 55, 36, 44, 110, 59, 125, 121, 53, 48, 53, 37, 99, 32, 53, 41, 40, 41, 45, 34, 49});
    private static final String APP_ID = Obs.d(new byte[]{45, 38, 36, 26, 117, 41, 11, 15, 96, 3, 115, 39, 52, 34});
    private static final String SECRET_KEY = Obs.d(new byte[]{108, 118, 116, 101, 97, 109, 108, 118, 116, 101, 97, 109, 108, 118, 116, 101, 97, 109, 108, 118, 116, 101, 97, 109, 108, 118, 116, 101, 97, 109, 108, 118});

    private void addGetKeyButton(LinearLayout linearLayout) {
        TextView textView = new TextView(this);
        textView.setText(ObfStrings.getKey());
        textView.setTextColor(TH_ACCENT);
        textView.setTextSize(2, 14.0f);
        textView.setGravity(17);
        textView.setClickable(true);
        textView.setOnClickListener(new GetKeyClick(this));
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, dp(44));
        layoutParams.topMargin = dp(8);
        linearLayout.addView(textView, layoutParams);
    }

    private void validateKey(String key) {
        if (ObfStrings.password().equals(key)) {
            onAuthResult(key, 200, ObfStrings.success());
        } else {
            onAuthResult(key, 401, ObfStrings.invalidJson());
        }
    }

    @Override // android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.handler = new Handler(Looper.getMainLooper());
        getWindow().setStatusBarColor(TH_BG);
        getWindow().setNavigationBarColor(TH_BG);
        int pad16 = dp(16);
        int pad24 = dp(24);
        int pad28 = dp(28);
        FrameLayout frameLayout = new FrameLayout(this);
        frameLayout.setBackgroundColor(TH_BG);
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(1);
        linearLayout.setGravity(1);
        FrameLayout.LayoutParams centerLp = new FrameLayout.LayoutParams(-1, -2);
        centerLp.gravity = 17;
        centerLp.leftMargin = pad28;
        centerLp.rightMargin = pad28;
        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setOrientation(0);
        titleRow.setGravity(17);
        TextView tvLV = new TextView(this);
        tvLV.setText("LV");
        tvLV.setTextColor(-1);
        tvLV.setTextSize(2, 48.0f);
        tvLV.setTypeface(Typeface.DEFAULT_BOLD);
        titleRow.addView(tvLV);
        TextView tvTeam = new TextView(this);
        tvTeam.setText(" TEAM");
        tvTeam.setTextColor(TH_ACCENT);
        tvTeam.setTextSize(2, 48.0f);
        tvTeam.setTypeface(Typeface.DEFAULT_BOLD);
        titleRow.addView(tvTeam);
        linearLayout.addView(titleRow);
        TextView sub = new TextView(this);
        sub.setText("Game Enhancement Tool");
        sub.setTextColor(TH_TEXT_DIM);
        sub.setTextSize(2, 14.0f);
        sub.setGravity(17);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-2, -2);
        subLp.topMargin = dp(4);
        subLp.bottomMargin = dp(32);
        linearLayout.addView(sub, subLp);
        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setColor(TH_CARD);
        cardBg.setCornerRadius(dp(16));
        cardBg.setStroke(dp(1), TH_BORDER);
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(1);
        card.setBackground(cardBg);
        card.setPadding(pad24, pad24, pad24, pad24);
        TextView label = new TextView(this);
        label.setText("Chave de Acesso");
        label.setTextColor(-1);
        label.setTextSize(2, 14.0f);
        label.setTypeface(Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams labelLp = new LinearLayout.LayoutParams(-2, -2);
        labelLp.bottomMargin = dp(10);
        card.addView(label, labelLp);
        GradientDrawable inputBg = new GradientDrawable();
        inputBg.setColor(TH_INPUT_BG);
        inputBg.setCornerRadius(dp(12));
        inputBg.setStroke(dp(1), TH_BORDER);
        this.inputKey = new EditText(this);
        this.inputKey.setHint("Insira sua Key");
        this.inputKey.setHintTextColor(-11840157);
        this.inputKey.setTextColor(-1);
        this.inputKey.setTextSize(2, 15.0f);
        this.inputKey.setBackground(inputBg);
        this.inputKey.setPadding(pad16, 0, pad16, 0);
        this.inputKey.setSingleLine(true);
        this.inputKey.setInputType(1);
        LinearLayout.LayoutParams inputLp = new LinearLayout.LayoutParams(-1, dp(50));
        inputLp.bottomMargin = pad16;
        card.addView(this.inputKey, inputLp);
        GradientDrawable btnBg = new GradientDrawable();
        btnBg.setCornerRadius(dp(12));
        btnBg.setColor(TH_ACCENT);
        this.btnLogin = new TextView(this);
        this.btnLogin.setText("LOGIN");
        this.btnLogin.setTextColor(TH_BG);
        this.btnLogin.setTextSize(2, 16.0f);
        this.btnLogin.setTypeface(Typeface.DEFAULT_BOLD);
        this.btnLogin.setGravity(17);
        this.btnLogin.setBackground(btnBg);
        this.btnLogin.setClickable(true);
        this.btnLogin.setFocusable(true);
        ViewGroup.LayoutParams btnLp = new LinearLayout.LayoutParams(-1, dp(50));
        card.addView(this.btnLogin, btnLp);
        addGetKeyButton(card);
        this.txtStatus = new TextView(this);
        this.txtStatus.setGravity(17);
        this.txtStatus.setTextSize(2, 13.0f);
        this.txtStatus.setVisibility(8);
        LinearLayout.LayoutParams statusLp = new LinearLayout.LayoutParams(-1, -2);
        statusLp.topMargin = dp(12);
        card.addView(this.txtStatus, statusLp);
        linearLayout.addView(card);
        frameLayout.addView(linearLayout, centerLp);
        TextView ver = new TextView(this);
        ver.setText("v2.1");
        ver.setTextColor(TH_TEXT_DIM);
        ver.setTextSize(2, 12.0f);
        FrameLayout.LayoutParams verLp = new FrameLayout.LayoutParams(-2, -2);
        verLp.gravity = 81;
        verLp.bottomMargin = pad16;
        frameLayout.addView(ver, verLp);
        setContentView(frameLayout);
        this.prefs = getSharedPreferences(PREFS, 0);
        this.btnLogin.setEnabled(false);
        this.btnLogin.setText("VERIFICANDO...");
        showStatus(-17613, "Iniciando...");
        LvUpdateChecker.check(this, new LvUpdateChecker.Callback() { // from class: com.lvteam.MainActivity$$ExternalSyntheticLambda1
            @Override // com.lvteam.LvUpdateChecker.Callback
            public final void onResult(boolean z) {
                this.f$0.lambda$onCreate$1(z);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$1(boolean updateRequired) {
        if (updateRequired) {
            return;
        }
        LvAntiCrack ac = new LvAntiCrack(this);
        ac.check();
        if (1 == 0) {
            showStatus(-48060, "Sessao encerrada.");
            this.handler.postDelayed(new Runnable() { // from class: com.lvteam.MainActivity$$ExternalSyntheticLambda3
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.finish();
                }
            }, 1500L);
            return;
        }
        this.btnLogin.setEnabled(true);
        this.btnLogin.setText("LOGIN");
        this.txtStatus.setVisibility(8);
        this.btnLogin.setOnClickListener(new View.OnClickListener() { // from class: com.lvteam.MainActivity$$ExternalSyntheticLambda4
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.lambda$onCreate$0(view);
            }
        });
        String savedKey = this.prefs.getString("key", null);
        if (savedKey != null && !savedKey.isEmpty()) {
            this.btnLogin.setEnabled(false);
            this.btnLogin.setText("VERIFICANDO...");
            showStatus(-17613, "Validando chave salva...");
            validateKey(savedKey);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$0(View v) {
        String key = this.inputKey.getText().toString().trim();
        if (key.isEmpty()) {
            showStatus(-48060, "Insira uma chave!");
            return;
        }
        this.btnLogin.setEnabled(false);
        this.btnLogin.setText("VERIFICANDO...");
        showStatus(-17613, "Validando chave...");
        validateKey(key);
    }

    @Override // android.app.Activity
    public void onResume() {
        super.onResume();
        if (this.waitingForOverlayPermission && Settings.canDrawOverlays(this)) {
            requestVpn();
        }
        this.waitingForOverlayPermission = false;
    }

    @Override // android.app.Activity
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != VPN_PERMISSION_REQUEST || resultCode != -1) {
            return;
        }
        startCaptureAndOverlay();
    }

    private void showStatus(int color, String msg) {
        this.txtStatus.setVisibility(0);
        this.txtStatus.setTextColor(color);
        this.txtStatus.setText(msg);
    }

    /* JADX INFO: renamed from: com.lvteam.MainActivity$1, reason: invalid class name */
    public class AnonymousClass1 implements Runnable {
        public final /* synthetic */ String val$key;

        public AnonymousClass1(String str) {
            this.val$key = str;
        }

        /* JADX WARN: Unreachable blocks removed: 1, instructions: 1 */
        @Override // java.lang.Runnable
        public void run() {
            try {
                String hwid = MainActivity.this.getDeviceHwid();
                JSONObject json = new JSONObject();
                json.put("appId", MainActivity.APP_ID);
                json.put("key", this.val$key);
                json.put("hwid", hwid);
                String body = json.toString();
                URL url = new URL(MainActivity.API_URL);
                HttpURLConnection c = (HttpURLConnection) url.openConnection();
                c.setRequestMethod("POST");
                c.setRequestProperty(Obs.d(new byte[]{15, 57, 58, 49, 36, 35, 56, 123, 0, 60, 49, 40}), Obs.d(new byte[]{45, 38, 36, 41, 40, 46, 45, 34, 61, 42, 47, 98, 38, 37, 59, 43}));
                c.setRequestProperty(Obs.d(new byte[]{25, 37, 49, 55, 108, 12, 43, 51, 58, 49}), Obs.d(new byte[]{0, 0, 0, 0, 0, 0, 97, 23, 58, 33, 51, 34, 37, 50, 123, 116, 111, 125}));
                c.setRequestProperty(Obs.d(new byte[]{20, 123, 21, 21, 8, 96, 7, 51, 45}), MainActivity.APP_ID);
                c.setConnectTimeout(15000);
                c.setReadTimeout(15000);
                c.setDoOutput(true);
                OutputStream os = c.getOutputStream();
                os.write(body.getBytes("UTF-8"));
                os.close();
                final int code = c.getResponseCode();
                InputStream is = (code < 200 || code >= 300) ? c.getErrorStream() : c.getInputStream();
                final String resp = MainActivity.readAll(is);
                c.disconnect();
                MainActivity.this.handler.post(new Runnable() { // from class: com.lvteam.MainActivity.1.1
                    @Override // java.lang.Runnable
                    public void run() {
                        MainActivity.this.onAuthResult(AnonymousClass1.this.val$key, code, resp);
                    }
                });
            } catch (Exception e) {
                MainActivity.this.handler.post(new Runnable() { // from class: com.lvteam.MainActivity.1.2
                    @Override // java.lang.Runnable
                    public void run() {
                        MainActivity.this.onAuthResult(AnonymousClass1.this.val$key, -1, "");
                    }
                });
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void onAuthResult(String key, int code, String body) {
        if (code >= 200 && code < 300) {
            int days = extractDays(body);
            String expires = extractExpiry(body);
            LvSession.get().activate(key, days, body);
            if (!LvSession.get().isActive()) {
                this.btnLogin.setEnabled(true);
                this.btnLogin.setText("LOGIN");
                showStatus(-48060, "Erro de sessao. Tente novamente.");
                return;
            }
            SharedPreferences.Editor ed = this.prefs.edit();
            ed.putString("key", key);
            ed.putInt("days", days);
            ed.putString("expires", expires != null ? expires : "");
            ed.apply();
            showStatus(TH_ACCENT, ObfStrings.successMessage() + days);
            this.handler.postDelayed(new Runnable() { // from class: com.lvteam.MainActivity.2
                @Override // java.lang.Runnable
                public void run() {
                    MainActivity.this.startSession();
                }
            }, 800L);
            return;
        }
        this.btnLogin.setEnabled(true);
        this.btnLogin.setText("LOGIN");
        if (code == -1) {
            showStatus(-48060, "Erro de conexao. Verifique sua internet.");
        } else {
            showStatus(-48060, parseError(body));
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void startSession() {
        if (Settings.canDrawOverlays(this)) {
            requestVpn();
            return;
        }
        this.waitingForOverlayPermission = true;
        startActivity(new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION", Uri.parse("package:" + getPackageName())));
    }

    private void requestVpn() {
        Intent permission = VpnService.prepare(this);
        if (permission == null) {
            startCaptureAndOverlay();
        } else {
            startActivityForResult(permission, VPN_PERMISSION_REQUEST);
        }
    }

    private void startCaptureAndOverlay() {
        if (!LvSession.get().isActive()) {
            showStatus(-48060, "Sessao invalida. Reinicie o app.");
            return;
        }
        Log.i(TAG, "Starting full IPv4 capture and overlay");
        Intent capture = new Intent(this, (Class<?>) PacketCaptureService.class).setAction(PacketCaptureService.ACTION_ENABLE_FULL_IPV4_ROUTE);
        startService(capture);
        Intent overlay = new Intent(this, (Class<?>) OverlayService.class);
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(overlay);
        } else {
            startService(overlay);
        }
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() { // from class: com.lvteam.MainActivity$$ExternalSyntheticLambda2
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.launchGame();
            }
        }, 750L);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void launchGame() {
        Log.i(TAG, "Opening target game");
        Intent game = new Intent().setClassName("com.dts.freefireth", "com.dts.freefireth.FFMainActivity");
        try {
            startActivity(game);
        } catch (ActivityNotFoundException e) {
            Log.w(TAG, "Target game activity not found", e);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public String getDeviceHwid() {
        String aid = Settings.Secure.getString(getContentResolver(), "android_id");
        return "android_" + aid + "_" + Build.MODEL;
    }

    private String parseError(String json) {
        try {
            JSONObject o = new JSONObject(json);
            String err = o.optString("error", "");
            if (err.isEmpty()) {
                err = o.optString("message", "");
            }
            if ("invalid_key".equals(err)) {
                return ObfStrings.invalidMessage();
            }
            if ("key_expired".equals(err)) {
                return "Chave expirada!";
            }
            if ("key_banned".equals(err)) {
                return "Chave banida!";
            }
            if ("key_paused".equals(err)) {
                return "Chave pausada!";
            }
            if ("app_paused".equals(err)) {
                return "Aplicativo pausado!";
            }
            if ("app_mismatch".equals(err)) {
                return "App incompativel!";
            }
            if ("device_locked".equals(err)) {
                return "Dispositivo bloqueado!";
            }
            if ("device_mismatch".equals(err)) {
                return "Dispositivo diferente!";
            }
            if ("hwid_mismatch".equals(err)) {
                return "HWID diferente!";
            }
            if ("device_required".equals(err)) {
                return "Dispositivo obrigatorio!";
            }
            if ("device_banned".equals(err)) {
                return "Dispositivo banido!";
            }
            return !err.isEmpty() ? err : "Erro na validacao (HTTP)";
        } catch (Exception e) {
            return "Erro na validacao (HTTP)";
        }
    }

    private int extractDays(String json) {
        int d;
        try {
            JSONObject o = new JSONObject(json);
            int d2 = findDays(o);
            if (d2 >= 0) {
                return d2;
            }
            if (o.has("data") && (d = findDays(o.getJSONObject("data"))) >= 0) {
                return d;
            }
            String exp = o.optString("keyExpiresAt", "");
            if (exp.isEmpty() && o.has("data")) {
                exp = o.getJSONObject("data").optString("keyExpiresAt", "");
            }
            if (exp.isEmpty()) {
                return 0;
            }
            return daysUntil(exp);
        } catch (Exception e) {
            return 0;
        }
    }

    private int findDays(JSONObject o) {
        String[] keys = {"days", "daysRemaining", "days_remaining", "remainingDays", "remaining_days", "dias", "diasRestantes"};
        for (String k : keys) {
            if (o.has(k)) {
                return o.optInt(k, -1);
            }
        }
        return -1;
    }

    private String extractExpiry(String json) {
        try {
            JSONObject o = new JSONObject(json);
            String e = o.optString("keyExpiresAt", "");
            if (!e.isEmpty()) {
                return e;
            }
            if (o.has("data")) {
                return o.getJSONObject("data").optString("keyExpiresAt", "");
            }
            return null;
        } catch (Exception e2) {
            return null;
        }
    }

    private int daysUntil(String iso) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
            Date d = sdf.parse(iso);
            if (d == null) {
                SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
                d = sdf2.parse(iso);
            }
            if (d != null) {
                long diff = d.getTime() - System.currentTimeMillis();
                return (int) (diff / 86400000);
            }
            return 0;
        } catch (Exception e) {
            return 0;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static String readAll(InputStream is) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        while (true) {
            String line = br.readLine();
            if (line == null) {
                br.close();
                return sb.toString();
            }
            sb.append(line);
        }
    }

    private int dp(int v) {
        return (int) ((v * getResources().getDisplayMetrics().density) + 0.5f);
    }
}
