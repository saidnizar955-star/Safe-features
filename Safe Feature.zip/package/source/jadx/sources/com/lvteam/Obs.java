package com.lvteam;

/* JADX INFO: loaded from: classes.dex */
public abstract class Obs {
    public static final byte[] K = {76, 86, 84, 69, 65, 77};

    public static String d(byte[] e) {
        byte[] r = new byte[e.length];
        for (int i = 0; i < e.length; i++) {
            r[i] = (byte) (e[i] ^ K[i % K.length]);
        }
        return new String(r);
    }
}
