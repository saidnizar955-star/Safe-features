package com.lvteam;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.Log;
import android.view.View;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public final class EspOverlayView extends View {
    public final Paint boxPaint;
    public final Paint distancePaint;
    public boolean drawBox;
    public boolean drawDistance;
    public boolean drawLine;
    public boolean drawName;
    public final List entities;
    public final Paint linePaint;
    public final Paint namePaint;
    public final Paint textShadowPaint;

    public EspOverlayView(Context context) {
        super(context);
        this.entities = new ArrayList();
        this.boxPaint = new Paint(1);
        this.linePaint = new Paint(1);
        this.namePaint = new Paint(1);
        this.distancePaint = new Paint(1);
        this.textShadowPaint = new Paint(1);
        float density = getResources().getDisplayMetrics().density;
        this.boxPaint.setStyle(Paint.Style.STROKE);
        this.linePaint.setStyle(Paint.Style.STROKE);
        this.namePaint.setTextAlign(Paint.Align.CENTER);
        this.namePaint.setTextSize(density * 12.0f);
        this.distancePaint.setTextAlign(Paint.Align.CENTER);
        this.distancePaint.setTextSize(density * 12.0f);
        this.textShadowPaint.setTextAlign(Paint.Align.CENTER);
        this.textShadowPaint.setColor(-16777216);
        this.textShadowPaint.setStyle(Paint.Style.FILL_AND_STROKE);
        this.textShadowPaint.setTextSize(12.0f * density);
        this.textShadowPaint.setStrokeWidth(2.0f * density);
        setColors(-1, -1, -1, -1);
        setThickness(1.0f);
    }

    public void setColors(int box, int line, int name, int distance) {
        this.boxPaint.setColor(box);
        this.linePaint.setColor(line);
        this.namePaint.setColor(name);
        this.distancePaint.setColor(distance);
        invalidate();
    }

    public void setThickness(float thickness) {
        float width = Math.max(1.0f, getResources().getDisplayMetrics().density * thickness);
        this.boxPaint.setStrokeWidth(width);
        this.linePaint.setStrokeWidth(width);
        invalidate();
    }

    public void setDrawOptions(boolean drawBox, boolean drawLine, boolean drawDistance, boolean drawName) {
        this.drawBox = drawBox;
        this.drawLine = drawLine;
        this.drawDistance = drawDistance;
        this.drawName = drawName;
        invalidate();
    }

    public void submitEntities(Collection collection) {
        this.entities.clear();
        if (collection != null) {
            this.entities.addAll(collection);
        }
        invalidate();
    }

    @Override // android.view.View
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        for (Entity entity : this.entities) {
            if (entity.width > 0.0f && entity.height > 0.0f && entity.health != 0.0f) {
                RectF box = new RectF(entity.left, entity.top, entity.left + entity.width, entity.top + entity.height);
                if (this.drawBox) {
                    canvas.drawRect(box, this.boxPaint);
                }
                if (this.drawLine) {
                    canvas.drawLine(canvas.getWidth() / 2.0f, canvas.getHeight(), box.centerX(), box.centerY(), this.linePaint);
                }
                if (this.drawName && entity.name != null) {
                    float tx = box.centerX();
                    float ty = box.top - dp(3);
                    canvas.drawText(entity.name, tx + 1.0f, ty + 1.0f, this.textShadowPaint);
                    canvas.drawText(entity.name, tx, ty, this.namePaint);
                }
                if (this.drawDistance) {
                    float tx2 = box.centerX();
                    float ty2 = box.bottom + dp(14);
                    String text = Math.round(entity.distanceMeters) + "m";
                    canvas.drawText(text, tx2 + 1.0f, 1.0f + ty2, this.textShadowPaint);
                    canvas.drawText(text, tx2, ty2, this.distancePaint);
                }
            }
        }
    }

    @Override // android.view.View
    public void onSizeChanged(int width, int height, int oldWidth, int oldHeight) {
        super.onSizeChanged(width, height, oldWidth, oldHeight);
        int rotation = getDisplay() == null ? -1 : getDisplay().getRotation();
        Log.i("EspOverlayView", "overlay=" + width + "x" + height + " rotation=" + rotation);
    }

    public final float dp(int value) {
        return value * getResources().getDisplayMetrics().density;
    }

    public static final class Entity {
        public final float distanceMeters;
        public final float health;
        public final float height;
        public final int id;
        public final float left;
        public final String name;
        public final float top;
        public final float width;

        public Entity(int id, String name, float left, float top, float width, float height, float health, float distanceMeters) {
            this.id = id;
            this.name = name;
            this.left = left;
            this.top = top;
            this.width = width;
            this.height = height;
            this.health = health;
            this.distanceMeters = distanceMeters;
        }
    }
}
