package com.lvteam;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.VpnService;
import android.os.IBinder;
import android.os.ParcelFileDescriptor;
import android.os.Process;
import android.os.SystemClock;
import android.system.OsConstants;
import android.util.Log;
import java.io.Closeable;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/* JADX INFO: loaded from: classes.dex */
public final class PacketCaptureService extends VpnService {
    public static final String ACTION_ENABLE_FULL_IPV4_ROUTE = "com.lvteam.action.ENABLE_FULL_IPV4_ROUTE";
    private static final long FULL_ROUTE_STARTUP_TIMEOUT_MS = 10000;
    private static final int MAX_PACKET_SIZE = 65535;
    private static final int MAX_TCP_FLOWS = 128;
    private static final int MAX_UDP_FLOWS = 128;
    private static final String TAG = "PacketCapture";
    private static final String TARGET_PACKAGE = "com.dts.freefireth";
    private static final int TCP_CLOSING_TIMEOUT_MS = 10000;
    private static final int TCP_CONNECT_TIMEOUT_MS = 10000;
    private static final int TCP_IDLE_TIMEOUT_MS = 300000;
    private static final int TCP_PENDING_DATA_LIMIT = 262144;
    private static final int TCP_SEGMENT_SIZE = 1200;
    private static final long TCP_WARNING_INTERVAL_MS = 30000;
    private static final int TP_MAX_HELD = 5000;
    private static final int UDP_IDLE_TIMEOUT_MS = 30000;
    private static final int VPN_MTU = 1280;
    private boolean fullRouteStartupPending;
    private volatile boolean inputRelayInitialized;
    private long lastTcpWarningAtMillis;
    private volatile boolean outputRelayInitialized;
    private ExecutorService relayExecutor;
    private volatile boolean relayReaderStarted;
    private volatile boolean relayRunning;
    private ScheduledFuture<?> startupWatchdogFuture;
    private volatile boolean tpReplayStarted;
    private ParcelFileDescriptor tunnel;
    private FileInputStream tunnelInput;
    private FileOutputStream tunnelOutput;
    private final ScheduledExecutorService startupWatchdog = Executors.newSingleThreadScheduledExecutor();
    private final Object flowLock = new Object();
    private final Object outputLock = new Object();
    private final Object tcpWarningLock = new Object();
    private final Map<FlowKey, UdpFlow> flows = new HashMap();
    private final Map<FlowKey, TcpFlow> tcpFlows = new HashMap();
    private final RawFrameDecoder frameDecoder = new RawFrameDecoder(EntityState.shared());
    private final AtomicInteger packetIdentification = new AtomicInteger();
    private final ArrayList<HeldUdpPacket> heldUplinkPackets = new ArrayList<>();

    public static final class HeldUdpPacket {
        public final long capturedAt = SystemClock.uptimeMillis();
        public final UdpFlow flow;
        public final byte[] payload;

        public HeldUdpPacket(byte[] payload, UdpFlow flow) {
            this.payload = payload;
            this.flow = flow;
        }
    }

    @Override // android.app.Service
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_ENABLE_FULL_IPV4_ROUTE.equals(intent.getAction())) {
            enableFullIpv4Route();
            return 2;
        }
        if (this.tunnel == null) {
            establishRouteFreeVpn();
            return 2;
        }
        return 2;
    }

    @Override // android.net.VpnService
    public void onRevoke() {
        Log.i(TAG, "VPN consent revoked");
        closeTunnel();
        super.onRevoke();
    }

    @Override // android.app.Service
    public void onDestroy() {
        closeTunnel();
        this.startupWatchdog.shutdownNow();
        super.onDestroy();
    }

    @Override // android.app.Service
    public void onTaskRemoved(Intent rootIntent) {
        closeTunnel();
        stopSelf();
        try {
            stopService(new Intent(this, (Class<?>) OverlayService.class));
        } catch (Exception e) {
        }
        super.onTaskRemoved(rootIntent);
        Process.killProcess(Process.myPid());
    }

    private void establishRouteFreeVpn() {
        this.tunnel = new VpnService.Builder(this).setSession("LV Team capture").addAddress("10.17.0.2", 32).establish();
        Log.i(TAG, this.tunnel == null ? "VPN establishment failed" : "VPN interface established");
        if (this.tunnel == null || startRelay()) {
            return;
        }
        closeTunnel();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void enableFullIpv4Route() {
        if (!areGenericRelaysInitialized()) {
            if (this.tunnel == null) {
                establishRouteFreeVpn();
            }
            if (!areGenericRelaysInitialized()) {
                Log.w(TAG, "Full-route startup waiting for generic relays");
                this.startupWatchdog.schedule(new Runnable() { // from class: com.lvteam.PacketCaptureService$$ExternalSyntheticLambda0
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.enableFullIpv4Route();
                    }
                }, 150L, TimeUnit.MILLISECONDS);
                return;
            }
        }
        closeTunnel();
        try {
            ParcelFileDescriptor fullRouteTunnel = new VpnService.Builder(this).setSession("LV Team full IPv4 routing test").addAddress("10.17.0.2", 32).setMtu(VPN_MTU).addRoute("0.0.0.0", 0).allowFamily(OsConstants.AF_INET6).addAllowedApplication(TARGET_PACKAGE).establish();
            if (fullRouteTunnel == null) {
                Log.w(TAG, "Full-route VPN establishment failed");
                closeTunnel();
                return;
            }
            this.tunnel = fullRouteTunnel;
            if (!startRelay()) {
                Log.w(TAG, "Full-route relay initialization failed");
                closeTunnel();
                return;
            }
            synchronized (this) {
                try {
                    this.fullRouteStartupPending = true;
                    this.startupWatchdogFuture = this.startupWatchdog.schedule(new Runnable() { // from class: com.lvteam.PacketCaptureService$$ExternalSyntheticLambda1
                        @Override // java.lang.Runnable
                        public final void run() {
                            this.f$0.failFullRouteStartup();
                        }
                    }, FULL_ROUTE_STARTUP_TIMEOUT_MS, TimeUnit.MILLISECONDS);
                    if (this.relayReaderStarted) {
                        completeFullRouteStartup();
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
            Log.i(TAG, "Full IPv4 routing test started");
        } catch (PackageManager.NameNotFoundException | RuntimeException e) {
            Log.w(TAG, "Full-route VPN establishment failed", e);
            closeTunnel();
        }
    }

    private synchronized boolean startRelay() {
        if (this.relayRunning || this.tunnel == null) {
            return areGenericRelaysInitialized();
        }
        try {
            this.tunnelInput = new FileInputStream(this.tunnel.getFileDescriptor());
            this.inputRelayInitialized = true;
            this.tunnelOutput = new FileOutputStream(this.tunnel.getFileDescriptor());
            this.outputRelayInitialized = true;
            this.relayExecutor = Executors.newCachedThreadPool();
            this.relayRunning = true;
            this.relayReaderStarted = false;
            this.relayExecutor.execute(new Runnable() { // from class: com.lvteam.PacketCaptureService$$ExternalSyntheticLambda3
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.readTunPackets();
                }
            });
            return true;
        } catch (RuntimeException e) {
            Log.w(TAG, "Could not initialize generic relays", e);
            return false;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void readTunPackets() {
        synchronized (this) {
            try {
                this.relayReaderStarted = true;
                if (this.fullRouteStartupPending) {
                    completeFullRouteStartup();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        byte[] buffer = new byte[MAX_PACKET_SIZE];
        while (this.relayRunning) {
            try {
                int length = this.tunnelInput.read(buffer);
                if (length > 0 && LvSession.get().isActive()) {
                    try {
                        this.frameDecoder.accept(buffer, length);
                    } catch (Exception e) {
                        Log.w(TAG, "accept error", e);
                    }
                    Ipv4UdpPacket udpPacket = Ipv4UdpPacket.parse(buffer, length);
                    if (udpPacket != null) {
                        forward(udpPacket);
                    } else {
                        Ipv4TcpPacket tcpPacket = Ipv4TcpPacket.parse(buffer, length);
                        if (tcpPacket != null) {
                            forward(tcpPacket);
                        }
                    }
                }
            } catch (IOException e2) {
                if (this.relayRunning) {
                    Log.w(TAG, "TUN input stopped", e2);
                    return;
                }
                return;
            }
        }
    }

    private void forward(Ipv4UdpPacket packet) {
        FlowKey key = new FlowKey(packet.sourceAddress, packet.sourcePort, packet.destinationAddress, packet.destinationPort);
        synchronized (this.flowLock) {
            if (!this.relayRunning || this.relayExecutor == null) {
                return;
            }
            UdpFlow flow = this.flows.get(key);
            if (flow == null) {
                evictUdpFlowsLocked();
                if (this.flows.size() >= 128) {
                    Log.w(TAG, "UDP flow limit reached");
                    return;
                }
                try {
                    DatagramSocket socket = new DatagramSocket();
                    if (!protect(socket)) {
                        Log.w(TAG, "UDP socket uses app VPN exclusion fallback");
                    }
                    socket.connect(packet.destinationAddress, packet.destinationPort);
                    socket.setSoTimeout(UDP_IDLE_TIMEOUT_MS);
                    flow = new UdpFlow(key, socket);
                    this.flows.put(key, flow);
                    this.relayExecutor.execute(flow);
                } catch (SocketException e) {
                    Log.w(TAG, "Could not create UDP flow", e);
                    return;
                }
            }
            int tpState = LvTeamShift.teleportBaseState;
            if (tpState == 2 && !this.tpReplayStarted) {
                this.tpReplayStarted = true;
                startTpReplay();
            }
            if (tpState == 0 && this.tpReplayStarted) {
                this.tpReplayStarted = false;
                synchronized (this.heldUplinkPackets) {
                    this.heldUplinkPackets.clear();
                }
            }
            if (tpState != 0 && packet.payload.length >= 40 && this.frameDecoder.isGameEndpoint(packet.destinationAddress, packet.destinationPort)) {
                if (tpState == 1) {
                    synchronized (this.heldUplinkPackets) {
                        try {
                            if (this.heldUplinkPackets.size() < TP_MAX_HELD) {
                                this.heldUplinkPackets.add(new HeldUdpPacket(packet.payload, flow));
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                    }
                    return;
                }
                return;
            }
            byte[] uplinkPayload = this.frameDecoder.shiftUplink(packet.payload, packet.payload.length, packet.destinationAddress, packet.destinationPort);
            flow.send(uplinkPayload);
        }
    }

    private void startTpReplay() {
        synchronized (this.heldUplinkPackets) {
            try {
                if (this.heldUplinkPackets.isEmpty()) {
                    LvTeamShift.teleportBaseState = 0;
                    this.tpReplayStarted = false;
                    LvShiftOverlay.refreshTpBase();
                    return;
                }
                final List<HeldUdpPacket> toReplay = new ArrayList<>(this.heldUplinkPackets);
                this.heldUplinkPackets.clear();
                if (this.relayExecutor != null) {
                    this.relayExecutor.execute(new Runnable() { // from class: com.lvteam.PacketCaptureService$$ExternalSyntheticLambda2
                        @Override // java.lang.Runnable
                        public final void run() {
                            this.f$0.lambda$startTpReplay$0(toReplay);
                        }
                    });
                    return;
                }
                LvTeamShift.teleportBaseState = 0;
                this.tpReplayStarted = false;
                LvShiftOverlay.refreshTpBase();
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$startTpReplay$0(List toReplay) {
        long baseAt = ((HeldUdpPacket) toReplay.get(0)).capturedAt;
        long startedAt = SystemClock.uptimeMillis();
        float speed = Math.max(1.0f, LvTeamShift.getTeleportSpeed());
        Iterator it = toReplay.iterator();
        while (it.hasNext()) {
            HeldUdpPacket hp = (HeldUdpPacket) it.next();
            if (LvTeamShift.teleportBaseState != 2) {
                break;
            }
            try {
                long due = ((long) ((hp.capturedAt - baseAt) / speed)) + startedAt;
                long wait = due - SystemClock.uptimeMillis();
                if (wait > 0) {
                    Thread.sleep(wait);
                }
                hp.flow.send(hp.payload);
            } catch (Exception e) {
            }
        }
        LvTeamShift.teleportBaseState = 0;
        this.tpReplayStarted = false;
        LvShiftOverlay.refreshTpBase();
    }

    private void forward(Ipv4TcpPacket packet) {
        FlowKey key = new FlowKey(packet.sourceAddress, packet.sourcePort, packet.destinationAddress, packet.destinationPort);
        boolean created = false;
        synchronized (this.flowLock) {
            try {
                TcpFlow flow = this.tcpFlows.get(key);
                if (flow != null && flow.isClosed()) {
                    this.tcpFlows.remove(key);
                    flow = null;
                }
                if (flow == null) {
                    if ((packet.flags & 18) != 2) {
                        return;
                    }
                    evictTcpFlowsLocked();
                    evictUdpFlowsLocked();
                    if (!this.relayRunning || this.relayExecutor == null) {
                        return;
                    }
                    if (this.tcpFlows.size() >= 128 && !evictOldestTcpFlowLocked()) {
                        warnTcp("TCP flow limit reached", null);
                        return;
                    }
                    if (this.tcpFlows.size() >= 128) {
                        warnTcp("TCP flow limit reached", null);
                        return;
                    }
                    Socket socket = null;
                    try {
                        socket = new Socket();
                        if (!protect(socket)) {
                            warnTcp("TCP socket uses app VPN exclusion fallback", null);
                        }
                        flow = new TcpFlow(key, socket, packet.sequenceNumber);
                        this.tcpFlows.put(key, flow);
                        flow.emitSynAck();
                        this.relayExecutor.execute(flow);
                        created = true;
                    } catch (RuntimeException e) {
                        if (flow != null) {
                            flow.removeAndClose();
                        } else {
                            closeQuietly(socket);
                        }
                        warnTcp("Could not create TCP flow", e);
                        return;
                    }
                }
                if (created) {
                    return;
                }
                flow.handle(packet);
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    private void evictTcpFlowsLocked() {
        long now = System.currentTimeMillis();
        Iterator<Map.Entry<FlowKey, TcpFlow>> iterator = this.tcpFlows.entrySet().iterator();
        while (iterator.hasNext()) {
            TcpFlow flow = iterator.next().getValue();
            if (flow.isIdle(now)) {
                flow.resetAndClose();
                iterator.remove();
            }
        }
    }

    private void evictUdpFlowsLocked() {
        long now = System.currentTimeMillis();
        Iterator<Map.Entry<FlowKey, UdpFlow>> iterator = this.flows.entrySet().iterator();
        while (iterator.hasNext()) {
            UdpFlow flow = iterator.next().getValue();
            if (flow.isIdle(now)) {
                flow.close();
                iterator.remove();
            }
        }
    }

    private boolean evictOldestTcpFlowLocked() {
        TcpFlow oldest = null;
        for (TcpFlow flow : this.tcpFlows.values()) {
            if (oldest == null || flow.lastActivityMillis < oldest.lastActivityMillis) {
                oldest = flow;
            }
        }
        if (oldest == null) {
            return false;
        }
        oldest.resetAndClose();
        if (this.tcpFlows.get(oldest.key) == oldest) {
            this.tcpFlows.remove(oldest.key);
        }
        warnTcp("TCP flow limit reached; evicted oldest TCP flow", null);
        return true;
    }

    private void warnTcp(String message, Exception error) {
        long now = System.currentTimeMillis();
        synchronized (this.tcpWarningLock) {
            try {
                if (now - this.lastTcpWarningAtMillis < TCP_WARNING_INTERVAL_MS) {
                    return;
                }
                this.lastTcpWarningAtMillis = now;
                if (error != null) {
                    Log.w(TAG, message, error);
                } else {
                    Log.w(TAG, message);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    private synchronized void closeTunnel() {
        try {
            this.fullRouteStartupPending = false;
            if (this.startupWatchdogFuture != null) {
                this.startupWatchdogFuture.cancel(false);
                this.startupWatchdogFuture = null;
            }
            this.relayRunning = false;
            this.inputRelayInitialized = false;
            this.outputRelayInitialized = false;
            this.relayReaderStarted = false;
            synchronized (this.flowLock) {
                try {
                    for (UdpFlow flow : this.flows.values()) {
                        flow.close();
                    }
                    this.flows.clear();
                    for (TcpFlow flow2 : this.tcpFlows.values()) {
                        flow2.close();
                    }
                    this.tcpFlows.clear();
                } catch (Throwable th) {
                    throw th;
                }
            }
            if (this.relayExecutor != null) {
                this.relayExecutor.shutdownNow();
                this.relayExecutor = null;
            }
            closeQuietly(this.tunnelInput);
            this.tunnelInput = null;
            synchronized (this.outputLock) {
                closeQuietly(this.tunnelOutput);
                this.tunnelOutput = null;
            }
            if (this.tunnel == null) {
                return;
            }
            try {
                this.tunnel.close();
            } catch (IOException e) {
            }
            this.tunnel = null;
        } catch (Throwable th2) {
            throw th2;
        }
    }

    private boolean areGenericRelaysInitialized() {
        return this.relayRunning && this.inputRelayInitialized && this.outputRelayInitialized;
    }

    private synchronized void completeFullRouteStartup() {
        this.fullRouteStartupPending = false;
        if (this.startupWatchdogFuture != null) {
            this.startupWatchdogFuture.cancel(false);
            this.startupWatchdogFuture = null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public synchronized void failFullRouteStartup() {
        if (this.fullRouteStartupPending && !this.relayReaderStarted && areGenericRelaysInitialized()) {
            Log.w(TAG, "Full-route startup timed out; tearing down VPN");
            closeTunnel();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void closeQuietly(Closeable closeable) {
        if (closeable == null) {
            return;
        }
        try {
            closeable.close();
        } catch (IOException e) {
        }
    }

    public final class UdpFlow implements Runnable {
        public final FlowKey key;
        public volatile long lastActivityMillis = System.currentTimeMillis();
        public final DatagramSocket socket;

        public UdpFlow(FlowKey key, DatagramSocket socket) {
            this.key = key;
            this.socket = socket;
        }

        public void send(byte[] payload) {
            try {
                this.socket.send(new DatagramPacket(payload, payload.length));
                this.lastActivityMillis = System.currentTimeMillis();
            } catch (IOException e) {
                Log.w(PacketCaptureService.TAG, "UDP send failed", e);
                removeAndClose();
            }
        }

        @Override // java.lang.Runnable
        public void run() {
            byte[] buffer = new byte[PacketCaptureService.MAX_PACKET_SIZE];
            DatagramPacket response = new DatagramPacket(buffer, buffer.length);
            while (PacketCaptureService.this.relayRunning && !this.socket.isClosed()) {
                try {
                    try {
                        response.setLength(buffer.length);
                        this.socket.receive(response);
                        this.lastActivityMillis = System.currentTimeMillis();
                        byte[] payload = new byte[response.getLength()];
                        System.arraycopy(response.getData(), response.getOffset(), payload, 0, payload.length);
                        try {
                            PacketCaptureService.this.frameDecoder.acceptUdpPayload(payload, payload.length, this.key.destinationAddress, this.key.destinationPort);
                            payload = PacketCaptureService.this.frameDecoder.shiftDownlink(payload, payload.length, this.key.destinationAddress, this.key.destinationPort);
                        } catch (Exception e) {
                            Log.w(PacketCaptureService.TAG, "shift error", e);
                        }
                        byte[] frame = Ipv4UdpPacket.response(this.key.destinationAddress, this.key.destinationPort, this.key.sourceAddress, this.key.sourcePort, payload, PacketCaptureService.this.packetIdentification.incrementAndGet() & PacketCaptureService.MAX_PACKET_SIZE);
                        synchronized (PacketCaptureService.this.outputLock) {
                            try {
                                if (PacketCaptureService.this.relayRunning && PacketCaptureService.this.tunnelOutput != null) {
                                    PacketCaptureService.this.tunnelOutput.write(frame);
                                }
                            } catch (Throwable th) {
                                throw th;
                            }
                        }
                    } catch (IOException e2) {
                        if (PacketCaptureService.this.relayRunning && !this.socket.isClosed()) {
                            Log.w(PacketCaptureService.TAG, "UDP receive failed", e2);
                        }
                    }
                } catch (Throwable th2) {
                    removeAndClose();
                    throw th2;
                }
            }
            removeAndClose();
        }

        public void close() {
            this.socket.close();
        }

        public boolean isIdle(long now) {
            return now - this.lastActivityMillis >= PacketCaptureService.TCP_WARNING_INTERVAL_MS;
        }

        public final void removeAndClose() {
            this.socket.close();
            synchronized (PacketCaptureService.this.flowLock) {
                try {
                    if (PacketCaptureService.this.flows.get(this.key) == this) {
                        PacketCaptureService.this.flows.remove(this.key);
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
    }

    public final class TcpFlow implements Runnable {
        public boolean clientFinReceived;
        public long clientNextSequence;
        public volatile boolean closed;
        public ScheduledFuture closingFuture;
        public boolean connected;
        public boolean handshakeAcknowledged;
        public final long initialClientSequence;
        public final FlowKey key;
        public int pendingPayloadBytes;
        public boolean remoteFinSent;
        public final Socket socket;
        public boolean synAckSent;
        public final ArrayDeque pendingPayload = new ArrayDeque();
        public long serverNextSequence = System.nanoTime() & 4294967295L;
        public final long initialServerSequence = this.serverNextSequence;
        public volatile long lastActivityMillis = System.currentTimeMillis();

        public TcpFlow(FlowKey key, Socket socket, long clientSequence) {
            this.key = key;
            this.socket = socket;
            this.initialClientSequence = clientSequence;
            this.clientNextSequence = PacketCaptureService.increment(clientSequence, 1);
        }

        public void handle(Ipv4TcpPacket packet) {
            synchronized (this) {
                try {
                    if (this.closed) {
                        return;
                    }
                    this.lastActivityMillis = System.currentTimeMillis();
                    if ((packet.flags & 4) != 0) {
                        removeAndClose();
                        return;
                    }
                    if ((packet.flags & 2) != 0) {
                        if (packet.sequenceNumber == this.initialClientSequence) {
                            emitSynAck();
                        }
                        return;
                    }
                    if ((packet.flags & 16) != 0 && !PacketCaptureService.isAfter(packet.acknowledgementNumber, this.serverNextSequence)) {
                        if (!this.handshakeAcknowledged) {
                            if (packet.acknowledgementNumber != this.serverNextSequence || packet.sequenceNumber != this.clientNextSequence) {
                                return;
                            } else {
                                this.handshakeAcknowledged = true;
                            }
                        }
                        if (this.remoteFinSent && packet.acknowledgementNumber == this.serverNextSequence) {
                            removeAndClose();
                            return;
                        }
                        if (packet.sequenceNumber != this.clientNextSequence) {
                            emit(16, new byte[0]);
                            return;
                        }
                        if (packet.payload.length > 0) {
                            PacketCaptureService.this.frameDecoder.acceptTcpPayload(this.key, packet.payload, packet.payload.length);
                            if (this.clientFinReceived || !queueOrWrite(packet.payload)) {
                                return;
                            } else {
                                this.clientNextSequence = PacketCaptureService.increment(this.clientNextSequence, packet.payload.length);
                            }
                        }
                        if ((packet.flags & 1) != 0 && !this.clientFinReceived) {
                            this.clientFinReceived = true;
                            this.clientNextSequence = PacketCaptureService.increment(this.clientNextSequence, 1);
                            if (this.connected && !shutdownOutput()) {
                                return;
                            }
                        }
                        if (packet.payload.length > 0 || (packet.flags & 1) != 0) {
                            emit(16, new byte[0]);
                        }
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }

        /* JADX WARN: Code duplicated, block: B:131:0x013a A[Catch: all -> 0x013e, TryCatch #16 {all -> 0x013e, blocks: (B:129:0x0136, B:131:0x013a, B:134:0x0140), top: B:191:0x0136 }] */
        /* JADX WARN: Code duplicated, block: B:177:0x011e A[EXC_TOP_SPLITTER, SYNTHETIC] */
        /* JADX WARN: Code duplicated, block: B:191:0x0136 A[EXC_TOP_SPLITTER, SYNTHETIC] */
        @Override // java.lang.Runnable
        public void run() {
            try {
                this.socket.connect(new InetSocketAddress(this.key.destinationAddress, this.key.destinationPort), 10000);
                try {
                    try {
                        this.socket.setSoTimeout(PacketCaptureService.TCP_IDLE_TIMEOUT_MS);
                        this.socket.setTcpNoDelay(true);
                        synchronized (this) {
                            if (!PacketCaptureService.this.relayRunning || this.socket.isClosed() || this.closed) {
                                synchronized (this) {
                                    try {
                                        if (!this.remoteFinSent) {
                                            removeAndClose();
                                        }
                                    } catch (Throwable th) {
                                        throw th;
                                    }
                                }
                                return;
                            }
                            this.connected = true;
                            if (!flushPendingData()) {
                                synchronized (this) {
                                    try {
                                        if (!this.remoteFinSent) {
                                            removeAndClose();
                                        }
                                    } catch (Throwable th2) {
                                        throw th2;
                                    }
                                }
                                return;
                            }
                            if (this.clientFinReceived && !shutdownOutput()) {
                                synchronized (this) {
                                    try {
                                        if (!this.remoteFinSent) {
                                            removeAndClose();
                                        }
                                    } catch (Throwable th3) {
                                        throw th3;
                                    }
                                }
                                return;
                            }
                            InputStream input = this.socket.getInputStream();
                            byte[] buffer = new byte[PacketCaptureService.TCP_SEGMENT_SIZE];
                            while (PacketCaptureService.this.relayRunning) {
                                try {
                                    int length = input.read(buffer);
                                    if (length == -1) {
                                        break;
                                    }
                                    byte[] payload = new byte[length];
                                    System.arraycopy(buffer, 0, payload, 0, length);
                                    synchronized (this) {
                                        try {
                                            if (!this.socket.isClosed()) {
                                                this.lastActivityMillis = System.currentTimeMillis();
                                                PacketCaptureService.this.frameDecoder.acceptTcpPayload(this.key, payload, payload.length);
                                                emit(16, payload);
                                            }
                                        } catch (Throwable th4) {
                                            throw th4;
                                        }
                                    }
                                } catch (SocketTimeoutException e) {
                                    if (isIdle(System.currentTimeMillis())) {
                                        emitReset();
                                        synchronized (this) {
                                            try {
                                                if (!this.remoteFinSent) {
                                                    removeAndClose();
                                                }
                                                return;
                                            } catch (Throwable th5) {
                                                throw th5;
                                            }
                                        }
                                    }
                                }
                            }
                            synchronized (this) {
                                try {
                                    if (PacketCaptureService.this.relayRunning && !this.socket.isClosed() && !this.closed) {
                                        emitRemoteFin();
                                    }
                                } catch (Throwable th6) {
                                    throw th6;
                                }
                            }
                            synchronized (this) {
                                try {
                                    if (!this.remoteFinSent) {
                                        removeAndClose();
                                    }
                                } catch (Throwable th7) {
                                    throw th7;
                                }
                            }
                        }
                    } catch (Throwable th8) {
                        synchronized (this) {
                            try {
                                if (!this.remoteFinSent) {
                                    removeAndClose();
                                }
                                throw th8;
                            } catch (Throwable th9) {
                                throw th9;
                            }
                        }
                    }
                } catch (IOException e2) {
                    synchronized (this) {
                        try {
                            if (PacketCaptureService.this.relayRunning && !this.socket.isClosed()) {
                                emitReset();
                            }
                        } catch (Throwable th10) {
                            throw th10;
                        }
                    }
                    synchronized (this) {
                        try {
                            if (!this.remoteFinSent) {
                                removeAndClose();
                            }
                        } catch (Throwable th11) {
                            throw th11;
                        }
                    }
                } catch (RuntimeException e3) {
                    synchronized (this) {
                        if (PacketCaptureService.this.relayRunning) {
                            emitReset();
                        }
                        synchronized (this) {
                            if (!this.remoteFinSent) {
                                removeAndClose();
                            }
                        }
                    }
                }
            } catch (IOException | RuntimeException e4) {
                synchronized (this) {
                    try {
                        if (PacketCaptureService.this.relayRunning && !this.socket.isClosed()) {
                            Log.w(PacketCaptureService.TAG, "TCP upstream connect failed", e4);
                            emitReset();
                        }
                    } catch (Throwable th12) {
                        throw th12;
                    }
                }
                removeAndClose();
            }
        }

        public boolean isIdle(long now) {
            return now - this.lastActivityMillis >= 300000;
        }

        public boolean isClosed() {
            return this.closed;
        }

        public final void emitSynAck() {
            if (writeResponse(this.initialServerSequence, 18, new byte[0]) && !this.synAckSent) {
                this.synAckSent = true;
                this.serverNextSequence = PacketCaptureService.increment(this.serverNextSequence, 1);
            }
        }

        public final void emitReset() {
            if (this.synAckSent) {
                emit(20, new byte[0]);
            } else {
                writeResponse(0L, 20, new byte[0]);
            }
        }

        public final void emit(int flags, byte[] payload) {
            long sequence = this.serverNextSequence;
            if (writeResponse(sequence, flags, payload)) {
                if ((flags & 2) != 0) {
                    this.serverNextSequence = PacketCaptureService.increment(this.serverNextSequence, 1);
                }
                if ((flags & 1) != 0) {
                    this.serverNextSequence = PacketCaptureService.increment(this.serverNextSequence, 1);
                }
                this.serverNextSequence = PacketCaptureService.increment(this.serverNextSequence, payload.length);
            }
        }

        public final boolean writeResponse(long sequence, int flags, byte[] payload) {
            byte[] frame = Ipv4TcpPacket.response(this.key.destinationAddress, this.key.destinationPort, this.key.sourceAddress, this.key.sourcePort, sequence, this.clientNextSequence, flags, payload, PacketCaptureService.this.packetIdentification.incrementAndGet() & PacketCaptureService.MAX_PACKET_SIZE);
            synchronized (PacketCaptureService.this.outputLock) {
                try {
                    try {
                        if (!PacketCaptureService.this.relayRunning || PacketCaptureService.this.tunnelOutput == null) {
                            return false;
                        }
                        PacketCaptureService.this.tunnelOutput.write(frame);
                        return true;
                    } catch (IOException e) {
                        return false;
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }

        public void close() {
            this.closed = true;
            if (this.closingFuture != null) {
                this.closingFuture.cancel(false);
            }
            PacketCaptureService.closeQuietly(this.socket);
        }

        public void resetAndClose() {
            synchronized (this) {
                try {
                    if (!this.socket.isClosed()) {
                        emitReset();
                    }
                    close();
                } catch (Throwable th) {
                    throw th;
                }
            }
        }

        public final void removeAndClose() {
            close();
            try {
                PacketCaptureService.this.startupWatchdog.execute(new Runnable() { // from class: com.lvteam.PacketCaptureService$TcpFlow$$ExternalSyntheticLambda0
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.lambda$removeAndClose$0();
                    }
                });
            } catch (RuntimeException e) {
            }
        }

        public final /* synthetic */ void lambda$removeAndClose$0() {
            synchronized (PacketCaptureService.this.flowLock) {
                try {
                    if (PacketCaptureService.this.tcpFlows.get(this.key) == this) {
                        PacketCaptureService.this.tcpFlows.remove(this.key);
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }

        public final boolean queueOrWrite(byte[] payload) {
            if (this.connected) {
                try {
                    OutputStream output = this.socket.getOutputStream();
                    output.write(payload);
                    output.flush();
                    return true;
                } catch (IOException | RuntimeException e) {
                    emitReset();
                    removeAndClose();
                    return false;
                }
            }
            if (this.pendingPayloadBytes + payload.length > PacketCaptureService.TCP_PENDING_DATA_LIMIT) {
                Log.w(PacketCaptureService.TAG, "TCP pending data queue overflow");
                emitReset();
                removeAndClose();
                return false;
            }
            this.pendingPayload.add(payload);
            this.pendingPayloadBytes += payload.length;
            return true;
        }

        public final boolean flushPendingData() {
            try {
                OutputStream output = this.socket.getOutputStream();
                while (!this.pendingPayload.isEmpty()) {
                    output.write((byte[]) this.pendingPayload.remove());
                }
                this.pendingPayloadBytes = 0;
                output.flush();
                return true;
            } catch (IOException e) {
                emitReset();
                removeAndClose();
                return false;
            } catch (RuntimeException e2) {
                emitReset();
                removeAndClose();
                return false;
            }
        }

        public final boolean shutdownOutput() {
            try {
                this.socket.shutdownOutput();
                return true;
            } catch (IOException | RuntimeException e) {
                emitReset();
                removeAndClose();
                return false;
            }
        }

        public final void emitRemoteFin() {
            if (this.remoteFinSent) {
                return;
            }
            emit(17, new byte[0]);
            this.remoteFinSent = true;
            this.closingFuture = PacketCaptureService.this.startupWatchdog.schedule(new Runnable() { // from class: com.lvteam.PacketCaptureService$TcpFlow$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.lambda$emitRemoteFin$1();
                }
            }, PacketCaptureService.FULL_ROUTE_STARTUP_TIMEOUT_MS, TimeUnit.MILLISECONDS);
        }

        public final /* synthetic */ void lambda$emitRemoteFin$1() {
            synchronized (this) {
                try {
                    if (this.remoteFinSent && !this.closed) {
                        removeAndClose();
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static long increment(long sequence, int amount) {
        return (((long) amount) + sequence) & 4294967295L;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static boolean isAfter(long sequence, long reference) {
        long difference = (sequence - reference) & 4294967295L;
        return difference != 0 && difference < 2147483648L;
    }

    public static final class FlowKey {
        public final InetAddress destinationAddress;
        public final int destinationPort;
        public final InetAddress sourceAddress;
        public final int sourcePort;

        public FlowKey(InetAddress sourceAddress, int sourcePort, InetAddress destinationAddress, int destinationPort) {
            this.sourceAddress = sourceAddress;
            this.sourcePort = sourcePort;
            this.destinationAddress = destinationAddress;
            this.destinationPort = destinationPort;
        }

        public boolean equals(Object other) {
            if (!(other instanceof FlowKey)) {
                return false;
            }
            FlowKey that = (FlowKey) other;
            return this.sourcePort == that.sourcePort && this.destinationPort == that.destinationPort && this.sourceAddress.equals(that.sourceAddress) && this.destinationAddress.equals(that.destinationAddress);
        }

        public int hashCode() {
            int result = this.sourceAddress.hashCode();
            return (((((result * 31) + this.sourcePort) * 31) + this.destinationAddress.hashCode()) * 31) + this.destinationPort;
        }
    }

    @Override // android.net.VpnService, android.app.Service
    public IBinder onBind(Intent intent) {
        return super.onBind(intent);
    }
}
