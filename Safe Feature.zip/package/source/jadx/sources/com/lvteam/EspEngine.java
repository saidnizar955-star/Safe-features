package com.lvteam;

import android.os.SystemClock;
import android.util.Log;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.BiFunction;
import java.util.function.ToDoubleFunction;

/* JADX INFO: loaded from: classes.dex */
public final class EspEngine {
    public volatile Camera camera;
    public final ConcurrentHashMap entities = new ConcurrentHashMap();
    public long lastProjectionReportAt;

    public void updateCamera(float x, float y, float z, float forwardX, float forwardY, float forwardZ, float verticalFovDegrees) {
        this.camera = new Camera(x, y, z, forwardX, forwardY, forwardZ, verticalFovDegrees);
    }

    public void clearCamera() {
        this.camera = null;
    }

    public void updateEntity(int id, final String name, final float x, final float y, final float z, final float height, final float health, boolean local, boolean ally, final long sourceUpdatedAt) {
        if (local || ally) {
            this.entities.remove(Integer.valueOf(id));
        } else {
            this.entities.compute(Integer.valueOf(id), new BiFunction() { // from class: com.lvteam.EspEngine$$ExternalSyntheticLambda4
                @Override // java.util.function.BiFunction
                public final Object apply(Object obj, Object obj2) {
                    return EspEngine.lambda$updateEntity$0(sourceUpdatedAt, name, x, y, z, height, health, (Integer) obj, (EspEngine.WorldEntity) obj2);
                }
            });
        }
    }

    public static /* synthetic */ WorldEntity lambda$updateEntity$0(long sourceUpdatedAt, String name, float x, float y, float z, float height, float health, Integer key, WorldEntity previous) {
        return (previous == null || previous.sourceUpdatedAt != sourceUpdatedAt) ? new WorldEntity(name, x, y, z, height, health, sourceUpdatedAt, previous) : previous;
    }

    public void retainOnly(Set set) {
        this.entities.keySet().retainAll(set);
    }

    public Collection project(int screenWidth, int screenHeight) {
        float z;
        float extraMs;
        EspEngine espEngine = this;
        Camera activeCamera = espEngine.camera;
        ArrayList<EspOverlayView.Entity> result = new ArrayList<>();
        if (activeCamera == null || screenWidth <= 0) {
            return result;
        }
        if (screenHeight <= 0) {
            return result;
        }
        long cutoff = SystemClock.elapsedRealtime() - 8000;
        float aspect = screenWidth / screenHeight;
        float focal = (float) (((double) screenHeight) / (Math.tan(Math.toRadians(activeCamera.verticalFov / 2.0f)) * 2.0d));
        for (Map.Entry<Integer, WorldEntity> entry : espEngine.entities.entrySet()) {
            WorldEntity entity = entry.getValue();
            if (entity.updatedAt < cutoff || entity.health == 0.0f) {
                espEngine = this;
                espEngine.entities.remove(entry.getKey(), entity);
                result = result;
                cutoff = cutoff;
                focal = focal;
            } else {
                float timeSinceUpdate = SystemClock.elapsedRealtime() - entity.updatedAt;
                float blend = Math.min(1.0f, timeSinceUpdate / 250.0f);
                float blend2 = blend * blend * (3.0f - (blend * 2.0f));
                float x = entity.previousX + ((entity.x - entity.previousX) * blend2);
                float y = entity.previousY + ((entity.y - entity.previousY) * blend2);
                float z2 = entity.previousZ + ((entity.z - entity.previousZ) * blend2);
                if (blend2 >= 1.0f && timeSinceUpdate < 550.0f) {
                    float extraMs2 = timeSinceUpdate - 250.0f;
                    float dampen = 1.0f - (extraMs2 / 300.0f);
                    float x2 = x + (entity.velocityX * extraMs2 * dampen);
                    y += entity.velocityY * extraMs2 * dampen;
                    z = z2 + (entity.velocityZ * extraMs2 * dampen);
                    extraMs = x2;
                } else {
                    z = z2;
                    extraMs = x;
                }
                long cutoff2 = cutoff;
                float y2 = y;
                float x3 = extraMs;
                float z3 = z;
                float focal2 = focal;
                ScreenPoint head = activeCamera.project(extraMs, y + 200.0f, z, screenWidth, screenHeight, focal, aspect);
                ArrayList<EspOverlayView.Entity> result2 = result;
                ScreenPoint feet = activeCamera.project(x3, y2 - entity.height, z3, screenWidth, screenHeight, focal2, aspect);
                if (feet == null) {
                    espEngine = this;
                    result = result2;
                    cutoff = cutoff2;
                    focal = focal2;
                } else if (head == null) {
                    espEngine = this;
                    cutoff = cutoff2;
                    focal = focal2;
                    result = result2;
                } else {
                    float boxHeight = Math.abs(feet.y - head.y);
                    if (boxHeight < 3.0f) {
                        espEngine = this;
                        result = result2;
                        cutoff = cutoff2;
                        focal = focal2;
                    } else if (boxHeight > screenHeight * 1.5f) {
                        espEngine = this;
                        cutoff = cutoff2;
                        focal = focal2;
                        result = result2;
                    } else {
                        float boxWidth = boxHeight * 0.42f;
                        float distance = activeCamera.distanceTo(x3, y2, z3) / 1000.0f;
                        if (distance > 160.0f) {
                            espEngine = this;
                            cutoff = cutoff2;
                            focal = focal2;
                            result = result2;
                        } else {
                            ScreenPoint bodyCenter = activeCamera.project(x3, (y2 + 100.0f) - (entity.height / 2.0f), z3, screenWidth, screenHeight, focal2, aspect);
                            float centerX = bodyCenter != null ? bodyCenter.x : (feet.x + head.x) / 2.0f;
                            if ((boxWidth / 2.0f) + centerX < 0.0f || centerX - (boxWidth / 2.0f) > screenWidth) {
                                espEngine = this;
                                result = result2;
                                cutoff = cutoff2;
                                focal = focal2;
                            } else if (Math.max(feet.y, head.y) < 0.0f) {
                                espEngine = this;
                                result = result2;
                                cutoff = cutoff2;
                                focal = focal2;
                            } else if (Math.min(feet.y, head.y) > screenHeight) {
                                espEngine = this;
                                cutoff = cutoff2;
                                focal = focal2;
                                result = result2;
                            } else {
                                result2.add(new EspOverlayView.Entity(entry.getKey().intValue(), entity.name, centerX - (boxWidth / 2.0f), Math.min(feet.y, head.y), boxWidth, boxHeight, entity.health, distance));
                                espEngine = this;
                                result = result2;
                                cutoff = cutoff2;
                                focal = focal2;
                            }
                        }
                    }
                }
            }
        }
        ArrayList<EspOverlayView.Entity> result3 = result;
        espEngine.reportProjection(activeCamera, result3, screenWidth, screenHeight);
        result3.sort(Comparator.comparingDouble(new ToDoubleFunction() { // from class: com.lvteam.EspEngine$$ExternalSyntheticLambda3
            @Override // java.util.function.ToDoubleFunction
            public final double applyAsDouble(Object obj) {
                return EspEngine.lambda$project$1((EspOverlayView.Entity) obj);
            }
        }));
        if (result3.size() > 64) {
            return new ArrayList(result3.subList(0, 64));
        }
        return result3;
    }

    public static /* synthetic */ double lambda$project$1(EspOverlayView.Entity entity) {
        return entity.distanceMeters;
    }

    public final void reportProjection(Camera camera, Collection collection, int screenWidth, int screenHeight) {
        long now = SystemClock.elapsedRealtime();
        if (now - this.lastProjectionReportAt < 2000) {
            return;
        }
        this.lastProjectionReportAt = now;
        if (collection.isEmpty()) {
            Log.i("EspEngine", "projection visible=0 screen=" + screenWidth + "x" + screenHeight);
            return;
        }
        EspOverlayView.Entity sample = (EspOverlayView.Entity) collection.iterator().next();
        Log.i("EspEngine", "projection visible=" + collection.size() + " screen=" + screenWidth + "x" + screenHeight + " camera=" + Math.round(camera.x) + "," + Math.round(camera.y) + "," + Math.round(camera.z) + " box=" + Math.round(sample.left + (sample.width / 2.0f)) + "," + Math.round(sample.top + (sample.height / 2.0f)) + " size=" + Math.round(sample.width) + "x" + Math.round(sample.height) + " distance=" + Math.round(sample.distanceMeters));
    }

    public static final class WorldEntity {
        public final float health;
        public final float height;
        public final String name;
        public final float previousX;
        public final float previousY;
        public final float previousZ;
        public final long sourceUpdatedAt;
        public final long updatedAt;
        public final float velocityX;
        public final float velocityY;
        public final float velocityZ;
        public final float x;
        public final float y;
        public final float z;

        public WorldEntity(String name, float x, float y, float z, float height, float health, long updatedAt, WorldEntity previous) {
            this.name = (name == null || name.isEmpty()) ? null : name;
            this.x = x;
            this.y = y;
            this.z = z;
            this.previousX = previous == null ? x : previous.x;
            this.previousY = previous == null ? y : previous.y;
            this.previousZ = previous == null ? z : previous.z;
            this.height = Math.max(0.1f, height);
            this.health = health;
            this.updatedAt = updatedAt;
            this.sourceUpdatedAt = updatedAt;
            if (previous != null && previous.sourceUpdatedAt > 0) {
                long dt = Math.max(1L, updatedAt - previous.sourceUpdatedAt);
                this.velocityX = (x - previous.x) / dt;
                this.velocityY = (y - previous.y) / dt;
                this.velocityZ = (z - previous.z) / dt;
                return;
            }
            this.velocityX = 0.0f;
            this.velocityY = 0.0f;
            this.velocityZ = 0.0f;
        }
    }

    public static final class Camera {
        public final float forwardX;
        public final float forwardY;
        public final float forwardZ;
        public final float rightX;
        public final float rightY;
        public final float rightZ;
        public final float verticalFov;
        public final float x;
        public final float y;
        public final float z;

        public Camera(float x, float y, float z, float forwardX, float forwardY, float forwardZ, float verticalFov) {
            this.x = x;
            this.y = y;
            this.z = z;
            float length = (float) Math.sqrt((forwardX * forwardX) + (forwardY * forwardY) + (forwardZ * forwardZ));
            this.forwardX = forwardX / Math.max(length, 1.0E-4f);
            this.forwardY = forwardY / Math.max(length, 1.0E-4f);
            this.forwardZ = forwardZ / Math.max(length, 1.0E-4f);
            float rightLength = (float) Math.sqrt((this.forwardX * this.forwardX) + (this.forwardZ * this.forwardZ));
            this.rightX = this.forwardZ / Math.max(rightLength, 1.0E-4f);
            this.rightY = 0.0f;
            this.rightZ = (-this.forwardX) / Math.max(rightLength, 1.0E-4f);
            this.verticalFov = Math.max(15.0f, Math.min(150.0f, verticalFov));
        }

        public ScreenPoint project(float worldX, float worldY, float worldZ, int width, int height, float focal, float aspect) {
            float dx = worldX - this.x;
            float dy = worldY - this.y;
            float dz = worldZ - this.z;
            float depth = (this.forwardX * dx) + (this.forwardY * dy) + (this.forwardZ * dz);
            if (depth <= 0.05f) {
                return null;
            }
            float side = (this.rightX * dx) + (this.rightY * dy) + (this.rightZ * dz);
            float upX = (this.forwardY * this.rightZ) - (this.forwardZ * this.rightY);
            float upY = (this.forwardZ * this.rightX) - (this.forwardX * this.rightZ);
            float upZ = (this.forwardX * this.rightY) - (this.forwardY * this.rightX);
            float up = (dx * upX) + (dy * upY) + (dz * upZ);
            return new ScreenPoint((width / 2.0f) + ((side * focal) / depth), (height / 2.0f) - ((up * focal) / depth));
        }

        public float distanceTo(float targetX, float targetY, float targetZ) {
            float dx = targetX - this.x;
            float dy = targetY - this.y;
            float dz = targetZ - this.z;
            return (float) Math.sqrt((dx * dx) + (dy * dy) + (dz * dz));
        }
    }

    public static final class ScreenPoint {
        public final float x;
        public final float y;

        public ScreenPoint(float x, float y) {
            this.x = x;
            this.y = y;
        }
    }
}
