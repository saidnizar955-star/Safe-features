package com.lvteam;

import android.app.Activity;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class LvUpdateChecker$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ String f$0;
    public final /* synthetic */ Activity f$1;
    public final /* synthetic */ LvUpdateChecker.Callback f$2;

    public /* synthetic */ LvUpdateChecker$$ExternalSyntheticLambda0(String str, Activity activity, LvUpdateChecker.Callback callback) {
        this.f$0 = str;
        this.f$1 = activity;
        this.f$2 = callback;
    }

    @Override // java.lang.Runnable
    public final void run() {
        LvUpdateChecker.lambda$check$1(this.f$0, this.f$1, this.f$2);
    }
}
