package com.lvteam;

/* JADX INFO: loaded from: classes.dex */
public final class ObfStrings {
    public static String channel() {
        return Obs.d(new byte[]{36, 34, 32, 53, 50, 119, 99, 121, 35, 45, 32, 57, 63, 55, 36, 53, 111, 46, 35, 59, 123, 38, 41, 44, 34, 56, 49, 41, 110, 125, 124, 100, 109, 19, 35, 117, 117, 58, 54, 17, 112, 5, 63, 38, 44, 41, 19, 38, 60, 0, 2, 119, 35});
    }

    public static String getKey() {
        return Obs.d(new byte[]{11, 51, 32, 101, 10, 40, 53});
    }

    public static String invalidJson() {
        return Obs.d(new byte[]{55, 116, 49, 55, 51, 34, 62, 116, 110, 103, 40, 35, 58, 55, 56, 44, 37, 18, 39, 51, 45, 103, 60});
    }

    public static String invalidMessage() {
        return Obs.d(new byte[]{15, 62, 53, 51, 36, 109, 37, 56, 34, 36, 45, 36, 40, 55, 117});
    }

    public static String password() {
        return Obs.d(new byte[]{0, 63, 32, 42, 9, 53});
    }

    public static String success() {
        return Obs.d(new byte[]{55, 116, 48, 36, 56, 62, 110, 108, 103, 115, 116, 97, 110, 61, 49, 60, 4, 53, 60, 63, 38, 32, 50, 12, 56, 116, 110, 103, 115, 125, 117, 111, 121, 116, 115, 96, 127, 103, 0, 119, 114, 119, 121, 111, 110, 112, 120, 23, 110, 43});
    }

    public static String successMessage() {
        return Obs.d(new byte[]{13, 35, 32, 32, 47, 57, 37, 53, 53, 33, 46, 108, 108, 18, 61, 36, 50, 109, 62, 51, 39, 49, 32, 35, 56, 51, 39, 127, 97});
    }
}
