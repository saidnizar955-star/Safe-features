package com.lvteam;

import android.os.SystemClock;
import java.io.ByteArrayOutputStream;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;

/* JADX INFO: loaded from: classes.dex */
public abstract class LvTeamShift {
    public static volatile float aimX;
    public static volatile float aimY;
    public static volatile long firePulseUntil;
    public static volatile boolean firing;
    public static boolean freezeActive;
    public static volatile boolean haveDownAnchor;
    public static volatile long[] heldUplink;
    public static long lastDownY;
    public static volatile boolean localHold;
    public static volatile long localTs;
    public static volatile double localX;
    public static volatile double localY;
    public static volatile double localZ;
    public static volatile long magnetFireTs;
    public static volatile boolean magnetFiring;
    public static volatile long magnetScopeTs;
    public static volatile boolean magnetScoping;
    public static volatile long[] pinnedLocal;
    public static volatile long scopePulseUntil;
    public static volatile boolean scoping;
    public static volatile long uplinkSidTs;
    public static volatile boolean wallEngaged;
    public static volatile float wallLockedX;
    public static volatile float wallLockedZ;
    public static volatile double wallOffsetMm;
    public static volatile double wallReleaseFromMm;
    public static volatile boolean wallReleasing;
    public static volatile long wallStartedAt;
    public static volatile boolean magnetOn = false;
    public static volatile float[] dir = {0.0f, 1.0f};
    public static volatile float[] lastDir = {0.0f, 1.0f};
    public static volatile float aimZ = 1.0f;
    public static volatile boolean localFreezeOn = false;
    public static volatile boolean tatuOn = false;
    public static volatile boolean freezeFireOn = false;
    public static volatile boolean freezeScopOn = false;
    public static volatile int teleportBaseState = 0;
    public static volatile int teleportSpeed = 3;
    public static volatile boolean wallPassOn = false;
    public static volatile int wallDistanceMm = 1000;
    public static volatile int depthMm = 1000;
    public static volatile int localShortId = -1;
    public static volatile boolean[] ignoredSlots = new boolean[256];
    public static final Object LOCK = new Object();
    public static final HashMap live = new HashMap();
    public static final HashMap held = new HashMap();

    public static void setIgnoredSlots(Collection collection) {
        boolean[] next = new boolean[256];
        if (collection != null) {
            Iterator it = collection.iterator();
            while (it.hasNext()) {
                Integer slot = (Integer) it.next();
                if (slot != null && slot.intValue() >= 0 && slot.intValue() < next.length) {
                    next[slot.intValue()] = true;
                }
            }
        }
        ignoredSlots = next;
    }

    public static void setDir(float x, float z) {
        double m = Math.sqrt((((double) x) * ((double) x)) + (((double) z) * ((double) z)));
        if (m < 0.05d) {
            return;
        }
        dir = new float[]{(float) (((double) x) / m), (float) (((double) z) / m)};
    }

    public static void setDir3D(float x, float y, float z) {
        double m = Math.sqrt((((double) x) * ((double) x)) + (((double) y) * ((double) y)) + (((double) z) * ((double) z)));
        if (m < 0.05d) {
            return;
        }
        aimX = (float) (((double) x) / m);
        aimY = (float) (((double) y) / m);
        aimZ = (float) (((double) z) / m);
    }

    public static void setLocalFreeze(boolean on) {
        localFreezeOn = on;
        if (!on) {
            heldUplink = null;
            localHold = false;
            pinnedLocal = null;
        }
    }

    public static void setTatu(boolean on) {
        tatuOn = on;
        haveDownAnchor = false;
    }

    public static void setFreezeFire(boolean on) {
        freezeFireOn = on;
    }

    public static void setFreezeScop(boolean on) {
        freezeScopOn = on;
    }

    public static void setTeleportBase(boolean on) {
        if (!on) {
            teleportBaseState = 0;
        }
    }

    public static int getTeleportSpeed() {
        return teleportSpeed;
    }

    public static void setTeleportSpeed(int times) {
        teleportSpeed = Math.max(1, Math.min(10, times));
    }

    public static void toggleTeleportBase() {
        int s = teleportBaseState;
        if (s == 0) {
            teleportBaseState = 1;
        } else if (s != 1) {
            teleportBaseState = 0;
        } else {
            teleportBaseState = 2;
        }
    }

    public static void setWallPass(boolean on) {
        boolean z = false;
        wallEngaged = false;
        wallStartedAt = SystemClock.elapsedRealtime();
        if (on) {
            wallOffsetMm = 0.0d;
            wallReleasing = false;
            wallPassOn = true;
            return;
        }
        wallPassOn = false;
        if (wallOffsetMm > 0.0d) {
            z = true;
        }
        wallReleasing = z;
        wallReleaseFromMm = wallOffsetMm;
        if (!wallReleasing) {
            wallOffsetMm = 0.0d;
        }
    }

    public static long[] wallPush(long encX, long encZ) {
        float fx;
        float fz;
        double off;
        if (!wallPassOn && !wallReleasing) {
            wallOffsetMm = 0.0d;
            wallEngaged = false;
            return null;
        }
        if (wallEngaged || wallReleasing) {
            fx = wallLockedX;
            fz = wallLockedZ;
        } else {
            float[] heading = dir;
            fx = heading[0];
            fz = heading[1];
        }
        double m = Math.sqrt((((double) fx) * ((double) fx)) + (((double) fz) * ((double) fz)));
        if (m < 0.05d) {
            return null;
        }
        float fx2 = (float) (((double) fx) / m);
        float fz2 = (float) (((double) fz) / m);
        double travelled = (SystemClock.elapsedRealtime() - wallStartedAt) * 3.0d;
        if (wallReleasing) {
            off = wallReleaseFromMm - travelled;
            if (off <= 0.0d) {
                wallReleasing = false;
                wallOffsetMm = 0.0d;
                return null;
            }
        } else {
            off = travelled;
            if (off >= wallDistanceMm) {
                off = wallDistanceMm;
                if (!wallEngaged) {
                    wallLockedX = fx2;
                    wallLockedZ = fz2;
                    wallEngaged = true;
                    LvShiftOverlay.refreshWall();
                }
            } else {
                wallLockedX = fx2;
                wallLockedZ = fz2;
            }
        }
        wallOffsetMm = off;
        long x = zz(encX) + Math.round(((double) fx2) * off);
        long z = zz(encZ) + Math.round(((double) fz2) * off);
        return new long[]{enc(x), enc(z)};
    }

    public static boolean tatuActive() {
        if (!tatuOn) {
            return false;
        }
        long now = SystemClock.elapsedRealtime();
        if (firing && now - firePulseUntil >= 2000) {
            firing = false;
        }
        if (scoping && now - scopePulseUntil >= 2000) {
            scoping = false;
        }
        return !firing && !scoping && now >= firePulseUntil && now >= scopePulseUntil;
    }

    public static long lowerY(long encY) {
        if (!tatuActive()) {
            haveDownAnchor = false;
            return encY;
        }
        long y = zz(encY);
        int depth = depthMm;
        if (!haveDownAnchor || (Math.abs(y - lastDownY) >= 450 && Math.abs(y - (lastDownY + ((long) depth))) >= 450)) {
            lastDownY = y - ((long) depth);
            haveDownAnchor = true;
            return enc(lastDownY);
        }
        return enc(lastDownY);
    }

    public static boolean isAnyActive() {
        return magnetOn || localFreezeOn || tatuOn || freezeFireOn || freezeScopOn || teleportBaseState != 0 || wallPassOn || wallReleasing;
    }

    public static boolean enemyFreezeActive() {
        long now = SystemClock.elapsedRealtime();
        if (!freezeFireOn || (!firing && now >= firePulseUntil)) {
            return freezeScopOn && (scoping || now < scopePulseUntil);
        }
        return true;
    }

    public static boolean isUplinkActive() {
        return localFreezeOn || tatuOn || wallPassOn || wallReleasing;
    }

    public static void observeCommand(int cmd) {
        long now = SystemClock.elapsedRealtime();
        switch (cmd) {
            case 103:
                firing = false;
                scoping = false;
                firePulseUntil = 0L;
                scopePulseUntil = 0L;
                magnetFiring = false;
                magnetScoping = false;
                break;
            case 104:
                firing = true;
                firePulseUntil = 700 + now;
                magnetFiring = true;
                magnetFireTs = now;
                break;
            case 105:
                firing = false;
                firePulseUntil = 0L;
                magnetFiring = false;
                break;
            case 137:
                scoping = true;
                scopePulseUntil = 1800 + now;
                magnetScoping = true;
                magnetScopeTs = now;
                break;
            case 138:
                scoping = false;
                scopePulseUntil = 0L;
                magnetScoping = false;
                break;
        }
    }

    /* JADX WARN: Bottom block not found for handler: all -> 0x00da */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static byte[] transformUp(byte[] r24) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 222
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.lvteam.LvTeamShift.transformUp(byte[]):byte[]");
    }

    public static byte[] transformDown(byte[] body) {
        if (body == null || body.length < 3) {
            return null;
        }
        synchronized (LOCK) {
            try {
                boolean fz = enemyFreezeActive();
                if (fz != freezeActive) {
                    freezeActive = fz;
                    held.clear();
                    if (fz && !live.isEmpty()) {
                        held.putAll(live);
                    }
                } else if (fz && held.isEmpty() && !live.isEmpty()) {
                    held.putAll(live);
                }
                latchLocal();
                if (body[0] == 0 && body[1] == 2) {
                    return rewriteSingle(body, fz);
                }
                return rewriteBatch(body, fz);
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public static void latchLocal() {
        if (!localFreezeOn) {
            localHold = false;
            pinnedLocal = null;
            return;
        }
        int loc = localShortId;
        if (loc < 0) {
            return;
        }
        if (localHold && pinnedLocal != null) {
            held.put(Integer.valueOf(loc), pinnedLocal);
            return;
        }
        long[] cur = (long[]) live.get(Integer.valueOf(loc));
        if (cur != null) {
            held.put(Integer.valueOf(loc), cur);
            pinnedLocal = cur;
            localHold = true;
        }
    }

    public static long[] heldPose(int sid, boolean fz) {
        int loc = localShortId;
        if (sid == loc) {
            if (localFreezeOn) {
                return (long[]) held.get(Integer.valueOf(sid));
            }
            return null;
        }
        if (fz) {
            return (long[]) held.get(Integer.valueOf(sid));
        }
        return null;
    }

    public static long[] recordPose(int sid, long rx, long ry, long rz, int poseEnd, boolean fz) {
        long[] np;
        long[] lp = {rx, ry, rz};
        live.put(Integer.valueOf(sid), lp);
        long[] hp = heldPose(sid, fz);
        long[] s = shift(sid, rx, ry, rz);
        if (s != null) {
            np = s;
        } else {
            np = hp != null ? hp : lp;
        }
        int loc = localShortId;
        if (tatuOn && loc >= 0 && sid == loc) {
            long ny = lowerY(np[1]);
            if (ny != np[1]) {
                np = new long[]{np[0], ny, np[2]};
            }
        }
        if (np[0] == rx && np[1] == ry && np[2] == rz) {
            return null;
        }
        return np;
    }

    public static byte[] rewriteSingle(byte[] body, boolean fz) {
        int poseEnd;
        long[] np;
        if (body.length < 4) {
            return null;
        }
        int sid = body[2] & 255;
        long[] v0 = readVarint(body, 3);
        if (v0 == null) {
            return null;
        }
        int p = (int) v0[1];
        long[] v1 = readVarint(body, p);
        if (v1 == null) {
            return null;
        }
        int p2 = (int) v1[1];
        long[] v2 = readVarint(body, p2);
        if (v2 == null || (np = recordPose(sid, v0[0], v1[0], v2[0], (poseEnd = (int) v2[1]), fz)) == null) {
            return null;
        }
        ByteArrayOutputStream o = new ByteArrayOutputStream(body.length + 16);
        o.write(body, 0, 3);
        writeVarint(o, np[0]);
        writeVarint(o, np[1]);
        writeVarint(o, np[2]);
        int afterPose = poseEnd;
        for (int i = 0; i < 3; i++) {
            long[] vv = readVarint(body, afterPose);
            if (vv == null) {
                break;
            }
            writeVarint(o, 0L);
            afterPose = (int) vv[1];
        }
        o.write(body, afterPose, body.length - afterPose);
        return o.toByteArray();
    }

    public static byte[] rewriteBatch(byte[] body, boolean fz) {
        long[] t;
        int i;
        boolean z;
        long[] v0 = readVarint(body, 0);
        byte[] bArr = null;
        if (v0 == null) {
            return null;
        }
        int i2 = 1;
        long[] cnt = readVarint(body, (int) v0[1]);
        if (cnt == null) {
            return null;
        }
        long n = zz(cnt[0]);
        if (n >= 0 && n <= 128) {
            int p = (int) cnt[1];
            ByteArrayOutputStream o = new ByteArrayOutputStream(body.length + 32);
            o.write(body, 0, p);
            int changed = 0;
            int i3 = 0;
            while (i3 < n) {
                if (p >= body.length) {
                    return bArr;
                }
                int sid = body[p] & 255;
                int recordStart = p;
                int p2 = p + 1;
                long[][] varints = new long[6][];
                int j = 0;
                for (int i4 = 6; j < i4; i4 = 6) {
                    varints[j] = readVarint(body, p2);
                    if (varints[j] == null) {
                        return bArr;
                    }
                    p2 = (int) varints[j][i2];
                    j++;
                    varints = varints;
                }
                long[][] varints2 = varints;
                long[] v1 = v0;
                int poseEnd = (int) varints2[2][i2];
                if (p2 + 5 > body.length || (t = readVarint(body, p2 + 5)) == null) {
                    return bArr;
                }
                long[] cnt2 = cnt;
                long n2 = n;
                int recordEnd = ((int) t[i2]) + i2;
                if (recordEnd > body.length) {
                    recordEnd = body.length;
                }
                long[] np = recordPose(sid, varints2[0][0], varints2[i2][0], varints2[2][0], poseEnd, fz);
                if (np == null) {
                    i = i2;
                    z = false;
                    int poseEnd2 = recordEnd - recordStart;
                    o.write(body, recordStart, poseEnd2);
                } else {
                    o.write(sid);
                    z = false;
                    writeVarint(o, np[0]);
                    writeVarint(o, np[1]);
                    writeVarint(o, np[2]);
                    writeVarint(o, 0L);
                    writeVarint(o, 0L);
                    writeVarint(o, 0L);
                    i = 1;
                    int afterVel = (int) varints2[5][1];
                    o.write(body, afterVel, recordEnd - afterVel);
                    changed++;
                }
                p = recordEnd;
                i3++;
                cnt = cnt2;
                v0 = v1;
                i2 = i;
                n = n2;
                bArr = null;
            }
            if (p < body.length) {
                o.write(body, p, body.length - p);
            }
            if (changed > 0) {
                return o.toByteArray();
            }
            return null;
        }
        return null;
    }

    public static boolean magnetActive() {
        if (!magnetOn) {
            return false;
        }
        long now = SystemClock.elapsedRealtime();
        if (magnetFiring && now - magnetFireTs > 5000) {
            magnetFiring = false;
        }
        if (magnetScoping && now - magnetScopeTs > 5000) {
            magnetScoping = false;
        }
        return magnetFiring || magnetScoping;
    }

    public static long[] shift(int sid, long rx, long ry, long rz) {
        if (!magnetActive()) {
            return null;
        }
        int loc = localShortId;
        if (loc >= 0 && sid == loc) {
            return null;
        }
        boolean[] ignored = ignoredSlots;
        if ((sid >= 0 && sid < ignored.length && ignored[sid]) || localTs == 0) {
            return null;
        }
        long ey = zz(ry);
        long fixedY = enc(660 + ey);
        double px = localX;
        double pz = localZ;
        float fx = aimX;
        float fz = aimZ;
        double hm2 = (((double) fx) * ((double) fx)) + (((double) fz) * ((double) fz));
        if (hm2 < 0.001d) {
            return null;
        }
        long ex = zz(rx);
        long ez = zz(rz);
        double dx = ex - px;
        double dz = ez - pz;
        double horizontalDist = Math.sqrt((dx * dx) + (dz * dz));
        if (horizontalDist < 500.0d) {
            return null;
        }
        double flatLen = Math.sqrt(hm2);
        double ffx = ((double) fx) / flatLen;
        double ffz = ((double) fz) / flatLen;
        double nx = px + (ffx * horizontalDist);
        double nz = pz + (ffz * horizontalDist);
        double ffx2 = ex;
        double ldx = nx - ffx2;
        double ffz2 = ez;
        double ldz = nz - ffz2;
        double lateralDist = Math.sqrt((ldx * ldx) + (ldz * ldz));
        if (lateralDist > 8000.0d) {
            double s = 8000.0d / lateralDist;
            nx = ex + (ldx * s);
            nz = ez + (ldz * s);
        }
        long enx = enc(Math.round(nx));
        long enz = enc(Math.round(nz));
        return new long[]{enx, fixedY, enz};
    }

    public static long[] readVarint(byte[] b, int p) {
        if (p < 0 || p >= b.length) {
            return null;
        }
        long val = 0;
        int shift = 0;
        while (p < b.length && shift <= 63) {
            int p2 = p + 1;
            int c = b[p] & 255;
            val |= ((long) (c & 127)) << shift;
            if (c < 128) {
                return new long[]{val, p2};
            }
            shift += 7;
            p = p2;
        }
        return null;
    }

    public static void writeVarint(ByteArrayOutputStream o, long v) {
        while (((-128) & v) != 0) {
            o.write((int) ((127 & v) | 128));
            v >>>= 7;
        }
        o.write((int) v);
    }

    public static long zz(long v) {
        return (v >>> 1) ^ (-(1 & v));
    }

    public static long enc(long v) {
        return (v << 1) ^ (v >> 63);
    }
}
