package com.lvteam;

import java.util.Arrays;

/* JADX INFO: loaded from: classes.dex */
public final class UdpDecodedFrame {
    public final int declaredPayloadLength;
    public final int flags;
    public final int orderId;
    public final byte[] payload;
    public final boolean reliable;
    public final int sendOption;
    public final int tag;

    public UdpDecodedFrame(int tag, byte[] payload, boolean reliable, int sendOption, int orderId, int flags, int declaredPayloadLength) {
        this.tag = tag;
        this.payload = Arrays.copyOf(payload, payload.length);
        this.reliable = reliable;
        this.sendOption = sendOption;
        this.orderId = orderId;
        this.flags = flags;
        this.declaredPayloadLength = declaredPayloadLength;
    }
}
