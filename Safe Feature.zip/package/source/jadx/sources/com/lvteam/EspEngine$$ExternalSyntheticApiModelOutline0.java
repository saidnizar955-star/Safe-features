package com.lvteam;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class EspEngine$$ExternalSyntheticApiModelOutline0 {
}
