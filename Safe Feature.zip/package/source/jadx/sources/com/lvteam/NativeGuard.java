package com.lvteam;

/* JADX INFO: loaded from: classes.dex */
public final class NativeGuard {
    public static native int check();

    public static native int pulse();

    static {
        System.loadLibrary("lvguard");
    }

    public static String describe(int bits) {
        StringBuilder sb = new StringBuilder();
        if ((bits & 1) != 0) {
            append(sb, "Root (native)");
        }
        if ((bits & 2) != 0) {
            append(sb, "Frida (native)");
        }
        if ((bits & 4) != 0) {
            append(sb, "Xposed (native)");
        }
        if ((bits & 8) != 0) {
            append(sb, "Debugger (native)");
        }
        if ((bits & 16) != 0) {
            append(sb, "Emulator (native)");
        }
        if ((bits & 32) != 0) {
            append(sb, "Memory Tamper");
        }
        if ((bits & 64) != 0) {
            append(sb, "Ptrace Debugger");
        }
        if ((bits & 128) != 0) {
            append(sb, "Timing Anomaly");
        }
        if ((bits & 256) != 0) {
            append(sb, "Library Injection");
        }
        if (sb.length() == 0) {
            return null;
        }
        return sb.toString();
    }

    private static void append(StringBuilder sb, String s) {
        if (sb.length() > 0) {
            sb.append(", ");
        }
        sb.append(s);
    }
}
