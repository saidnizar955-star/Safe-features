.class public abstract Lcom/lvteam/LvTeamShift;
.super Ljava/lang/Object;
.source "LvTeamShift.java"


# static fields
.field public static final LOCK:Ljava/lang/Object;

.field public static volatile aimX:F

.field public static volatile aimY:F

.field public static volatile aimZ:F

.field public static volatile depthMm:I

.field public static volatile dir:[F

.field public static volatile firePulseUntil:J

.field public static volatile firing:Z

.field public static freezeActive:Z

.field public static volatile freezeFireOn:Z

.field public static volatile freezeScopOn:Z

.field public static volatile haveDownAnchor:Z

.field public static final held:Ljava/util/HashMap;

.field public static volatile heldUplink:[J

.field public static volatile ignoredSlots:[Z

.field public static volatile lastDir:[F

.field public static lastDownY:J

.field public static final live:Ljava/util/HashMap;

.field public static volatile localFreezeOn:Z

.field public static volatile localHold:Z

.field public static volatile localShortId:I

.field public static volatile localTs:J

.field public static volatile localX:D

.field public static volatile localY:D

.field public static volatile localZ:D

.field public static volatile magnetFireTs:J

.field public static volatile magnetFiring:Z

.field public static volatile magnetOn:Z

.field public static volatile magnetScopeTs:J

.field public static volatile magnetScoping:Z

.field public static volatile pinnedLocal:[J

.field public static volatile scopePulseUntil:J

.field public static volatile scoping:Z

.field public static volatile tatuOn:Z

.field public static volatile teleportBaseState:I

.field public static volatile teleportSpeed:I

.field public static volatile uplinkSidTs:J

.field public static volatile wallDistanceMm:I

.field public static volatile wallEngaged:Z

.field public static volatile wallLockedX:F

.field public static volatile wallLockedZ:F

.field public static volatile wallOffsetMm:D

.field public static volatile wallPassOn:Z

.field public static volatile wallReleaseFromMm:D

.field public static volatile wallReleasing:Z

.field public static volatile wallStartedAt:J


# direct methods
.method static constructor <clinit>()V
    .locals 4

    .line 10
    const/4 v0, 0x0

    sput-boolean v0, Lcom/lvteam/LvTeamShift;->magnetOn:Z

    .line 11
    const/high16 v1, 0x3f800000    # 1.0f

    const/4 v2, 0x2

    new-array v3, v2, [F

    fill-array-data v3, :array_0

    sput-object v3, Lcom/lvteam/LvTeamShift;->dir:[F

    .line 12
    new-array v2, v2, [F

    fill-array-data v2, :array_1

    sput-object v2, Lcom/lvteam/LvTeamShift;->lastDir:[F

    .line 15
    sput v1, Lcom/lvteam/LvTeamShift;->aimZ:F

    .line 17
    sput-boolean v0, Lcom/lvteam/LvTeamShift;->localFreezeOn:Z

    .line 18
    sput-boolean v0, Lcom/lvteam/LvTeamShift;->tatuOn:Z

    .line 20
    sput-boolean v0, Lcom/lvteam/LvTeamShift;->freezeFireOn:Z

    .line 22
    sput-boolean v0, Lcom/lvteam/LvTeamShift;->freezeScopOn:Z

    .line 26
    sput v0, Lcom/lvteam/LvTeamShift;->teleportBaseState:I

    .line 30
    const/4 v1, 0x3

    sput v1, Lcom/lvteam/LvTeamShift;->teleportSpeed:I

    .line 32
    sput-boolean v0, Lcom/lvteam/LvTeamShift;->wallPassOn:Z

    .line 35
    const/16 v0, 0x3e8

    sput v0, Lcom/lvteam/LvTeamShift;->wallDistanceMm:I

    .line 53
    sput v0, Lcom/lvteam/LvTeamShift;->depthMm:I

    .line 62
    const/4 v0, -0x1

    sput v0, Lcom/lvteam/LvTeamShift;->localShortId:I

    .line 69
    const/16 v0, 0x100

    new-array v0, v0, [Z

    sput-object v0, Lcom/lvteam/LvTeamShift;->ignoredSlots:[Z

    .line 97
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lcom/lvteam/LvTeamShift;->LOCK:Ljava/lang/Object;

    .line 98
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    sput-object v0, Lcom/lvteam/LvTeamShift;->live:Ljava/util/HashMap;

    .line 99
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    sput-object v0, Lcom/lvteam/LvTeamShift;->held:Ljava/util/HashMap;

    return-void

    :array_0
    .array-data 4
        0x0
        0x3f800000    # 1.0f
    .end array-data

    :array_1
    .array-data 4
        0x0
        0x3f800000    # 1.0f
    .end array-data
.end method

.method public static enc(J)J
    .locals 4
    .param p0, "v"    # J

    .line 614
    const/4 v0, 0x1

    shl-long v0, p0, v0

    const/16 v2, 0x3f

    shr-long v2, p0, v2

    xor-long/2addr v0, v2

    return-wide v0
.end method

.method public static enemyFreezeActive()Z
    .locals 6

    .line 293
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    .line 294
    .local v0, "now":J
    sget-boolean v2, Lcom/lvteam/LvTeamShift;->freezeFireOn:Z

    const/4 v3, 0x1

    if-eqz v2, :cond_1

    sget-boolean v2, Lcom/lvteam/LvTeamShift;->firing:Z

    if-nez v2, :cond_0

    sget-wide v4, Lcom/lvteam/LvTeamShift;->firePulseUntil:J

    cmp-long v2, v0, v4

    if-gez v2, :cond_1

    :cond_0
    return v3

    .line 295
    :cond_1
    sget-boolean v2, Lcom/lvteam/LvTeamShift;->freezeScopOn:Z

    if-eqz v2, :cond_3

    sget-boolean v2, Lcom/lvteam/LvTeamShift;->scoping:Z

    if-nez v2, :cond_2

    sget-wide v4, Lcom/lvteam/LvTeamShift;->scopePulseUntil:J

    cmp-long v2, v0, v4

    if-gez v2, :cond_3

    :cond_2
    goto :goto_0

    :cond_3
    const/4 v3, 0x0

    :goto_0
    return v3
.end method

.method public static getTeleportSpeed()I
    .locals 1

    .line 148
    sget v0, Lcom/lvteam/LvTeamShift;->teleportSpeed:I

    return v0
.end method

.method public static heldPose(IZ)[J
    .locals 3
    .param p0, "sid"    # I
    .param p1, "fz"    # Z

    .line 425
    sget v0, Lcom/lvteam/LvTeamShift;->localShortId:I

    .line 426
    .local v0, "loc":I
    const/4 v1, 0x0

    if-ne p0, v0, :cond_1

    .line 427
    sget-boolean v2, Lcom/lvteam/LvTeamShift;->localFreezeOn:Z

    if-eqz v2, :cond_0

    sget-object v1, Lcom/lvteam/LvTeamShift;->held:Ljava/util/HashMap;

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, [J

    :cond_0
    return-object v1

    .line 429
    :cond_1
    if-eqz p1, :cond_2

    sget-object v1, Lcom/lvteam/LvTeamShift;->held:Ljava/util/HashMap;

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, [J

    :cond_2
    return-object v1
.end method

.method public static isAnyActive()Z
    .locals 1

    .line 288
    sget-boolean v0, Lcom/lvteam/LvTeamShift;->magnetOn:Z

    if-nez v0, :cond_0

    sget-boolean v0, Lcom/lvteam/LvTeamShift;->localFreezeOn:Z

    if-nez v0, :cond_0

    sget-boolean v0, Lcom/lvteam/LvTeamShift;->tatuOn:Z

    if-nez v0, :cond_0

    sget-boolean v0, Lcom/lvteam/LvTeamShift;->freezeFireOn:Z

    if-nez v0, :cond_0

    sget-boolean v0, Lcom/lvteam/LvTeamShift;->freezeScopOn:Z

    if-nez v0, :cond_0

    sget v0, Lcom/lvteam/LvTeamShift;->teleportBaseState:I

    if-nez v0, :cond_0

    sget-boolean v0, Lcom/lvteam/LvTeamShift;->wallPassOn:Z

    if-nez v0, :cond_0

    sget-boolean v0, Lcom/lvteam/LvTeamShift;->wallReleasing:Z

    if-eqz v0, :cond_1

    :cond_0
    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    goto :goto_1

    :goto_0
    const/4 v0, 0x1

    :goto_1
    return v0
.end method

.method public static isUplinkActive()Z
    .locals 1

    .line 299
    sget-boolean v0, Lcom/lvteam/LvTeamShift;->localFreezeOn:Z

    if-nez v0, :cond_0

    sget-boolean v0, Lcom/lvteam/LvTeamShift;->tatuOn:Z

    if-nez v0, :cond_0

    sget-boolean v0, Lcom/lvteam/LvTeamShift;->wallPassOn:Z

    if-nez v0, :cond_0

    sget-boolean v0, Lcom/lvteam/LvTeamShift;->wallReleasing:Z

    if-eqz v0, :cond_1

    :cond_0
    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    goto :goto_1

    :goto_0
    const/4 v0, 0x1

    :goto_1
    return v0
.end method

.method public static latchLocal()V
    .locals 4

    .line 405
    sget-boolean v0, Lcom/lvteam/LvTeamShift;->localFreezeOn:Z

    if-nez v0, :cond_0

    .line 406
    const/4 v0, 0x0

    sput-boolean v0, Lcom/lvteam/LvTeamShift;->localHold:Z

    .line 407
    const/4 v0, 0x0

    sput-object v0, Lcom/lvteam/LvTeamShift;->pinnedLocal:[J

    .line 408
    return-void

    .line 410
    :cond_0
    sget v0, Lcom/lvteam/LvTeamShift;->localShortId:I

    .line 411
    .local v0, "loc":I
    if-gez v0, :cond_1

    return-void

    .line 412
    :cond_1
    sget-boolean v1, Lcom/lvteam/LvTeamShift;->localHold:Z

    if-eqz v1, :cond_2

    sget-object v1, Lcom/lvteam/LvTeamShift;->pinnedLocal:[J

    if-eqz v1, :cond_2

    .line 413
    sget-object v1, Lcom/lvteam/LvTeamShift;->held:Ljava/util/HashMap;

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    sget-object v3, Lcom/lvteam/LvTeamShift;->pinnedLocal:[J

    invoke-virtual {v1, v2, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 414
    return-void

    .line 416
    :cond_2
    sget-object v1, Lcom/lvteam/LvTeamShift;->live:Ljava/util/HashMap;

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, [J

    .line 417
    .local v1, "cur":[J
    if-eqz v1, :cond_3

    .line 418
    sget-object v2, Lcom/lvteam/LvTeamShift;->held:Ljava/util/HashMap;

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v2, v3, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 419
    sput-object v1, Lcom/lvteam/LvTeamShift;->pinnedLocal:[J

    .line 420
    const/4 v2, 0x1

    sput-boolean v2, Lcom/lvteam/LvTeamShift;->localHold:Z

    .line 422
    :cond_3
    return-void
.end method

.method public static lowerY(J)J
    .locals 9
    .param p0, "encY"    # J

    .line 272
    invoke-static {}, Lcom/lvteam/LvTeamShift;->tatuActive()Z

    move-result v0

    if-nez v0, :cond_0

    .line 273
    const/4 v0, 0x0

    sput-boolean v0, Lcom/lvteam/LvTeamShift;->haveDownAnchor:Z

    .line 274
    return-wide p0

    .line 276
    :cond_0
    invoke-static {p0, p1}, Lcom/lvteam/LvTeamShift;->zz(J)J

    move-result-wide v0

    .line 277
    .local v0, "y":J
    sget v2, Lcom/lvteam/LvTeamShift;->depthMm:I

    .line 278
    .local v2, "depth":I
    sget-boolean v3, Lcom/lvteam/LvTeamShift;->haveDownAnchor:Z

    if-eqz v3, :cond_2

    .line 279
    sget-wide v3, Lcom/lvteam/LvTeamShift;->lastDownY:J

    sub-long v3, v0, v3

    invoke-static {v3, v4}, Ljava/lang/Math;->abs(J)J

    move-result-wide v3

    const-wide/16 v5, 0x1c2

    cmp-long v3, v3, v5

    if-gez v3, :cond_1

    sget-wide v3, Lcom/lvteam/LvTeamShift;->lastDownY:J

    invoke-static {v3, v4}, Lcom/lvteam/LvTeamShift;->enc(J)J

    move-result-wide v3

    return-wide v3

    .line 280
    :cond_1
    sget-wide v3, Lcom/lvteam/LvTeamShift;->lastDownY:J

    int-to-long v7, v2

    add-long/2addr v3, v7

    sub-long v3, v0, v3

    invoke-static {v3, v4}, Ljava/lang/Math;->abs(J)J

    move-result-wide v3

    cmp-long v3, v3, v5

    if-gez v3, :cond_2

    sget-wide v3, Lcom/lvteam/LvTeamShift;->lastDownY:J

    invoke-static {v3, v4}, Lcom/lvteam/LvTeamShift;->enc(J)J

    move-result-wide v3

    return-wide v3

    .line 282
    :cond_2
    int-to-long v3, v2

    sub-long v3, v0, v3

    sput-wide v3, Lcom/lvteam/LvTeamShift;->lastDownY:J

    .line 283
    const/4 v3, 0x1

    sput-boolean v3, Lcom/lvteam/LvTeamShift;->haveDownAnchor:Z

    .line 284
    sget-wide v3, Lcom/lvteam/LvTeamShift;->lastDownY:J

    invoke-static {v3, v4}, Lcom/lvteam/LvTeamShift;->enc(J)J

    move-result-wide v3

    return-wide v3
.end method

.method public static magnetActive()Z
    .locals 8

    .line 531
    sget-boolean v0, Lcom/lvteam/LvTeamShift;->magnetOn:Z

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    .line 532
    :cond_0
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v2

    .line 533
    .local v2, "now":J
    sget-boolean v0, Lcom/lvteam/LvTeamShift;->magnetFiring:Z

    const-wide/16 v4, 0x1388

    if-eqz v0, :cond_1

    sget-wide v6, Lcom/lvteam/LvTeamShift;->magnetFireTs:J

    sub-long v6, v2, v6

    cmp-long v0, v6, v4

    if-lez v0, :cond_1

    .line 534
    sput-boolean v1, Lcom/lvteam/LvTeamShift;->magnetFiring:Z

    .line 536
    :cond_1
    sget-boolean v0, Lcom/lvteam/LvTeamShift;->magnetScoping:Z

    if-eqz v0, :cond_2

    sget-wide v6, Lcom/lvteam/LvTeamShift;->magnetScopeTs:J

    sub-long v6, v2, v6

    cmp-long v0, v6, v4

    if-lez v0, :cond_2

    .line 537
    sput-boolean v1, Lcom/lvteam/LvTeamShift;->magnetScoping:Z

    .line 539
    :cond_2
    sget-boolean v0, Lcom/lvteam/LvTeamShift;->magnetFiring:Z

    if-nez v0, :cond_3

    sget-boolean v0, Lcom/lvteam/LvTeamShift;->magnetScoping:Z

    if-eqz v0, :cond_4

    :cond_3
    const/4 v1, 0x1

    :cond_4
    return v1
.end method

.method public static observeCommand(I)V
    .locals 6
    .param p0, "cmd"    # I

    .line 303
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    .line 304
    .local v0, "now":J
    const/4 v2, 0x1

    const-wide/16 v3, 0x0

    const/4 v5, 0x0

    sparse-switch p0, :sswitch_data_0

    goto :goto_0

    .line 331
    :sswitch_0
    sput-boolean v5, Lcom/lvteam/LvTeamShift;->scoping:Z

    .line 332
    sput-wide v3, Lcom/lvteam/LvTeamShift;->scopePulseUntil:J

    .line 333
    sput-boolean v5, Lcom/lvteam/LvTeamShift;->magnetScoping:Z

    .line 334
    goto :goto_0

    .line 325
    :sswitch_1
    sput-boolean v2, Lcom/lvteam/LvTeamShift;->scoping:Z

    .line 326
    const-wide/16 v3, 0x708

    add-long/2addr v3, v0

    sput-wide v3, Lcom/lvteam/LvTeamShift;->scopePulseUntil:J

    .line 327
    sput-boolean v2, Lcom/lvteam/LvTeamShift;->magnetScoping:Z

    .line 328
    sput-wide v0, Lcom/lvteam/LvTeamShift;->magnetScopeTs:J

    .line 329
    goto :goto_0

    .line 320
    :sswitch_2
    sput-boolean v5, Lcom/lvteam/LvTeamShift;->firing:Z

    .line 321
    sput-wide v3, Lcom/lvteam/LvTeamShift;->firePulseUntil:J

    .line 322
    sput-boolean v5, Lcom/lvteam/LvTeamShift;->magnetFiring:Z

    .line 323
    goto :goto_0

    .line 314
    :sswitch_3
    sput-boolean v2, Lcom/lvteam/LvTeamShift;->firing:Z

    .line 315
    const-wide/16 v3, 0x2bc

    add-long/2addr v3, v0

    sput-wide v3, Lcom/lvteam/LvTeamShift;->firePulseUntil:J

    .line 316
    sput-boolean v2, Lcom/lvteam/LvTeamShift;->magnetFiring:Z

    .line 317
    sput-wide v0, Lcom/lvteam/LvTeamShift;->magnetFireTs:J

    .line 318
    goto :goto_0

    .line 306
    :sswitch_4
    sput-boolean v5, Lcom/lvteam/LvTeamShift;->firing:Z

    .line 307
    sput-boolean v5, Lcom/lvteam/LvTeamShift;->scoping:Z

    .line 308
    sput-wide v3, Lcom/lvteam/LvTeamShift;->firePulseUntil:J

    .line 309
    sput-wide v3, Lcom/lvteam/LvTeamShift;->scopePulseUntil:J

    .line 310
    sput-boolean v5, Lcom/lvteam/LvTeamShift;->magnetFiring:Z

    .line 311
    sput-boolean v5, Lcom/lvteam/LvTeamShift;->magnetScoping:Z

    .line 312
    nop

    .line 338
    :goto_0
    return-void

    :sswitch_data_0
    .sparse-switch
        0x67 -> :sswitch_4
        0x68 -> :sswitch_3
        0x69 -> :sswitch_2
        0x89 -> :sswitch_1
        0x8a -> :sswitch_0
    .end sparse-switch
.end method

.method public static readVarint([BI)[J
    .locals 9
    .param p0, "b"    # [B
    .param p1, "p"    # I

    .line 589
    const/4 v0, 0x1

    const/4 v1, 0x0

    if-ltz p1, :cond_0

    array-length v2, p0

    if-lt p1, v2, :cond_1

    :cond_0
    goto :goto_1

    .line 590
    :cond_1
    const-wide/16 v2, 0x0

    .line 591
    .local v2, "val":J
    const/4 v4, 0x0

    .line 592
    .local v4, "shift":I
    :goto_0
    array-length v5, p0

    if-ge p1, v5, :cond_3

    const/16 v5, 0x3f

    if-gt v4, v5, :cond_3

    .line 593
    add-int/lit8 v5, p1, 0x1

    .end local p1    # "p":I
    .local v5, "p":I
    aget-byte p1, p0, p1

    and-int/lit16 p1, p1, 0xff

    .line 594
    .local p1, "c":I
    and-int/lit8 v6, p1, 0x7f

    int-to-long v6, v6

    shl-long/2addr v6, v4

    or-long/2addr v2, v6

    .line 595
    const/16 v6, 0x80

    if-ge p1, v6, :cond_2

    int-to-long v6, v5

    const/4 v1, 0x2

    new-array v1, v1, [J

    const/4 v8, 0x0

    aput-wide v2, v1, v8

    aput-wide v6, v1, v0

    return-object v1

    .line 596
    :cond_2
    nop

    .end local p1    # "c":I
    add-int/lit8 v4, v4, 0x7

    .line 597
    move p1, v5

    goto :goto_0

    .line 598
    .end local v5    # "p":I
    .local p1, "p":I
    :cond_3
    return-object v1

    .line 589
    .end local v2    # "val":J
    .end local v4    # "shift":I
    :goto_1
    return-object v1
.end method

.method public static recordPose(IJJJIZ)[J
    .locals 17
    .param p0, "sid"    # I
    .param p1, "rx"    # J
    .param p3, "ry"    # J
    .param p5, "rz"    # J
    .param p7, "poseEnd"    # I
    .param p8, "fz"    # Z

    .line 433
    move/from16 v0, p0

    const/4 v1, 0x3

    new-array v2, v1, [J

    const/4 v3, 0x0

    aput-wide p1, v2, v3

    const/4 v4, 0x1

    aput-wide p3, v2, v4

    const/4 v5, 0x2

    aput-wide p5, v2, v5

    .line 434
    .local v2, "lp":[J
    sget-object v6, Lcom/lvteam/LvTeamShift;->live:Ljava/util/HashMap;

    invoke-static/range {p0 .. p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-virtual {v6, v7, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 435
    move/from16 v6, p8

    invoke-static {v0, v6}, Lcom/lvteam/LvTeamShift;->heldPose(IZ)[J

    move-result-object v7

    .line 437
    .local v7, "hp":[J
    invoke-static/range {p0 .. p6}, Lcom/lvteam/LvTeamShift;->shift(IJJJ)[J

    move-result-object v8

    .line 438
    .local v8, "s":[J
    if-eqz v8, :cond_0

    move-object v9, v8

    goto :goto_0

    :cond_0
    if-eqz v7, :cond_1

    move-object v9, v7

    goto :goto_0

    :cond_1
    move-object v9, v2

    .line 440
    .local v9, "np":[J
    :goto_0
    sget v10, Lcom/lvteam/LvTeamShift;->localShortId:I

    .line 441
    .local v10, "loc":I
    sget-boolean v11, Lcom/lvteam/LvTeamShift;->tatuOn:Z

    if-eqz v11, :cond_2

    if-ltz v10, :cond_2

    if-ne v0, v10, :cond_2

    .line 442
    aget-wide v11, v9, v4

    invoke-static {v11, v12}, Lcom/lvteam/LvTeamShift;->lowerY(J)J

    move-result-wide v11

    .line 443
    .local v11, "ny":J
    aget-wide v13, v9, v4

    cmp-long v13, v11, v13

    if-eqz v13, :cond_2

    aget-wide v13, v9, v3

    aget-wide v15, v9, v5

    new-array v1, v1, [J

    aput-wide v13, v1, v3

    aput-wide v11, v1, v4

    aput-wide v15, v1, v5

    move-object v9, v1

    .line 445
    .end local v11    # "ny":J
    :cond_2
    aget-wide v11, v9, v3

    cmp-long v1, v11, p1

    if-nez v1, :cond_3

    aget-wide v3, v9, v4

    cmp-long v1, v3, p3

    if-nez v1, :cond_3

    aget-wide v3, v9, v5

    cmp-long v1, v3, p5

    if-nez v1, :cond_3

    const/4 v1, 0x0

    return-object v1

    .line 446
    :cond_3
    return-object v9
.end method

.method public static rewriteBatch([BZ)[B
    .locals 27
    .param p0, "body"    # [B
    .param p1, "fz"    # Z

    .line 478
    move-object/from16 v0, p0

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcom/lvteam/LvTeamShift;->readVarint([BI)[J

    move-result-object v2

    .line 479
    .local v2, "v0":[J
    const/4 v3, 0x0

    if-nez v2, :cond_0

    return-object v3

    .line 480
    :cond_0
    const/4 v4, 0x1

    aget-wide v5, v2, v4

    long-to-int v5, v5

    invoke-static {v0, v5}, Lcom/lvteam/LvTeamShift;->readVarint([BI)[J

    move-result-object v5

    .line 481
    .local v5, "cnt":[J
    if-nez v5, :cond_1

    return-object v3

    .line 482
    :cond_1
    aget-wide v6, v5, v1

    invoke-static {v6, v7}, Lcom/lvteam/LvTeamShift;->zz(J)J

    move-result-wide v6

    .line 483
    .local v6, "n":J
    const-wide/16 v8, 0x0

    cmp-long v10, v6, v8

    if-ltz v10, :cond_d

    const-wide/16 v10, 0x80

    cmp-long v10, v6, v10

    if-lez v10, :cond_2

    move-object v9, v2

    move-object v8, v5

    move-wide/from16 v25, v6

    goto/16 :goto_4

    .line 484
    :cond_2
    aget-wide v10, v5, v4

    long-to-int v10, v10

    .line 486
    .local v10, "p":I
    new-instance v11, Ljava/io/ByteArrayOutputStream;

    array-length v12, v0

    add-int/lit8 v12, v12, 0x20

    invoke-direct {v11, v12}, Ljava/io/ByteArrayOutputStream;-><init>(I)V

    .line 487
    .local v11, "o":Ljava/io/ByteArrayOutputStream;
    invoke-virtual {v11, v0, v1, v10}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    .line 488
    const/4 v12, 0x0

    .line 489
    .local v12, "changed":I
    const/4 v13, 0x0

    .local v13, "i":I
    :goto_0
    int-to-long v14, v13

    cmp-long v14, v14, v6

    if-gez v14, :cond_a

    .line 490
    array-length v14, v0

    if-lt v10, v14, :cond_3

    return-object v3

    .line 491
    :cond_3
    aget-byte v14, v0, v10

    and-int/lit16 v14, v14, 0xff

    .line 492
    .local v14, "sid":I
    move v15, v10

    .line 493
    .local v15, "recordStart":I
    add-int/lit8 v10, v10, 0x1

    .line 494
    const/4 v8, 0x6

    new-array v9, v8, [[J

    .line 495
    .local v9, "varints":[[J
    const/16 v16, 0x0

    move/from16 v1, v16

    .local v1, "j":I
    :goto_1
    if-ge v1, v8, :cond_5

    .line 496
    invoke-static {v0, v10}, Lcom/lvteam/LvTeamShift;->readVarint([BI)[J

    move-result-object v16

    aput-object v16, v9, v1

    .line 497
    aget-object v16, v9, v1

    if-nez v16, :cond_4

    return-object v3

    .line 498
    :cond_4
    aget-object v16, v9, v1

    move-object/from16 v24, v9

    .end local v9    # "varints":[[J
    .local v24, "varints":[[J
    aget-wide v8, v16, v4

    long-to-int v10, v8

    .line 495
    add-int/lit8 v1, v1, 0x1

    move-object/from16 v9, v24

    const/4 v8, 0x6

    goto :goto_1

    .end local v24    # "varints":[[J
    .restart local v9    # "varints":[[J
    :cond_5
    move-object/from16 v24, v9

    .line 500
    .end local v1    # "j":I
    .end local v9    # "varints":[[J
    .restart local v24    # "varints":[[J
    const/4 v1, 0x2

    aget-object v8, v24, v1

    move-object v9, v2

    .end local v2    # "v0":[J
    .local v9, "v0":[J
    aget-wide v1, v8, v4

    long-to-int v1, v1

    .line 501
    .local v1, "poseEnd":I
    add-int/lit8 v2, v10, 0x5

    array-length v8, v0

    if-le v2, v8, :cond_6

    return-object v3

    .line 502
    :cond_6
    add-int/lit8 v2, v10, 0x5

    invoke-static {v0, v2}, Lcom/lvteam/LvTeamShift;->readVarint([BI)[J

    move-result-object v2

    .line 503
    .local v2, "t":[J
    if-nez v2, :cond_7

    return-object v3

    .line 504
    :cond_7
    move-object v8, v5

    move-wide/from16 v25, v6

    .end local v5    # "cnt":[J
    .end local v6    # "n":J
    .local v8, "cnt":[J
    .local v25, "n":J
    aget-wide v5, v2, v4

    long-to-int v5, v5

    add-int/2addr v5, v4

    .line 505
    .local v5, "recordEnd":I
    array-length v6, v0

    if-le v5, v6, :cond_8

    array-length v5, v0

    .line 507
    :cond_8
    const/4 v6, 0x0

    aget-object v7, v24, v6

    aget-wide v16, v7, v6

    aget-object v7, v24, v4

    aget-wide v18, v7, v6

    const/4 v7, 0x2

    aget-object v20, v24, v7

    aget-wide v21, v20, v6

    move v6, v15

    .end local v15    # "recordStart":I
    .local v6, "recordStart":I
    move v15, v14

    move-wide/from16 v20, v21

    move/from16 v22, v1

    move/from16 v23, p1

    invoke-static/range {v15 .. v23}, Lcom/lvteam/LvTeamShift;->recordPose(IJJJIZ)[J

    move-result-object v7

    .line 508
    .local v7, "np":[J
    if-eqz v7, :cond_9

    .line 509
    invoke-virtual {v11, v14}, Ljava/io/ByteArrayOutputStream;->write(I)V

    .line 510
    const/4 v15, 0x0

    aget-wide v3, v7, v15

    invoke-static {v11, v3, v4}, Lcom/lvteam/LvTeamShift;->writeVarint(Ljava/io/ByteArrayOutputStream;J)V

    .line 511
    move v4, v1

    move-object/from16 v18, v2

    const/4 v3, 0x1

    .end local v1    # "poseEnd":I
    .end local v2    # "t":[J
    .local v4, "poseEnd":I
    .local v18, "t":[J
    aget-wide v1, v7, v3

    invoke-static {v11, v1, v2}, Lcom/lvteam/LvTeamShift;->writeVarint(Ljava/io/ByteArrayOutputStream;J)V

    .line 512
    const/4 v1, 0x2

    aget-wide v1, v7, v1

    invoke-static {v11, v1, v2}, Lcom/lvteam/LvTeamShift;->writeVarint(Ljava/io/ByteArrayOutputStream;J)V

    .line 513
    const-wide/16 v1, 0x0

    invoke-static {v11, v1, v2}, Lcom/lvteam/LvTeamShift;->writeVarint(Ljava/io/ByteArrayOutputStream;J)V

    .line 514
    invoke-static {v11, v1, v2}, Lcom/lvteam/LvTeamShift;->writeVarint(Ljava/io/ByteArrayOutputStream;J)V

    .line 515
    invoke-static {v11, v1, v2}, Lcom/lvteam/LvTeamShift;->writeVarint(Ljava/io/ByteArrayOutputStream;J)V

    .line 516
    const/4 v3, 0x5

    aget-object v3, v24, v3

    const/16 v17, 0x1

    aget-wide v1, v3, v17

    long-to-int v1, v1

    .line 517
    .local v1, "afterVel":I
    sub-int v2, v5, v1

    invoke-virtual {v11, v0, v1, v2}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    .line 518
    nop

    .end local v1    # "afterVel":I
    add-int/lit8 v12, v12, 0x1

    .line 519
    goto :goto_2

    .line 520
    .end local v4    # "poseEnd":I
    .end local v18    # "t":[J
    .local v1, "poseEnd":I
    .restart local v2    # "t":[J
    :cond_9
    move-object/from16 v18, v2

    move/from16 v17, v4

    const/4 v15, 0x0

    move v4, v1

    .end local v1    # "poseEnd":I
    .end local v2    # "t":[J
    .restart local v4    # "poseEnd":I
    .restart local v18    # "t":[J
    sub-int v1, v5, v6

    invoke-virtual {v11, v0, v6, v1}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    .line 522
    :goto_2
    move v10, v5

    .line 489
    .end local v4    # "poseEnd":I
    .end local v5    # "recordEnd":I
    .end local v6    # "recordStart":I
    .end local v7    # "np":[J
    .end local v14    # "sid":I
    .end local v18    # "t":[J
    .end local v24    # "varints":[[J
    add-int/lit8 v13, v13, 0x1

    move-object v5, v8

    move-object v2, v9

    move v1, v15

    move/from16 v4, v17

    move-wide/from16 v6, v25

    const/4 v3, 0x0

    const-wide/16 v8, 0x0

    goto/16 :goto_0

    .end local v8    # "cnt":[J
    .end local v9    # "v0":[J
    .end local v25    # "n":J
    .local v2, "v0":[J
    .local v5, "cnt":[J
    .local v6, "n":J
    :cond_a
    move-object v9, v2

    move-object v8, v5

    move-wide/from16 v25, v6

    .line 524
    .end local v2    # "v0":[J
    .end local v5    # "cnt":[J
    .end local v6    # "n":J
    .end local v13    # "i":I
    .restart local v8    # "cnt":[J
    .restart local v9    # "v0":[J
    .restart local v25    # "n":J
    array-length v1, v0

    if-ge v10, v1, :cond_b

    .line 525
    array-length v1, v0

    sub-int/2addr v1, v10

    invoke-virtual {v11, v0, v10, v1}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    .line 527
    :cond_b
    if-lez v12, :cond_c

    invoke-virtual {v11}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v3

    goto :goto_3

    :cond_c
    const/4 v3, 0x0

    :goto_3
    return-object v3

    .line 483
    .end local v8    # "cnt":[J
    .end local v9    # "v0":[J
    .end local v10    # "p":I
    .end local v11    # "o":Ljava/io/ByteArrayOutputStream;
    .end local v12    # "changed":I
    .end local v25    # "n":J
    .restart local v2    # "v0":[J
    .restart local v5    # "cnt":[J
    .restart local v6    # "n":J
    :cond_d
    move-object v9, v2

    move-object v8, v5

    move-wide/from16 v25, v6

    .end local v2    # "v0":[J
    .end local v5    # "cnt":[J
    .end local v6    # "n":J
    .restart local v8    # "cnt":[J
    .restart local v9    # "v0":[J
    .restart local v25    # "n":J
    :goto_4
    const/4 v1, 0x0

    return-object v1
.end method

.method public static rewriteSingle([BZ)[B
    .locals 19
    .param p0, "body"    # [B
    .param p1, "fz"    # Z

    .line 450
    move-object/from16 v0, p0

    array-length v1, v0

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-ge v1, v2, :cond_0

    return-object v3

    .line 451
    :cond_0
    const/4 v1, 0x2

    aget-byte v2, v0, v1

    and-int/lit16 v2, v2, 0xff

    .line 452
    .local v2, "sid":I
    const/4 v4, 0x3

    .line 453
    .local v4, "p":I
    invoke-static {v0, v4}, Lcom/lvteam/LvTeamShift;->readVarint([BI)[J

    move-result-object v13

    .local v13, "v0":[J
    if-nez v13, :cond_1

    return-object v3

    :cond_1
    const/4 v14, 0x1

    aget-wide v5, v13, v14

    long-to-int v4, v5

    .line 454
    invoke-static {v0, v4}, Lcom/lvteam/LvTeamShift;->readVarint([BI)[J

    move-result-object v15

    .local v15, "v1":[J
    if-nez v15, :cond_2

    return-object v3

    :cond_2
    aget-wide v5, v15, v14

    long-to-int v12, v5

    .line 455
    .end local v4    # "p":I
    .local v12, "p":I
    invoke-static {v0, v12}, Lcom/lvteam/LvTeamShift;->readVarint([BI)[J

    move-result-object v16

    .local v16, "v2":[J
    if-nez v16, :cond_3

    return-object v3

    .line 456
    :cond_3
    aget-wide v4, v16, v14

    long-to-int v11, v4

    .line 458
    .local v11, "poseEnd":I
    const/4 v9, 0x0

    aget-wide v5, v13, v9

    aget-wide v7, v15, v9

    aget-wide v17, v16, v9

    move v4, v2

    move v1, v9

    move-wide/from16 v9, v17

    move/from16 v17, v11

    .end local v11    # "poseEnd":I
    .local v17, "poseEnd":I
    move/from16 v18, v12

    .end local v12    # "p":I
    .local v18, "p":I
    move/from16 v12, p1

    invoke-static/range {v4 .. v12}, Lcom/lvteam/LvTeamShift;->recordPose(IJJJIZ)[J

    move-result-object v4

    .line 459
    .local v4, "np":[J
    if-nez v4, :cond_4

    return-object v3

    .line 461
    :cond_4
    new-instance v3, Ljava/io/ByteArrayOutputStream;

    array-length v5, v0

    add-int/lit8 v5, v5, 0x10

    invoke-direct {v3, v5}, Ljava/io/ByteArrayOutputStream;-><init>(I)V

    .line 462
    .local v3, "o":Ljava/io/ByteArrayOutputStream;
    const/4 v5, 0x3

    invoke-virtual {v3, v0, v1, v5}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    .line 463
    aget-wide v6, v4, v1

    invoke-static {v3, v6, v7}, Lcom/lvteam/LvTeamShift;->writeVarint(Ljava/io/ByteArrayOutputStream;J)V

    .line 464
    aget-wide v6, v4, v14

    invoke-static {v3, v6, v7}, Lcom/lvteam/LvTeamShift;->writeVarint(Ljava/io/ByteArrayOutputStream;J)V

    .line 465
    const/4 v1, 0x2

    aget-wide v6, v4, v1

    invoke-static {v3, v6, v7}, Lcom/lvteam/LvTeamShift;->writeVarint(Ljava/io/ByteArrayOutputStream;J)V

    .line 466
    move/from16 v1, v17

    .line 467
    .local v1, "afterPose":I
    const/4 v6, 0x0

    .local v6, "i":I
    :goto_0
    if-ge v6, v5, :cond_6

    .line 468
    invoke-static {v0, v1}, Lcom/lvteam/LvTeamShift;->readVarint([BI)[J

    move-result-object v7

    .line 469
    .local v7, "vv":[J
    if-nez v7, :cond_5

    goto :goto_1

    .line 470
    :cond_5
    const-wide/16 v8, 0x0

    invoke-static {v3, v8, v9}, Lcom/lvteam/LvTeamShift;->writeVarint(Ljava/io/ByteArrayOutputStream;J)V

    .line 471
    aget-wide v8, v7, v14

    long-to-int v1, v8

    .line 467
    .end local v7    # "vv":[J
    add-int/lit8 v6, v6, 0x1

    goto :goto_0

    .line 473
    .end local v6    # "i":I
    :cond_6
    :goto_1
    array-length v5, v0

    sub-int/2addr v5, v1

    invoke-virtual {v3, v0, v1, v5}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    .line 474
    invoke-virtual {v3}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v5

    return-object v5
.end method

.method public static setDir(FF)V
    .locals 6
    .param p0, "x"    # F
    .param p1, "z"    # F

    .line 108
    float-to-double v0, p0

    float-to-double v2, p0

    mul-double/2addr v0, v2

    float-to-double v2, p1

    float-to-double v4, p1

    mul-double/2addr v2, v4

    add-double/2addr v0, v2

    invoke-static {v0, v1}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v0

    .line 109
    .local v0, "m":D
    const-wide v2, 0x3fa999999999999aL    # 0.05

    cmpg-double v2, v0, v2

    if-gez v2, :cond_0

    return-void

    .line 110
    :cond_0
    float-to-double v2, p0

    div-double/2addr v2, v0

    double-to-float v2, v2

    float-to-double v3, p1

    div-double/2addr v3, v0

    double-to-float v3, v3

    const/4 v4, 0x2

    new-array v4, v4, [F

    const/4 v5, 0x0

    aput v2, v4, v5

    const/4 v2, 0x1

    aput v3, v4, v2

    sput-object v4, Lcom/lvteam/LvTeamShift;->dir:[F

    .line 111
    return-void
.end method

.method public static setDir3D(FFF)V
    .locals 6
    .param p0, "x"    # F
    .param p1, "y"    # F
    .param p2, "z"    # F

    .line 114
    float-to-double v0, p0

    float-to-double v2, p0

    mul-double/2addr v0, v2

    float-to-double v2, p1

    float-to-double v4, p1

    mul-double/2addr v2, v4

    add-double/2addr v0, v2

    float-to-double v2, p2

    float-to-double v4, p2

    mul-double/2addr v2, v4

    add-double/2addr v0, v2

    invoke-static {v0, v1}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v0

    .line 115
    .local v0, "m":D
    const-wide v2, 0x3fa999999999999aL    # 0.05

    cmpg-double v2, v0, v2

    if-gez v2, :cond_0

    return-void

    .line 116
    :cond_0
    float-to-double v2, p0

    div-double/2addr v2, v0

    double-to-float v2, v2

    sput v2, Lcom/lvteam/LvTeamShift;->aimX:F

    .line 117
    float-to-double v2, p1

    div-double/2addr v2, v0

    double-to-float v2, v2

    sput v2, Lcom/lvteam/LvTeamShift;->aimY:F

    .line 118
    float-to-double v2, p2

    div-double/2addr v2, v0

    double-to-float v2, v2

    sput v2, Lcom/lvteam/LvTeamShift;->aimZ:F

    .line 119
    return-void
.end method

.method public static setFreezeFire(Z)V
    .locals 0
    .param p0, "on"    # Z

    .line 136
    sput-boolean p0, Lcom/lvteam/LvTeamShift;->freezeFireOn:Z

    .line 137
    return-void
.end method

.method public static setFreezeScop(Z)V
    .locals 0
    .param p0, "on"    # Z

    .line 140
    sput-boolean p0, Lcom/lvteam/LvTeamShift;->freezeScopOn:Z

    .line 141
    return-void
.end method

.method public static setIgnoredSlots(Ljava/util/Collection;)V
    .locals 5

    .line 72
    .local p0, "slots":Ljava/util/Collection;, "Ljava/util/Collection<Ljava/lang/Integer;>;"
    const/16 v0, 0x100

    new-array v0, v0, [Z

    .line 73
    .local v0, "next":[Z
    if-eqz p0, :cond_1

    .line 74
    invoke-interface {p0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    nop

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Integer;

    .line 75
    .local v2, "slot":Ljava/lang/Integer;
    if-eqz v2, :cond_0

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v3

    if-ltz v3, :cond_0

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v3

    array-length v4, v0

    if-ge v3, v4, :cond_0

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v3

    const/4 v4, 0x1

    aput-boolean v4, v0, v3

    .line 76
    .end local v2    # "slot":Ljava/lang/Integer;
    :cond_0
    goto :goto_0

    .line 78
    :cond_1
    sput-object v0, Lcom/lvteam/LvTeamShift;->ignoredSlots:[Z

    .line 79
    return-void
.end method

.method public static setLocalFreeze(Z)V
    .locals 2
    .param p0, "on"    # Z

    .line 122
    sput-boolean p0, Lcom/lvteam/LvTeamShift;->localFreezeOn:Z

    .line 123
    if-nez p0, :cond_0

    .line 124
    const/4 v0, 0x0

    sput-object v0, Lcom/lvteam/LvTeamShift;->heldUplink:[J

    .line 125
    const/4 v1, 0x0

    sput-boolean v1, Lcom/lvteam/LvTeamShift;->localHold:Z

    .line 126
    sput-object v0, Lcom/lvteam/LvTeamShift;->pinnedLocal:[J

    .line 128
    :cond_0
    return-void
.end method

.method public static setTatu(Z)V
    .locals 1
    .param p0, "on"    # Z

    .line 131
    sput-boolean p0, Lcom/lvteam/LvTeamShift;->tatuOn:Z

    .line 132
    const/4 v0, 0x0

    sput-boolean v0, Lcom/lvteam/LvTeamShift;->haveDownAnchor:Z

    .line 133
    return-void
.end method

.method public static setTeleportBase(Z)V
    .locals 1
    .param p0, "on"    # Z

    .line 144
    if-nez p0, :cond_0

    const/4 v0, 0x0

    sput v0, Lcom/lvteam/LvTeamShift;->teleportBaseState:I

    .line 145
    :cond_0
    return-void
.end method

.method public static setTeleportSpeed(I)V
    .locals 2
    .param p0, "times"    # I

    .line 152
    const/16 v0, 0xa

    invoke-static {v0, p0}, Ljava/lang/Math;->min(II)I

    move-result v0

    const/4 v1, 0x1

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    sput v0, Lcom/lvteam/LvTeamShift;->teleportSpeed:I

    .line 153
    return-void
.end method

.method public static setWallPass(Z)V
    .locals 6
    .param p0, "on"    # Z

    .line 163
    const/4 v0, 0x0

    sput-boolean v0, Lcom/lvteam/LvTeamShift;->wallEngaged:Z

    .line 164
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v1

    sput-wide v1, Lcom/lvteam/LvTeamShift;->wallStartedAt:J

    .line 165
    const/4 v1, 0x1

    const-wide/16 v2, 0x0

    if-eqz p0, :cond_0

    .line 166
    sput-wide v2, Lcom/lvteam/LvTeamShift;->wallOffsetMm:D

    .line 167
    sput-boolean v0, Lcom/lvteam/LvTeamShift;->wallReleasing:Z

    .line 168
    sput-boolean v1, Lcom/lvteam/LvTeamShift;->wallPassOn:Z

    .line 169
    return-void

    .line 171
    :cond_0
    sput-boolean v0, Lcom/lvteam/LvTeamShift;->wallPassOn:Z

    .line 174
    sget-wide v4, Lcom/lvteam/LvTeamShift;->wallOffsetMm:D

    cmpl-double v4, v4, v2

    if-lez v4, :cond_1

    move v0, v1

    :cond_1
    sput-boolean v0, Lcom/lvteam/LvTeamShift;->wallReleasing:Z

    .line 175
    sget-wide v0, Lcom/lvteam/LvTeamShift;->wallOffsetMm:D

    sput-wide v0, Lcom/lvteam/LvTeamShift;->wallReleaseFromMm:D

    .line 176
    sget-boolean v0, Lcom/lvteam/LvTeamShift;->wallReleasing:Z

    if-nez v0, :cond_2

    sput-wide v2, Lcom/lvteam/LvTeamShift;->wallOffsetMm:D

    .line 177
    :cond_2
    return-void
.end method

.method public static shift(IJJJ)[J
    .locals 47
    .param p0, "sid"    # I
    .param p1, "rx"    # J
    .param p3, "ry"    # J
    .param p5, "rz"    # J

    .line 543
    move/from16 v0, p0

    invoke-static {}, Lcom/lvteam/LvTeamShift;->magnetActive()Z

    move-result v1

    const/4 v2, 0x0

    if-nez v1, :cond_0

    return-object v2

    .line 545
    :cond_0
    sget v1, Lcom/lvteam/LvTeamShift;->localShortId:I

    .line 546
    .local v1, "loc":I
    if-ltz v1, :cond_1

    if-ne v0, v1, :cond_1

    return-object v2

    .line 548
    :cond_1
    sget-object v3, Lcom/lvteam/LvTeamShift;->ignoredSlots:[Z

    .line 549
    .local v3, "ignored":[Z
    if-ltz v0, :cond_2

    array-length v4, v3

    if-ge v0, v4, :cond_2

    aget-boolean v4, v3, v0

    if-eqz v4, :cond_2

    return-object v2

    .line 551
    :cond_2
    sget-wide v4, Lcom/lvteam/LvTeamShift;->localTs:J

    const-wide/16 v6, 0x0

    cmp-long v4, v4, v6

    if-nez v4, :cond_3

    return-object v2

    .line 553
    :cond_3
    invoke-static/range {p3 .. p4}, Lcom/lvteam/LvTeamShift;->zz(J)J

    move-result-wide v4

    .line 554
    .local v4, "ey":J
    const-wide/16 v6, 0x294

    add-long/2addr v6, v4

    invoke-static {v6, v7}, Lcom/lvteam/LvTeamShift;->enc(J)J

    move-result-wide v6

    .line 556
    .local v6, "fixedY":J
    sget-wide v8, Lcom/lvteam/LvTeamShift;->localX:D

    .local v8, "px":D
    sget-wide v10, Lcom/lvteam/LvTeamShift;->localZ:D

    .line 557
    .local v10, "pz":D
    sget v12, Lcom/lvteam/LvTeamShift;->aimX:F

    .local v12, "fx":F
    sget v13, Lcom/lvteam/LvTeamShift;->aimZ:F

    .line 558
    .local v13, "fz":F
    float-to-double v14, v12

    move-object/from16 v17, v3

    .end local v3    # "ignored":[Z
    .local v17, "ignored":[Z
    float-to-double v2, v12

    mul-double/2addr v14, v2

    float-to-double v2, v13

    move/from16 v18, v1

    .end local v1    # "loc":I
    .local v18, "loc":I
    float-to-double v0, v13

    mul-double/2addr v2, v0

    add-double/2addr v14, v2

    .line 559
    .local v14, "hm2":D
    const-wide v0, 0x3f50624dd2f1a9fcL    # 0.001

    cmpg-double v0, v14, v0

    if-gez v0, :cond_4

    const/4 v0, 0x0

    return-object v0

    .line 561
    :cond_4
    invoke-static/range {p1 .. p2}, Lcom/lvteam/LvTeamShift;->zz(J)J

    move-result-wide v0

    .line 562
    .local v0, "ex":J
    invoke-static/range {p5 .. p6}, Lcom/lvteam/LvTeamShift;->zz(J)J

    move-result-wide v2

    .line 564
    .local v2, "ez":J
    move-wide/from16 v19, v4

    .end local v4    # "ey":J
    .local v19, "ey":J
    long-to-double v4, v0

    sub-double/2addr v4, v8

    move-wide/from16 v21, v6

    .end local v6    # "fixedY":J
    .local v4, "dx":D
    .local v21, "fixedY":J
    long-to-double v6, v2

    sub-double/2addr v6, v10

    .line 565
    .local v6, "dz":D
    mul-double v23, v4, v4

    mul-double v25, v6, v6

    add-double v23, v23, v25

    invoke-static/range {v23 .. v24}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v23

    .line 566
    .local v23, "horizontalDist":D
    const-wide v25, 0x407f400000000000L    # 500.0

    cmpg-double v25, v23, v25

    if-gez v25, :cond_5

    const/16 v16, 0x0

    return-object v16

    .line 568
    :cond_5
    invoke-static {v14, v15}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v25

    .line 569
    .local v25, "flatLen":D
    move-wide/from16 v27, v4

    .end local v4    # "dx":D
    .local v27, "dx":D
    float-to-double v4, v12

    div-double v4, v4, v25

    move-wide/from16 v29, v6

    .end local v6    # "dz":D
    .local v4, "ffx":D
    .local v29, "dz":D
    float-to-double v6, v13

    div-double v6, v6, v25

    .line 571
    .local v6, "ffz":D
    mul-double v31, v4, v23

    add-double v31, v8, v31

    .line 572
    .local v31, "nx":D
    mul-double v33, v6, v23

    add-double v33, v10, v33

    .line 574
    .local v33, "nz":D
    move-wide/from16 v35, v4

    .end local v4    # "ffx":D
    .local v35, "ffx":D
    long-to-double v4, v0

    sub-double v4, v31, v4

    move-wide/from16 v37, v6

    .end local v6    # "ffz":D
    .local v4, "ldx":D
    .local v37, "ffz":D
    long-to-double v6, v2

    sub-double v6, v33, v6

    .line 575
    .local v6, "ldz":D
    mul-double v39, v4, v4

    mul-double v41, v6, v6

    add-double v39, v39, v41

    invoke-static/range {v39 .. v40}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v39

    .line 576
    .local v39, "lateralDist":D
    const-wide v41, 0x40bf400000000000L    # 8000.0

    cmpl-double v16, v39, v41

    if-lez v16, :cond_6

    .line 577
    div-double v41, v41, v39

    .line 578
    .local v41, "s":D
    move-wide/from16 v43, v8

    .end local v8    # "px":D
    .local v43, "px":D
    long-to-double v8, v0

    mul-double v45, v4, v41

    add-double v31, v8, v45

    .line 579
    long-to-double v8, v2

    mul-double v45, v6, v41

    add-double v33, v8, v45

    goto :goto_0

    .line 576
    .end local v41    # "s":D
    .end local v43    # "px":D
    .restart local v8    # "px":D
    :cond_6
    move-wide/from16 v43, v8

    .line 582
    .end local v8    # "px":D
    .restart local v43    # "px":D
    :goto_0
    invoke-static/range {v31 .. v32}, Ljava/lang/Math;->round(D)J

    move-result-wide v8

    invoke-static {v8, v9}, Lcom/lvteam/LvTeamShift;->enc(J)J

    move-result-wide v8

    .line 583
    .local v8, "enx":J
    invoke-static/range {v33 .. v34}, Ljava/lang/Math;->round(D)J

    move-result-wide v41

    invoke-static/range {v41 .. v42}, Lcom/lvteam/LvTeamShift;->enc(J)J

    move-result-wide v41

    .line 585
    .local v41, "enz":J
    move-wide/from16 v45, v0

    .end local v0    # "ex":J
    .local v45, "ex":J
    const/4 v0, 0x3

    new-array v0, v0, [J

    const/4 v1, 0x0

    aput-wide v8, v0, v1

    const/4 v1, 0x1

    aput-wide v21, v0, v1

    const/4 v1, 0x2

    aput-wide v41, v0, v1

    return-object v0
.end method

.method public static tatuActive()Z
    .locals 8

    .line 264
    sget-boolean v0, Lcom/lvteam/LvTeamShift;->tatuOn:Z

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    .line 265
    :cond_0
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v2

    .line 266
    .local v2, "now":J
    sget-boolean v0, Lcom/lvteam/LvTeamShift;->firing:Z

    const-wide/16 v4, 0x7d0

    if-eqz v0, :cond_1

    sget-wide v6, Lcom/lvteam/LvTeamShift;->firePulseUntil:J

    sub-long v6, v2, v6

    cmp-long v0, v6, v4

    if-ltz v0, :cond_1

    sput-boolean v1, Lcom/lvteam/LvTeamShift;->firing:Z

    .line 267
    :cond_1
    sget-boolean v0, Lcom/lvteam/LvTeamShift;->scoping:Z

    if-eqz v0, :cond_2

    sget-wide v6, Lcom/lvteam/LvTeamShift;->scopePulseUntil:J

    sub-long v6, v2, v6

    cmp-long v0, v6, v4

    if-ltz v0, :cond_2

    sput-boolean v1, Lcom/lvteam/LvTeamShift;->scoping:Z

    .line 268
    :cond_2
    sget-boolean v0, Lcom/lvteam/LvTeamShift;->firing:Z

    if-nez v0, :cond_3

    sget-boolean v0, Lcom/lvteam/LvTeamShift;->scoping:Z

    if-nez v0, :cond_3

    sget-wide v4, Lcom/lvteam/LvTeamShift;->firePulseUntil:J

    cmp-long v0, v2, v4

    if-ltz v0, :cond_3

    sget-wide v4, Lcom/lvteam/LvTeamShift;->scopePulseUntil:J

    cmp-long v0, v2, v4

    if-ltz v0, :cond_3

    const/4 v1, 0x1

    :cond_3
    return v1
.end method

.method public static toggleTeleportBase()V
    .locals 2

    .line 156
    sget v0, Lcom/lvteam/LvTeamShift;->teleportBaseState:I

    .line 157
    .local v0, "s":I
    const/4 v1, 0x1

    if-nez v0, :cond_0

    sput v1, Lcom/lvteam/LvTeamShift;->teleportBaseState:I

    goto :goto_0

    .line 158
    :cond_0
    if-ne v0, v1, :cond_1

    const/4 v1, 0x2

    sput v1, Lcom/lvteam/LvTeamShift;->teleportBaseState:I

    goto :goto_0

    .line 159
    :cond_1
    const/4 v1, 0x0

    sput v1, Lcom/lvteam/LvTeamShift;->teleportBaseState:I

    .line 160
    :goto_0
    return-void
.end method

.method public static transformDown([B)[B
    .locals 4
    .param p0, "body"    # [B

    .line 387
    if-eqz p0, :cond_0

    array-length v0, p0

    const/4 v1, 0x3

    if-ge v0, v1, :cond_1

    :cond_0
    goto :goto_2

    .line 388
    :cond_1
    sget-object v0, Lcom/lvteam/LvTeamShift;->LOCK:Ljava/lang/Object;

    monitor-enter v0

    .line 389
    :try_start_0
    invoke-static {}, Lcom/lvteam/LvTeamShift;->enemyFreezeActive()Z

    move-result v1

    .line 390
    .local v1, "fz":Z
    sget-boolean v2, Lcom/lvteam/LvTeamShift;->freezeActive:Z

    if-eq v1, v2, :cond_2

    .line 391
    sput-boolean v1, Lcom/lvteam/LvTeamShift;->freezeActive:Z

    .line 392
    sget-object v2, Lcom/lvteam/LvTeamShift;->held:Ljava/util/HashMap;

    invoke-virtual {v2}, Ljava/util/HashMap;->clear()V

    .line 393
    if-eqz v1, :cond_3

    sget-object v2, Lcom/lvteam/LvTeamShift;->live:Ljava/util/HashMap;

    invoke-virtual {v2}, Ljava/util/HashMap;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_3

    sget-object v2, Lcom/lvteam/LvTeamShift;->held:Ljava/util/HashMap;

    sget-object v3, Lcom/lvteam/LvTeamShift;->live:Ljava/util/HashMap;

    invoke-virtual {v2, v3}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V

    goto :goto_0

    .line 401
    .end local v1    # "fz":Z
    :catchall_0
    move-exception v1

    goto :goto_1

    .line 394
    .restart local v1    # "fz":Z
    :cond_2
    if-eqz v1, :cond_3

    sget-object v2, Lcom/lvteam/LvTeamShift;->held:Ljava/util/HashMap;

    invoke-virtual {v2}, Ljava/util/HashMap;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_3

    sget-object v2, Lcom/lvteam/LvTeamShift;->live:Ljava/util/HashMap;

    invoke-virtual {v2}, Ljava/util/HashMap;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_3

    .line 395
    sget-object v2, Lcom/lvteam/LvTeamShift;->held:Ljava/util/HashMap;

    sget-object v3, Lcom/lvteam/LvTeamShift;->live:Ljava/util/HashMap;

    invoke-virtual {v2, v3}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V

    .line 397
    :cond_3
    :goto_0
    invoke-static {}, Lcom/lvteam/LvTeamShift;->latchLocal()V

    .line 399
    const/4 v2, 0x0

    aget-byte v2, p0, v2

    if-nez v2, :cond_4

    const/4 v2, 0x1

    aget-byte v2, p0, v2

    const/4 v3, 0x2

    if-ne v2, v3, :cond_4

    invoke-static {p0, v1}, Lcom/lvteam/LvTeamShift;->rewriteSingle([BZ)[B

    move-result-object v2

    monitor-exit v0

    return-object v2

    .line 400
    :cond_4
    invoke-static {p0, v1}, Lcom/lvteam/LvTeamShift;->rewriteBatch([BZ)[B

    move-result-object v2

    monitor-exit v0

    return-object v2

    .line 401
    .end local v1    # "fz":Z
    :goto_1
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v1

    .line 387
    :goto_2
    const/4 v0, 0x0

    return-object v0
.end method

.method public static transformUp([B)[B
    .locals 24
    .param p0, "body"    # [B

    .line 341
    move-object/from16 v1, p0

    const/4 v0, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-eqz v1, :cond_0

    array-length v6, v1

    if-ge v6, v4, :cond_1

    :cond_0
    goto/16 :goto_4

    .line 342
    :cond_1
    invoke-static {v1, v3}, Lcom/lvteam/LvTeamShift;->readVarint([BI)[J

    move-result-object v6

    .line 343
    .local v6, "id":[J
    if-nez v6, :cond_2

    return-object v5

    .line 344
    :cond_2
    aget-wide v7, v6, v2

    long-to-int v7, v7

    invoke-static {v1, v7}, Lcom/lvteam/LvTeamShift;->readVarint([BI)[J

    move-result-object v7

    .line 345
    .local v7, "vx":[J
    if-nez v7, :cond_3

    return-object v5

    .line 346
    :cond_3
    aget-wide v8, v7, v2

    long-to-int v8, v8

    invoke-static {v1, v8}, Lcom/lvteam/LvTeamShift;->readVarint([BI)[J

    move-result-object v8

    .line 347
    .local v8, "vy":[J
    if-nez v8, :cond_4

    return-object v5

    .line 348
    :cond_4
    aget-wide v9, v8, v2

    long-to-int v9, v9

    invoke-static {v1, v9}, Lcom/lvteam/LvTeamShift;->readVarint([BI)[J

    move-result-object v9

    .line 349
    .local v9, "vz":[J
    if-nez v9, :cond_5

    return-object v5

    .line 351
    :cond_5
    aget-wide v10, v6, v3

    const-wide/16 v12, 0xff

    and-long/2addr v10, v12

    long-to-int v10, v10

    .line 352
    .local v10, "sid":I
    if-lez v10, :cond_6

    const/16 v11, 0x81

    if-ge v10, v11, :cond_6

    .line 353
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v11

    sput-wide v11, Lcom/lvteam/LvTeamShift;->uplinkSidTs:J

    .line 354
    sput v10, Lcom/lvteam/LvTeamShift;->localShortId:I

    .line 357
    :cond_6
    aget-wide v11, v7, v3

    .local v11, "ox":J
    aget-wide v13, v8, v3

    .local v13, "oy":J
    aget-wide v15, v9, v3

    .line 358
    .local v15, "oz":J
    sget-object v17, Lcom/lvteam/LvTeamShift;->LOCK:Ljava/lang/Object;

    monitor-enter v17

    .line 359
    :try_start_0
    sget-boolean v18, Lcom/lvteam/LvTeamShift;->localFreezeOn:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    if-eqz v18, :cond_8

    .line 360
    :try_start_1
    sget-object v18, Lcom/lvteam/LvTeamShift;->heldUplink:[J

    if-nez v18, :cond_7

    aget-wide v18, v7, v3

    aget-wide v20, v8, v3

    aget-wide v22, v9, v3

    new-array v4, v4, [J

    aput-wide v18, v4, v3

    aput-wide v20, v4, v2

    aput-wide v22, v4, v0

    sput-object v4, Lcom/lvteam/LvTeamShift;->heldUplink:[J

    goto :goto_0

    .line 373
    :catchall_0
    move-exception v0

    move-object v4, v6

    goto/16 :goto_3

    .line 361
    :cond_7
    :goto_0
    sget-object v4, Lcom/lvteam/LvTeamShift;->heldUplink:[J

    aget-wide v18, v4, v3

    move-wide/from16 v11, v18

    .line 362
    sget-object v4, Lcom/lvteam/LvTeamShift;->heldUplink:[J

    aget-wide v18, v4, v2

    move-wide/from16 v13, v18

    .line 363
    sget-object v4, Lcom/lvteam/LvTeamShift;->heldUplink:[J

    aget-wide v18, v4, v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    move-wide/from16 v15, v18

    move-object v4, v6

    move-wide v5, v15

    goto :goto_1

    .line 365
    :cond_8
    :try_start_2
    sput-object v5, Lcom/lvteam/LvTeamShift;->heldUplink:[J
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    move-object v4, v6

    move-wide v5, v15

    .line 367
    .end local v6    # "id":[J
    .end local v15    # "oz":J
    .local v4, "id":[J
    .local v5, "oz":J
    :goto_1
    :try_start_3
    invoke-static {v13, v14}, Lcom/lvteam/LvTeamShift;->lowerY(J)J

    move-result-wide v15

    move-wide v13, v15

    .line 368
    invoke-static {v11, v12, v5, v6}, Lcom/lvteam/LvTeamShift;->wallPush(JJ)[J

    move-result-object v15

    .line 369
    .local v15, "wp":[J
    if-eqz v15, :cond_9

    .line 370
    aget-wide v18, v15, v3

    move-wide/from16 v11, v18

    .line 371
    aget-wide v18, v15, v2

    move-wide/from16 v5, v18

    goto :goto_2

    .line 373
    .end local v15    # "wp":[J
    :catchall_1
    move-exception v0

    move-wide v15, v5

    goto :goto_3

    :cond_9
    :goto_2
    monitor-exit v17
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 374
    aget-wide v15, v7, v3

    cmp-long v15, v11, v15

    if-nez v15, :cond_a

    aget-wide v15, v8, v3

    cmp-long v15, v13, v15

    if-nez v15, :cond_a

    aget-wide v15, v9, v3

    cmp-long v15, v5, v15

    if-nez v15, :cond_a

    const/4 v0, 0x0

    return-object v0

    .line 376
    :cond_a
    new-instance v0, Ljava/io/ByteArrayOutputStream;

    array-length v15, v1

    add-int/lit8 v15, v15, 0x10

    invoke-direct {v0, v15}, Ljava/io/ByteArrayOutputStream;-><init>(I)V

    .line 377
    .local v0, "o":Ljava/io/ByteArrayOutputStream;
    aget-wide v2, v4, v3

    invoke-static {v0, v2, v3}, Lcom/lvteam/LvTeamShift;->writeVarint(Ljava/io/ByteArrayOutputStream;J)V

    .line 378
    invoke-static {v0, v11, v12}, Lcom/lvteam/LvTeamShift;->writeVarint(Ljava/io/ByteArrayOutputStream;J)V

    .line 379
    invoke-static {v0, v13, v14}, Lcom/lvteam/LvTeamShift;->writeVarint(Ljava/io/ByteArrayOutputStream;J)V

    .line 380
    invoke-static {v0, v5, v6}, Lcom/lvteam/LvTeamShift;->writeVarint(Ljava/io/ByteArrayOutputStream;J)V

    .line 381
    const/4 v2, 0x1

    aget-wide v2, v9, v2

    long-to-int v2, v2

    .line 382
    .local v2, "rest":I
    array-length v3, v1

    sub-int/2addr v3, v2

    invoke-virtual {v0, v1, v2, v3}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    .line 383
    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v3

    return-object v3

    .line 373
    .end local v0    # "o":Ljava/io/ByteArrayOutputStream;
    .end local v2    # "rest":I
    .end local v4    # "id":[J
    .end local v5    # "oz":J
    .restart local v6    # "id":[J
    .local v15, "oz":J
    :catchall_2
    move-exception v0

    move-object v4, v6

    .end local v6    # "id":[J
    .restart local v4    # "id":[J
    :goto_3
    :try_start_4
    monitor-exit v17
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_3

    throw v0

    :catchall_3
    move-exception v0

    goto :goto_3

    .line 341
    .end local v4    # "id":[J
    .end local v7    # "vx":[J
    .end local v8    # "vy":[J
    .end local v9    # "vz":[J
    .end local v10    # "sid":I
    .end local v11    # "ox":J
    .end local v13    # "oy":J
    .end local v15    # "oz":J
    :goto_4
    const/4 v0, 0x0

    return-object v0
.end method

.method public static wallPush(JJ)[J
    .locals 18
    .param p0, "encX"    # J
    .param p2, "encZ"    # J

    .line 195
    const/4 v0, 0x1

    sget-boolean v1, Lcom/lvteam/LvTeamShift;->wallPassOn:Z

    const/4 v2, 0x0

    const/4 v3, 0x0

    const-wide/16 v4, 0x0

    if-nez v1, :cond_0

    sget-boolean v1, Lcom/lvteam/LvTeamShift;->wallReleasing:Z

    if-nez v1, :cond_0

    .line 196
    sput-wide v4, Lcom/lvteam/LvTeamShift;->wallOffsetMm:D

    .line 197
    sput-boolean v3, Lcom/lvteam/LvTeamShift;->wallEngaged:Z

    .line 198
    return-object v2

    .line 202
    :cond_0
    sget-boolean v1, Lcom/lvteam/LvTeamShift;->wallEngaged:Z

    if-nez v1, :cond_1

    sget-boolean v1, Lcom/lvteam/LvTeamShift;->wallReleasing:Z

    if-eqz v1, :cond_2

    :cond_1
    goto :goto_0

    .line 208
    :cond_2
    sget-object v1, Lcom/lvteam/LvTeamShift;->dir:[F

    .line 209
    .local v1, "heading":[F
    aget v6, v1, v3

    .line 210
    .local v6, "fx":F
    aget v7, v1, v0

    .local v7, "fz":F
    goto :goto_1

    .line 205
    .end local v1    # "heading":[F
    .end local v6    # "fx":F
    .end local v7    # "fz":F
    :goto_0
    sget v6, Lcom/lvteam/LvTeamShift;->wallLockedX:F

    .line 206
    .restart local v6    # "fx":F
    sget v7, Lcom/lvteam/LvTeamShift;->wallLockedZ:F

    .line 212
    .restart local v7    # "fz":F
    :goto_1
    float-to-double v8, v6

    float-to-double v10, v6

    mul-double/2addr v8, v10

    float-to-double v10, v7

    float-to-double v12, v7

    mul-double/2addr v10, v12

    add-double/2addr v8, v10

    invoke-static {v8, v9}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v8

    .line 213
    .local v8, "m":D
    const-wide v10, 0x3fa999999999999aL    # 0.05

    cmpg-double v1, v8, v10

    if-gez v1, :cond_3

    return-object v2

    .line 214
    :cond_3
    float-to-double v10, v6

    div-double/2addr v10, v8

    double-to-float v1, v10

    .line 215
    .end local v6    # "fx":F
    .local v1, "fx":F
    float-to-double v10, v7

    div-double/2addr v10, v8

    double-to-float v6, v10

    .line 219
    .end local v7    # "fz":F
    .local v6, "fz":F
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v10

    sget-wide v12, Lcom/lvteam/LvTeamShift;->wallStartedAt:J

    sub-long/2addr v10, v12

    long-to-double v10, v10

    const-wide/high16 v12, 0x4008000000000000L    # 3.0

    mul-double/2addr v10, v12

    .line 221
    .local v10, "travelled":D
    sget-boolean v7, Lcom/lvteam/LvTeamShift;->wallReleasing:Z

    if-eqz v7, :cond_4

    .line 222
    sget-wide v12, Lcom/lvteam/LvTeamShift;->wallReleaseFromMm:D

    sub-double/2addr v12, v10

    .line 223
    .local v12, "off":D
    cmpg-double v7, v12, v4

    if-gtz v7, :cond_6

    .line 224
    sput-boolean v3, Lcom/lvteam/LvTeamShift;->wallReleasing:Z

    .line 225
    sput-wide v4, Lcom/lvteam/LvTeamShift;->wallOffsetMm:D

    .line 226
    return-object v2

    .line 229
    .end local v12    # "off":D
    :cond_4
    move-wide v12, v10

    .line 230
    .restart local v12    # "off":D
    sget v2, Lcom/lvteam/LvTeamShift;->wallDistanceMm:I

    int-to-double v4, v2

    cmpl-double v2, v12, v4

    if-ltz v2, :cond_5

    .line 231
    sget v2, Lcom/lvteam/LvTeamShift;->wallDistanceMm:I

    int-to-double v12, v2

    .line 232
    sget-boolean v2, Lcom/lvteam/LvTeamShift;->wallEngaged:Z

    if-nez v2, :cond_6

    .line 233
    sput v1, Lcom/lvteam/LvTeamShift;->wallLockedX:F

    .line 234
    sput v6, Lcom/lvteam/LvTeamShift;->wallLockedZ:F

    .line 235
    sput-boolean v0, Lcom/lvteam/LvTeamShift;->wallEngaged:Z

    .line 236
    invoke-static {}, Lcom/lvteam/LvShiftOverlay;->refreshWall()V

    goto :goto_2

    .line 239
    :cond_5
    sput v1, Lcom/lvteam/LvTeamShift;->wallLockedX:F

    .line 240
    sput v6, Lcom/lvteam/LvTeamShift;->wallLockedZ:F

    .line 243
    :cond_6
    :goto_2
    sput-wide v12, Lcom/lvteam/LvTeamShift;->wallOffsetMm:D

    .line 245
    invoke-static/range {p0 .. p1}, Lcom/lvteam/LvTeamShift;->zz(J)J

    move-result-wide v4

    float-to-double v14, v1

    mul-double/2addr v14, v12

    invoke-static {v14, v15}, Ljava/lang/Math;->round(D)J

    move-result-wide v14

    add-long/2addr v4, v14

    .line 246
    .local v4, "x":J
    invoke-static/range {p2 .. p3}, Lcom/lvteam/LvTeamShift;->zz(J)J

    move-result-wide v14

    move v7, v1

    .end local v1    # "fx":F
    .local v7, "fx":F
    float-to-double v0, v6

    mul-double/2addr v0, v12

    invoke-static {v0, v1}, Ljava/lang/Math;->round(D)J

    move-result-wide v0

    add-long/2addr v14, v0

    .line 247
    .local v14, "z":J
    invoke-static {v4, v5}, Lcom/lvteam/LvTeamShift;->enc(J)J

    move-result-wide v0

    invoke-static {v14, v15}, Lcom/lvteam/LvTeamShift;->enc(J)J

    move-result-wide v16

    const/4 v2, 0x2

    new-array v2, v2, [J

    aput-wide v0, v2, v3

    const/4 v0, 0x1

    aput-wide v16, v2, v0

    return-object v2
.end method

.method public static writeVarint(Ljava/io/ByteArrayOutputStream;J)V
    .locals 4
    .param p0, "o"    # Ljava/io/ByteArrayOutputStream;
    .param p1, "v"    # J

    .line 602
    nop

    :goto_0
    const-wide/16 v0, -0x80

    and-long/2addr v0, p1

    const-wide/16 v2, 0x0

    cmp-long v0, v0, v2

    if-eqz v0, :cond_0

    .line 603
    const-wide/16 v0, 0x7f

    and-long/2addr v0, p1

    const-wide/16 v2, 0x80

    or-long/2addr v0, v2

    long-to-int v0, v0

    invoke-virtual {p0, v0}, Ljava/io/ByteArrayOutputStream;->write(I)V

    .line 604
    const/4 v0, 0x7

    ushr-long/2addr p1, v0

    goto :goto_0

    .line 606
    :cond_0
    long-to-int v0, p1

    invoke-virtual {p0, v0}, Ljava/io/ByteArrayOutputStream;->write(I)V

    .line 607
    return-void
.end method

.method public static zz(J)J
    .locals 4
    .param p0, "v"    # J

    .line 610
    const/4 v0, 0x1

    ushr-long v0, p0, v0

    const-wide/16 v2, 0x1

    and-long/2addr v2, p0

    neg-long v2, v2

    xor-long/2addr v0, v2

    return-wide v0
.end method
