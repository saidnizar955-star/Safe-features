.class public Lcom/lvteam/MainActivity;
.super Landroid/app/Activity;
.source "MainActivity.java"


# static fields
.field private static final API_URL:Ljava/lang/String;

.field private static final APP_ID:Ljava/lang/String;

.field static final PREFS:Ljava/lang/String; = "lv_auth"

.field private static final SECRET_KEY:Ljava/lang/String;

.field private static final TAG:Ljava/lang/String; = "MainActivity"

.field private static final TH_ACCENT:I = -0xff1a01

.field private static final TH_BG:I = -0xf5f1e6

.field private static final TH_BORDER:I = -0xcfc9c3

.field private static final TH_CARD:I = -0xe9e4de

.field private static final TH_INPUT_BG:I = -0xf2eee9

.field private static final TH_TEXT:I = -0xf0f01

.field private static final TH_TEXT_DIM:I = -0x777756

.field private static final VPN_PERMISSION_REQUEST:I = 0x7


# instance fields
.field private btnLogin:Landroid/widget/TextView;

.field private handler:Landroid/os/Handler;

.field private inputKey:Landroid/widget/EditText;

.field private prefs:Landroid/content/SharedPreferences;

.field private txtStatus:Landroid/widget/TextView;

.field private waitingForOverlayPermission:Z


# direct methods
.method public static synthetic $r8$lambda$N1foJ3QXexTDPncU2foyX0jpR04(Lcom/lvteam/MainActivity;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/lvteam/MainActivity;->launchGame()V

    return-void
.end method

.method public static synthetic $r8$lambda$_F6VHCIXfIgYA6obA4zNrqoX1Fw(Lcom/lvteam/MainActivity;Z)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/lvteam/MainActivity;->lambda$onCreate$1(Z)V

    return-void
.end method

.method public static synthetic $r8$lambda$bZOMgTmQzBRPmHGtpBVG0fjpmoM(Lcom/lvteam/MainActivity;Landroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/lvteam/MainActivity;->lambda$onCreate$0(Landroid/view/View;)V

    return-void
.end method

.method public static bridge synthetic -$$Nest$fgethandler(Lcom/lvteam/MainActivity;)Landroid/os/Handler;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/lvteam/MainActivity;->handler:Landroid/os/Handler;

    return-object p0
.end method

.method public static bridge synthetic -$$Nest$mgetDeviceHwid(Lcom/lvteam/MainActivity;)Ljava/lang/String;
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/lvteam/MainActivity;->getDeviceHwid()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static bridge synthetic -$$Nest$monAuthResult(Lcom/lvteam/MainActivity;Ljava/lang/String;ILjava/lang/String;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2, p3}, Lcom/lvteam/MainActivity;->onAuthResult(Ljava/lang/String;ILjava/lang/String;)V

    return-void
.end method

.method public static bridge synthetic -$$Nest$mstartSession(Lcom/lvteam/MainActivity;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/lvteam/MainActivity;->startSession()V

    return-void
.end method

.method public static bridge synthetic -$$Nest$sfgetAPI_URL()Ljava/lang/String;
    .locals 1

    .line 0
    sget-object v0, Lcom/lvteam/MainActivity;->API_URL:Ljava/lang/String;

    return-object v0
.end method

.method public static bridge synthetic -$$Nest$sfgetAPP_ID()Ljava/lang/String;
    .locals 1

    .line 0
    sget-object v0, Lcom/lvteam/MainActivity;->APP_ID:Ljava/lang/String;

    return-object v0
.end method

.method public static bridge synthetic -$$Nest$sfgetSECRET_KEY()Ljava/lang/String;
    .locals 1

    .line 0
    sget-object v0, Lcom/lvteam/MainActivity;->SECRET_KEY:Ljava/lang/String;

    return-object v0
.end method

.method public static bridge synthetic -$$Nest$smreadAll(Ljava/io/InputStream;)Ljava/lang/String;
    .locals 0

    .line 0
    invoke-static {p0}, Lcom/lvteam/MainActivity;->readAll(Ljava/io/InputStream;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static constructor <clinit>()V
    .locals 2

    .line 39
    const/16 v0, 0x39

    const/16 v1, 0xe

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    invoke-static {v0}, Lcom/lvteam/Obs;->d([B)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/lvteam/MainActivity;->API_URL:Ljava/lang/String;

    .line 40
    new-array v0, v1, [B

    fill-array-data v0, :array_1

    invoke-static {v0}, Lcom/lvteam/Obs;->d([B)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/lvteam/MainActivity;->APP_ID:Ljava/lang/String;

    .line 41
    const/16 v1, 0x20

    new-array v0, v1, [B

    fill-array-data v0, :array_2

    invoke-static {v0}, Lcom/lvteam/Obs;->d([B)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/lvteam/MainActivity;->SECRET_KEY:Ljava/lang/String;

    return-void

    :array_0
    .array-data 1
        0x24t
        0x22t
        0x20t
        0x35t
        0x32t
        0x77t
        0x63t
        0x79t
        0x31t
        0x33t
        0x34t
        0x2et
        0x23t
        0x24t
        0x31t
        0x68t
        0x72t
        0x7et
        0x25t
        0x3bt
        0x39t
        0x36t
        0x22t
        0x39t
        0x62t
        0x3bt
        0x35t
        0x2bt
        0x34t
        0x3et
        0x62t
        0x25t
        0x24t
        0x24t
        0x22t
        0x28t
        0x63t
        0x37t
        0x24t
        0x2ct
        0x6et
        0x3bt
        0x7dt
        0x79t
        0x35t
        0x30t
        0x35t
        0x25t
        0x63t
        0x20t
        0x35t
        0x29t
        0x28t
        0x29t
        0x2dt
        0x22t
        0x31t
    .end array-data

    nop

    :array_1
    .array-data 1
        0x2dt
        0x26t
        0x24t
        0x1at
        0x75t
        0x29t
        0xbt
        0xft
        0x60t
        0x3t
        0x73t
        0x27t
        0x34t
        0x22t
    .end array-data

    nop

    :array_2
    .array-data 1
        0x6ct
        0x76t
        0x74t
        0x65t
        0x61t
        0x6dt
        0x6ct
        0x76t
        0x74t
        0x65t
        0x61t
        0x6dt
        0x6ct
        0x76t
        0x74t
        0x65t
        0x61t
        0x6dt
        0x6ct
        0x76t
        0x74t
        0x65t
        0x61t
        0x6dt
        0x6ct
        0x76t
        0x74t
        0x65t
        0x61t
        0x6dt
        0x6ct
        0x76t
    .end array-data
.end method

.method public constructor <init>()V
    .locals 0

    .line 35
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method

.method private addGetKeyButton(Landroid/widget/LinearLayout;)V
    .locals 8

    new-instance v0, Landroid/widget/TextView;

    invoke-direct {v0, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    invoke-static {}, Lcom/lvteam/ObfStrings;->getKey()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v1, -0xff1a01

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v1, 0x41600000    # 14.0f

    const/4 v2, 0x2

    invoke-virtual {v0, v2, v1}, Landroid/widget/TextView;->setTextSize(IF)V

    const/16 v1, 0x11

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setGravity(I)V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/view/View;->setClickable(Z)V

    new-instance v1, Lcom/lvteam/GetKeyClick;

    invoke-direct {v1, p0}, Lcom/lvteam/GetKeyClick;-><init>(Landroid/app/Activity;)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, -0x1

    const/16 v3, 0x2c

    invoke-direct {p0, v3}, Lcom/lvteam/MainActivity;->dp(I)I

    move-result v3

    invoke-direct {v1, v2, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/16 v2, 0x8

    invoke-direct {p0, v2}, Lcom/lvteam/MainActivity;->dp(I)I

    move-result v2

    iput v2, v1, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {p1, v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method private daysUntil(Ljava/lang/String;)I
    .locals 6
    .param p1, "iso"    # Ljava/lang/String;

    .line 464
    :try_start_0
    new-instance v0, Ljava/text/SimpleDateFormat;

    const-string v1, "yyyy-MM-dd\'T\'HH:mm:ss"

    invoke-direct {v0, v1}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    .line 465
    .local v0, "sdf":Ljava/text/SimpleDateFormat;
    invoke-virtual {v0, p1}, Ljava/text/DateFormat;->parse(Ljava/lang/String;)Ljava/util/Date;

    move-result-object v1

    .line 466
    .local v1, "d":Ljava/util/Date;
    if-nez v1, :cond_0

    .line 467
    new-instance v2, Ljava/text/SimpleDateFormat;

    const-string v3, "yyyy-MM-dd"

    invoke-direct {v2, v3}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    move-object v0, v2

    .line 468
    invoke-virtual {v0, p1}, Ljava/text/DateFormat;->parse(Ljava/lang/String;)Ljava/util/Date;

    move-result-object v2

    move-object v1, v2

    goto :goto_0

    .line 474
    .end local v0    # "sdf":Ljava/text/SimpleDateFormat;
    .end local v1    # "d":Ljava/util/Date;
    :catch_0
    move-exception v0

    goto :goto_1

    .line 470
    .restart local v0    # "sdf":Ljava/text/SimpleDateFormat;
    .restart local v1    # "d":Ljava/util/Date;
    :cond_0
    :goto_0
    if-eqz v1, :cond_1

    .line 471
    invoke-virtual {v1}, Ljava/util/Date;->getTime()J

    move-result-wide v2

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    sub-long/2addr v2, v4

    .line 472
    .local v2, "diff":J
    const-wide/32 v4, 0x5265c00

    div-long v4, v2, v4
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    long-to-int v4, v4

    return v4

    .line 470
    .end local v2    # "diff":J
    :cond_1
    nop

    .line 474
    .end local v0    # "sdf":Ljava/text/SimpleDateFormat;
    .end local v1    # "d":Ljava/util/Date;
    :goto_1
    nop

    .line 475
    const/4 v0, 0x0

    return v0
.end method

.method private dp(I)I
    .locals 2
    .param p1, "v"    # I

    .line 488
    int-to-float v0, p1

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v1

    iget v1, v1, Landroid/util/DisplayMetrics;->density:F

    mul-float/2addr v0, v1

    const/high16 v1, 0x3f000000    # 0.5f

    add-float/2addr v0, v1

    float-to-int v0, v0

    return v0
.end method

.method private extractDays(Ljava/lang/String;)I
    .locals 7
    .param p1, "json"    # Ljava/lang/String;

    .line 427
    const-string v0, ""

    const-string v1, "keyExpiresAt"

    const-string v2, "data"

    :try_start_0
    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 428
    .local v3, "o":Lorg/json/JSONObject;
    invoke-direct {p0, v3}, Lcom/lvteam/MainActivity;->findDays(Lorg/json/JSONObject;)I

    move-result v4

    .line 429
    .local v4, "d":I
    if-ltz v4, :cond_0

    return v4

    .line 430
    :cond_0
    invoke-virtual {v3, v2}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_1

    .line 431
    invoke-virtual {v3, v2}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v5

    invoke-direct {p0, v5}, Lcom/lvteam/MainActivity;->findDays(Lorg/json/JSONObject;)I

    move-result v5

    move v4, v5

    .line 432
    if-ltz v4, :cond_1

    return v4

    .line 438
    .end local v3    # "o":Lorg/json/JSONObject;
    .end local v4    # "d":I
    :catch_0
    move-exception v0

    goto :goto_0

    .line 434
    .restart local v3    # "o":Lorg/json/JSONObject;
    .restart local v4    # "d":I
    :cond_1
    invoke-virtual {v3, v1, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 435
    .local v5, "exp":Ljava/lang/String;
    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v6

    if-eqz v6, :cond_2

    invoke-virtual {v3, v2}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_2

    .line 436
    invoke-virtual {v3, v2}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    invoke-virtual {v2, v1, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    move-object v5, v0

    .line 437
    :cond_2
    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_3

    invoke-direct {p0, v5}, Lcom/lvteam/MainActivity;->daysUntil(Ljava/lang/String;)I

    move-result v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return v0

    :cond_3
    nop

    .line 438
    .end local v3    # "o":Lorg/json/JSONObject;
    .end local v4    # "d":I
    .end local v5    # "exp":Ljava/lang/String;
    :goto_0
    nop

    .line 439
    const/4 v0, 0x0

    return v0
.end method

.method private extractExpiry(Ljava/lang/String;)Ljava/lang/String;
    .locals 6
    .param p1, "json"    # Ljava/lang/String;

    .line 453
    const-string v0, "data"

    const-string v1, ""

    const-string v2, "keyExpiresAt"

    :try_start_0
    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 454
    .local v3, "o":Lorg/json/JSONObject;
    invoke-virtual {v3, v2, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 455
    .local v4, "e":Ljava/lang/String;
    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_0

    return-object v4

    .line 456
    :cond_0
    invoke-virtual {v3, v0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_1

    .line 457
    invoke-virtual {v3, v0}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    .line 458
    .end local v3    # "o":Lorg/json/JSONObject;
    .end local v4    # "e":Ljava/lang/String;
    :catch_0
    move-exception v0

    goto :goto_0

    .line 456
    .restart local v3    # "o":Lorg/json/JSONObject;
    .restart local v4    # "e":Ljava/lang/String;
    :cond_1
    nop

    .line 458
    .end local v3    # "o":Lorg/json/JSONObject;
    .end local v4    # "e":Ljava/lang/String;
    :goto_0
    nop

    .line 459
    const/4 v0, 0x0

    return-object v0
.end method

.method private findDays(Lorg/json/JSONObject;)I
    .locals 7
    .param p1, "o"    # Lorg/json/JSONObject;

    .line 443
    const-string v5, "dias"

    const-string v6, "diasRestantes"

    const-string v0, "days"

    const-string v1, "daysRemaining"

    const-string v2, "days_remaining"

    const-string v3, "remainingDays"

    const-string v4, "remaining_days"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v0

    .line 445
    .local v0, "keys":[Ljava/lang/String;
    array-length v1, v0

    const/4 v2, 0x0

    :goto_0
    const/4 v3, -0x1

    if-ge v2, v1, :cond_1

    aget-object v4, v0, v2

    .line 446
    .local v4, "k":Ljava/lang/String;
    invoke-virtual {p1, v4}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_0

    invoke-virtual {p1, v4, v3}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v1

    return v1

    .line 445
    .end local v4    # "k":Ljava/lang/String;
    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    .line 448
    :cond_1
    return v3
.end method

.method private getDeviceHwid()Ljava/lang/String;
    .locals 3

    .line 399
    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    const-string v1, "android_id"

    invoke-static {v0, v1}, Landroid/provider/Settings$Secure;->getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 401
    .local v0, "aid":Ljava/lang/String;
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "android_"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "_"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v2, Landroid/os/Build;->MODEL:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    return-object v1
.end method

.method private synthetic lambda$onCreate$0(Landroid/view/View;)V
    .locals 3
    .param p1, "v"    # Landroid/view/View;

    .line 224
    iget-object v0, p0, Lcom/lvteam/MainActivity;->inputKey:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    .line 225
    .local v0, "key":Ljava/lang/String;
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_0

    .line 226
    const v1, -0xbbbc

    const-string v2, "Insira uma chave!"

    invoke-direct {p0, v1, v2}, Lcom/lvteam/MainActivity;->showStatus(ILjava/lang/String;)V

    .line 227
    return-void

    .line 229
    :cond_0
    iget-object v1, p0, Lcom/lvteam/MainActivity;->btnLogin:Landroid/widget/TextView;

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setEnabled(Z)V

    .line 230
    iget-object v1, p0, Lcom/lvteam/MainActivity;->btnLogin:Landroid/widget/TextView;

    const-string v2, "VERIFICANDO..."

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 231
    const/16 v1, -0x44cd

    const-string v2, "Validando chave..."

    invoke-direct {p0, v1, v2}, Lcom/lvteam/MainActivity;->showStatus(ILjava/lang/String;)V

    .line 232
    invoke-direct {p0, v0}, Lcom/lvteam/MainActivity;->validateKey(Ljava/lang/String;)V

    .line 233
    return-void
.end method

.method private synthetic lambda$onCreate$1(Z)V
    .locals 5
    .param p1, "updateRequired"    # Z

    .line 210
    if-eqz p1, :cond_0

    return-void

    .line 212
    :cond_0
    new-instance v0, Lcom/lvteam/LvAntiCrack;

    invoke-direct {v0, p0}, Lcom/lvteam/LvAntiCrack;-><init>(Landroid/app/Activity;)V

    .line 213
    .local v0, "ac":Lcom/lvteam/LvAntiCrack;
    invoke-virtual {v0}, Lcom/lvteam/LvAntiCrack;->check()Z

    move-result v1

    const/4 v1, 0x1

    if-nez v1, :cond_1

    .line 214
    const v1, -0xbbbc

    const-string v2, "Sessao encerrada."

    invoke-direct {p0, v1, v2}, Lcom/lvteam/MainActivity;->showStatus(ILjava/lang/String;)V

    .line 215
    iget-object v1, p0, Lcom/lvteam/MainActivity;->handler:Landroid/os/Handler;

    new-instance v2, Lcom/lvteam/MainActivity$$ExternalSyntheticLambda3;

    invoke-direct {v2, p0}, Lcom/lvteam/MainActivity$$ExternalSyntheticLambda3;-><init>(Lcom/lvteam/MainActivity;)V

    const-wide/16 v3, 0x5dc

    invoke-virtual {v1, v2, v3, v4}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 216
    return-void

    .line 219
    :cond_1
    iget-object v1, p0, Lcom/lvteam/MainActivity;->btnLogin:Landroid/widget/TextView;

    const/4 v2, 0x1

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setEnabled(Z)V

    .line 220
    iget-object v1, p0, Lcom/lvteam/MainActivity;->btnLogin:Landroid/widget/TextView;

    const-string v2, "LOGIN"

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 221
    iget-object v1, p0, Lcom/lvteam/MainActivity;->txtStatus:Landroid/widget/TextView;

    const/16 v2, 0x8

    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 223
    iget-object v1, p0, Lcom/lvteam/MainActivity;->btnLogin:Landroid/widget/TextView;

    new-instance v2, Lcom/lvteam/MainActivity$$ExternalSyntheticLambda4;

    invoke-direct {v2, p0}, Lcom/lvteam/MainActivity$$ExternalSyntheticLambda4;-><init>(Lcom/lvteam/MainActivity;)V

    invoke-virtual {v1, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 235
    iget-object v1, p0, Lcom/lvteam/MainActivity;->prefs:Landroid/content/SharedPreferences;

    const-string v2, "key"

    const/4 v3, 0x0

    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 236
    .local v1, "savedKey":Ljava/lang/String;
    if-eqz v1, :cond_2

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_2

    .line 237
    iget-object v2, p0, Lcom/lvteam/MainActivity;->btnLogin:Landroid/widget/TextView;

    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setEnabled(Z)V

    .line 238
    iget-object v2, p0, Lcom/lvteam/MainActivity;->btnLogin:Landroid/widget/TextView;

    const-string v3, "VERIFICANDO..."

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 239
    const/16 v2, -0x44cd

    const-string v3, "Validando chave salva..."

    invoke-direct {p0, v2, v3}, Lcom/lvteam/MainActivity;->showStatus(ILjava/lang/String;)V

    .line 240
    invoke-direct {p0, v1}, Lcom/lvteam/MainActivity;->validateKey(Ljava/lang/String;)V

    .line 242
    :cond_2
    return-void
.end method

.method private launchGame()V
    .locals 4

    .line 388
    const-string v0, "Opening target game"

    const-string v1, "MainActivity"

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 389
    new-instance v0, Landroid/content/Intent;

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    const-string v2, "com.dts.freefireth"

    const-string v3, "com.dts.freefireth.FFMainActivity"

    invoke-virtual {v0, v2, v3}, Landroid/content/Intent;->setClassName(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    .line 392
    .local v0, "game":Landroid/content/Intent;
    :try_start_0
    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Landroid/content/ActivityNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    .line 395
    goto :goto_0

    .line 393
    :catch_0
    move-exception v2

    .line 394
    .local v2, "e":Landroid/content/ActivityNotFoundException;
    const-string v3, "Target game activity not found"

    invoke-static {v1, v3, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 396
    .end local v2    # "e":Landroid/content/ActivityNotFoundException;
    :goto_0
    return-void
.end method

.method private onAuthResult(Ljava/lang/String;ILjava/lang/String;)V
    .locals 7
    .param p1, "key"    # Ljava/lang/String;
    .param p2, "code"    # I
    .param p3, "body"    # Ljava/lang/String;

    .line 316
    const/16 v0, 0xc8

    const-string v1, "LOGIN"

    const/4 v2, 0x1

    const v3, -0xbbbc

    if-lt p2, v0, :cond_2

    const/16 v0, 0x12c

    if-ge p2, v0, :cond_2

    .line 317
    invoke-direct {p0, p3}, Lcom/lvteam/MainActivity;->extractDays(Ljava/lang/String;)I

    move-result v0

    .line 318
    .local v0, "days":I
    invoke-direct {p0, p3}, Lcom/lvteam/MainActivity;->extractExpiry(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 320
    .local v4, "expires":Ljava/lang/String;
    invoke-static {}, Lcom/lvteam/LvSession;->get()Lcom/lvteam/LvSession;

    move-result-object v5

    invoke-virtual {v5, p1, v0, p3}, Lcom/lvteam/LvSession;->activate(Ljava/lang/String;ILjava/lang/String;)V

    .line 322
    invoke-static {}, Lcom/lvteam/LvSession;->get()Lcom/lvteam/LvSession;

    move-result-object v5

    invoke-virtual {v5}, Lcom/lvteam/LvSession;->isActive()Z

    move-result v5

    if-nez v5, :cond_0

    .line 323
    iget-object v5, p0, Lcom/lvteam/MainActivity;->btnLogin:Landroid/widget/TextView;

    invoke-virtual {v5, v2}, Landroid/widget/TextView;->setEnabled(Z)V

    .line 324
    iget-object v2, p0, Lcom/lvteam/MainActivity;->btnLogin:Landroid/widget/TextView;

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 325
    const-string v1, "Erro de sessao. Tente novamente."

    invoke-direct {p0, v3, v1}, Lcom/lvteam/MainActivity;->showStatus(ILjava/lang/String;)V

    .line 326
    return-void

    .line 329
    :cond_0
    iget-object v1, p0, Lcom/lvteam/MainActivity;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    .line 330
    .local v1, "ed":Landroid/content/SharedPreferences$Editor;
    const-string v2, "key"

    invoke-interface {v1, v2, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 331
    const-string v2, "days"

    invoke-interface {v1, v2, v0}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    .line 332
    if-eqz v4, :cond_1

    move-object v2, v4

    goto :goto_0

    :cond_1
    const-string v2, ""

    :goto_0
    const-string v3, "expires"

    invoke-interface {v1, v3, v2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 333
    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 335
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/lvteam/ObfStrings;->successMessage()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const v3, -0xff1a01

    invoke-direct {p0, v3, v2}, Lcom/lvteam/MainActivity;->showStatus(ILjava/lang/String;)V

    .line 336
    iget-object v2, p0, Lcom/lvteam/MainActivity;->handler:Landroid/os/Handler;

    new-instance v3, Lcom/lvteam/MainActivity$2;

    invoke-direct {v3, p0}, Lcom/lvteam/MainActivity$2;-><init>(Lcom/lvteam/MainActivity;)V

    const-wide/16 v5, 0x320

    invoke-virtual {v2, v3, v5, v6}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 342
    .end local v0    # "days":I
    .end local v1    # "ed":Landroid/content/SharedPreferences$Editor;
    .end local v4    # "expires":Ljava/lang/String;
    goto :goto_1

    .line 343
    :cond_2
    iget-object v0, p0, Lcom/lvteam/MainActivity;->btnLogin:Landroid/widget/TextView;

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setEnabled(Z)V

    .line 344
    iget-object v0, p0, Lcom/lvteam/MainActivity;->btnLogin:Landroid/widget/TextView;

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 345
    const/4 v0, -0x1

    if-ne p2, v0, :cond_3

    .line 346
    const-string v0, "Erro de conexao. Verifique sua internet."

    invoke-direct {p0, v3, v0}, Lcom/lvteam/MainActivity;->showStatus(ILjava/lang/String;)V

    goto :goto_1

    .line 348
    :cond_3
    invoke-direct {p0, p3}, Lcom/lvteam/MainActivity;->parseError(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v3, v0}, Lcom/lvteam/MainActivity;->showStatus(ILjava/lang/String;)V

    .line 351
    :goto_1
    return-void
.end method

.method private parseError(Ljava/lang/String;)Ljava/lang/String;
    .locals 4
    .param p1, "json"    # Ljava/lang/String;

    .line 406
    const-string v0, ""

    :try_start_0
    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 407
    .local v1, "o":Lorg/json/JSONObject;
    const-string v2, "error"

    invoke-virtual {v1, v2, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 408
    .local v2, "err":Ljava/lang/String;
    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_0

    const-string v3, "message"

    invoke-virtual {v1, v3, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    move-object v2, v0

    goto :goto_0

    .line 421
    .end local v1    # "o":Lorg/json/JSONObject;
    .end local v2    # "err":Ljava/lang/String;
    :catch_0
    move-exception v0

    goto/16 :goto_1

    .line 409
    .restart local v1    # "o":Lorg/json/JSONObject;
    .restart local v2    # "err":Ljava/lang/String;
    :cond_0
    :goto_0
    const-string v0, "invalid_key"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-static {}, Lcom/lvteam/ObfStrings;->invalidMessage()Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 410
    :cond_1
    const-string v0, "key_expired"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    const-string v0, "Chave expirada!"

    return-object v0

    .line 411
    :cond_2
    const-string v0, "key_banned"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3

    const-string v0, "Chave banida!"

    return-object v0

    .line 412
    :cond_3
    const-string v0, "key_paused"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4

    const-string v0, "Chave pausada!"

    return-object v0

    .line 413
    :cond_4
    const-string v0, "app_paused"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_5

    const-string v0, "Aplicativo pausado!"

    return-object v0

    .line 414
    :cond_5
    const-string v0, "app_mismatch"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_6

    const-string v0, "App incompativel!"

    return-object v0

    .line 415
    :cond_6
    const-string v0, "device_locked"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_7

    const-string v0, "Dispositivo bloqueado!"

    return-object v0

    .line 416
    :cond_7
    const-string v0, "device_mismatch"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_8

    const-string v0, "Dispositivo diferente!"

    return-object v0

    .line 417
    :cond_8
    const-string v0, "hwid_mismatch"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_9

    const-string v0, "HWID diferente!"

    return-object v0

    .line 418
    :cond_9
    const-string v0, "device_required"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_a

    const-string v0, "Dispositivo obrigatorio!"

    return-object v0

    .line 419
    :cond_a
    const-string v0, "device_banned"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_b

    const-string v0, "Dispositivo banido!"

    return-object v0

    .line 420
    :cond_b
    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    if-nez v0, :cond_c

    return-object v2

    .line 421
    .end local v1    # "o":Lorg/json/JSONObject;
    .end local v2    # "err":Ljava/lang/String;
    :cond_c
    :goto_1
    nop

    .line 422
    const-string v0, "Erro na validacao (HTTP)"

    return-object v0
.end method

.method private static readAll(Ljava/io/InputStream;)Ljava/lang/String;
    .locals 4
    .param p0, "is"    # Ljava/io/InputStream;

    .line 479
    new-instance v0, Ljava/io/BufferedReader;

    new-instance v1, Ljava/io/InputStreamReader;

    const-string v2, "UTF-8"

    invoke-direct {v1, p0, v2}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/lang/String;)V

    invoke-direct {v0, v1}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    .line 480
    .local v0, "br":Ljava/io/BufferedReader;
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 482
    .local v1, "sb":Ljava/lang/StringBuilder;
    :goto_0
    invoke-virtual {v0}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v2

    move-object v3, v2

    .local v3, "line":Ljava/lang/String;
    if-eqz v2, :cond_0

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_0

    .line 483
    :cond_0
    invoke-virtual {v0}, Ljava/io/BufferedReader;->close()V

    .line 484
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    return-object v2
.end method

.method private requestVpn()V
    .locals 2

    .line 364
    invoke-static {p0}, Landroid/net/VpnService;->prepare(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object v0

    .line 365
    .local v0, "permission":Landroid/content/Intent;
    if-nez v0, :cond_0

    .line 366
    invoke-direct {p0}, Lcom/lvteam/MainActivity;->startCaptureAndOverlay()V

    goto :goto_0

    .line 368
    :cond_0
    const/4 v1, 0x7

    invoke-virtual {p0, v0, v1}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;I)V

    .line 370
    :goto_0
    return-void
.end method

.method private showStatus(ILjava/lang/String;)V
    .locals 2
    .param p1, "color"    # I
    .param p2, "msg"    # Ljava/lang/String;

    .line 259
    iget-object v0, p0, Lcom/lvteam/MainActivity;->txtStatus:Landroid/widget/TextView;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 260
    iget-object v0, p0, Lcom/lvteam/MainActivity;->txtStatus:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 261
    iget-object v0, p0, Lcom/lvteam/MainActivity;->txtStatus:Landroid/widget/TextView;

    invoke-virtual {v0, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 262
    return-void
.end method

.method private startCaptureAndOverlay()V
    .locals 6

    .line 373
    invoke-static {}, Lcom/lvteam/LvSession;->get()Lcom/lvteam/LvSession;

    move-result-object v0

    invoke-virtual {v0}, Lcom/lvteam/LvSession;->isActive()Z

    move-result v0

    if-nez v0, :cond_0

    .line 374
    const v0, -0xbbbc

    const-string v1, "Sessao invalida. Reinicie o app."

    invoke-direct {p0, v0, v1}, Lcom/lvteam/MainActivity;->showStatus(ILjava/lang/String;)V

    .line 375
    return-void

    .line 377
    :cond_0
    const-string v0, "MainActivity"

    const-string v1, "Starting full IPv4 capture and overlay"

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 378
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/lvteam/PacketCaptureService;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 379
    const-string v1, "com.lvteam.action.ENABLE_FULL_IPV4_ROUTE"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    .line 380
    .local v0, "capture":Landroid/content/Intent;
    invoke-virtual {p0, v0}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    .line 381
    new-instance v1, Landroid/content/Intent;

    const-class v2, Lcom/lvteam/OverlayService;

    invoke-direct {v1, p0, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 382
    .local v1, "overlay":Landroid/content/Intent;
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x1a

    if-lt v2, v3, :cond_1

    invoke-static {p0, v1}, Lcom/lvteam/MainActivity$$ExternalSyntheticApiModelOutline0;->m(Lcom/lvteam/MainActivity;Landroid/content/Intent;)Landroid/content/ComponentName;

    goto :goto_0

    .line 383
    :cond_1
    invoke-virtual {p0, v1}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    .line 384
    :goto_0
    new-instance v2, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v3

    invoke-direct {v2, v3}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v3, Lcom/lvteam/MainActivity$$ExternalSyntheticLambda2;

    invoke-direct {v3, p0}, Lcom/lvteam/MainActivity$$ExternalSyntheticLambda2;-><init>(Lcom/lvteam/MainActivity;)V

    const-wide/16 v4, 0x2ee

    invoke-virtual {v2, v3, v4, v5}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 385
    return-void
.end method

.method private startSession()V
    .locals 3

    .line 354
    invoke-static {p0}, Landroid/provider/Settings;->canDrawOverlays(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 355
    invoke-direct {p0}, Lcom/lvteam/MainActivity;->requestVpn()V

    .line 356
    return-void

    .line 358
    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/lvteam/MainActivity;->waitingForOverlayPermission:Z

    .line 359
    new-instance v0, Landroid/content/Intent;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "package:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 360
    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    const-string v2, "android.settings.action.MANAGE_OVERLAY_PERMISSION"

    invoke-direct {v0, v2, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 359
    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 361
    return-void
.end method

.method private validateKey(Ljava/lang/String;)V
    .locals 2
    .param p1, "key"    # Ljava/lang/String;

    invoke-static {}, Lcom/lvteam/ObfStrings;->password()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {}, Lcom/lvteam/ObfStrings;->success()Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0xc8

    invoke-direct {p0, p1, v1, v0}, Lcom/lvteam/MainActivity;->onAuthResult(Ljava/lang/String;ILjava/lang/String;)V

    return-void

    :cond_0
    invoke-static {}, Lcom/lvteam/ObfStrings;->invalidJson()Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0x191

    invoke-direct {p0, p1, v1, v0}, Lcom/lvteam/MainActivity;->onAuthResult(Ljava/lang/String;ILjava/lang/String;)V

    return-void
.end method


# virtual methods
.method public onActivityResult(IILandroid/content/Intent;)V
    .locals 1
    .param p1, "requestCode"    # I
    .param p2, "resultCode"    # I
    .param p3, "data"    # Landroid/content/Intent;

    .line 254
    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onActivityResult(IILandroid/content/Intent;)V

    .line 255
    const/4 v0, 0x7

    if-ne p1, v0, :cond_0

    const/4 v0, -0x1

    if-ne p2, v0, :cond_0

    invoke-direct {p0}, Lcom/lvteam/MainActivity;->startCaptureAndOverlay()V

    .line 256
    :cond_0
    return-void
.end method

.method public onCreate(Landroid/os/Bundle;)V
    .locals 25
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 61
    move-object/from16 v0, p0

    invoke-super/range {p0 .. p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 63
    new-instance v1, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v1, v0, Lcom/lvteam/MainActivity;->handler:Landroid/os/Handler;

    .line 65
    nop

    .line 66
    invoke-virtual/range {p0 .. p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v1

    const v2, -0xf5f1e6

    invoke-virtual {v1, v2}, Landroid/view/Window;->setStatusBarColor(I)V

    .line 67
    invoke-virtual/range {p0 .. p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v1

    invoke-virtual {v1, v2}, Landroid/view/Window;->setNavigationBarColor(I)V

    .line 70
    const/16 v1, 0x10

    invoke-direct {v0, v1}, Lcom/lvteam/MainActivity;->dp(I)I

    move-result v3

    .line 71
    .local v3, "pad16":I
    const/16 v4, 0x18

    invoke-direct {v0, v4}, Lcom/lvteam/MainActivity;->dp(I)I

    move-result v4

    .line 72
    .local v4, "pad24":I
    const/16 v5, 0x1c

    invoke-direct {v0, v5}, Lcom/lvteam/MainActivity;->dp(I)I

    move-result v5

    .line 74
    .local v5, "pad28":I
    new-instance v6, Landroid/widget/FrameLayout;

    invoke-direct {v6, v0}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    .line 75
    .local v6, "root":Landroid/widget/FrameLayout;
    invoke-virtual {v6, v2}, Landroid/view/View;->setBackgroundColor(I)V

    .line 77
    new-instance v7, Landroid/widget/LinearLayout;

    invoke-direct {v7, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 78
    .local v7, "center":Landroid/widget/LinearLayout;
    const/4 v8, 0x1

    invoke-virtual {v7, v8}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 79
    invoke-virtual {v7, v8}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 81
    new-instance v9, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v10, -0x1

    const/4 v11, -0x2

    invoke-direct {v9, v10, v11}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    .line 84
    .local v9, "centerLp":Landroid/widget/FrameLayout$LayoutParams;
    const/16 v12, 0x11

    iput v12, v9, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    .line 85
    iput v5, v9, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    .line 86
    iput v5, v9, Landroid/widget/FrameLayout$LayoutParams;->rightMargin:I

    .line 88
    new-instance v13, Landroid/widget/LinearLayout;

    invoke-direct {v13, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 89
    .local v13, "titleRow":Landroid/widget/LinearLayout;
    const/4 v14, 0x0

    invoke-virtual {v13, v14}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 90
    invoke-virtual {v13, v12}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 92
    new-instance v15, Landroid/widget/TextView;

    invoke-direct {v15, v0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 93
    .local v15, "tvLV":Landroid/widget/TextView;
    const-string v2, "LV"

    invoke-virtual {v15, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 94
    invoke-virtual {v15, v10}, Landroid/widget/TextView;->setTextColor(I)V

    .line 95
    const/4 v2, 0x2

    const/high16 v14, 0x42400000    # 48.0f

    invoke-virtual {v15, v2, v14}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 96
    sget-object v10, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v15, v10}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 97
    invoke-virtual {v13, v15}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 99
    new-instance v10, Landroid/widget/TextView;

    invoke-direct {v10, v0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 100
    .local v10, "tvTeam":Landroid/widget/TextView;
    const-string v8, " TEAM"

    invoke-virtual {v10, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 101
    const v8, -0xff1a01

    invoke-virtual {v10, v8}, Landroid/widget/TextView;->setTextColor(I)V

    .line 102
    invoke-virtual {v10, v2, v14}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 103
    sget-object v14, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v10, v14}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 104
    invoke-virtual {v13, v10}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 106
    invoke-virtual {v7, v13}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 108
    new-instance v14, Landroid/widget/TextView;

    invoke-direct {v14, v0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 109
    .local v14, "sub":Landroid/widget/TextView;
    const-string v8, "Game Enhancement Tool"

    invoke-virtual {v14, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 110
    const v8, -0x777756

    invoke-virtual {v14, v8}, Landroid/widget/TextView;->setTextColor(I)V

    .line 111
    const/high16 v8, 0x41600000    # 14.0f

    invoke-virtual {v14, v2, v8}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 112
    invoke-virtual {v14, v12}, Landroid/widget/TextView;->setGravity(I)V

    .line 113
    new-instance v12, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v12, v11, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 116
    .local v12, "subLp":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v11, 0x4

    invoke-direct {v0, v11}, Lcom/lvteam/MainActivity;->dp(I)I

    move-result v11

    iput v11, v12, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 117
    const/16 v11, 0x20

    invoke-direct {v0, v11}, Lcom/lvteam/MainActivity;->dp(I)I

    move-result v11

    iput v11, v12, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 118
    invoke-virtual {v7, v14, v12}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 120
    new-instance v11, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v11}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 121
    .local v11, "cardBg":Landroid/graphics/drawable/GradientDrawable;
    const v2, -0xe9e4de

    invoke-virtual {v11, v2}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 122
    invoke-direct {v0, v1}, Lcom/lvteam/MainActivity;->dp(I)I

    move-result v1

    int-to-float v1, v1

    invoke-virtual {v11, v1}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 123
    const/4 v1, 0x1

    invoke-direct {v0, v1}, Lcom/lvteam/MainActivity;->dp(I)I

    move-result v2

    const v8, -0xcfc9c3

    invoke-virtual {v11, v2, v8}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 125
    new-instance v2, Landroid/widget/LinearLayout;

    invoke-direct {v2, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 126
    .local v2, "card":Landroid/widget/LinearLayout;
    invoke-virtual {v2, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 127
    invoke-virtual {v2, v11}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 128
    invoke-virtual {v2, v4, v4, v4, v4}, Landroid/view/View;->setPadding(IIII)V

    .line 130
    new-instance v1, Landroid/widget/TextView;

    invoke-direct {v1, v0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 131
    .local v1, "label":Landroid/widget/TextView;
    const-string v8, "Chave de Acesso"

    invoke-virtual {v1, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 132
    const/4 v8, -0x1

    invoke-virtual {v1, v8}, Landroid/widget/TextView;->setTextColor(I)V

    .line 133
    move/from16 v20, v4

    const/high16 v4, 0x41600000    # 14.0f

    const/4 v8, 0x2

    .end local v4    # "pad24":I
    .local v20, "pad24":I
    invoke-virtual {v1, v8, v4}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 134
    sget-object v4, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 135
    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v8, -0x2

    invoke-direct {v4, v8, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 138
    .local v4, "labelLp":Landroid/widget/LinearLayout$LayoutParams;
    const/16 v8, 0xa

    invoke-direct {v0, v8}, Lcom/lvteam/MainActivity;->dp(I)I

    move-result v8

    iput v8, v4, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 139
    invoke-virtual {v2, v1, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 141
    new-instance v8, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v8}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 142
    .local v8, "inputBg":Landroid/graphics/drawable/GradientDrawable;
    move-object/from16 v22, v1

    .end local v1    # "label":Landroid/widget/TextView;
    .local v22, "label":Landroid/widget/TextView;
    const v1, -0xf2eee9

    invoke-virtual {v8, v1}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 143
    const/16 v1, 0xc

    move-object/from16 v23, v4

    .end local v4    # "labelLp":Landroid/widget/LinearLayout$LayoutParams;
    .local v23, "labelLp":Landroid/widget/LinearLayout$LayoutParams;
    invoke-direct {v0, v1}, Lcom/lvteam/MainActivity;->dp(I)I

    move-result v4

    int-to-float v4, v4

    invoke-virtual {v8, v4}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 144
    const/4 v4, 0x1

    invoke-direct {v0, v4}, Lcom/lvteam/MainActivity;->dp(I)I

    move-result v1

    const v4, -0xcfc9c3

    invoke-virtual {v8, v1, v4}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 146
    new-instance v1, Landroid/widget/EditText;

    invoke-direct {v1, v0}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    iput-object v1, v0, Lcom/lvteam/MainActivity;->inputKey:Landroid/widget/EditText;

    .line 147
    iget-object v1, v0, Lcom/lvteam/MainActivity;->inputKey:Landroid/widget/EditText;

    const-string v4, "Insira sua Key"

    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    .line 148
    iget-object v1, v0, Lcom/lvteam/MainActivity;->inputKey:Landroid/widget/EditText;

    const v4, -0xb4aa9d

    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setHintTextColor(I)V

    .line 149
    iget-object v1, v0, Lcom/lvteam/MainActivity;->inputKey:Landroid/widget/EditText;

    const/4 v4, -0x1

    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setTextColor(I)V

    .line 150
    iget-object v1, v0, Lcom/lvteam/MainActivity;->inputKey:Landroid/widget/EditText;

    const/high16 v4, 0x41700000    # 15.0f

    move/from16 v21, v5

    const/4 v5, 0x2

    .end local v5    # "pad28":I
    .local v21, "pad28":I
    invoke-virtual {v1, v5, v4}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 151
    iget-object v1, v0, Lcom/lvteam/MainActivity;->inputKey:Landroid/widget/EditText;

    invoke-virtual {v1, v8}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 152
    iget-object v1, v0, Lcom/lvteam/MainActivity;->inputKey:Landroid/widget/EditText;

    const/4 v4, 0x0

    invoke-virtual {v1, v3, v4, v3, v4}, Landroid/view/View;->setPadding(IIII)V

    .line 153
    iget-object v1, v0, Lcom/lvteam/MainActivity;->inputKey:Landroid/widget/EditText;

    const/4 v4, 0x1

    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setSingleLine(Z)V

    .line 154
    iget-object v1, v0, Lcom/lvteam/MainActivity;->inputKey:Landroid/widget/EditText;

    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setInputType(I)V

    .line 155
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    .line 156
    const/16 v4, 0x32

    invoke-direct {v0, v4}, Lcom/lvteam/MainActivity;->dp(I)I

    move-result v5

    const/4 v4, -0x1

    invoke-direct {v1, v4, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 157
    .local v1, "inputLp":Landroid/widget/LinearLayout$LayoutParams;
    iput v3, v1, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 158
    iget-object v4, v0, Lcom/lvteam/MainActivity;->inputKey:Landroid/widget/EditText;

    invoke-virtual {v2, v4, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 160
    new-instance v4, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v4}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 161
    .local v4, "btnBg":Landroid/graphics/drawable/GradientDrawable;
    move-object/from16 v24, v1

    const/16 v5, 0xc

    .end local v1    # "inputLp":Landroid/widget/LinearLayout$LayoutParams;
    .local v24, "inputLp":Landroid/widget/LinearLayout$LayoutParams;
    invoke-direct {v0, v5}, Lcom/lvteam/MainActivity;->dp(I)I

    move-result v1

    int-to-float v1, v1

    invoke-virtual {v4, v1}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 162
    const v1, -0xff1a01

    invoke-virtual {v4, v1}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 164
    new-instance v1, Landroid/widget/TextView;

    invoke-direct {v1, v0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    iput-object v1, v0, Lcom/lvteam/MainActivity;->btnLogin:Landroid/widget/TextView;

    .line 165
    iget-object v1, v0, Lcom/lvteam/MainActivity;->btnLogin:Landroid/widget/TextView;

    const-string v5, "LOGIN"

    invoke-virtual {v1, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 166
    iget-object v1, v0, Lcom/lvteam/MainActivity;->btnLogin:Landroid/widget/TextView;

    const v5, -0xf5f1e6

    invoke-virtual {v1, v5}, Landroid/widget/TextView;->setTextColor(I)V

    .line 167
    iget-object v1, v0, Lcom/lvteam/MainActivity;->btnLogin:Landroid/widget/TextView;

    const/high16 v5, 0x41800000    # 16.0f

    move-object/from16 v16, v8

    const/4 v8, 0x2

    .end local v8    # "inputBg":Landroid/graphics/drawable/GradientDrawable;
    .local v16, "inputBg":Landroid/graphics/drawable/GradientDrawable;
    invoke-virtual {v1, v8, v5}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 168
    iget-object v1, v0, Lcom/lvteam/MainActivity;->btnLogin:Landroid/widget/TextView;

    sget-object v5, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v1, v5}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 169
    iget-object v1, v0, Lcom/lvteam/MainActivity;->btnLogin:Landroid/widget/TextView;

    const/16 v5, 0x11

    invoke-virtual {v1, v5}, Landroid/widget/TextView;->setGravity(I)V

    .line 170
    iget-object v1, v0, Lcom/lvteam/MainActivity;->btnLogin:Landroid/widget/TextView;

    invoke-virtual {v1, v4}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 171
    iget-object v1, v0, Lcom/lvteam/MainActivity;->btnLogin:Landroid/widget/TextView;

    const/4 v5, 0x1

    invoke-virtual {v1, v5}, Landroid/view/View;->setClickable(Z)V

    .line 172
    iget-object v1, v0, Lcom/lvteam/MainActivity;->btnLogin:Landroid/widget/TextView;

    invoke-virtual {v1, v5}, Landroid/view/View;->setFocusable(Z)V

    .line 173
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    .line 174
    const/16 v5, 0x32

    invoke-direct {v0, v5}, Lcom/lvteam/MainActivity;->dp(I)I

    move-result v5

    const/4 v8, -0x1

    invoke-direct {v1, v8, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 175
    .local v1, "btnLp":Landroid/widget/LinearLayout$LayoutParams;
    iget-object v5, v0, Lcom/lvteam/MainActivity;->btnLogin:Landroid/widget/TextView;

    invoke-virtual {v2, v5, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-direct {v0, v2}, Lcom/lvteam/MainActivity;->addGetKeyButton(Landroid/widget/LinearLayout;)V

    .line 177
    new-instance v5, Landroid/widget/TextView;

    invoke-direct {v5, v0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    iput-object v5, v0, Lcom/lvteam/MainActivity;->txtStatus:Landroid/widget/TextView;

    .line 178
    iget-object v5, v0, Lcom/lvteam/MainActivity;->txtStatus:Landroid/widget/TextView;

    const/16 v8, 0x11

    invoke-virtual {v5, v8}, Landroid/widget/TextView;->setGravity(I)V

    .line 179
    iget-object v5, v0, Lcom/lvteam/MainActivity;->txtStatus:Landroid/widget/TextView;

    const/high16 v8, 0x41500000    # 13.0f

    move-object/from16 v18, v1

    const/4 v1, 0x2

    .end local v1    # "btnLp":Landroid/widget/LinearLayout$LayoutParams;
    .local v18, "btnLp":Landroid/widget/LinearLayout$LayoutParams;
    invoke-virtual {v5, v1, v8}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 180
    iget-object v1, v0, Lcom/lvteam/MainActivity;->txtStatus:Landroid/widget/TextView;

    const/16 v5, 0x8

    invoke-virtual {v1, v5}, Landroid/view/View;->setVisibility(I)V

    .line 181
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v5, -0x1

    const/4 v8, -0x2

    invoke-direct {v1, v5, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 184
    .local v1, "statusLp":Landroid/widget/LinearLayout$LayoutParams;
    const/16 v5, 0xc

    invoke-direct {v0, v5}, Lcom/lvteam/MainActivity;->dp(I)I

    move-result v5

    iput v5, v1, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 185
    iget-object v5, v0, Lcom/lvteam/MainActivity;->txtStatus:Landroid/widget/TextView;

    invoke-virtual {v2, v5, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 187
    invoke-virtual {v7, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 188
    invoke-virtual {v6, v7, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 190
    new-instance v5, Landroid/widget/TextView;

    invoke-direct {v5, v0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 191
    .local v5, "ver":Landroid/widget/TextView;
    const-string v8, "v2.1"

    invoke-virtual {v5, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 192
    const v8, -0x777756

    invoke-virtual {v5, v8}, Landroid/widget/TextView;->setTextColor(I)V

    .line 193
    const/high16 v8, 0x41400000    # 12.0f

    move-object/from16 v17, v1

    const/4 v1, 0x2

    .end local v1    # "statusLp":Landroid/widget/LinearLayout$LayoutParams;
    .local v17, "statusLp":Landroid/widget/LinearLayout$LayoutParams;
    invoke-virtual {v5, v1, v8}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 194
    new-instance v1, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v8, -0x2

    invoke-direct {v1, v8, v8}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    .line 197
    .local v1, "verLp":Landroid/widget/FrameLayout$LayoutParams;
    const/16 v8, 0x51

    iput v8, v1, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    .line 198
    iput v3, v1, Landroid/widget/FrameLayout$LayoutParams;->bottomMargin:I

    .line 199
    invoke-virtual {v6, v5, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 201
    invoke-virtual {v0, v6}, Landroid/app/Activity;->setContentView(Landroid/view/View;)V

    .line 203
    const-string v8, "lv_auth"

    move-object/from16 v19, v1

    const/4 v1, 0x0

    .end local v1    # "verLp":Landroid/widget/FrameLayout$LayoutParams;
    .local v19, "verLp":Landroid/widget/FrameLayout$LayoutParams;
    invoke-virtual {v0, v8, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v8

    iput-object v8, v0, Lcom/lvteam/MainActivity;->prefs:Landroid/content/SharedPreferences;

    .line 205
    iget-object v8, v0, Lcom/lvteam/MainActivity;->btnLogin:Landroid/widget/TextView;

    invoke-virtual {v8, v1}, Landroid/widget/TextView;->setEnabled(Z)V

    .line 206
    iget-object v1, v0, Lcom/lvteam/MainActivity;->btnLogin:Landroid/widget/TextView;

    const-string v8, "VERIFICANDO..."

    invoke-virtual {v1, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 207
    const/16 v1, -0x44cd

    const-string v8, "Iniciando..."

    invoke-direct {v0, v1, v8}, Lcom/lvteam/MainActivity;->showStatus(ILjava/lang/String;)V

    .line 209
    new-instance v1, Lcom/lvteam/MainActivity$$ExternalSyntheticLambda1;

    invoke-direct {v1, v0}, Lcom/lvteam/MainActivity$$ExternalSyntheticLambda1;-><init>(Lcom/lvteam/MainActivity;)V

    invoke-static {v0, v1}, Lcom/lvteam/LvUpdateChecker;->check(Landroid/app/Activity;Lcom/lvteam/LvUpdateChecker$Callback;)V

    .line 243
    return-void
.end method

.method public onResume()V
    .locals 1

    .line 247
    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    .line 248
    iget-boolean v0, p0, Lcom/lvteam/MainActivity;->waitingForOverlayPermission:Z

    if-eqz v0, :cond_0

    invoke-static {p0}, Landroid/provider/Settings;->canDrawOverlays(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-direct {p0}, Lcom/lvteam/MainActivity;->requestVpn()V

    .line 249
    :cond_0
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/lvteam/MainActivity;->waitingForOverlayPermission:Z

    .line 250
    return-void
.end method
