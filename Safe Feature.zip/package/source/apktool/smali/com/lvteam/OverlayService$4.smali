.class public Lcom/lvteam/OverlayService$4;
.super Ljava/lang/Object;
.source "OverlayService.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/lvteam/OverlayService;->startSessionCheck()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic this$0:Lcom/lvteam/OverlayService;


# direct methods
.method public constructor <init>(Lcom/lvteam/OverlayService;)V
    .locals 0
    .param p1, "this$0"    # Lcom/lvteam/OverlayService;

    .line 1262
    iput-object p1, p0, Lcom/lvteam/OverlayService$4;->this$0:Lcom/lvteam/OverlayService;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 1265
    invoke-static {}, Lcom/lvteam/LvSession;->get()Lcom/lvteam/LvSession;

    move-result-object v0

    invoke-virtual {v0}, Lcom/lvteam/LvSession;->isActive()Z

    move-result v0

    if-nez v0, :cond_0

    .line 1266
    iget-object v0, p0, Lcom/lvteam/OverlayService$4;->this$0:Lcom/lvteam/OverlayService;

    const-string v1, "Sessao expirada."

    invoke-static {v0, v1}, Lcom/lvteam/OverlayService;->-$$Nest$mkillApp(Lcom/lvteam/OverlayService;Ljava/lang/String;)V

    .line 1267
    return-void

    .line 1270
    :cond_0
    :try_start_0
    invoke-static {}, Lcom/lvteam/NativeGuard;->pulse()I

    move-result v0

    .line 1271
    .local v0, "bits":I
    if-eqz v0, :cond_1

    .line 1272
    invoke-static {}, Lcom/lvteam/LvSession;->get()Lcom/lvteam/LvSession;

    move-result-object v1

    invoke-virtual {v1}, Lcom/lvteam/LvSession;->invalidate()V

    .line 1273
    iget-object v1, p0, Lcom/lvteam/OverlayService$4;->this$0:Lcom/lvteam/OverlayService;

    const-string v2, "Sessao encerrada."

    invoke-static {v1, v2}, Lcom/lvteam/OverlayService;->-$$Nest$mkillApp(Lcom/lvteam/OverlayService;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/UnsatisfiedLinkError; {:try_start_0 .. :try_end_0} :catch_0

    .line 1274
    return-void

    .line 1276
    .end local v0    # "bits":I
    :catch_0
    move-exception v0

    goto :goto_0

    .line 1271
    .restart local v0    # "bits":I
    :cond_1
    nop

    .line 1276
    .end local v0    # "bits":I
    :goto_0
    nop

    .line 1277
    iget-object v0, p0, Lcom/lvteam/OverlayService$4;->this$0:Lcom/lvteam/OverlayService;

    invoke-static {v0}, Lcom/lvteam/OverlayService;->-$$Nest$fgetsessionCheckHandler(Lcom/lvteam/OverlayService;)Landroid/os/Handler;

    move-result-object v0

    if-eqz v0, :cond_2

    .line 1278
    iget-object v0, p0, Lcom/lvteam/OverlayService$4;->this$0:Lcom/lvteam/OverlayService;

    invoke-static {v0}, Lcom/lvteam/OverlayService;->-$$Nest$fgetsessionCheckHandler(Lcom/lvteam/OverlayService;)Landroid/os/Handler;

    move-result-object v0

    const-wide/32 v1, 0x1d4c0

    invoke-virtual {v0, p0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 1279
    :cond_2
    return-void
.end method
