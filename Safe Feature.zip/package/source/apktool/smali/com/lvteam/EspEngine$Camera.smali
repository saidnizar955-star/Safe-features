.class public final Lcom/lvteam/EspEngine$Camera;
.super Ljava/lang/Object;
.source "EspEngine.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/lvteam/EspEngine;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Camera"
.end annotation


# instance fields
.field public final forwardX:F

.field public final forwardY:F

.field public final forwardZ:F

.field public final rightX:F

.field public final rightY:F

.field public final rightZ:F

.field public final verticalFov:F

.field public final x:F

.field public final y:F

.field public final z:F


# direct methods
.method public constructor <init>(FFFFFFF)V
    .locals 5
    .param p1, "x"    # F
    .param p2, "y"    # F
    .param p3, "z"    # F
    .param p4, "forwardX"    # F
    .param p5, "forwardY"    # F
    .param p6, "forwardZ"    # F
    .param p7, "verticalFov"    # F

    .line 166
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 167
    iput p1, p0, Lcom/lvteam/EspEngine$Camera;->x:F

    iput p2, p0, Lcom/lvteam/EspEngine$Camera;->y:F

    iput p3, p0, Lcom/lvteam/EspEngine$Camera;->z:F

    .line 168
    mul-float v0, p4, p4

    mul-float v1, p5, p5

    add-float/2addr v0, v1

    mul-float v1, p6, p6

    add-float/2addr v0, v1

    float-to-double v0, v0

    invoke-static {v0, v1}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v0

    double-to-float v0, v0

    .line 169
    .local v0, "length":F
    const v1, 0x38d1b717    # 1.0E-4f

    invoke-static {v0, v1}, Ljava/lang/Math;->max(FF)F

    move-result v2

    div-float v2, p4, v2

    iput v2, p0, Lcom/lvteam/EspEngine$Camera;->forwardX:F

    .line 170
    invoke-static {v0, v1}, Ljava/lang/Math;->max(FF)F

    move-result v2

    div-float v2, p5, v2

    iput v2, p0, Lcom/lvteam/EspEngine$Camera;->forwardY:F

    .line 171
    invoke-static {v0, v1}, Ljava/lang/Math;->max(FF)F

    move-result v2

    div-float v2, p6, v2

    iput v2, p0, Lcom/lvteam/EspEngine$Camera;->forwardZ:F

    .line 172
    iget v2, p0, Lcom/lvteam/EspEngine$Camera;->forwardX:F

    iget v3, p0, Lcom/lvteam/EspEngine$Camera;->forwardX:F

    mul-float/2addr v2, v3

    iget v3, p0, Lcom/lvteam/EspEngine$Camera;->forwardZ:F

    iget v4, p0, Lcom/lvteam/EspEngine$Camera;->forwardZ:F

    mul-float/2addr v3, v4

    add-float/2addr v2, v3

    float-to-double v2, v2

    invoke-static {v2, v3}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v2

    double-to-float v2, v2

    .line 173
    .local v2, "rightLength":F
    iget v3, p0, Lcom/lvteam/EspEngine$Camera;->forwardZ:F

    invoke-static {v2, v1}, Ljava/lang/Math;->max(FF)F

    move-result v4

    div-float/2addr v3, v4

    iput v3, p0, Lcom/lvteam/EspEngine$Camera;->rightX:F

    .line 174
    const/4 v3, 0x0

    iput v3, p0, Lcom/lvteam/EspEngine$Camera;->rightY:F

    .line 175
    iget v3, p0, Lcom/lvteam/EspEngine$Camera;->forwardX:F

    neg-float v3, v3

    invoke-static {v2, v1}, Ljava/lang/Math;->max(FF)F

    move-result v1

    div-float/2addr v3, v1

    iput v3, p0, Lcom/lvteam/EspEngine$Camera;->rightZ:F

    .line 176
    const/high16 v1, 0x43160000    # 150.0f

    invoke-static {v1, p7}, Ljava/lang/Math;->min(FF)F

    move-result v1

    const/high16 v3, 0x41700000    # 15.0f

    invoke-static {v3, v1}, Ljava/lang/Math;->max(FF)F

    move-result v1

    iput v1, p0, Lcom/lvteam/EspEngine$Camera;->verticalFov:F

    .line 177
    return-void
.end method


# virtual methods
.method public distanceTo(FFF)F
    .locals 5
    .param p1, "targetX"    # F
    .param p2, "targetY"    # F
    .param p3, "targetZ"    # F

    .line 192
    iget v0, p0, Lcom/lvteam/EspEngine$Camera;->x:F

    sub-float v0, p1, v0

    .local v0, "dx":F
    iget v1, p0, Lcom/lvteam/EspEngine$Camera;->y:F

    sub-float v1, p2, v1

    .local v1, "dy":F
    iget v2, p0, Lcom/lvteam/EspEngine$Camera;->z:F

    sub-float v2, p3, v2

    .line 193
    .local v2, "dz":F
    mul-float v3, v0, v0

    mul-float v4, v1, v1

    add-float/2addr v3, v4

    mul-float v4, v2, v2

    add-float/2addr v3, v4

    float-to-double v3, v3

    invoke-static {v3, v4}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v3

    double-to-float v3, v3

    return v3
.end method

.method public project(FFFIIFF)Lcom/lvteam/EspEngine$ScreenPoint;
    .locals 16
    .param p1, "worldX"    # F
    .param p2, "worldY"    # F
    .param p3, "worldZ"    # F
    .param p4, "width"    # I
    .param p5, "height"    # I
    .param p6, "focal"    # F
    .param p7, "aspect"    # F

    .line 180
    move-object/from16 v0, p0

    iget v1, v0, Lcom/lvteam/EspEngine$Camera;->x:F

    sub-float v1, p1, v1

    .local v1, "dx":F
    iget v2, v0, Lcom/lvteam/EspEngine$Camera;->y:F

    sub-float v2, p2, v2

    .local v2, "dy":F
    iget v3, v0, Lcom/lvteam/EspEngine$Camera;->z:F

    sub-float v3, p3, v3

    .line 181
    .local v3, "dz":F
    iget v4, v0, Lcom/lvteam/EspEngine$Camera;->forwardX:F

    mul-float/2addr v4, v1

    iget v5, v0, Lcom/lvteam/EspEngine$Camera;->forwardY:F

    mul-float/2addr v5, v2

    add-float/2addr v4, v5

    iget v5, v0, Lcom/lvteam/EspEngine$Camera;->forwardZ:F

    mul-float/2addr v5, v3

    add-float/2addr v4, v5

    .line 182
    .local v4, "depth":F
    const v5, 0x3d4ccccd    # 0.05f

    cmpg-float v5, v4, v5

    if-gtz v5, :cond_0

    const/4 v5, 0x0

    return-object v5

    .line 183
    :cond_0
    iget v5, v0, Lcom/lvteam/EspEngine$Camera;->rightX:F

    mul-float/2addr v5, v1

    iget v6, v0, Lcom/lvteam/EspEngine$Camera;->rightY:F

    mul-float/2addr v6, v2

    add-float/2addr v5, v6

    iget v6, v0, Lcom/lvteam/EspEngine$Camera;->rightZ:F

    mul-float/2addr v6, v3

    add-float/2addr v5, v6

    .line 184
    .local v5, "side":F
    iget v6, v0, Lcom/lvteam/EspEngine$Camera;->forwardY:F

    iget v7, v0, Lcom/lvteam/EspEngine$Camera;->rightZ:F

    mul-float/2addr v6, v7

    iget v7, v0, Lcom/lvteam/EspEngine$Camera;->forwardZ:F

    iget v8, v0, Lcom/lvteam/EspEngine$Camera;->rightY:F

    mul-float/2addr v7, v8

    sub-float/2addr v6, v7

    .line 185
    .local v6, "upX":F
    iget v7, v0, Lcom/lvteam/EspEngine$Camera;->forwardZ:F

    iget v8, v0, Lcom/lvteam/EspEngine$Camera;->rightX:F

    mul-float/2addr v7, v8

    iget v8, v0, Lcom/lvteam/EspEngine$Camera;->forwardX:F

    iget v9, v0, Lcom/lvteam/EspEngine$Camera;->rightZ:F

    mul-float/2addr v8, v9

    sub-float/2addr v7, v8

    .line 186
    .local v7, "upY":F
    iget v8, v0, Lcom/lvteam/EspEngine$Camera;->forwardX:F

    iget v9, v0, Lcom/lvteam/EspEngine$Camera;->rightY:F

    mul-float/2addr v8, v9

    iget v9, v0, Lcom/lvteam/EspEngine$Camera;->forwardY:F

    iget v10, v0, Lcom/lvteam/EspEngine$Camera;->rightX:F

    mul-float/2addr v9, v10

    sub-float/2addr v8, v9

    .line 187
    .local v8, "upZ":F
    mul-float v9, v1, v6

    mul-float v10, v2, v7

    add-float/2addr v9, v10

    mul-float v10, v3, v8

    add-float/2addr v9, v10

    .line 188
    .local v9, "up":F
    new-instance v10, Lcom/lvteam/EspEngine$ScreenPoint;

    move/from16 v11, p4

    int-to-float v12, v11

    const/high16 v13, 0x40000000    # 2.0f

    div-float/2addr v12, v13

    mul-float v14, v5, p6

    div-float/2addr v14, v4

    add-float/2addr v12, v14

    move/from16 v14, p5

    int-to-float v15, v14

    div-float/2addr v15, v13

    mul-float v13, v9, p6

    div-float/2addr v13, v4

    sub-float/2addr v15, v13

    invoke-direct {v10, v12, v15}, Lcom/lvteam/EspEngine$ScreenPoint;-><init>(FF)V

    return-object v10
.end method
