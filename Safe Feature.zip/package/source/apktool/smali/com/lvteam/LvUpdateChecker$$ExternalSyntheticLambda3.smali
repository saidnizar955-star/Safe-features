.class public final synthetic Lcom/lvteam/LvUpdateChecker$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field public final synthetic f$0:Landroid/app/Activity;


# direct methods
.method public synthetic constructor <init>(Landroid/app/Activity;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/lvteam/LvUpdateChecker$$ExternalSyntheticLambda3;->f$0:Landroid/app/Activity;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/lvteam/LvUpdateChecker$$ExternalSyntheticLambda3;->f$0:Landroid/app/Activity;

    invoke-static {v0, p1, p2}, Lcom/lvteam/LvUpdateChecker;->$r8$lambda$0YoxoJllgPyau1-YCb3SjaQqiEk(Landroid/app/Activity;Landroid/content/DialogInterface;I)V

    return-void
.end method
