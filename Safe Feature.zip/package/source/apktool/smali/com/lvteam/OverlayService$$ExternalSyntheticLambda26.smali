.class public final synthetic Lcom/lvteam/OverlayService$$ExternalSyntheticLambda26;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# direct methods
.method public synthetic constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 0

    .line 0
    invoke-static {}, Lcom/lvteam/OverlayService;->$r8$lambda$TyS14aa87qU2_QsJ_o3fPoV5a4k()V

    return-void
.end method
