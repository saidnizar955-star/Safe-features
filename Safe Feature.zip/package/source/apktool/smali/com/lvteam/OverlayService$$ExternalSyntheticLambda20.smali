.class public final synthetic Lcom/lvteam/OverlayService$$ExternalSyntheticLambda20;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:Lcom/lvteam/OverlayService;

.field public final synthetic f$1:I

.field public final synthetic f$2:Landroid/graphics/drawable/GradientDrawable;


# direct methods
.method public synthetic constructor <init>(Lcom/lvteam/OverlayService;ILandroid/graphics/drawable/GradientDrawable;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda20;->f$0:Lcom/lvteam/OverlayService;

    iput p2, p0, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda20;->f$1:I

    iput-object p3, p0, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda20;->f$2:Landroid/graphics/drawable/GradientDrawable;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda20;->f$0:Lcom/lvteam/OverlayService;

    iget v1, p0, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda20;->f$1:I

    iget-object v2, p0, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda20;->f$2:Landroid/graphics/drawable/GradientDrawable;

    invoke-static {v0, v1, v2, p1}, Lcom/lvteam/OverlayService;->$r8$lambda$s1bJGMdopGfHHR09io1fN343nbU(Lcom/lvteam/OverlayService;ILandroid/graphics/drawable/GradientDrawable;Landroid/view/View;)V

    return-void
.end method
