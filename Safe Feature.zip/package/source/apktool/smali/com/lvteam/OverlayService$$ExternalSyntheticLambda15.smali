.class public final synthetic Lcom/lvteam/OverlayService$$ExternalSyntheticLambda15;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:Lcom/lvteam/OverlayService;

.field public final synthetic f$1:I


# direct methods
.method public synthetic constructor <init>(Lcom/lvteam/OverlayService;I)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda15;->f$0:Lcom/lvteam/OverlayService;

    iput p2, p0, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda15;->f$1:I

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda15;->f$0:Lcom/lvteam/OverlayService;

    iget v1, p0, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda15;->f$1:I

    invoke-static {v0, v1, p1}, Lcom/lvteam/OverlayService;->$r8$lambda$YGaolynwQit2uwJWQV-IF5f5dDs(Lcom/lvteam/OverlayService;ILandroid/view/View;)V

    return-void
.end method
