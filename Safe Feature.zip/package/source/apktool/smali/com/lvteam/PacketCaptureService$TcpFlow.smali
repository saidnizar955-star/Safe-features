.class public final Lcom/lvteam/PacketCaptureService$TcpFlow;
.super Ljava/lang/Object;
.source "PacketCaptureService.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/lvteam/PacketCaptureService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x11
    name = "TcpFlow"
.end annotation


# instance fields
.field public clientFinReceived:Z

.field public clientNextSequence:J

.field public volatile closed:Z

.field public closingFuture:Ljava/util/concurrent/ScheduledFuture;

.field public connected:Z

.field public handshakeAcknowledged:Z

.field public final initialClientSequence:J

.field public final initialServerSequence:J

.field public final key:Lcom/lvteam/PacketCaptureService$FlowKey;

.field public volatile lastActivityMillis:J

.field public final pendingPayload:Ljava/util/ArrayDeque;

.field public pendingPayloadBytes:I

.field public remoteFinSent:Z

.field public serverNextSequence:J

.field public final socket:Ljava/net/Socket;

.field public synAckSent:Z

.field public final synthetic this$0:Lcom/lvteam/PacketCaptureService;


# direct methods
.method public static synthetic $r8$lambda$4t-jINYqvDL3FQY8N1o0okRsSF8(Lcom/lvteam/PacketCaptureService$TcpFlow;)V
    .locals 0

    .line 0
    invoke-virtual {p0}, Lcom/lvteam/PacketCaptureService$TcpFlow;->lambda$emitRemoteFin$1()V

    return-void
.end method

.method public static synthetic $r8$lambda$bf1912WEVFogDhVOFZ0IRmgG2n8(Lcom/lvteam/PacketCaptureService$TcpFlow;)V
    .locals 0

    .line 0
    invoke-virtual {p0}, Lcom/lvteam/PacketCaptureService$TcpFlow;->lambda$removeAndClose$0()V

    return-void
.end method

.method public static bridge synthetic -$$Nest$fgetkey(Lcom/lvteam/PacketCaptureService$TcpFlow;)Lcom/lvteam/PacketCaptureService$FlowKey;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->key:Lcom/lvteam/PacketCaptureService$FlowKey;

    return-object p0
.end method

.method public static bridge synthetic -$$Nest$fgetlastActivityMillis(Lcom/lvteam/PacketCaptureService$TcpFlow;)J
    .locals 2

    .line 0
    iget-wide v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->lastActivityMillis:J

    return-wide v0
.end method

.method public static bridge synthetic -$$Nest$memitSynAck(Lcom/lvteam/PacketCaptureService$TcpFlow;)V
    .locals 0

    .line 0
    invoke-virtual {p0}, Lcom/lvteam/PacketCaptureService$TcpFlow;->emitSynAck()V

    return-void
.end method

.method public static bridge synthetic -$$Nest$mremoveAndClose(Lcom/lvteam/PacketCaptureService$TcpFlow;)V
    .locals 0

    .line 0
    invoke-virtual {p0}, Lcom/lvteam/PacketCaptureService$TcpFlow;->removeAndClose()V

    return-void
.end method

.method public constructor <init>(Lcom/lvteam/PacketCaptureService;Lcom/lvteam/PacketCaptureService$FlowKey;Ljava/net/Socket;J)V
    .locals 4
    .param p2, "key"    # Lcom/lvteam/PacketCaptureService$FlowKey;
    .param p3, "socket"    # Ljava/net/Socket;
    .param p4, "clientSequence"    # J

    .line 565
    iput-object p1, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->this$0:Lcom/lvteam/PacketCaptureService;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 552
    new-instance p1, Ljava/util/ArrayDeque;

    invoke-direct {p1}, Ljava/util/ArrayDeque;-><init>()V

    iput-object p1, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->pendingPayload:Ljava/util/ArrayDeque;

    .line 566
    iput-object p2, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->key:Lcom/lvteam/PacketCaptureService$FlowKey;

    .line 567
    iput-object p3, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->socket:Ljava/net/Socket;

    .line 568
    iput-wide p4, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->initialClientSequence:J

    .line 569
    const/4 p1, 0x1

    invoke-static {p4, p5, p1}, Lcom/lvteam/PacketCaptureService;->-$$Nest$smincrement(JI)J

    move-result-wide v0

    iput-wide v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->clientNextSequence:J

    .line 570
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v0

    const-wide v2, 0xffffffffL

    and-long/2addr v0, v2

    iput-wide v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->serverNextSequence:J

    .line 571
    iget-wide v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->serverNextSequence:J

    iput-wide v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->initialServerSequence:J

    .line 572
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    iput-wide v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->lastActivityMillis:J

    .line 573
    return-void
.end method


# virtual methods
.method public close()V
    .locals 2

    .line 732
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->closed:Z

    .line 733
    iget-object v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->closingFuture:Ljava/util/concurrent/ScheduledFuture;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->closingFuture:Ljava/util/concurrent/ScheduledFuture;

    const/4 v1, 0x0

    invoke-interface {v0, v1}, Ljava/util/concurrent/Future;->cancel(Z)Z

    .line 734
    :cond_0
    iget-object v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->socket:Ljava/net/Socket;

    invoke-static {v0}, Lcom/lvteam/PacketCaptureService;->-$$Nest$smcloseQuietly(Ljava/io/Closeable;)V

    .line 735
    return-void
.end method

.method public final emit(I[B)V
    .locals 6
    .param p1, "flags"    # I
    .param p2, "payload"    # [B

    .line 709
    iget-wide v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->serverNextSequence:J

    .line 710
    .local v0, "sequence":J
    invoke-virtual {p0, v0, v1, p1, p2}, Lcom/lvteam/PacketCaptureService$TcpFlow;->writeResponse(JI[B)Z

    move-result v2

    if-nez v2, :cond_0

    return-void

    .line 711
    :cond_0
    and-int/lit8 v2, p1, 0x2

    const/4 v3, 0x1

    if-eqz v2, :cond_1

    iget-wide v4, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->serverNextSequence:J

    invoke-static {v4, v5, v3}, Lcom/lvteam/PacketCaptureService;->-$$Nest$smincrement(JI)J

    move-result-wide v4

    iput-wide v4, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->serverNextSequence:J

    .line 712
    :cond_1
    and-int/lit8 v2, p1, 0x1

    if-eqz v2, :cond_2

    iget-wide v4, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->serverNextSequence:J

    invoke-static {v4, v5, v3}, Lcom/lvteam/PacketCaptureService;->-$$Nest$smincrement(JI)J

    move-result-wide v2

    iput-wide v2, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->serverNextSequence:J

    .line 713
    :cond_2
    iget-wide v2, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->serverNextSequence:J

    array-length v4, p2

    invoke-static {v2, v3, v4}, Lcom/lvteam/PacketCaptureService;->-$$Nest$smincrement(JI)J

    move-result-wide v2

    iput-wide v2, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->serverNextSequence:J

    .line 714
    return-void
.end method

.method public final emitRemoteFin()V
    .locals 5

    .line 807
    iget-boolean v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->remoteFinSent:Z

    if-eqz v0, :cond_0

    return-void

    .line 808
    :cond_0
    const/4 v0, 0x0

    new-array v0, v0, [B

    const/16 v1, 0x11

    invoke-virtual {p0, v1, v0}, Lcom/lvteam/PacketCaptureService$TcpFlow;->emit(I[B)V

    .line 809
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->remoteFinSent:Z

    .line 810
    iget-object v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->this$0:Lcom/lvteam/PacketCaptureService;

    invoke-static {v0}, Lcom/lvteam/PacketCaptureService;->-$$Nest$fgetstartupWatchdog(Lcom/lvteam/PacketCaptureService;)Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object v0

    new-instance v1, Lcom/lvteam/PacketCaptureService$TcpFlow$$ExternalSyntheticLambda1;

    invoke-direct {v1, p0}, Lcom/lvteam/PacketCaptureService$TcpFlow$$ExternalSyntheticLambda1;-><init>(Lcom/lvteam/PacketCaptureService$TcpFlow;)V

    const-wide/16 v2, 0x2710

    sget-object v4, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-interface {v0, v1, v2, v3, v4}, Ljava/util/concurrent/ScheduledExecutorService;->schedule(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;

    move-result-object v0

    iput-object v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->closingFuture:Ljava/util/concurrent/ScheduledFuture;

    .line 815
    return-void
.end method

.method public final emitReset()V
    .locals 5

    .line 700
    iget-boolean v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->synAckSent:Z

    const/4 v1, 0x0

    const/16 v2, 0x14

    if-eqz v0, :cond_0

    .line 701
    new-array v0, v1, [B

    invoke-virtual {p0, v2, v0}, Lcom/lvteam/PacketCaptureService$TcpFlow;->emit(I[B)V

    goto :goto_0

    .line 704
    :cond_0
    const-wide/16 v3, 0x0

    new-array v0, v1, [B

    invoke-virtual {p0, v3, v4, v2, v0}, Lcom/lvteam/PacketCaptureService$TcpFlow;->writeResponse(JI[B)Z

    .line 706
    :goto_0
    return-void
.end method

.method public final emitSynAck()V
    .locals 4

    .line 692
    iget-wide v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->initialServerSequence:J

    const/4 v2, 0x0

    new-array v2, v2, [B

    const/16 v3, 0x12

    invoke-virtual {p0, v0, v1, v3, v2}, Lcom/lvteam/PacketCaptureService$TcpFlow;->writeResponse(JI[B)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-boolean v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->synAckSent:Z

    if-nez v0, :cond_0

    .line 694
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->synAckSent:Z

    .line 695
    iget-wide v1, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->serverNextSequence:J

    invoke-static {v1, v2, v0}, Lcom/lvteam/PacketCaptureService;->-$$Nest$smincrement(JI)J

    move-result-wide v0

    iput-wide v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->serverNextSequence:J

    .line 697
    :cond_0
    return-void
.end method

.method public final flushPendingData()Z
    .locals 3

    .line 783
    const/4 v0, 0x0

    :try_start_0
    iget-object v1, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->socket:Ljava/net/Socket;

    invoke-virtual {v1}, Ljava/net/Socket;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v1

    .line 784
    .local v1, "output":Ljava/io/OutputStream;
    :goto_0
    iget-object v2, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->pendingPayload:Ljava/util/ArrayDeque;

    invoke-virtual {v2}, Ljava/util/ArrayDeque;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_0

    iget-object v2, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->pendingPayload:Ljava/util/ArrayDeque;

    invoke-virtual {v2}, Ljava/util/ArrayDeque;->remove()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, [B

    invoke-virtual {v1, v2}, Ljava/io/OutputStream;->write([B)V

    goto :goto_0

    .line 788
    .end local v1    # "output":Ljava/io/OutputStream;
    :catch_0
    move-exception v1

    goto :goto_1

    :catch_1
    move-exception v1

    goto :goto_1

    .line 785
    .restart local v1    # "output":Ljava/io/OutputStream;
    :cond_0
    iput v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->pendingPayloadBytes:I

    .line 786
    invoke-virtual {v1}, Ljava/io/OutputStream;->flush()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    .line 787
    const/4 v0, 0x1

    return v0

    .line 788
    .end local v1    # "output":Ljava/io/OutputStream;
    :goto_1
    nop

    .line 789
    .local v1, "e":Ljava/lang/Exception;
    invoke-virtual {p0}, Lcom/lvteam/PacketCaptureService$TcpFlow;->emitReset()V

    .line 790
    invoke-virtual {p0}, Lcom/lvteam/PacketCaptureService$TcpFlow;->removeAndClose()V

    .line 791
    return v0
.end method

.method public handle(Lcom/lvteam/Ipv4TcpPacket;)V
    .locals 7
    .param p1, "packet"    # Lcom/lvteam/Ipv4TcpPacket;

    .line 576
    monitor-enter p0

    .line 577
    :try_start_0
    iget-boolean v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->closed:Z

    if-eqz v0, :cond_0

    monitor-exit p0

    return-void

    .line 616
    :catchall_0
    move-exception v0

    goto/16 :goto_5

    .line 578
    :cond_0
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    iput-wide v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->lastActivityMillis:J

    .line 579
    iget v0, p1, Lcom/lvteam/Ipv4TcpPacket;->flags:I

    and-int/lit8 v0, v0, 0x4

    if-eqz v0, :cond_1

    .line 580
    invoke-virtual {p0}, Lcom/lvteam/PacketCaptureService$TcpFlow;->removeAndClose()V

    .line 581
    monitor-exit p0

    return-void

    .line 583
    :cond_1
    iget v0, p1, Lcom/lvteam/Ipv4TcpPacket;->flags:I

    and-int/lit8 v0, v0, 0x2

    if-eqz v0, :cond_3

    .line 584
    iget-wide v0, p1, Lcom/lvteam/Ipv4TcpPacket;->sequenceNumber:J

    iget-wide v2, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->initialClientSequence:J

    cmp-long v0, v0, v2

    if-nez v0, :cond_2

    invoke-virtual {p0}, Lcom/lvteam/PacketCaptureService$TcpFlow;->emitSynAck()V

    .line 585
    :cond_2
    monitor-exit p0

    return-void

    .line 587
    :cond_3
    iget v0, p1, Lcom/lvteam/Ipv4TcpPacket;->flags:I

    const/16 v1, 0x10

    and-int/2addr v0, v1

    if-eqz v0, :cond_10

    iget-wide v2, p1, Lcom/lvteam/Ipv4TcpPacket;->acknowledgementNumber:J

    iget-wide v4, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->serverNextSequence:J

    .line 588
    invoke-static {v2, v3, v4, v5}, Lcom/lvteam/PacketCaptureService;->-$$Nest$smisAfter(JJ)Z

    move-result v0

    if-eqz v0, :cond_4

    goto/16 :goto_4

    .line 589
    :cond_4
    iget-boolean v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->handshakeAcknowledged:Z

    const/4 v2, 0x1

    if-nez v0, :cond_7

    .line 590
    iget-wide v3, p1, Lcom/lvteam/Ipv4TcpPacket;->acknowledgementNumber:J

    iget-wide v5, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->serverNextSequence:J

    cmp-long v0, v3, v5

    if-nez v0, :cond_5

    iget-wide v3, p1, Lcom/lvteam/Ipv4TcpPacket;->sequenceNumber:J

    iget-wide v5, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->clientNextSequence:J

    cmp-long v0, v3, v5

    if-eqz v0, :cond_6

    :cond_5
    goto :goto_0

    .line 592
    :cond_6
    iput-boolean v2, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->handshakeAcknowledged:Z

    goto :goto_1

    .line 591
    :goto_0
    monitor-exit p0

    return-void

    .line 594
    :cond_7
    :goto_1
    iget-boolean v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->remoteFinSent:Z

    if-eqz v0, :cond_8

    iget-wide v3, p1, Lcom/lvteam/Ipv4TcpPacket;->acknowledgementNumber:J

    iget-wide v5, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->serverNextSequence:J

    cmp-long v0, v3, v5

    if-nez v0, :cond_8

    .line 595
    invoke-virtual {p0}, Lcom/lvteam/PacketCaptureService$TcpFlow;->removeAndClose()V

    .line 596
    monitor-exit p0

    return-void

    .line 598
    :cond_8
    iget-wide v3, p1, Lcom/lvteam/Ipv4TcpPacket;->sequenceNumber:J

    iget-wide v5, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->clientNextSequence:J

    cmp-long v0, v3, v5

    const/4 v3, 0x0

    if-eqz v0, :cond_9

    .line 599
    new-array v0, v3, [B

    invoke-virtual {p0, v1, v0}, Lcom/lvteam/PacketCaptureService$TcpFlow;->emit(I[B)V

    .line 600
    monitor-exit p0

    return-void

    .line 602
    :cond_9
    iget-object v0, p1, Lcom/lvteam/Ipv4TcpPacket;->payload:[B

    array-length v0, v0

    if-lez v0, :cond_c

    .line 604
    iget-object v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->this$0:Lcom/lvteam/PacketCaptureService;

    invoke-static {v0}, Lcom/lvteam/PacketCaptureService;->-$$Nest$fgetframeDecoder(Lcom/lvteam/PacketCaptureService;)Lcom/lvteam/RawFrameDecoder;

    move-result-object v0

    iget-object v4, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->key:Lcom/lvteam/PacketCaptureService$FlowKey;

    iget-object v5, p1, Lcom/lvteam/Ipv4TcpPacket;->payload:[B

    iget-object v6, p1, Lcom/lvteam/Ipv4TcpPacket;->payload:[B

    array-length v6, v6

    invoke-virtual {v0, v4, v5, v6}, Lcom/lvteam/RawFrameDecoder;->acceptTcpPayload(Lcom/lvteam/PacketCaptureService$FlowKey;[BI)V

    .line 605
    iget-boolean v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->clientFinReceived:Z

    if-nez v0, :cond_a

    iget-object v0, p1, Lcom/lvteam/Ipv4TcpPacket;->payload:[B

    invoke-virtual {p0, v0}, Lcom/lvteam/PacketCaptureService$TcpFlow;->queueOrWrite([B)Z

    move-result v0

    if-nez v0, :cond_b

    :cond_a
    goto :goto_2

    .line 606
    :cond_b
    iget-wide v4, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->clientNextSequence:J

    iget-object v0, p1, Lcom/lvteam/Ipv4TcpPacket;->payload:[B

    array-length v0, v0

    invoke-static {v4, v5, v0}, Lcom/lvteam/PacketCaptureService;->-$$Nest$smincrement(JI)J

    move-result-wide v4

    iput-wide v4, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->clientNextSequence:J

    goto :goto_3

    .line 605
    :goto_2
    monitor-exit p0

    return-void

    .line 608
    :cond_c
    :goto_3
    iget v0, p1, Lcom/lvteam/Ipv4TcpPacket;->flags:I

    and-int/2addr v0, v2

    if-eqz v0, :cond_d

    iget-boolean v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->clientFinReceived:Z

    if-nez v0, :cond_d

    .line 609
    iput-boolean v2, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->clientFinReceived:Z

    .line 610
    iget-wide v4, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->clientNextSequence:J

    invoke-static {v4, v5, v2}, Lcom/lvteam/PacketCaptureService;->-$$Nest$smincrement(JI)J

    move-result-wide v4

    iput-wide v4, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->clientNextSequence:J

    .line 611
    iget-boolean v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->connected:Z

    if-eqz v0, :cond_d

    invoke-virtual {p0}, Lcom/lvteam/PacketCaptureService$TcpFlow;->shutdownOutput()Z

    move-result v0

    if-nez v0, :cond_d

    monitor-exit p0

    return-void

    .line 613
    :cond_d
    iget-object v0, p1, Lcom/lvteam/Ipv4TcpPacket;->payload:[B

    array-length v0, v0

    if-gtz v0, :cond_e

    iget v0, p1, Lcom/lvteam/Ipv4TcpPacket;->flags:I

    and-int/2addr v0, v2

    if-eqz v0, :cond_f

    .line 614
    :cond_e
    new-array v0, v3, [B

    invoke-virtual {p0, v1, v0}, Lcom/lvteam/PacketCaptureService$TcpFlow;->emit(I[B)V

    .line 616
    :cond_f
    monitor-exit p0

    .line 617
    return-void

    .line 588
    :cond_10
    :goto_4
    monitor-exit p0

    return-void

    .line 616
    :goto_5
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v0
.end method

.method public isClosed()Z
    .locals 1

    .line 688
    iget-boolean v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->closed:Z

    return v0
.end method

.method public isIdle(J)Z
    .locals 4
    .param p1, "now"    # J

    .line 684
    iget-wide v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->lastActivityMillis:J

    sub-long v0, p1, v0

    const-wide/32 v2, 0x493e0

    cmp-long v0, v0, v2

    if-ltz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final synthetic lambda$emitRemoteFin$1()V
    .locals 1

    .line 811
    monitor-enter p0

    .line 812
    :try_start_0
    iget-boolean v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->remoteFinSent:Z

    if-eqz v0, :cond_0

    iget-boolean v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->closed:Z

    if-nez v0, :cond_0

    invoke-virtual {p0}, Lcom/lvteam/PacketCaptureService$TcpFlow;->removeAndClose()V

    goto :goto_0

    .line 813
    :catchall_0
    move-exception v0

    goto :goto_1

    :cond_0
    :goto_0
    monitor-exit p0

    .line 814
    return-void

    .line 813
    :goto_1
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v0
.end method

.method public final synthetic lambda$removeAndClose$0()V
    .locals 3

    .line 748
    iget-object v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->this$0:Lcom/lvteam/PacketCaptureService;

    invoke-static {v0}, Lcom/lvteam/PacketCaptureService;->-$$Nest$fgetflowLock(Lcom/lvteam/PacketCaptureService;)Ljava/lang/Object;

    move-result-object v0

    monitor-enter v0

    .line 749
    :try_start_0
    iget-object v1, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->this$0:Lcom/lvteam/PacketCaptureService;

    invoke-static {v1}, Lcom/lvteam/PacketCaptureService;->-$$Nest$fgettcpFlows(Lcom/lvteam/PacketCaptureService;)Ljava/util/Map;

    move-result-object v1

    iget-object v2, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->key:Lcom/lvteam/PacketCaptureService$FlowKey;

    invoke-interface {v1, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    if-ne v1, p0, :cond_0

    iget-object v1, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->this$0:Lcom/lvteam/PacketCaptureService;

    invoke-static {v1}, Lcom/lvteam/PacketCaptureService;->-$$Nest$fgettcpFlows(Lcom/lvteam/PacketCaptureService;)Ljava/util/Map;

    move-result-object v1

    iget-object v2, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->key:Lcom/lvteam/PacketCaptureService$FlowKey;

    invoke-interface {v1, v2}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_0

    .line 750
    :catchall_0
    move-exception v1

    goto :goto_1

    :cond_0
    :goto_0
    monitor-exit v0

    .line 751
    return-void

    .line 750
    :goto_1
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v1
.end method

.method public final queueOrWrite([B)Z
    .locals 4
    .param p1, "payload"    # [B

    .line 758
    iget-boolean v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->connected:Z

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    .line 760
    :try_start_0
    iget-object v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->socket:Ljava/net/Socket;

    invoke-virtual {v0}, Ljava/net/Socket;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v0

    .line 761
    .local v0, "output":Ljava/io/OutputStream;
    invoke-virtual {v0, p1}, Ljava/io/OutputStream;->write([B)V

    .line 762
    invoke-virtual {v0}, Ljava/io/OutputStream;->flush()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    .line 763
    return v2

    .line 764
    .end local v0    # "output":Ljava/io/OutputStream;
    :catch_0
    move-exception v0

    goto :goto_0

    :catch_1
    move-exception v0

    .line 765
    .local v0, "e":Ljava/lang/Exception;
    :goto_0
    invoke-virtual {p0}, Lcom/lvteam/PacketCaptureService$TcpFlow;->emitReset()V

    .line 766
    invoke-virtual {p0}, Lcom/lvteam/PacketCaptureService$TcpFlow;->removeAndClose()V

    .line 767
    return v1

    .line 770
    .end local v0    # "e":Ljava/lang/Exception;
    :cond_0
    iget v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->pendingPayloadBytes:I

    array-length v3, p1

    add-int/2addr v0, v3

    const/high16 v3, 0x40000

    if-le v0, v3, :cond_1

    .line 771
    const-string v0, "PacketCapture"

    const-string v2, "TCP pending data queue overflow"

    invoke-static {v0, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 772
    invoke-virtual {p0}, Lcom/lvteam/PacketCaptureService$TcpFlow;->emitReset()V

    .line 773
    invoke-virtual {p0}, Lcom/lvteam/PacketCaptureService$TcpFlow;->removeAndClose()V

    .line 774
    return v1

    .line 776
    :cond_1
    iget-object v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->pendingPayload:Ljava/util/ArrayDeque;

    invoke-virtual {v0, p1}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z

    .line 777
    iget v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->pendingPayloadBytes:I

    array-length v1, p1

    add-int/2addr v0, v1

    iput v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->pendingPayloadBytes:I

    .line 778
    return v2
.end method

.method public final removeAndClose()V
    .locals 2

    .line 745
    invoke-virtual {p0}, Lcom/lvteam/PacketCaptureService$TcpFlow;->close()V

    .line 747
    :try_start_0
    iget-object v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->this$0:Lcom/lvteam/PacketCaptureService;

    invoke-static {v0}, Lcom/lvteam/PacketCaptureService;->-$$Nest$fgetstartupWatchdog(Lcom/lvteam/PacketCaptureService;)Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object v0

    new-instance v1, Lcom/lvteam/PacketCaptureService$TcpFlow$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0}, Lcom/lvteam/PacketCaptureService$TcpFlow$$ExternalSyntheticLambda0;-><init>(Lcom/lvteam/PacketCaptureService$TcpFlow;)V

    invoke-interface {v0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    .line 754
    goto :goto_0

    .line 752
    :catch_0
    move-exception v0

    .line 755
    :goto_0
    return-void
.end method

.method public resetAndClose()V
    .locals 1

    .line 738
    monitor-enter p0

    .line 739
    :try_start_0
    iget-object v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->socket:Ljava/net/Socket;

    invoke-virtual {v0}, Ljava/net/Socket;->isClosed()Z

    move-result v0

    if-nez v0, :cond_0

    invoke-virtual {p0}, Lcom/lvteam/PacketCaptureService$TcpFlow;->emitReset()V

    goto :goto_0

    .line 741
    :catchall_0
    move-exception v0

    goto :goto_1

    .line 740
    :cond_0
    :goto_0
    invoke-virtual {p0}, Lcom/lvteam/PacketCaptureService$TcpFlow;->close()V

    .line 741
    monitor-exit p0

    .line 742
    return-void

    .line 741
    :goto_1
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v0
.end method

.method public run()V
    .locals 7

    .line 622
    :try_start_0
    iget-object v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->socket:Ljava/net/Socket;

    new-instance v1, Ljava/net/InetSocketAddress;

    iget-object v2, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->key:Lcom/lvteam/PacketCaptureService$FlowKey;

    iget-object v2, v2, Lcom/lvteam/PacketCaptureService$FlowKey;->destinationAddress:Ljava/net/InetAddress;

    iget-object v3, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->key:Lcom/lvteam/PacketCaptureService$FlowKey;

    iget v3, v3, Lcom/lvteam/PacketCaptureService$FlowKey;->destinationPort:I

    invoke-direct {v1, v2, v3}, Ljava/net/InetSocketAddress;-><init>(Ljava/net/InetAddress;I)V

    const/16 v2, 0x2710

    invoke-virtual {v0, v1, v2}, Ljava/net/Socket;->connect(Ljava/net/SocketAddress;I)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_4
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_3

    .line 633
    nop

    .line 635
    :try_start_1
    iget-object v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->socket:Ljava/net/Socket;

    const v1, 0x493e0

    invoke-virtual {v0, v1}, Ljava/net/Socket;->setSoTimeout(I)V

    .line 636
    iget-object v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->socket:Ljava/net/Socket;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Ljava/net/Socket;->setTcpNoDelay(Z)V

    .line 637
    monitor-enter p0
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_4

    .line 638
    :try_start_2
    iget-object v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->this$0:Lcom/lvteam/PacketCaptureService;

    invoke-static {v0}, Lcom/lvteam/PacketCaptureService;->-$$Nest$fgetrelayRunning(Lcom/lvteam/PacketCaptureService;)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->socket:Ljava/net/Socket;

    invoke-virtual {v0}, Ljava/net/Socket;->isClosed()Z

    move-result v0

    if-nez v0, :cond_0

    iget-boolean v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->closed:Z

    if-eqz v0, :cond_1

    :cond_0
    goto/16 :goto_f

    .line 639
    :cond_1
    iput-boolean v1, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->connected:Z

    .line 640
    invoke-virtual {p0}, Lcom/lvteam/PacketCaptureService$TcpFlow;->flushPendingData()Z

    move-result v0

    if-nez v0, :cond_3

    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 677
    monitor-enter p0

    .line 678
    :try_start_3
    iget-boolean v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->remoteFinSent:Z

    if-nez v0, :cond_2

    invoke-virtual {p0}, Lcom/lvteam/PacketCaptureService$TcpFlow;->removeAndClose()V

    goto :goto_0

    .line 679
    :catchall_0
    move-exception v0

    goto :goto_1

    :cond_2
    :goto_0
    monitor-exit p0

    .line 640
    return-void

    .line 679
    :goto_1
    monitor-exit p0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    throw v0

    .line 642
    :catchall_1
    move-exception v0

    goto/16 :goto_12

    .line 641
    :cond_3
    :try_start_4
    iget-boolean v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->clientFinReceived:Z

    if-eqz v0, :cond_5

    invoke-virtual {p0}, Lcom/lvteam/PacketCaptureService$TcpFlow;->shutdownOutput()Z

    move-result v0

    if-nez v0, :cond_5

    monitor-exit p0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    .line 677
    monitor-enter p0

    .line 678
    :try_start_5
    iget-boolean v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->remoteFinSent:Z

    if-nez v0, :cond_4

    invoke-virtual {p0}, Lcom/lvteam/PacketCaptureService$TcpFlow;->removeAndClose()V

    goto :goto_2

    .line 679
    :catchall_2
    move-exception v0

    goto :goto_3

    :cond_4
    :goto_2
    monitor-exit p0

    .line 641
    return-void

    .line 679
    :goto_3
    monitor-exit p0
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    throw v0

    .line 642
    :cond_5
    :try_start_6
    monitor-exit p0
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_1

    .line 643
    :try_start_7
    iget-object v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->socket:Ljava/net/Socket;

    invoke-virtual {v0}, Ljava/net/Socket;->getInputStream()Ljava/io/InputStream;

    move-result-object v0

    .line 644
    .local v0, "input":Ljava/io/InputStream;
    const/16 v1, 0x4b0

    new-array v1, v1, [B

    .line 646
    .local v1, "buffer":[B
    :goto_4
    iget-object v2, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->this$0:Lcom/lvteam/PacketCaptureService;

    invoke-static {v2}, Lcom/lvteam/PacketCaptureService;->-$$Nest$fgetrelayRunning(Lcom/lvteam/PacketCaptureService;)Z

    move-result v2
    :try_end_7
    .catch Ljava/io/IOException; {:try_start_7 .. :try_end_7} :catch_1
    .catch Ljava/lang/RuntimeException; {:try_start_7 .. :try_end_7} :catch_0
    .catchall {:try_start_7 .. :try_end_7} :catchall_4

    if-eqz v2, :cond_a

    .line 648
    :try_start_8
    invoke-virtual {v0, v1}, Ljava/io/InputStream;->read([B)I

    move-result v2
    :try_end_8
    .catch Ljava/net/SocketTimeoutException; {:try_start_8 .. :try_end_8} :catch_2
    .catch Ljava/io/IOException; {:try_start_8 .. :try_end_8} :catch_1
    .catch Ljava/lang/RuntimeException; {:try_start_8 .. :try_end_8} :catch_0
    .catchall {:try_start_8 .. :try_end_8} :catchall_4

    .line 655
    .local v2, "length":I
    nop

    .line 656
    const/4 v3, -0x1

    if-ne v2, v3, :cond_6

    goto :goto_9

    .line 657
    :cond_6
    :try_start_9
    new-array v3, v2, [B

    .line 658
    .local v3, "payload":[B
    const/4 v4, 0x0

    invoke-static {v1, v4, v3, v4, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 659
    monitor-enter p0
    :try_end_9
    .catch Ljava/io/IOException; {:try_start_9 .. :try_end_9} :catch_1
    .catch Ljava/lang/RuntimeException; {:try_start_9 .. :try_end_9} :catch_0
    .catchall {:try_start_9 .. :try_end_9} :catchall_4

    .line 660
    :try_start_a
    iget-object v4, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->socket:Ljava/net/Socket;

    invoke-virtual {v4}, Ljava/net/Socket;->isClosed()Z

    move-result v4

    if-nez v4, :cond_7

    .line 661
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    iput-wide v4, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->lastActivityMillis:J

    .line 662
    iget-object v4, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->this$0:Lcom/lvteam/PacketCaptureService;

    invoke-static {v4}, Lcom/lvteam/PacketCaptureService;->-$$Nest$fgetframeDecoder(Lcom/lvteam/PacketCaptureService;)Lcom/lvteam/RawFrameDecoder;

    move-result-object v4

    iget-object v5, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->key:Lcom/lvteam/PacketCaptureService$FlowKey;

    array-length v6, v3

    invoke-virtual {v4, v5, v3, v6}, Lcom/lvteam/RawFrameDecoder;->acceptTcpPayload(Lcom/lvteam/PacketCaptureService$FlowKey;[BI)V

    .line 663
    const/16 v4, 0x10

    invoke-virtual {p0, v4, v3}, Lcom/lvteam/PacketCaptureService$TcpFlow;->emit(I[B)V

    goto :goto_5

    .line 665
    :catchall_3
    move-exception v4

    goto :goto_6

    :cond_7
    :goto_5
    monitor-exit p0

    .line 666
    .end local v3    # "payload":[B
    goto :goto_4

    .line 665
    .restart local v3    # "payload":[B
    :goto_6
    monitor-exit p0
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_3

    :try_start_b
    throw v4

    .line 677
    .end local v0    # "input":Ljava/io/InputStream;
    .end local v1    # "buffer":[B
    .end local v2    # "length":I
    .end local v3    # "payload":[B
    :catchall_4
    move-exception v0

    goto/16 :goto_19

    .line 670
    :catch_0
    move-exception v0

    goto :goto_13

    :catch_1
    move-exception v0

    goto :goto_13

    .line 649
    .restart local v0    # "input":Ljava/io/InputStream;
    .restart local v1    # "buffer":[B
    :catch_2
    move-exception v2

    .line 650
    .local v2, "e":Ljava/net/SocketTimeoutException;
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    invoke-virtual {p0, v3, v4}, Lcom/lvteam/PacketCaptureService$TcpFlow;->isIdle(J)Z

    move-result v3

    if-eqz v3, :cond_9

    .line 651
    invoke-virtual {p0}, Lcom/lvteam/PacketCaptureService$TcpFlow;->emitReset()V
    :try_end_b
    .catch Ljava/io/IOException; {:try_start_b .. :try_end_b} :catch_1
    .catch Ljava/lang/RuntimeException; {:try_start_b .. :try_end_b} :catch_0
    .catchall {:try_start_b .. :try_end_b} :catchall_4

    .line 677
    monitor-enter p0

    .line 678
    :try_start_c
    iget-boolean v3, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->remoteFinSent:Z

    if-nez v3, :cond_8

    invoke-virtual {p0}, Lcom/lvteam/PacketCaptureService$TcpFlow;->removeAndClose()V

    goto :goto_7

    .line 679
    :catchall_5
    move-exception v3

    goto :goto_8

    :cond_8
    :goto_7
    monitor-exit p0

    .line 652
    return-void

    .line 679
    :goto_8
    monitor-exit p0
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_5

    throw v3

    .line 654
    :cond_9
    goto :goto_4

    .line 667
    .end local v2    # "e":Ljava/net/SocketTimeoutException;
    :cond_a
    :goto_9
    :try_start_d
    monitor-enter p0
    :try_end_d
    .catch Ljava/io/IOException; {:try_start_d .. :try_end_d} :catch_1
    .catch Ljava/lang/RuntimeException; {:try_start_d .. :try_end_d} :catch_0
    .catchall {:try_start_d .. :try_end_d} :catchall_4

    .line 668
    :try_start_e
    iget-object v2, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->this$0:Lcom/lvteam/PacketCaptureService;

    invoke-static {v2}, Lcom/lvteam/PacketCaptureService;->-$$Nest$fgetrelayRunning(Lcom/lvteam/PacketCaptureService;)Z

    move-result v2

    if-eqz v2, :cond_b

    iget-object v2, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->socket:Ljava/net/Socket;

    invoke-virtual {v2}, Ljava/net/Socket;->isClosed()Z

    move-result v2

    if-nez v2, :cond_b

    iget-boolean v2, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->closed:Z

    if-nez v2, :cond_b

    invoke-virtual {p0}, Lcom/lvteam/PacketCaptureService$TcpFlow;->emitRemoteFin()V

    goto :goto_a

    .line 669
    :catchall_6
    move-exception v2

    goto :goto_e

    :cond_b
    :goto_a
    monitor-exit p0
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_6

    .line 677
    .end local v0    # "input":Ljava/io/InputStream;
    .end local v1    # "buffer":[B
    monitor-enter p0

    .line 678
    :try_start_f
    iget-boolean v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->remoteFinSent:Z

    if-nez v0, :cond_c

    invoke-virtual {p0}, Lcom/lvteam/PacketCaptureService$TcpFlow;->removeAndClose()V

    goto :goto_b

    .line 679
    :catchall_7
    move-exception v0

    goto :goto_d

    :cond_c
    :goto_b
    monitor-exit p0

    .line 680
    :goto_c
    goto :goto_16

    .line 679
    :goto_d
    monitor-exit p0
    :try_end_f
    .catchall {:try_start_f .. :try_end_f} :catchall_7

    throw v0

    .line 669
    .restart local v0    # "input":Ljava/io/InputStream;
    .restart local v1    # "buffer":[B
    :goto_e
    :try_start_10
    monitor-exit p0
    :try_end_10
    .catchall {:try_start_10 .. :try_end_10} :catchall_6

    :try_start_11
    throw v2
    :try_end_11
    .catch Ljava/io/IOException; {:try_start_11 .. :try_end_11} :catch_1
    .catch Ljava/lang/RuntimeException; {:try_start_11 .. :try_end_11} :catch_0
    .catchall {:try_start_11 .. :try_end_11} :catchall_4

    .line 638
    .end local v0    # "input":Ljava/io/InputStream;
    .end local v1    # "buffer":[B
    :goto_f
    :try_start_12
    monitor-exit p0
    :try_end_12
    .catchall {:try_start_12 .. :try_end_12} :catchall_1

    .line 677
    monitor-enter p0

    .line 678
    :try_start_13
    iget-boolean v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->remoteFinSent:Z

    if-nez v0, :cond_d

    invoke-virtual {p0}, Lcom/lvteam/PacketCaptureService$TcpFlow;->removeAndClose()V

    goto :goto_10

    .line 679
    :catchall_8
    move-exception v0

    goto :goto_11

    :cond_d
    :goto_10
    monitor-exit p0

    .line 638
    return-void

    .line 679
    :goto_11
    monitor-exit p0
    :try_end_13
    .catchall {:try_start_13 .. :try_end_13} :catchall_8

    throw v0

    .line 642
    :goto_12
    :try_start_14
    monitor-exit p0
    :try_end_14
    .catchall {:try_start_14 .. :try_end_14} :catchall_1

    :try_start_15
    throw v0
    :try_end_15
    .catch Ljava/io/IOException; {:try_start_15 .. :try_end_15} :catch_1
    .catch Ljava/lang/RuntimeException; {:try_start_15 .. :try_end_15} :catch_0
    .catchall {:try_start_15 .. :try_end_15} :catchall_4

    .line 670
    :goto_13
    nop

    .line 671
    .local v0, "e":Ljava/lang/Exception;
    :try_start_16
    monitor-enter p0
    :try_end_16
    .catchall {:try_start_16 .. :try_end_16} :catchall_4

    .line 672
    :try_start_17
    iget-object v1, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->this$0:Lcom/lvteam/PacketCaptureService;

    invoke-static {v1}, Lcom/lvteam/PacketCaptureService;->-$$Nest$fgetrelayRunning(Lcom/lvteam/PacketCaptureService;)Z

    move-result v1

    if-eqz v1, :cond_e

    iget-object v1, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->socket:Ljava/net/Socket;

    invoke-virtual {v1}, Ljava/net/Socket;->isClosed()Z

    move-result v1

    if-nez v1, :cond_e

    .line 673
    invoke-virtual {p0}, Lcom/lvteam/PacketCaptureService$TcpFlow;->emitReset()V

    goto :goto_14

    .line 675
    :catchall_9
    move-exception v1

    goto :goto_18

    :cond_e
    :goto_14
    monitor-exit p0
    :try_end_17
    .catchall {:try_start_17 .. :try_end_17} :catchall_9

    .line 677
    .end local v0    # "e":Ljava/lang/Exception;
    monitor-enter p0

    .line 678
    :try_start_18
    iget-boolean v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->remoteFinSent:Z

    if-nez v0, :cond_f

    invoke-virtual {p0}, Lcom/lvteam/PacketCaptureService$TcpFlow;->removeAndClose()V

    goto :goto_15

    .line 679
    :catchall_a
    move-exception v0

    goto :goto_17

    :cond_f
    :goto_15
    monitor-exit p0

    goto :goto_c

    .line 681
    :goto_16
    return-void

    .line 679
    :goto_17
    monitor-exit p0
    :try_end_18
    .catchall {:try_start_18 .. :try_end_18} :catchall_a

    throw v0

    .line 675
    .restart local v0    # "e":Ljava/lang/Exception;
    :goto_18
    :try_start_19
    monitor-exit p0
    :try_end_19
    .catchall {:try_start_19 .. :try_end_19} :catchall_9

    :try_start_1a
    throw v1
    :try_end_1a
    .catchall {:try_start_1a .. :try_end_1a} :catchall_4

    .line 677
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_19
    monitor-enter p0

    .line 678
    :try_start_1b
    iget-boolean v1, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->remoteFinSent:Z

    if-nez v1, :cond_10

    invoke-virtual {p0}, Lcom/lvteam/PacketCaptureService$TcpFlow;->removeAndClose()V

    goto :goto_1a

    .line 679
    :catchall_b
    move-exception v0

    goto :goto_1b

    :cond_10
    :goto_1a
    monitor-exit p0
    :try_end_1b
    .catchall {:try_start_1b .. :try_end_1b} :catchall_b

    .line 680
    throw v0

    .line 679
    :goto_1b
    :try_start_1c
    monitor-exit p0
    :try_end_1c
    .catchall {:try_start_1c .. :try_end_1c} :catchall_b

    throw v0

    .line 624
    :catch_3
    move-exception v0

    goto :goto_1c

    :catch_4
    move-exception v0

    .line 625
    .restart local v0    # "e":Ljava/lang/Exception;
    :goto_1c
    monitor-enter p0

    .line 626
    :try_start_1d
    iget-object v1, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->this$0:Lcom/lvteam/PacketCaptureService;

    invoke-static {v1}, Lcom/lvteam/PacketCaptureService;->-$$Nest$fgetrelayRunning(Lcom/lvteam/PacketCaptureService;)Z

    move-result v1

    if-eqz v1, :cond_11

    iget-object v1, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->socket:Ljava/net/Socket;

    invoke-virtual {v1}, Ljava/net/Socket;->isClosed()Z

    move-result v1

    if-nez v1, :cond_11

    .line 627
    const-string v1, "PacketCapture"

    const-string v2, "TCP upstream connect failed"

    invoke-static {v1, v2, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 628
    invoke-virtual {p0}, Lcom/lvteam/PacketCaptureService$TcpFlow;->emitReset()V

    goto :goto_1d

    .line 630
    :catchall_c
    move-exception v1

    goto :goto_1e

    :cond_11
    :goto_1d
    monitor-exit p0
    :try_end_1d
    .catchall {:try_start_1d .. :try_end_1d} :catchall_c

    .line 631
    invoke-virtual {p0}, Lcom/lvteam/PacketCaptureService$TcpFlow;->removeAndClose()V

    .line 632
    return-void

    .line 630
    :goto_1e
    :try_start_1e
    monitor-exit p0
    :try_end_1e
    .catchall {:try_start_1e .. :try_end_1e} :catchall_c

    throw v1
.end method

.method public final shutdownOutput()Z
    .locals 2

    .line 797
    :try_start_0
    iget-object v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow;->socket:Ljava/net/Socket;

    invoke-virtual {v0}, Ljava/net/Socket;->shutdownOutput()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    .line 798
    const/4 v0, 0x1

    return v0

    .line 799
    :catch_0
    move-exception v0

    goto :goto_0

    :catch_1
    move-exception v0

    .line 800
    .local v0, "e":Ljava/lang/Exception;
    :goto_0
    invoke-virtual {p0}, Lcom/lvteam/PacketCaptureService$TcpFlow;->emitReset()V

    .line 801
    invoke-virtual {p0}, Lcom/lvteam/PacketCaptureService$TcpFlow;->removeAndClose()V

    .line 802
    const/4 v1, 0x0

    return v1
.end method

.method public final writeResponse(JI[B)Z
    .locals 13
    .param p1, "sequence"    # J
    .param p3, "flags"    # I
    .param p4, "payload"    # [B

    .line 717
    move-object v1, p0

    iget-object v0, v1, Lcom/lvteam/PacketCaptureService$TcpFlow;->key:Lcom/lvteam/PacketCaptureService$FlowKey;

    iget-object v2, v0, Lcom/lvteam/PacketCaptureService$FlowKey;->destinationAddress:Ljava/net/InetAddress;

    iget-object v0, v1, Lcom/lvteam/PacketCaptureService$TcpFlow;->key:Lcom/lvteam/PacketCaptureService$FlowKey;

    iget v3, v0, Lcom/lvteam/PacketCaptureService$FlowKey;->destinationPort:I

    iget-object v0, v1, Lcom/lvteam/PacketCaptureService$TcpFlow;->key:Lcom/lvteam/PacketCaptureService$FlowKey;

    iget-object v4, v0, Lcom/lvteam/PacketCaptureService$FlowKey;->sourceAddress:Ljava/net/InetAddress;

    iget-object v0, v1, Lcom/lvteam/PacketCaptureService$TcpFlow;->key:Lcom/lvteam/PacketCaptureService$FlowKey;

    iget v5, v0, Lcom/lvteam/PacketCaptureService$FlowKey;->sourcePort:I

    iget-wide v8, v1, Lcom/lvteam/PacketCaptureService$TcpFlow;->clientNextSequence:J

    iget-object v0, v1, Lcom/lvteam/PacketCaptureService$TcpFlow;->this$0:Lcom/lvteam/PacketCaptureService;

    invoke-static {v0}, Lcom/lvteam/PacketCaptureService;->-$$Nest$fgetpacketIdentification(Lcom/lvteam/PacketCaptureService;)Ljava/util/concurrent/atomic/AtomicInteger;

    move-result-object v0

    .line 719
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->incrementAndGet()I

    move-result v0

    const v6, 0xffff

    and-int v12, v0, v6

    .line 717
    move-wide v6, p1

    move/from16 v10, p3

    move-object/from16 v11, p4

    invoke-static/range {v2 .. v12}, Lcom/lvteam/Ipv4TcpPacket;->response(Ljava/net/InetAddress;ILjava/net/InetAddress;IJJI[BI)[B

    move-result-object v2

    .line 720
    .local v2, "frame":[B
    iget-object v0, v1, Lcom/lvteam/PacketCaptureService$TcpFlow;->this$0:Lcom/lvteam/PacketCaptureService;

    invoke-static {v0}, Lcom/lvteam/PacketCaptureService;->-$$Nest$fgetoutputLock(Lcom/lvteam/PacketCaptureService;)Ljava/lang/Object;

    move-result-object v3

    monitor-enter v3

    .line 722
    const/4 v4, 0x0

    :try_start_0
    iget-object v0, v1, Lcom/lvteam/PacketCaptureService$TcpFlow;->this$0:Lcom/lvteam/PacketCaptureService;

    invoke-static {v0}, Lcom/lvteam/PacketCaptureService;->-$$Nest$fgetrelayRunning(Lcom/lvteam/PacketCaptureService;)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, v1, Lcom/lvteam/PacketCaptureService$TcpFlow;->this$0:Lcom/lvteam/PacketCaptureService;

    invoke-static {v0}, Lcom/lvteam/PacketCaptureService;->-$$Nest$fgettunnelOutput(Lcom/lvteam/PacketCaptureService;)Ljava/io/FileOutputStream;

    move-result-object v0

    if-nez v0, :cond_1

    :cond_0
    goto :goto_0

    .line 723
    :cond_1
    iget-object v0, v1, Lcom/lvteam/PacketCaptureService$TcpFlow;->this$0:Lcom/lvteam/PacketCaptureService;

    invoke-static {v0}, Lcom/lvteam/PacketCaptureService;->-$$Nest$fgettunnelOutput(Lcom/lvteam/PacketCaptureService;)Ljava/io/FileOutputStream;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/io/FileOutputStream;->write([B)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 726
    nop

    .line 727
    :try_start_1
    monitor-exit v3

    .line 728
    const/4 v0, 0x1

    return v0

    .line 727
    :catchall_0
    move-exception v0

    goto :goto_2

    .line 724
    :catch_0
    move-exception v0

    goto :goto_1

    .line 722
    :goto_0
    monitor-exit v3

    return v4

    .line 724
    :goto_1
    nop

    .line 725
    .local v0, "e":Ljava/io/IOException;
    monitor-exit v3

    return v4

    .line 727
    .end local v0    # "e":Ljava/io/IOException;
    :goto_2
    monitor-exit v3
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method
