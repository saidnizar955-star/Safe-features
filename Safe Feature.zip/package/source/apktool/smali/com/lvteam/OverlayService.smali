.class public Lcom/lvteam/OverlayService;
.super Landroid/app/Service;
.source "OverlayService.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/lvteam/OverlayService$DraggableLayout;,
        Lcom/lvteam/OverlayService$DropdownCallback;,
        Lcom/lvteam/OverlayService$ToggleCallback;,
        Lcom/lvteam/OverlayService$SliderCallback;
    }
.end annotation


# static fields
.field private static final CHANNEL_ID:Ljava/lang/String; = "lv_team_overlay"

.field private static final EL_BOX:I = 0x0

.field private static final EL_DIST:I = 0x3

.field private static final EL_FOV:I = 0x4

.field private static final EL_LINE:I = 0x1

.field private static final EL_NAME:I = 0x2

.field private static final TAB_AIM:I = 0x0

.field private static final TAB_COUNT:I = 0x5

.field private static final TAB_EXPLOIT:I = 0x3

.field private static final TAB_ICONS:[Ljava/lang/String;

.field private static final TAB_NAMES:[Ljava/lang/String;

.field private static final TAB_PLAYERS:I = 0x2

.field private static final TAB_SETTINGS:I = 0x4

.field private static final TAB_VIEWS:I = 0x1

.field private static final TH_ACCENT:I = -0xd6490a

.field private static final TH_BG:I = -0xff2eee9

.field private static final TH_BORDER:I = -0xcbc3b6

.field private static final TH_CHECK_OFF:I = -0xf1ebe4

.field private static final TH_CONTENT:I = -0xeee7e0

.field private static final TH_DIVIDER:I = -0xe3dcd2

.field private static final TH_HEADER:I = -0xe9e4de

.field private static final TH_RED:I = -0x1ac6cb

.field private static final TH_SIDEBAR:I = -0xf2eee9

.field private static final TH_SIDEBAR_ACTIVE:I = -0xe9ddcc

.field private static final TH_SURFACE:I = -0xe3dccd

.field private static final TH_TEXT:I = -0x19120d

.field private static final TH_TEXT_DIM:I = -0x827a70

.field private static final TH_TOGGLE_OFF:I = -0xe1dacb

.field private static final TH_TOGGLE_ON:I = -0xde690d


# instance fields
.field private activeTab:I

.field private appIcon:Landroid/widget/ImageView;

.field private bodyContainer:Landroid/widget/LinearLayout;

.field private boxEnabled:Z

.field private boxOverlay:Lcom/lvteam/EspOverlayView;

.field private circleOverlay:Landroid/view/View;

.field private circleParams:Landroid/view/WindowManager$LayoutParams;

.field private final colors:[I

.field private drawDistance:Z

.field private drawLine:Z

.field private drawName:Z

.field private final elementColor:[I

.field private enemyCounterEnabled:Z

.field private enemyCounterOverlay:Landroid/widget/LinearLayout;

.field private enemyValue:Landroid/widget/TextView;

.field private final entityState:Lcom/lvteam/EntityState;

.field private espEnabled:Z

.field private final espEngine:Lcom/lvteam/EspEngine;

.field private final espFrame:Landroid/view/Choreographer$FrameCallback;

.field private espMasterBox:Landroid/widget/FrameLayout;

.field private fovPercent:I

.field private headerContainer:Landroid/widget/LinearLayout;

.field private final ignoredIds:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private initialTouchX:F

.field private initialTouchY:F

.field private initialX:I

.field private initialY:I

.field private volatile lastProjected:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/lvteam/EspOverlayView$Entity;",
            ">;"
        }
    .end annotation
.end field

.field private maxDistanceM:I

.field private minimized:Z

.field private overlay:Landroid/view/View;

.field private overlayBackground:Landroid/graphics/drawable/GradientDrawable;

.field private overlayParams:Landroid/view/WindowManager$LayoutParams;

.field private playerEmptyLabel:Landroid/widget/TextView;

.field private playerListContainer:Landroid/widget/LinearLayout;

.field private playerUpdateHandler:Landroid/os/Handler;

.field private sessionCheckHandler:Landroid/os/Handler;

.field private final sidebarAccents:[Landroid/view/View;

.field private final sidebarIcons:[Landroid/widget/TextView;

.field private final sidebarItems:[Landroid/widget/LinearLayout;

.field private final sidebarLabels:[Landroid/widget/TextView;

.field private final tabPanels:[Landroid/widget/LinearLayout;

.field private teamTitleOverlay:Landroid/widget/TextView;

.field private thicknessIndex:I

.field private thicknessLabel:Landroid/widget/TextView;

.field private final thicknesses:[F

.field private windowManager:Landroid/view/WindowManager;


# direct methods
.method public static synthetic $r8$lambda$0w30vPqE3YhQSjDgnIvD4sSemQ8(Lcom/lvteam/OverlayService;Landroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/lvteam/OverlayService;->lambda$showOverlay$0(Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$3FRDUcnLKTbKj9J3n4-TI11Sw1A(Lcom/lvteam/OverlayService;ILandroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/lvteam/OverlayService;->lambda$refreshPlayerList$25(ILandroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$7O9oNG1XykC8PUdYtUouXRt6gDY(Lcom/lvteam/OverlayService;Z)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/lvteam/OverlayService;->lambda$buildViewsTab$9(Z)V

    return-void
.end method

.method public static synthetic $r8$lambda$Ahi-I5U-sh-dpbl7_DvQ6eLO68k(Lcom/lvteam/OverlayService;Z)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/lvteam/OverlayService;->setCircleEnabled(Z)V

    return-void
.end method

.method public static synthetic $r8$lambda$C4OQEI9KowuFLzeEX6wfPlaQEwo(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 0

    .line 0
    invoke-static {p0, p1}, Lcom/lvteam/OverlayService;->lambda$addSliderRow$21(Landroid/view/View;Landroid/view/MotionEvent;)Z

    move-result p0

    return p0
.end method

.method public static synthetic $r8$lambda$E6VikiRSOlkXreFuPOwPRwqmgW4(Lcom/lvteam/OverlayService;Z)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/lvteam/OverlayService;->lambda$buildViewsTab$11(Z)V

    return-void
.end method

.method public static synthetic $r8$lambda$GiljZffzQoL1sBXoP_kMGk5Vs70([Ljava/lang/String;Landroid/widget/TextView;Lcom/lvteam/OverlayService$DropdownCallback;Landroid/view/View;)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3}, Lcom/lvteam/OverlayService;->lambda$addDropdownRow$20([Ljava/lang/String;Landroid/widget/TextView;Lcom/lvteam/OverlayService$DropdownCallback;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$IfVShZ9NK7cs7Qe6Gd1jYn8txNc(Lcom/lvteam/OverlayService;Lcom/lvteam/OverlayService$ToggleCallback;Landroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/lvteam/OverlayService;->lambda$addFeatureToggle$16(Lcom/lvteam/OverlayService$ToggleCallback;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$KSNblP8sT7lmyB19nMtzPePrL00(Lcom/lvteam/OverlayService;Landroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/lvteam/OverlayService;->lambda$buildThicknessPicker$23(Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$LBC2mY49Td03HsopEY-9QYWjSLA(Lcom/lvteam/OverlayService;ILandroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/lvteam/OverlayService;->lambda$addShiftToggle$19(ILandroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$QL9A76WAuuB3Wnf3FXYGeJUDZuc(Lcom/lvteam/OverlayService;Landroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/lvteam/OverlayService;->lambda$buildThicknessPicker$22(Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$SGuFj4_Kf5ymqwSefcak0ISSaAk(Lcom/lvteam/OverlayService;I)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/lvteam/OverlayService;->lambda$buildViewsTab$12(I)V

    return-void
.end method

.method public static synthetic $r8$lambda$Tpmj64-R8qKJ3g4lHDrs2E_d0rk(Z)V
    .locals 0

    .line 0
    invoke-static {p0}, Lcom/lvteam/OverlayService;->lambda$buildAimTab$6(Z)V

    return-void
.end method

.method public static synthetic $r8$lambda$TyS14aa87qU2_QsJ_o3fPoV5a4k()V
    .locals 0

    .line 0
    invoke-static {}, Lcom/lvteam/OverlayService;->lambda$killApp$26()V

    return-void
.end method

.method public static synthetic $r8$lambda$YGaolynwQit2uwJWQV-IF5f5dDs(Lcom/lvteam/OverlayService;ILandroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/lvteam/OverlayService;->lambda$refreshPlayerList$24(ILandroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$bniRpGPsQNHd4jDzwpEnJ-IWq5U(Lcom/lvteam/OverlayService;ILandroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/lvteam/OverlayService;->lambda$buildSidebar$2(ILandroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$i1q6eDqqHgNvDGQYtNCfZstmK_8(Lcom/lvteam/OverlayService;Landroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/lvteam/OverlayService;->lambda$buildPlayersTab$14(Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$koJTyZo30Lx5F9RxP2fgdQT12FQ(Lcom/lvteam/OverlayService;Z)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/lvteam/OverlayService;->lambda$buildViewsTab$7(Z)V

    return-void
.end method

.method public static synthetic $r8$lambda$kuVJC3WS1dRic_oU3zwwzQtxenA(Lcom/lvteam/OverlayService;Z)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/lvteam/OverlayService;->lambda$buildViewsTab$13(Z)V

    return-void
.end method

.method public static synthetic $r8$lambda$mx-g_u6T1stoRigZCyuat24fnnw(Lcom/lvteam/OverlayService;I)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/lvteam/OverlayService;->lambda$buildAimTab$4(I)V

    return-void
.end method

.method public static synthetic $r8$lambda$q9g9grDYPtTiFTxv0SptkmTRkkM(Lcom/lvteam/OverlayService;Z)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/lvteam/OverlayService;->lambda$buildViewsTab$10(Z)V

    return-void
.end method

.method public static synthetic $r8$lambda$qAF-veioSt0oAHDPitobc7pX1nc(Lcom/lvteam/OverlayService;Z)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/lvteam/OverlayService;->lambda$buildViewsTab$8(Z)V

    return-void
.end method

.method public static synthetic $r8$lambda$qxCh6ru9daFvwVSYicb8UEl4UlU(Lcom/lvteam/OverlayService;Landroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/lvteam/OverlayService;->lambda$buildHeader$1(Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$s1bJGMdopGfHHR09io1fN343nbU(Lcom/lvteam/OverlayService;ILandroid/graphics/drawable/GradientDrawable;Landroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2, p3}, Lcom/lvteam/OverlayService;->lambda$makeSwatch$18(ILandroid/graphics/drawable/GradientDrawable;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$wJITroAQzTkx94Sv22nkttrJ2zE(Lcom/lvteam/OverlayService;Lcom/lvteam/OverlayService$ToggleCallback;Landroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/lvteam/OverlayService;->lambda$addEspToggle$17(Lcom/lvteam/OverlayService$ToggleCallback;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$x2ZAIY11ukwafi8lmj5m_xsIR60(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 0

    .line 0
    invoke-static {p0, p1}, Lcom/lvteam/OverlayService;->lambda$buildTabPanel$3(Landroid/view/View;Landroid/view/MotionEvent;)Z

    move-result p0

    return p0
.end method

.method public static synthetic $r8$lambda$y5HNrKHSSx-A2loHszI5-YuI-74(Lcom/lvteam/OverlayService;Landroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/lvteam/OverlayService;->lambda$buildSettingsTab$15(Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$y92_gy5ujw6L8oH20DEUMhzGKVQ(Z)V
    .locals 0

    .line 0
    invoke-static {p0}, Lcom/lvteam/OverlayService;->lambda$buildAimTab$5(Z)V

    return-void
.end method

.method public static bridge synthetic -$$Nest$fgetactiveTab(Lcom/lvteam/OverlayService;)I
    .locals 0

    .line 0
    iget p0, p0, Lcom/lvteam/OverlayService;->activeTab:I

    return p0
.end method

.method public static bridge synthetic -$$Nest$fgetboxOverlay(Lcom/lvteam/OverlayService;)Lcom/lvteam/EspOverlayView;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/lvteam/OverlayService;->boxOverlay:Lcom/lvteam/EspOverlayView;

    return-object p0
.end method

.method public static bridge synthetic -$$Nest$fgetentityState(Lcom/lvteam/OverlayService;)Lcom/lvteam/EntityState;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/lvteam/OverlayService;->entityState:Lcom/lvteam/EntityState;

    return-object p0
.end method

.method public static bridge synthetic -$$Nest$fgetespEngine(Lcom/lvteam/OverlayService;)Lcom/lvteam/EspEngine;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/lvteam/OverlayService;->espEngine:Lcom/lvteam/EspEngine;

    return-object p0
.end method

.method public static bridge synthetic -$$Nest$fgetignoredIds(Lcom/lvteam/OverlayService;)Ljava/util/Set;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/lvteam/OverlayService;->ignoredIds:Ljava/util/Set;

    return-object p0
.end method

.method public static bridge synthetic -$$Nest$fgetinitialTouchX(Lcom/lvteam/OverlayService;)F
    .locals 0

    .line 0
    iget p0, p0, Lcom/lvteam/OverlayService;->initialTouchX:F

    return p0
.end method

.method public static bridge synthetic -$$Nest$fgetinitialTouchY(Lcom/lvteam/OverlayService;)F
    .locals 0

    .line 0
    iget p0, p0, Lcom/lvteam/OverlayService;->initialTouchY:F

    return p0
.end method

.method public static bridge synthetic -$$Nest$fgetinitialX(Lcom/lvteam/OverlayService;)I
    .locals 0

    .line 0
    iget p0, p0, Lcom/lvteam/OverlayService;->initialX:I

    return p0
.end method

.method public static bridge synthetic -$$Nest$fgetinitialY(Lcom/lvteam/OverlayService;)I
    .locals 0

    .line 0
    iget p0, p0, Lcom/lvteam/OverlayService;->initialY:I

    return p0
.end method

.method public static bridge synthetic -$$Nest$fgetminimized(Lcom/lvteam/OverlayService;)Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/lvteam/OverlayService;->minimized:Z

    return p0
.end method

.method public static bridge synthetic -$$Nest$fgetoverlayParams(Lcom/lvteam/OverlayService;)Landroid/view/WindowManager$LayoutParams;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/lvteam/OverlayService;->overlayParams:Landroid/view/WindowManager$LayoutParams;

    return-object p0
.end method

.method public static bridge synthetic -$$Nest$fgetplayerUpdateHandler(Lcom/lvteam/OverlayService;)Landroid/os/Handler;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/lvteam/OverlayService;->playerUpdateHandler:Landroid/os/Handler;

    return-object p0
.end method

.method public static bridge synthetic -$$Nest$fgetsessionCheckHandler(Lcom/lvteam/OverlayService;)Landroid/os/Handler;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/lvteam/OverlayService;->sessionCheckHandler:Landroid/os/Handler;

    return-object p0
.end method

.method public static bridge synthetic -$$Nest$fgetwindowManager(Lcom/lvteam/OverlayService;)Landroid/view/WindowManager;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/lvteam/OverlayService;->windowManager:Landroid/view/WindowManager;

    return-object p0
.end method

.method public static bridge synthetic -$$Nest$fputinitialTouchX(Lcom/lvteam/OverlayService;F)V
    .locals 0

    .line 0
    iput p1, p0, Lcom/lvteam/OverlayService;->initialTouchX:F

    return-void
.end method

.method public static bridge synthetic -$$Nest$fputinitialTouchY(Lcom/lvteam/OverlayService;F)V
    .locals 0

    .line 0
    iput p1, p0, Lcom/lvteam/OverlayService;->initialTouchY:F

    return-void
.end method

.method public static bridge synthetic -$$Nest$fputinitialX(Lcom/lvteam/OverlayService;I)V
    .locals 0

    .line 0
    iput p1, p0, Lcom/lvteam/OverlayService;->initialX:I

    return-void
.end method

.method public static bridge synthetic -$$Nest$fputinitialY(Lcom/lvteam/OverlayService;I)V
    .locals 0

    .line 0
    iput p1, p0, Lcom/lvteam/OverlayService;->initialY:I

    return-void
.end method

.method public static bridge synthetic -$$Nest$fputlastProjected(Lcom/lvteam/OverlayService;Ljava/util/List;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/lvteam/OverlayService;->lastProjected:Ljava/util/List;

    return-void
.end method

.method public static bridge synthetic -$$Nest$mdp(Lcom/lvteam/OverlayService;I)I
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result p0

    return p0
.end method

.method public static bridge synthetic -$$Nest$mkillApp(Lcom/lvteam/OverlayService;Ljava/lang/String;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/lvteam/OverlayService;->killApp(Ljava/lang/String;)V

    return-void
.end method

.method public static bridge synthetic -$$Nest$mrefreshPlayerList(Lcom/lvteam/OverlayService;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/lvteam/OverlayService;->refreshPlayerList()V

    return-void
.end method

.method public static bridge synthetic -$$Nest$mupdateEnemyCounter(Lcom/lvteam/OverlayService;I)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/lvteam/OverlayService;->updateEnemyCounter(I)V

    return-void
.end method

.method static constructor <clinit>()V
    .locals 5

    .line 62
    const-string v0, "\u26a1"

    const-string v1, "\u2699"

    const-string v2, "\u25c9"

    const-string v3, "\u2630"

    filled-new-array {v2, v2, v3, v0, v1}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/lvteam/OverlayService;->TAB_ICONS:[Ljava/lang/String;

    .line 63
    const-string v0, "Exploit"

    const-string v1, "Settings"

    const-string v2, "Aim"

    const-string v3, "Views"

    const-string v4, "Players"

    filled-new-array {v2, v3, v4, v0, v1}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/lvteam/OverlayService;->TAB_NAMES:[Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 36
    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    .line 72
    const/4 v0, 0x5

    new-array v1, v0, [Landroid/widget/LinearLayout;

    iput-object v1, p0, Lcom/lvteam/OverlayService;->tabPanels:[Landroid/widget/LinearLayout;

    .line 73
    new-array v1, v0, [Landroid/widget/LinearLayout;

    iput-object v1, p0, Lcom/lvteam/OverlayService;->sidebarItems:[Landroid/widget/LinearLayout;

    .line 74
    new-array v1, v0, [Landroid/widget/TextView;

    iput-object v1, p0, Lcom/lvteam/OverlayService;->sidebarIcons:[Landroid/widget/TextView;

    .line 75
    new-array v1, v0, [Landroid/widget/TextView;

    iput-object v1, p0, Lcom/lvteam/OverlayService;->sidebarLabels:[Landroid/widget/TextView;

    .line 76
    new-array v1, v0, [Landroid/view/View;

    iput-object v1, p0, Lcom/lvteam/OverlayService;->sidebarAccents:[Landroid/view/View;

    .line 77
    const/4 v1, 0x0

    iput v1, p0, Lcom/lvteam/OverlayService;->activeTab:I

    .line 83
    new-instance v1, Lcom/lvteam/EspEngine;

    invoke-direct {v1}, Lcom/lvteam/EspEngine;-><init>()V

    iput-object v1, p0, Lcom/lvteam/OverlayService;->espEngine:Lcom/lvteam/EspEngine;

    .line 84
    invoke-static {}, Lcom/lvteam/EntityState;->shared()Lcom/lvteam/EntityState;

    move-result-object v1

    iput-object v1, p0, Lcom/lvteam/OverlayService;->entityState:Lcom/lvteam/EntityState;

    .line 95
    const/16 v1, 0x6e

    iput v1, p0, Lcom/lvteam/OverlayService;->fovPercent:I

    .line 96
    const/16 v1, 0xa0

    iput v1, p0, Lcom/lvteam/OverlayService;->maxDistanceM:I

    .line 104
    filled-new-array {v0, v0, v0, v0, v0}, [I

    move-result-object v1

    iput-object v1, p0, Lcom/lvteam/OverlayService;->elementColor:[I

    .line 106
    iput v0, p0, Lcom/lvteam/OverlayService;->thicknessIndex:I

    .line 107
    const/4 v0, 0x6

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    iput-object v0, p0, Lcom/lvteam/OverlayService;->colors:[I

    .line 108
    const/16 v0, 0xb

    new-array v0, v0, [F

    fill-array-data v0, :array_1

    iput-object v0, p0, Lcom/lvteam/OverlayService;->thicknesses:[F

    .line 115
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/lvteam/OverlayService;->lastProjected:Ljava/util/List;

    .line 117
    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    iput-object v0, p0, Lcom/lvteam/OverlayService;->ignoredIds:Ljava/util/Set;

    .line 120
    new-instance v0, Lcom/lvteam/OverlayService$1;

    invoke-direct {v0, p0}, Lcom/lvteam/OverlayService$1;-><init>(Lcom/lvteam/OverlayService;)V

    iput-object v0, p0, Lcom/lvteam/OverlayService;->espFrame:Landroid/view/Choreographer$FrameCallback;

    return-void

    nop

    :array_0
    .array-data 4
        -0x10000
        -0xff0100
        -0xffff01
        -0x100
        -0xff01
        -0x1
    .end array-data

    :array_1
    .array-data 4
        0x3f000000    # 0.5f
        0x3f19999a    # 0.6f
        0x3f333333    # 0.7f
        0x3f4ccccd    # 0.8f
        0x3f666666    # 0.9f
        0x3f800000    # 1.0f
        0x3f8ccccd    # 1.1f
        0x3f99999a    # 1.2f
        0x3fa66666    # 1.3f
        0x3fb33333    # 1.4f
        0x3fc00000    # 1.5f
    .end array-data
.end method

.method private addDropdownRow(Landroid/widget/LinearLayout;Ljava/lang/String;[Ljava/lang/String;ILcom/lvteam/OverlayService$DropdownCallback;)V
    .locals 6
    .param p1, "parent"    # Landroid/widget/LinearLayout;
    .param p2, "name"    # Ljava/lang/String;
    .param p3, "options"    # [Ljava/lang/String;
    .param p4, "initial"    # I
    .param p5, "cb"    # Lcom/lvteam/OverlayService$DropdownCallback;

    .line 743
    invoke-direct {p0, p1, p2}, Lcom/lvteam/OverlayService;->newRow(Landroid/widget/LinearLayout;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v0

    .line 745
    .local v0, "row":Landroid/widget/LinearLayout;
    new-instance v1, Landroid/widget/TextView;

    invoke-direct {v1, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 746
    .local v1, "dd":Landroid/widget/TextView;
    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 747
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    aget-object v3, p3, p4

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, "  \u25bc"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 748
    const v2, -0x19120d

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 749
    const/high16 v2, 0x41400000    # 12.0f

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextSize(F)V

    .line 750
    const-string v2, "sans-serif-medium"

    const/4 v3, 0x0

    invoke-static {v2, v3}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 751
    const/16 v2, 0x11

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setGravity(I)V

    .line 752
    const/16 v2, 0xc

    invoke-direct {p0, v2}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v4

    invoke-direct {p0, v2}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v2

    invoke-virtual {v1, v4, v3, v2, v3}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 753
    new-instance v2, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v2}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 754
    .local v2, "bg":Landroid/graphics/drawable/GradientDrawable;
    const/4 v3, 0x7

    invoke-direct {p0, v3}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v3

    int-to-float v3, v3

    invoke-virtual {v2, v3}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 755
    const v3, -0xe3dccd

    invoke-virtual {v2, v3}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 756
    const/4 v3, 0x1

    invoke-direct {p0, v3}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v3

    const v4, -0xcbc3b6

    invoke-virtual {v2, v3, v4}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 757
    invoke-virtual {v1, v2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 758
    new-instance v3, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda22;

    invoke-direct {v3, p3, v1, p5}, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda22;-><init>([Ljava/lang/String;Landroid/widget/TextView;Lcom/lvteam/OverlayService$DropdownCallback;)V

    invoke-virtual {v1, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 764
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    .line 765
    const/16 v4, 0x20

    invoke-direct {p0, v4}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v4

    const/4 v5, -0x2

    invoke-direct {v3, v5, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 764
    invoke-virtual {v0, v1, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 766
    invoke-direct {p0, p1}, Lcom/lvteam/OverlayService;->addRowLine(Landroid/widget/LinearLayout;)V

    .line 767
    return-void
.end method

.method private addEspToggle(Landroid/widget/LinearLayout;Ljava/lang/String;ILcom/lvteam/OverlayService$ToggleCallback;)Landroid/widget/FrameLayout;
    .locals 5
    .param p1, "parent"    # Landroid/widget/LinearLayout;
    .param p2, "name"    # Ljava/lang/String;
    .param p3, "element"    # I
    .param p4, "cb"    # Lcom/lvteam/OverlayService$ToggleCallback;

    .line 679
    invoke-direct {p0, p1, p2}, Lcom/lvteam/OverlayService;->newRow(Landroid/widget/LinearLayout;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v0

    .line 680
    .local v0, "row":Landroid/widget/LinearLayout;
    invoke-direct {p0, p3}, Lcom/lvteam/OverlayService;->makeSwatch(I)Landroid/view/View;

    move-result-object v1

    invoke-direct {p0}, Lcom/lvteam/OverlayService;->swatchParams()Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 682
    invoke-direct {p0}, Lcom/lvteam/OverlayService;->makeCheckbox()Landroid/widget/FrameLayout;

    move-result-object v1

    .line 683
    .local v1, "box":Landroid/widget/FrameLayout;
    new-instance v2, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda27;

    invoke-direct {v2, p0, p4}, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda27;-><init>(Lcom/lvteam/OverlayService;Lcom/lvteam/OverlayService$ToggleCallback;)V

    invoke-virtual {v1, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 690
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v3, 0x1a

    invoke-direct {p0, v3}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v4

    invoke-direct {p0, v3}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v3

    invoke-direct {v2, v4, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 691
    invoke-direct {p0, p1}, Lcom/lvteam/OverlayService;->addRowLine(Landroid/widget/LinearLayout;)V

    .line 692
    return-object v1
.end method

.method private addFeatureToggle(Landroid/widget/LinearLayout;Ljava/lang/String;Lcom/lvteam/OverlayService$ToggleCallback;)Landroid/widget/FrameLayout;
    .locals 5
    .param p1, "parent"    # Landroid/widget/LinearLayout;
    .param p2, "name"    # Ljava/lang/String;
    .param p3, "cb"    # Lcom/lvteam/OverlayService$ToggleCallback;

    .line 654
    invoke-direct {p0, p1, p2}, Lcom/lvteam/OverlayService;->newRow(Landroid/widget/LinearLayout;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v0

    .line 655
    .local v0, "row":Landroid/widget/LinearLayout;
    invoke-direct {p0}, Lcom/lvteam/OverlayService;->makeCheckbox()Landroid/widget/FrameLayout;

    move-result-object v1

    .line 656
    .local v1, "box":Landroid/widget/FrameLayout;
    new-instance v2, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda18;

    invoke-direct {v2, p0, p3}, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda18;-><init>(Lcom/lvteam/OverlayService;Lcom/lvteam/OverlayService$ToggleCallback;)V

    invoke-virtual {v1, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 663
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v3, 0x1a

    invoke-direct {p0, v3}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v4

    invoke-direct {p0, v3}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v3

    invoke-direct {v2, v4, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 664
    invoke-direct {p0, p1}, Lcom/lvteam/OverlayService;->addRowLine(Landroid/widget/LinearLayout;)V

    .line 665
    return-object v1
.end method

.method private addInfoRow(Landroid/widget/LinearLayout;Ljava/lang/String;Ljava/lang/String;)V
    .locals 8
    .param p1, "parent"    # Landroid/widget/LinearLayout;
    .param p2, "key"    # Ljava/lang/String;
    .param p3, "value"    # Ljava/lang/String;

    .line 856
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 857
    .local v0, "row":Landroid/widget/LinearLayout;
    const/16 v1, 0x10

    invoke-direct {p0, v1}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v2

    const/16 v3, 0xe

    invoke-direct {p0, v3}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v3

    const/4 v4, 0x0

    invoke-virtual {v0, v2, v4, v3, v4}, Landroid/view/View;->setPadding(IIII)V

    .line 858
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 860
    new-instance v1, Landroid/widget/TextView;

    invoke-direct {v1, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 861
    .local v1, "kTv":Landroid/widget/TextView;
    invoke-virtual {v1, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 862
    const v2, -0x827a70

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 863
    const/high16 v2, 0x41500000    # 13.0f

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextSize(F)V

    .line 864
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v5, 0x26

    invoke-direct {p0, v5}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v6

    const/high16 v7, 0x3f800000    # 1.0f

    invoke-direct {v3, v4, v6, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, v1, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 866
    new-instance v3, Landroid/widget/TextView;

    invoke-direct {v3, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 867
    .local v3, "vTv":Landroid/widget/TextView;
    invoke-virtual {v3, p3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 868
    const v6, -0x19120d

    invoke-virtual {v3, v6}, Landroid/widget/TextView;->setTextColor(I)V

    .line 869
    invoke-virtual {v3, v2}, Landroid/widget/TextView;->setTextSize(F)V

    .line 870
    const-string v2, "sans-serif-medium"

    invoke-static {v2, v4}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object v2

    invoke-virtual {v3, v2}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 871
    const v2, 0x800015

    invoke-virtual {v3, v2}, Landroid/widget/TextView;->setGravity(I)V

    .line 872
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    .line 873
    invoke-direct {p0, v5}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v4

    const/4 v6, -0x2

    invoke-direct {v2, v6, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 872
    invoke-virtual {v0, v3, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 875
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    .line 876
    invoke-direct {p0, v5}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v4

    const/4 v5, -0x1

    invoke-direct {v2, v5, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 875
    invoke-virtual {p1, v0, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 877
    invoke-direct {p0, p1}, Lcom/lvteam/OverlayService;->addRowLine(Landroid/widget/LinearLayout;)V

    .line 878
    return-void
.end method

.method private addRowLine(Landroid/widget/LinearLayout;)V
    .locals 5
    .param p1, "parent"    # Landroid/widget/LinearLayout;

    .line 645
    new-instance v0, Landroid/view/View;

    invoke-direct {v0, p0}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 646
    .local v0, "d":Landroid/view/View;
    const v1, -0xe3dcd2

    invoke-virtual {v0, v1}, Landroid/view/View;->setBackgroundColor(I)V

    .line 647
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    .line 648
    const/4 v2, 0x1

    invoke-direct {p0, v2}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v2

    const/4 v3, -0x1

    invoke-direct {v1, v3, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 649
    .local v1, "lp":Landroid/widget/LinearLayout$LayoutParams;
    const/16 v2, 0x10

    invoke-direct {p0, v2}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v2

    const/16 v3, 0xe

    invoke-direct {p0, v3}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v3

    const/4 v4, 0x0

    invoke-virtual {v1, v2, v4, v3, v4}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 650
    invoke-virtual {p1, v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 651
    return-void
.end method

.method private addSectionLabel(Landroid/widget/LinearLayout;Ljava/lang/String;)V
    .locals 9
    .param p1, "parent"    # Landroid/widget/LinearLayout;
    .param p2, "text"    # Ljava/lang/String;

    .line 881
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 882
    .local v0, "row":Landroid/widget/LinearLayout;
    const/16 v1, 0x10

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 883
    invoke-direct {p0, v1}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v1

    const/16 v2, 0xa

    invoke-direct {p0, v2}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v3

    const/16 v4, 0xe

    invoke-direct {p0, v4}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v4

    const/4 v5, 0x4

    invoke-direct {p0, v5}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v5

    invoke-virtual {v0, v1, v3, v4, v5}, Landroid/view/View;->setPadding(IIII)V

    .line 885
    new-instance v1, Landroid/view/View;

    invoke-direct {v1, p0}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 886
    .local v1, "l1":Landroid/view/View;
    const v3, -0xe3dcd2

    invoke-virtual {v1, v3}, Landroid/view/View;->setBackgroundColor(I)V

    .line 887
    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v5, 0x1

    invoke-direct {p0, v5}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v6

    const/4 v7, 0x0

    const/high16 v8, 0x3f800000    # 1.0f

    invoke-direct {v4, v7, v6, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, v1, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 889
    new-instance v4, Landroid/widget/TextView;

    invoke-direct {v4, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 890
    .local v4, "tv":Landroid/widget/TextView;
    invoke-virtual {v4, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 891
    const v6, -0x827a70

    invoke-virtual {v4, v6}, Landroid/widget/TextView;->setTextColor(I)V

    .line 892
    const/high16 v6, 0x41200000    # 10.0f

    invoke-virtual {v4, v6}, Landroid/widget/TextView;->setTextSize(F)V

    .line 893
    sget-object v6, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v4, v6}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 894
    const v6, 0x3e3851ec    # 0.18f

    invoke-virtual {v4, v6}, Landroid/widget/TextView;->setLetterSpacing(F)V

    .line 895
    const/16 v6, 0x11

    invoke-virtual {v4, v6}, Landroid/widget/TextView;->setGravity(I)V

    .line 896
    invoke-direct {p0, v2}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v6

    invoke-direct {p0, v2}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v2

    invoke-virtual {v4, v6, v7, v2, v7}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 897
    invoke-virtual {v0, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 899
    new-instance v2, Landroid/view/View;

    invoke-direct {v2, p0}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 900
    .local v2, "l2":Landroid/view/View;
    invoke-virtual {v2, v3}, Landroid/view/View;->setBackgroundColor(I)V

    .line 901
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {p0, v5}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v5

    invoke-direct {v3, v7, v5, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, v2, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 903
    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 904
    return-void
.end method

.method private addShiftToggle(Landroid/widget/LinearLayout;Ljava/lang/String;I)V
    .locals 5
    .param p1, "parent"    # Landroid/widget/LinearLayout;
    .param p2, "name"    # Ljava/lang/String;
    .param p3, "shiftId"    # I

    .line 721
    invoke-direct {p0, p1, p2}, Lcom/lvteam/OverlayService;->newRow(Landroid/widget/LinearLayout;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v0

    .line 722
    .local v0, "row":Landroid/widget/LinearLayout;
    invoke-direct {p0}, Lcom/lvteam/OverlayService;->makeCheckbox()Landroid/widget/FrameLayout;

    move-result-object v1

    .line 723
    .local v1, "box":Landroid/widget/FrameLayout;
    new-instance v2, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda14;

    invoke-direct {v2, p0, p3}, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda14;-><init>(Lcom/lvteam/OverlayService;I)V

    invoke-virtual {v1, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 737
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v3, 0x1a

    invoke-direct {p0, v3}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v4

    invoke-direct {p0, v3}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v3

    invoke-direct {v2, v4, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 738
    invoke-direct {p0, p1}, Lcom/lvteam/OverlayService;->addRowLine(Landroid/widget/LinearLayout;)V

    .line 739
    return-void
.end method

.method private addSliderRow(Landroid/widget/LinearLayout;Ljava/lang/String;Ljava/lang/String;IIILcom/lvteam/OverlayService$SliderCallback;)V
    .locals 16
    .param p1, "parent"    # Landroid/widget/LinearLayout;
    .param p2, "name"    # Ljava/lang/String;
    .param p3, "suffix"    # Ljava/lang/String;
    .param p4, "min"    # I
    .param p5, "max"    # I
    .param p6, "initial"    # I
    .param p7, "cb"    # Lcom/lvteam/OverlayService$SliderCallback;
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ClickableViewAccessibility"
        }
    .end annotation

    .line 772
    move-object/from16 v6, p0

    move-object/from16 v7, p1

    move/from16 v8, p6

    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, v6}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v9, v0

    .line 773
    .local v9, "labelRow":Landroid/widget/LinearLayout;
    const/16 v0, 0x10

    invoke-virtual {v9, v0}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 774
    invoke-direct {v6, v0}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v0

    const/16 v1, 0x8

    invoke-direct {v6, v1}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v1

    const/16 v2, 0xe

    invoke-direct {v6, v2}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v2

    const/4 v10, 0x0

    invoke-virtual {v9, v0, v1, v2, v10}, Landroid/view/View;->setPadding(IIII)V

    .line 776
    new-instance v0, Landroid/widget/TextView;

    invoke-direct {v0, v6}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v11, v0

    .line 777
    .local v11, "label":Landroid/widget/TextView;
    move-object/from16 v12, p2

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 778
    const v0, -0x19120d

    invoke-virtual {v11, v0}, Landroid/widget/TextView;->setTextColor(I)V

    .line 779
    const/high16 v0, 0x41600000    # 14.0f

    invoke-virtual {v11, v0}, Landroid/widget/TextView;->setTextSize(F)V

    .line 780
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v1, 0x1a

    invoke-direct {v6, v1}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v2

    const/high16 v3, 0x3f800000    # 1.0f

    invoke-direct {v0, v10, v2, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v9, v11, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 782
    new-instance v0, Landroid/widget/TextView;

    invoke-direct {v0, v6}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v13, v0

    .line 783
    .local v13, "valueLabel":Landroid/widget/TextView;
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-object/from16 v14, p3

    invoke-virtual {v0, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v13, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 784
    const v0, -0xd6490a

    invoke-virtual {v13, v0}, Landroid/widget/TextView;->setTextColor(I)V

    .line 785
    const/high16 v2, 0x41500000    # 13.0f

    invoke-virtual {v13, v2}, Landroid/widget/TextView;->setTextSize(F)V

    .line 786
    sget-object v2, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v13, v2}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 787
    const v2, 0x800015

    invoke-virtual {v13, v2}, Landroid/widget/TextView;->setGravity(I)V

    .line 788
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    .line 789
    invoke-direct {v6, v1}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v1

    const/4 v3, -0x2

    invoke-direct {v2, v3, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 788
    invoke-virtual {v9, v13, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 791
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    .line 792
    const/16 v2, 0x22

    invoke-direct {v6, v2}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v2

    const/4 v15, -0x1

    invoke-direct {v1, v15, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 791
    invoke-virtual {v7, v9, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 794
    new-instance v1, Landroid/widget/SeekBar;

    invoke-direct {v1, v6}, Landroid/widget/SeekBar;-><init>(Landroid/content/Context;)V

    move-object v5, v1

    .line 795
    .local v5, "seekBar":Landroid/widget/SeekBar;
    sub-int v1, p5, p4

    invoke-virtual {v5, v1}, Landroid/widget/ProgressBar;->setMax(I)V

    .line 796
    sub-int v1, v8, p4

    invoke-virtual {v5, v1}, Landroid/widget/ProgressBar;->setProgress(I)V

    .line 797
    invoke-static {v0}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v1

    invoke-virtual {v5, v1}, Landroid/widget/ProgressBar;->setProgressTintList(Landroid/content/res/ColorStateList;)V

    .line 798
    invoke-static {v0}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v0

    invoke-virtual {v5, v0}, Landroid/widget/AbsSeekBar;->setThumbTintList(Landroid/content/res/ColorStateList;)V

    .line 799
    const v0, -0xe1dacb

    invoke-static {v0}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v0

    invoke-virtual {v5, v0}, Landroid/widget/ProgressBar;->setProgressBackgroundTintList(Landroid/content/res/ColorStateList;)V

    .line 800
    new-instance v0, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda25;

    invoke-direct {v0}, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda25;-><init>()V

    invoke-virtual {v5, v0}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 804
    new-instance v4, Lcom/lvteam/OverlayService$2;

    move-object v0, v4

    move-object/from16 v1, p0

    move/from16 v2, p4

    move-object v3, v13

    move-object v10, v4

    move-object/from16 v4, p3

    move-object v15, v5

    .end local v5    # "seekBar":Landroid/widget/SeekBar;
    .local v15, "seekBar":Landroid/widget/SeekBar;
    move-object/from16 v5, p7

    invoke-direct/range {v0 .. v5}, Lcom/lvteam/OverlayService$2;-><init>(Lcom/lvteam/OverlayService;ILandroid/widget/TextView;Ljava/lang/String;Lcom/lvteam/OverlayService$SliderCallback;)V

    invoke-virtual {v15, v10}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    .line 813
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    .line 814
    const/16 v1, 0x1c

    invoke-direct {v6, v1}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v1

    const/4 v2, -0x1

    invoke-direct {v0, v2, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 815
    .local v0, "slp":Landroid/widget/LinearLayout$LayoutParams;
    const/16 v1, 0xa

    invoke-direct {v6, v1}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v2

    invoke-direct {v6, v1}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v1

    const/4 v3, 0x6

    invoke-direct {v6, v3}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v3

    const/4 v4, 0x0

    invoke-virtual {v0, v2, v4, v1, v3}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 816
    invoke-virtual {v7, v15, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 817
    invoke-direct/range {p0 .. p1}, Lcom/lvteam/OverlayService;->addRowLine(Landroid/widget/LinearLayout;)V

    .line 818
    return-void
.end method

.method private appVersionName()Ljava/lang/String;
    .locals 3

    .line 1316
    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object v0

    iget-object v0, v0, Landroid/content/pm/PackageInfo;->versionName:Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    .line 1317
    :catch_0
    move-exception v0

    .line 1318
    .local v0, "ignored":Ljava/lang/Exception;
    const-string v1, "-"

    return-object v1
.end method

.method private applyCheckboxStyle(Landroid/widget/FrameLayout;Z)V
    .locals 3
    .param p1, "cb"    # Landroid/widget/FrameLayout;
    .param p2, "on"    # Z

    .line 840
    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v0}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 841
    .local v0, "bg":Landroid/graphics/drawable/GradientDrawable;
    const/16 v1, 0x8

    invoke-direct {p0, v1}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v1

    int-to-float v1, v1

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 842
    const/4 v1, 0x1

    if-eqz p2, :cond_0

    .line 843
    const v2, -0xde690d

    invoke-virtual {v0, v2}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 844
    invoke-direct {p0, v1}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v1

    const v2, -0xb03c09

    invoke-virtual {v0, v1, v2}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    goto :goto_0

    .line 846
    :cond_0
    const v2, -0xf1ebe4

    invoke-virtual {v0, v2}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 847
    invoke-direct {p0, v1}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v1

    const v2, -0xcbc3b6

    invoke-virtual {v0, v1, v2}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 849
    :goto_0
    invoke-virtual {p1, v0}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 850
    const/4 v1, 0x0

    invoke-virtual {p1, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    if-eqz p2, :cond_1

    const/4 v2, -0x1

    goto :goto_1

    :cond_1
    const v2, 0xffffff

    :goto_1
    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 851
    return-void
.end method

.method private buildAimTab(Landroid/widget/LinearLayout;)V
    .locals 11
    .param p1, "c"    # Landroid/widget/LinearLayout;

    .line 462
    const-string v0, "Enable Aim"

    const/4 v1, 0x0

    invoke-direct {p0, p1, v0, v1}, Lcom/lvteam/OverlayService;->addShiftToggle(Landroid/widget/LinearLayout;Ljava/lang/String;I)V

    .line 463
    const-string v0, "Magnetic"

    const-string v1, "Silent"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v5

    const/4 v6, 0x0

    const/4 v7, 0x0

    const-string v4, "Metodo Aim"

    move-object v2, p0

    move-object v3, p1

    invoke-direct/range {v2 .. v7}, Lcom/lvteam/OverlayService;->addDropdownRow(Landroid/widget/LinearLayout;Ljava/lang/String;[Ljava/lang/String;ILcom/lvteam/OverlayService$DropdownCallback;)V

    .line 464
    new-instance v0, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda5;

    invoke-direct {v0}, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda5;-><init>()V

    const-string v1, "Freeze Scop"

    invoke-direct {p0, p1, v1, v0}, Lcom/lvteam/OverlayService;->addFeatureToggle(Landroid/widget/LinearLayout;Ljava/lang/String;Lcom/lvteam/OverlayService$ToggleCallback;)Landroid/widget/FrameLayout;

    .line 465
    new-instance v0, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda6;

    invoke-direct {v0}, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda6;-><init>()V

    const-string v1, "Freeze Fire"

    invoke-direct {p0, p1, v1, v0}, Lcom/lvteam/OverlayService;->addFeatureToggle(Landroid/widget/LinearLayout;Ljava/lang/String;Lcom/lvteam/OverlayService$ToggleCallback;)Landroid/widget/FrameLayout;

    .line 466
    new-instance v0, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda7;

    invoke-direct {v0, p0}, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda7;-><init>(Lcom/lvteam/OverlayService;)V

    const-string v1, "Enable Fov"

    const/4 v2, 0x4

    invoke-direct {p0, p1, v1, v2, v0}, Lcom/lvteam/OverlayService;->addEspToggle(Landroid/widget/LinearLayout;Ljava/lang/String;ILcom/lvteam/OverlayService$ToggleCallback;)Landroid/widget/FrameLayout;

    .line 467
    iget v9, p0, Lcom/lvteam/OverlayService;->fovPercent:I

    new-instance v10, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda8;

    invoke-direct {v10, p0}, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda8;-><init>(Lcom/lvteam/OverlayService;)V

    const-string v5, "Changed Fov"

    const-string v6, "%"

    const/16 v7, 0x32

    const/16 v8, 0xc8

    move-object v3, p0

    move-object v4, p1

    invoke-direct/range {v3 .. v10}, Lcom/lvteam/OverlayService;->addSliderRow(Landroid/widget/LinearLayout;Ljava/lang/String;Ljava/lang/String;IIILcom/lvteam/OverlayService$SliderCallback;)V

    .line 471
    new-instance v0, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda9;

    invoke-direct {v0}, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda9;-><init>()V

    const-string v1, "Aim Line"

    invoke-direct {p0, p1, v1, v0}, Lcom/lvteam/OverlayService;->addFeatureToggle(Landroid/widget/LinearLayout;Ljava/lang/String;Lcom/lvteam/OverlayService$ToggleCallback;)Landroid/widget/FrameLayout;

    .line 472
    new-instance v0, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda10;

    invoke-direct {v0}, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda10;-><init>()V

    const-string v1, "Ignore Derrubados"

    invoke-direct {p0, p1, v1, v0}, Lcom/lvteam/OverlayService;->addFeatureToggle(Landroid/widget/LinearLayout;Ljava/lang/String;Lcom/lvteam/OverlayService$ToggleCallback;)Landroid/widget/FrameLayout;

    .line 473
    return-void
.end method

.method private buildExploitTab(Landroid/widget/LinearLayout;)V
    .locals 10
    .param p1, "c"    # Landroid/widget/LinearLayout;

    .line 569
    const-string v0, "Ghost Hacker"

    const/4 v1, 0x1

    invoke-direct {p0, p1, v0, v1}, Lcom/lvteam/OverlayService;->addShiftToggle(Landroid/widget/LinearLayout;Ljava/lang/String;I)V

    .line 570
    const-string v0, "Teleporte"

    const/4 v1, 0x3

    invoke-direct {p0, p1, v0, v1}, Lcom/lvteam/OverlayService;->addShiftToggle(Landroid/widget/LinearLayout;Ljava/lang/String;I)V

    .line 571
    nop

    .line 572
    invoke-static {}, Lcom/lvteam/LvTeamShift;->getTeleportSpeed()I

    move-result v8

    new-instance v9, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda24;

    invoke-direct {v9}, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda24;-><init>()V

    .line 571
    const-string v4, "Velocidade TP"

    const-string v5, "x"

    const/4 v6, 0x1

    const/16 v7, 0xa

    move-object v2, p0

    move-object v3, p1

    invoke-direct/range {v2 .. v9}, Lcom/lvteam/OverlayService;->addSliderRow(Landroid/widget/LinearLayout;Ljava/lang/String;Ljava/lang/String;IIILcom/lvteam/OverlayService$SliderCallback;)V

    .line 573
    const-string v0, "Under Player"

    const/4 v1, 0x2

    invoke-direct {p0, p1, v0, v1}, Lcom/lvteam/OverlayService;->addShiftToggle(Landroid/widget/LinearLayout;Ljava/lang/String;I)V

    .line 580
    return-void
.end method

.method private buildHeader()Landroid/widget/LinearLayout;
    .locals 13

    .line 296
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 297
    .local v0, "header":Landroid/widget/LinearLayout;
    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 298
    const v2, -0xe9e4de

    invoke-virtual {v0, v2}, Landroid/view/View;->setBackgroundColor(I)V

    .line 300
    new-instance v2, Landroid/widget/LinearLayout;

    invoke-direct {v2, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 301
    .local v2, "row":Landroid/widget/LinearLayout;
    const/16 v3, 0x10

    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 302
    invoke-direct {p0, v3}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v4

    const/16 v5, 0xc

    invoke-direct {p0, v5}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v5

    const/16 v6, 0xa

    invoke-direct {p0, v6}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v6

    const/16 v7, 0x8

    invoke-direct {p0, v7}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v7

    invoke-virtual {v2, v4, v5, v6, v7}, Landroid/view/View;->setPadding(IIII)V

    .line 304
    new-instance v4, Landroid/widget/TextView;

    invoke-direct {v4, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 305
    .local v4, "lvText":Landroid/widget/TextView;
    const-string v5, "LV "

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 306
    const v5, -0xd6490a

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setTextColor(I)V

    .line 307
    const/high16 v6, 0x41880000    # 17.0f

    invoke-virtual {v4, v6}, Landroid/widget/TextView;->setTextSize(F)V

    .line 308
    const v7, 0x3d4ccccd    # 0.05f

    invoke-virtual {v4, v7}, Landroid/widget/TextView;->setLetterSpacing(F)V

    .line 309
    const-string v8, "sans-serif-medium"

    invoke-static {v8, v1}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object v9

    invoke-virtual {v4, v9}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 310
    new-instance v9, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v10, -0x2

    invoke-direct {v9, v10, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v2, v4, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 314
    new-instance v9, Landroid/widget/TextView;

    invoke-direct {v9, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 315
    .local v9, "teamText":Landroid/widget/TextView;
    const-string v11, "TEAM"

    invoke-virtual {v9, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 316
    const v11, -0x19120d

    invoke-virtual {v9, v11}, Landroid/widget/TextView;->setTextColor(I)V

    .line 317
    invoke-virtual {v9, v6}, Landroid/widget/TextView;->setTextSize(F)V

    .line 318
    invoke-virtual {v9, v7}, Landroid/widget/TextView;->setLetterSpacing(F)V

    .line 319
    invoke-static {v8, v1}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object v7

    invoke-virtual {v9, v7}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 320
    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v8, 0x3f800000    # 1.0f

    const/4 v11, 0x0

    invoke-direct {v7, v11, v10, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v2, v9, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 323
    new-instance v7, Landroid/widget/TextView;

    invoke-direct {v7, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 324
    .local v7, "minBtn":Landroid/widget/TextView;
    const-string v8, "\u2500"

    invoke-virtual {v7, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 325
    const v8, -0x827a70

    invoke-virtual {v7, v8}, Landroid/widget/TextView;->setTextColor(I)V

    .line 326
    invoke-virtual {v7, v6}, Landroid/widget/TextView;->setTextSize(F)V

    .line 327
    const/16 v6, 0x11

    invoke-virtual {v7, v6}, Landroid/widget/TextView;->setGravity(I)V

    .line 328
    new-instance v6, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v6}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 329
    .local v6, "minBg":Landroid/graphics/drawable/GradientDrawable;
    const/4 v8, 0x7

    invoke-direct {p0, v8}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v8

    int-to-float v8, v8

    invoke-virtual {v6, v8}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 330
    const v8, -0xe3dccd

    invoke-virtual {v6, v8}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 331
    invoke-direct {p0, v1}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v1

    const v8, -0xcbc3b6

    invoke-virtual {v6, v1, v8}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 332
    invoke-virtual {v7, v6}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 333
    new-instance v1, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda21;

    invoke-direct {v1, p0}, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda21;-><init>(Lcom/lvteam/OverlayService;)V

    invoke-virtual {v7, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 334
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v8, 0x1e

    invoke-direct {p0, v8}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v10

    invoke-direct {p0, v8}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v8

    invoke-direct {v1, v10, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v2, v7, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 336
    invoke-virtual {v0, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 338
    new-instance v1, Landroid/view/View;

    invoke-direct {v1, p0}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 339
    .local v1, "line":Landroid/view/View;
    new-instance v8, Landroid/graphics/drawable/GradientDrawable;

    sget-object v10, Landroid/graphics/drawable/GradientDrawable$Orientation;->LEFT_RIGHT:Landroid/graphics/drawable/GradientDrawable$Orientation;

    filled-new-array {v11, v5, v5, v11}, [I

    move-result-object v5

    invoke-direct {v8, v10, v5}, Landroid/graphics/drawable/GradientDrawable;-><init>(Landroid/graphics/drawable/GradientDrawable$Orientation;[I)V

    move-object v5, v8

    .line 342
    .local v5, "lineBg":Landroid/graphics/drawable/GradientDrawable;
    invoke-virtual {v1, v5}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 343
    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    .line 344
    const/4 v10, 0x2

    invoke-direct {p0, v10}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v10

    const/4 v12, -0x1

    invoke-direct {v8, v12, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 345
    .local v8, "lp":Landroid/widget/LinearLayout$LayoutParams;
    invoke-direct {p0, v3}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v10

    invoke-direct {p0, v3}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v3

    invoke-virtual {v8, v10, v11, v3, v11}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 346
    invoke-virtual {v0, v1, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 348
    return-object v0
.end method

.method private buildPlayersTab(Landroid/widget/LinearLayout;)V
    .locals 16
    .param p1, "c"    # Landroid/widget/LinearLayout;

    .line 511
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    new-instance v2, Landroid/widget/LinearLayout;

    invoke-direct {v2, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 512
    .local v2, "headerRow":Landroid/widget/LinearLayout;
    const/16 v3, 0x10

    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 513
    invoke-direct {v0, v3}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v4

    const/16 v5, 0x8

    invoke-direct {v0, v5}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v6

    const/16 v7, 0xe

    invoke-direct {v0, v7}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v8

    invoke-direct {v0, v5}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v5

    invoke-virtual {v2, v4, v6, v8, v5}, Landroid/view/View;->setPadding(IIII)V

    .line 515
    new-instance v4, Landroid/widget/TextView;

    invoke-direct {v4, v0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 516
    .local v4, "header":Landroid/widget/TextView;
    const-string v5, "Players Detectados"

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 517
    const v5, -0xd6490a

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setTextColor(I)V

    .line 518
    const/high16 v5, 0x41500000    # 13.0f

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setTextSize(F)V

    .line 519
    const-string v6, "sans-serif-medium"

    const/4 v8, 0x1

    invoke-static {v6, v8}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object v6

    invoke-virtual {v4, v6}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 520
    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v9, 0x3f800000    # 1.0f

    const/4 v10, 0x0

    const/4 v11, -0x2

    invoke-direct {v6, v10, v11, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v2, v4, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 523
    new-instance v6, Landroid/widget/TextView;

    invoke-direct {v6, v0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 524
    .local v6, "clearBtn":Landroid/widget/TextView;
    const-string v9, "LIMPAR"

    invoke-virtual {v6, v9}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 525
    const v9, -0x827a70

    invoke-virtual {v6, v9}, Landroid/widget/TextView;->setTextColor(I)V

    .line 526
    const/high16 v12, 0x41200000    # 10.0f

    invoke-virtual {v6, v12}, Landroid/widget/TextView;->setTextSize(F)V

    .line 527
    sget-object v13, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v6, v13}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 528
    const/16 v13, 0x11

    invoke-virtual {v6, v13}, Landroid/widget/TextView;->setGravity(I)V

    .line 529
    const/16 v14, 0xa

    invoke-direct {v0, v14}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v15

    invoke-direct {v0, v14}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v14

    invoke-virtual {v6, v15, v10, v14, v10}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 530
    new-instance v10, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v10}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 531
    .local v10, "clearBg":Landroid/graphics/drawable/GradientDrawable;
    const/4 v14, 0x6

    invoke-direct {v0, v14}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v15

    int-to-float v15, v15

    invoke-virtual {v10, v15}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 532
    const v15, -0xe3dccd

    invoke-virtual {v10, v15}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 533
    invoke-direct {v0, v8}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v15

    const v8, -0xcbc3b6

    invoke-virtual {v10, v15, v8}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 534
    invoke-virtual {v6, v10}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 535
    new-instance v8, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda19;

    invoke-direct {v8, v0}, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda19;-><init>(Lcom/lvteam/OverlayService;)V

    invoke-virtual {v6, v8}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 540
    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    .line 541
    const/16 v15, 0x18

    invoke-direct {v0, v15}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v15

    invoke-direct {v8, v11, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 540
    invoke-virtual {v2, v6, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 543
    invoke-virtual {v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 544
    invoke-direct/range {p0 .. p1}, Lcom/lvteam/OverlayService;->addRowLine(Landroid/widget/LinearLayout;)V

    .line 546
    new-instance v8, Landroid/widget/TextView;

    invoke-direct {v8, v0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 547
    .local v8, "hint":Landroid/widget/TextView;
    const-string v15, "Toque num player para o ESP e o Magnet ignorarem ele"

    invoke-virtual {v8, v15}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 548
    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setTextColor(I)V

    .line 549
    invoke-virtual {v8, v12}, Landroid/widget/TextView;->setTextSize(F)V

    .line 550
    invoke-direct {v0, v3}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v3

    invoke-direct {v0, v14}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v12

    invoke-direct {v0, v7}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v15

    invoke-direct {v0, v14}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v14

    invoke-virtual {v8, v3, v12, v15, v14}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 551
    invoke-virtual {v1, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 553
    new-instance v3, Landroid/widget/TextView;

    invoke-direct {v3, v0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    iput-object v3, v0, Lcom/lvteam/OverlayService;->playerEmptyLabel:Landroid/widget/TextView;

    .line 554
    iget-object v3, v0, Lcom/lvteam/OverlayService;->playerEmptyLabel:Landroid/widget/TextView;

    const-string v12, "Nenhum player detectado"

    invoke-virtual {v3, v12}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 555
    iget-object v3, v0, Lcom/lvteam/OverlayService;->playerEmptyLabel:Landroid/widget/TextView;

    invoke-virtual {v3, v9}, Landroid/widget/TextView;->setTextColor(I)V

    .line 556
    iget-object v3, v0, Lcom/lvteam/OverlayService;->playerEmptyLabel:Landroid/widget/TextView;

    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setTextSize(F)V

    .line 557
    iget-object v3, v0, Lcom/lvteam/OverlayService;->playerEmptyLabel:Landroid/widget/TextView;

    invoke-virtual {v3, v13}, Landroid/widget/TextView;->setGravity(I)V

    .line 558
    iget-object v3, v0, Lcom/lvteam/OverlayService;->playerEmptyLabel:Landroid/widget/TextView;

    invoke-direct {v0, v7}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v5

    const/16 v9, 0x32

    invoke-direct {v0, v9}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v12

    invoke-direct {v0, v7}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v7

    invoke-direct {v0, v9}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v9

    invoke-virtual {v3, v5, v12, v7, v9}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 559
    iget-object v3, v0, Lcom/lvteam/OverlayService;->playerEmptyLabel:Landroid/widget/TextView;

    invoke-virtual {v1, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 561
    new-instance v3, Landroid/widget/LinearLayout;

    invoke-direct {v3, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    iput-object v3, v0, Lcom/lvteam/OverlayService;->playerListContainer:Landroid/widget/LinearLayout;

    .line 562
    iget-object v3, v0, Lcom/lvteam/OverlayService;->playerListContainer:Landroid/widget/LinearLayout;

    const/4 v5, 0x1

    invoke-virtual {v3, v5}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 563
    iget-object v3, v0, Lcom/lvteam/OverlayService;->playerListContainer:Landroid/widget/LinearLayout;

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v7, -0x1

    invoke-direct {v5, v7, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v3, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 566
    return-void
.end method

.method private buildSettingsTab(Landroid/widget/LinearLayout;)V
    .locals 9
    .param p1, "c"    # Landroid/widget/LinearLayout;

    .line 583
    new-instance v0, Landroid/widget/TextView;

    invoke-direct {v0, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 584
    .local v0, "header":Landroid/widget/TextView;
    const-string v1, "Informa\u00e7\u00f5es"

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 585
    const v1, -0xd6490a

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 586
    const/high16 v1, 0x41500000    # 13.0f

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextSize(F)V

    .line 587
    const-string v1, "sans-serif-medium"

    const/4 v2, 0x1

    invoke-static {v1, v2}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 588
    const/16 v1, 0x10

    invoke-direct {p0, v1}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v2

    const/16 v3, 0x8

    invoke-direct {p0, v3}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v4

    const/16 v5, 0xe

    invoke-direct {p0, v5}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v5

    invoke-direct {p0, v3}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v3

    invoke-virtual {v0, v2, v4, v5, v3}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 589
    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 590
    invoke-direct {p0, p1}, Lcom/lvteam/OverlayService;->addRowLine(Landroid/widget/LinearLayout;)V

    .line 592
    const-string v2, "Vers\u00e3o"

    invoke-direct {p0}, Lcom/lvteam/OverlayService;->appVersionName()Ljava/lang/String;

    move-result-object v3

    invoke-direct {p0, p1, v2, v3}, Lcom/lvteam/OverlayService;->addInfoRow(Landroid/widget/LinearLayout;Ljava/lang/String;Ljava/lang/String;)V

    .line 593
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v3, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, " "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v3, Landroid/os/Build;->MODEL:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v3, "Dispositivo"

    invoke-direct {p0, p1, v3, v2}, Lcom/lvteam/OverlayService;->addInfoRow(Landroid/widget/LinearLayout;Ljava/lang/String;Ljava/lang/String;)V

    .line 595
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "API "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v3, "Android"

    invoke-direct {p0, p1, v3, v2}, Lcom/lvteam/OverlayService;->addInfoRow(Landroid/widget/LinearLayout;Ljava/lang/String;Ljava/lang/String;)V

    .line 597
    new-instance v2, Landroid/view/View;

    invoke-direct {v2, p0}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 598
    .local v2, "spacer":Landroid/view/View;
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    .line 599
    const/16 v4, 0x18

    invoke-direct {p0, v4}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v4

    const/4 v5, -0x1

    invoke-direct {v3, v5, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 598
    invoke-virtual {p1, v2, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 601
    new-instance v3, Landroid/widget/TextView;

    invoke-direct {v3, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 602
    .local v3, "exitBtn":Landroid/widget/TextView;
    const-string v4, "EXIT"

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 603
    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setTextColor(I)V

    .line 604
    const/high16 v4, 0x41700000    # 15.0f

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setTextSize(F)V

    .line 605
    sget-object v4, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 606
    const v4, 0x3dcccccd    # 0.1f

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setLetterSpacing(F)V

    .line 607
    const/16 v4, 0x11

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setGravity(I)V

    .line 608
    new-instance v4, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v4}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 609
    .local v4, "exitBg":Landroid/graphics/drawable/GradientDrawable;
    const v6, -0x1ac6cb

    invoke-virtual {v4, v6}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 610
    const/16 v6, 0x9

    invoke-direct {p0, v6}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v6

    int-to-float v6, v6

    invoke-virtual {v4, v6}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 611
    invoke-virtual {v3, v4}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 612
    const/16 v6, 0xc

    invoke-direct {p0, v6}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v7

    invoke-direct {p0, v6}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v6

    const/4 v8, 0x0

    invoke-virtual {v3, v8, v7, v8, v6}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 613
    new-instance v6, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda23;

    invoke-direct {v6, p0}, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda23;-><init>(Lcom/lvteam/OverlayService;)V

    invoke-virtual {v3, v6}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 614
    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v7, -0x2

    invoke-direct {v6, v5, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object v5, v6

    .line 617
    .local v5, "elp":Landroid/widget/LinearLayout$LayoutParams;
    invoke-direct {p0, v1}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v6

    invoke-direct {p0, v1}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v1

    invoke-virtual {v5, v6, v8, v1, v8}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 618
    invoke-virtual {p1, v3, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 619
    return-void
.end method

.method private buildSidebar()Landroid/widget/LinearLayout;
    .locals 16

    .line 352
    move-object/from16 v0, p0

    new-instance v1, Landroid/widget/LinearLayout;

    invoke-direct {v1, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 353
    .local v1, "sidebar":Landroid/widget/LinearLayout;
    const/4 v2, 0x1

    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 354
    const v3, -0xf2eee9

    invoke-virtual {v1, v3}, Landroid/view/View;->setBackgroundColor(I)V

    .line 355
    const/16 v3, 0x8

    invoke-direct {v0, v3}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v4

    invoke-direct {v0, v3}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v3

    const/4 v5, 0x0

    invoke-virtual {v1, v5, v4, v5, v3}, Landroid/view/View;->setPadding(IIII)V

    .line 357
    const/4 v3, 0x0

    .local v3, "i":I
    :goto_0
    const/4 v4, 0x5

    if-ge v3, v4, :cond_0

    .line 358
    move v6, v3

    .line 359
    .local v6, "tab":I
    new-instance v7, Landroid/widget/LinearLayout;

    invoke-direct {v7, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 360
    .local v7, "item":Landroid/widget/LinearLayout;
    invoke-virtual {v7, v5}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 361
    const/16 v8, 0x10

    invoke-virtual {v7, v8}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 363
    new-instance v9, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v9}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 364
    .local v9, "itemBg":Landroid/graphics/drawable/GradientDrawable;
    const/16 v10, 0xa

    invoke-direct {v0, v10}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v10

    int-to-float v10, v10

    invoke-virtual {v9, v10}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 365
    invoke-virtual {v7, v9}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 366
    invoke-virtual {v7, v9}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 368
    new-instance v10, Landroid/view/View;

    invoke-direct {v10, v0}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 369
    .local v10, "accent":Landroid/view/View;
    new-instance v11, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v11}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 370
    .local v11, "accentBg":Landroid/graphics/drawable/GradientDrawable;
    const/4 v12, 0x2

    invoke-direct {v0, v12}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v12

    int-to-float v12, v12

    invoke-virtual {v11, v12}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 371
    invoke-virtual {v10, v11}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 372
    new-instance v12, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v13, 0x3

    invoke-direct {v0, v13}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v14

    const/16 v15, 0x14

    invoke-direct {v0, v15}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v13

    invoke-direct {v12, v14, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 373
    .local v12, "accentLp":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v13, 0x4

    invoke-direct {v0, v13}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v13

    const/4 v14, 0x7

    invoke-direct {v0, v14}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v4

    invoke-virtual {v12, v13, v5, v4, v5}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 374
    invoke-virtual {v7, v10, v12}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 376
    new-instance v4, Landroid/widget/TextView;

    invoke-direct {v4, v0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 377
    .local v4, "icon":Landroid/widget/TextView;
    sget-object v13, Lcom/lvteam/OverlayService;->TAB_ICONS:[Ljava/lang/String;

    aget-object v13, v13, v3

    invoke-virtual {v4, v13}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 378
    const/high16 v13, 0x41500000    # 13.0f

    invoke-virtual {v4, v13}, Landroid/widget/TextView;->setTextSize(F)V

    .line 379
    const/16 v5, 0x11

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setGravity(I)V

    .line 380
    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v0, v15}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v14

    invoke-direct {v0, v15}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v15

    invoke-direct {v5, v14, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v7, v4, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 382
    new-instance v5, Landroid/widget/TextView;

    invoke-direct {v5, v0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 383
    .local v5, "label":Landroid/widget/TextView;
    sget-object v14, Lcom/lvteam/OverlayService;->TAB_NAMES:[Ljava/lang/String;

    aget-object v14, v14, v3

    invoke-virtual {v5, v14}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 384
    invoke-virtual {v5, v13}, Landroid/widget/TextView;->setTextSize(F)V

    .line 385
    const-string v13, "sans-serif-medium"

    invoke-static {v13, v2}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object v13

    invoke-virtual {v5, v13}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 386
    invoke-virtual {v5, v8}, Landroid/widget/TextView;->setGravity(I)V

    .line 387
    const/4 v8, 0x7

    invoke-direct {v0, v8}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v8

    const/4 v13, 0x0

    invoke-virtual {v5, v8, v13, v13, v13}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 388
    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v14, 0x3f800000    # 1.0f

    const/4 v15, -0x1

    invoke-direct {v8, v13, v15, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v7, v5, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 391
    new-instance v8, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda4;

    invoke-direct {v8, v0, v6}, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda4;-><init>(Lcom/lvteam/OverlayService;I)V

    invoke-virtual {v7, v8}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 393
    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    .line 394
    const/16 v14, 0x30

    invoke-direct {v0, v14}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v14

    invoke-direct {v8, v15, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 395
    .local v8, "itemLp":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v14, 0x5

    invoke-direct {v0, v14}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v15

    const/4 v2, 0x3

    invoke-direct {v0, v2}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v13

    invoke-direct {v0, v14}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v14

    invoke-direct {v0, v2}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v2

    invoke-virtual {v8, v15, v13, v14, v2}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 396
    invoke-virtual {v1, v7, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 398
    iget-object v2, v0, Lcom/lvteam/OverlayService;->sidebarItems:[Landroid/widget/LinearLayout;

    aput-object v7, v2, v3

    .line 399
    iget-object v2, v0, Lcom/lvteam/OverlayService;->sidebarIcons:[Landroid/widget/TextView;

    aput-object v4, v2, v3

    .line 400
    iget-object v2, v0, Lcom/lvteam/OverlayService;->sidebarLabels:[Landroid/widget/TextView;

    aput-object v5, v2, v3

    .line 401
    iget-object v2, v0, Lcom/lvteam/OverlayService;->sidebarAccents:[Landroid/view/View;

    aput-object v10, v2, v3

    .line 357
    .end local v4    # "icon":Landroid/widget/TextView;
    .end local v5    # "label":Landroid/widget/TextView;
    .end local v6    # "tab":I
    .end local v7    # "item":Landroid/widget/LinearLayout;
    .end local v8    # "itemLp":Landroid/widget/LinearLayout$LayoutParams;
    .end local v9    # "itemBg":Landroid/graphics/drawable/GradientDrawable;
    .end local v10    # "accent":Landroid/view/View;
    .end local v11    # "accentBg":Landroid/graphics/drawable/GradientDrawable;
    .end local v12    # "accentLp":Landroid/widget/LinearLayout$LayoutParams;
    add-int/lit8 v3, v3, 0x1

    const/4 v2, 0x1

    const/4 v5, 0x0

    goto/16 :goto_0

    :cond_0
    nop

    .line 403
    .end local v3    # "i":I
    return-object v1
.end method

.method private buildTabPanel(I)Landroid/widget/LinearLayout;
    .locals 6
    .param p1, "tab"    # I

    .line 428
    new-instance v0, Landroid/widget/ScrollView;

    invoke-direct {v0, p0}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    .line 429
    .local v0, "scroll":Landroid/widget/ScrollView;
    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/ScrollView;->setFillViewport(Z)V

    .line 430
    new-instance v2, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda13;

    invoke-direct {v2}, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda13;-><init>()V

    invoke-virtual {v0, v2}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 435
    new-instance v2, Landroid/widget/LinearLayout;

    invoke-direct {v2, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 436
    .local v2, "content":Landroid/widget/LinearLayout;
    invoke-virtual {v2, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 437
    const/4 v3, 0x4

    invoke-direct {p0, v3}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v3

    const/16 v4, 0x8

    invoke-direct {p0, v4}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v4

    const/4 v5, 0x0

    invoke-virtual {v2, v5, v3, v5, v4}, Landroid/view/View;->setPadding(IIII)V

    .line 439
    packed-switch p1, :pswitch_data_0

    goto :goto_0

    .line 444
    :pswitch_0
    invoke-direct {p0, v2}, Lcom/lvteam/OverlayService;->buildSettingsTab(Landroid/widget/LinearLayout;)V

    goto :goto_0

    .line 443
    :pswitch_1
    invoke-direct {p0, v2}, Lcom/lvteam/OverlayService;->buildExploitTab(Landroid/widget/LinearLayout;)V

    goto :goto_0

    .line 442
    :pswitch_2
    invoke-direct {p0, v2}, Lcom/lvteam/OverlayService;->buildPlayersTab(Landroid/widget/LinearLayout;)V

    goto :goto_0

    .line 441
    :pswitch_3
    invoke-direct {p0, v2}, Lcom/lvteam/OverlayService;->buildViewsTab(Landroid/widget/LinearLayout;)V

    goto :goto_0

    .line 440
    :pswitch_4
    invoke-direct {p0, v2}, Lcom/lvteam/OverlayService;->buildAimTab(Landroid/widget/LinearLayout;)V

    .line 447
    :goto_0
    new-instance v3, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v4, -0x2

    const/4 v5, -0x1

    invoke-direct {v3, v5, v4}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v2, v3}, Landroid/widget/ScrollView;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 451
    new-instance v3, Landroid/widget/LinearLayout;

    invoke-direct {v3, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 452
    .local v3, "wrapper":Landroid/widget/LinearLayout;
    invoke-virtual {v3, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 453
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v1, v5, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v3, v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 456
    return-object v3

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method private buildThicknessPicker(Landroid/widget/LinearLayout;)V
    .locals 8
    .param p1, "parent"    # Landroid/widget/LinearLayout;

    .line 907
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 908
    .local v0, "row":Landroid/widget/LinearLayout;
    const/16 v1, 0x10

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 909
    invoke-direct {p0, v1}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v1

    const/4 v2, 0x2

    invoke-direct {p0, v2}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v2

    const/16 v3, 0xe

    invoke-direct {p0, v3}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v3

    const/4 v4, 0x6

    invoke-direct {p0, v4}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v4

    invoke-virtual {v0, v1, v2, v3, v4}, Landroid/view/View;->setPadding(IIII)V

    .line 911
    const-string v1, "\u25c2"

    invoke-direct {p0, v1}, Lcom/lvteam/OverlayService;->styledArrow(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v1

    .line 912
    .local v1, "prev":Landroid/widget/TextView;
    new-instance v2, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda11;

    invoke-direct {v2, p0}, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda11;-><init>(Lcom/lvteam/OverlayService;)V

    invoke-virtual {v1, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 913
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v3, 0x20

    invoke-direct {p0, v3}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v4

    invoke-direct {p0, v3}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v5

    invoke-direct {v2, v4, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 915
    new-instance v2, Landroid/widget/TextView;

    invoke-direct {v2, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    iput-object v2, p0, Lcom/lvteam/OverlayService;->thicknessLabel:Landroid/widget/TextView;

    .line 916
    iget-object v2, p0, Lcom/lvteam/OverlayService;->thicknessLabel:Landroid/widget/TextView;

    iget-object v4, p0, Lcom/lvteam/OverlayService;->thicknesses:[F

    iget v5, p0, Lcom/lvteam/OverlayService;->thicknessIndex:I

    aget v4, v4, v5

    invoke-static {v4}, Ljava/lang/String;->valueOf(F)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 917
    iget-object v2, p0, Lcom/lvteam/OverlayService;->thicknessLabel:Landroid/widget/TextView;

    const v4, -0x19120d

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTextColor(I)V

    .line 918
    iget-object v2, p0, Lcom/lvteam/OverlayService;->thicknessLabel:Landroid/widget/TextView;

    const/high16 v4, 0x41400000    # 12.0f

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTextSize(F)V

    .line 919
    iget-object v2, p0, Lcom/lvteam/OverlayService;->thicknessLabel:Landroid/widget/TextView;

    sget-object v4, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 920
    iget-object v2, p0, Lcom/lvteam/OverlayService;->thicknessLabel:Landroid/widget/TextView;

    const/16 v4, 0x11

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setGravity(I)V

    .line 921
    iget-object v2, p0, Lcom/lvteam/OverlayService;->thicknessLabel:Landroid/widget/TextView;

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {p0, v3}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v5

    const/high16 v6, 0x3f800000    # 1.0f

    const/4 v7, 0x0

    invoke-direct {v4, v7, v5, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, v2, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 923
    const-string v2, "\u25b8"

    invoke-direct {p0, v2}, Lcom/lvteam/OverlayService;->styledArrow(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v2

    .line 924
    .local v2, "next":Landroid/widget/TextView;
    new-instance v4, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda12;

    invoke-direct {v4, p0}, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda12;-><init>(Lcom/lvteam/OverlayService;)V

    invoke-virtual {v2, v4}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 925
    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {p0, v3}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v5

    invoke-direct {p0, v3}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v3

    invoke-direct {v4, v5, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v2, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 927
    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 928
    return-void
.end method

.method private buildViewsTab(Landroid/widget/LinearLayout;)V
    .locals 11
    .param p1, "c"    # Landroid/widget/LinearLayout;

    .line 476
    new-instance v0, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda28;

    invoke-direct {v0, p0}, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda28;-><init>(Lcom/lvteam/OverlayService;)V

    const-string v1, "Enable Esp"

    invoke-direct {p0, p1, v1, v0}, Lcom/lvteam/OverlayService;->addFeatureToggle(Landroid/widget/LinearLayout;Ljava/lang/String;Lcom/lvteam/OverlayService$ToggleCallback;)Landroid/widget/FrameLayout;

    move-result-object v0

    iput-object v0, p0, Lcom/lvteam/OverlayService;->espMasterBox:Landroid/widget/FrameLayout;

    .line 480
    new-instance v0, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda29;

    invoke-direct {v0, p0}, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda29;-><init>(Lcom/lvteam/OverlayService;)V

    const-string v1, "Esp Line"

    const/4 v2, 0x1

    invoke-direct {p0, p1, v1, v2, v0}, Lcom/lvteam/OverlayService;->addEspToggle(Landroid/widget/LinearLayout;Ljava/lang/String;ILcom/lvteam/OverlayService$ToggleCallback;)Landroid/widget/FrameLayout;

    .line 485
    new-instance v0, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda30;

    invoke-direct {v0, p0}, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda30;-><init>(Lcom/lvteam/OverlayService;)V

    const-string v1, "Esp Box"

    const/4 v2, 0x0

    invoke-direct {p0, p1, v1, v2, v0}, Lcom/lvteam/OverlayService;->addEspToggle(Landroid/widget/LinearLayout;Ljava/lang/String;ILcom/lvteam/OverlayService$ToggleCallback;)Landroid/widget/FrameLayout;

    .line 490
    new-instance v0, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda31;

    invoke-direct {v0, p0}, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda31;-><init>(Lcom/lvteam/OverlayService;)V

    const-string v1, "Esp Name"

    const/4 v2, 0x2

    invoke-direct {p0, p1, v1, v2, v0}, Lcom/lvteam/OverlayService;->addEspToggle(Landroid/widget/LinearLayout;Ljava/lang/String;ILcom/lvteam/OverlayService$ToggleCallback;)Landroid/widget/FrameLayout;

    .line 495
    new-instance v0, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda32;

    invoke-direct {v0, p0}, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda32;-><init>(Lcom/lvteam/OverlayService;)V

    const-string v1, "Esp Distance"

    const/4 v2, 0x3

    invoke-direct {p0, p1, v1, v2, v0}, Lcom/lvteam/OverlayService;->addEspToggle(Landroid/widget/LinearLayout;Ljava/lang/String;ILcom/lvteam/OverlayService$ToggleCallback;)Landroid/widget/FrameLayout;

    .line 500
    iget v9, p0, Lcom/lvteam/OverlayService;->maxDistanceM:I

    new-instance v10, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda33;

    invoke-direct {v10, p0}, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda33;-><init>(Lcom/lvteam/OverlayService;)V

    const-string v5, "Max Distance"

    const-string v6, "m"

    const/16 v7, 0xa

    const/16 v8, 0xc8

    move-object v3, p0

    move-object v4, p1

    invoke-direct/range {v3 .. v10}, Lcom/lvteam/OverlayService;->addSliderRow(Landroid/widget/LinearLayout;Ljava/lang/String;Ljava/lang/String;IIILcom/lvteam/OverlayService$SliderCallback;)V

    .line 501
    const-string v0, "Corner"

    const-string v1, "Full"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v5

    const/4 v6, 0x0

    const/4 v7, 0x0

    const-string v4, "Box Style"

    move-object v2, p0

    move-object v3, p1

    invoke-direct/range {v2 .. v7}, Lcom/lvteam/OverlayService;->addDropdownRow(Landroid/widget/LinearLayout;Ljava/lang/String;[Ljava/lang/String;ILcom/lvteam/OverlayService$DropdownCallback;)V

    .line 502
    new-instance v0, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda34;

    invoke-direct {v0, p0}, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda34;-><init>(Lcom/lvteam/OverlayService;)V

    const-string v1, "Enemy Count"

    invoke-direct {p0, p1, v1, v0}, Lcom/lvteam/OverlayService;->addFeatureToggle(Landroid/widget/LinearLayout;Ljava/lang/String;Lcom/lvteam/OverlayService$ToggleCallback;)Landroid/widget/FrameLayout;

    .line 506
    const-string v0, "ESPESSURA"

    invoke-direct {p0, p1, v0}, Lcom/lvteam/OverlayService;->addSectionLabel(Landroid/widget/LinearLayout;Ljava/lang/String;)V

    .line 507
    invoke-direct {p0, p1}, Lcom/lvteam/OverlayService;->buildThicknessPicker(Landroid/widget/LinearLayout;)V

    .line 508
    return-void
.end method

.method private changeThickness(I)V
    .locals 4
    .param p1, "dir"    # I

    .line 969
    iget v0, p0, Lcom/lvteam/OverlayService;->thicknessIndex:I

    add-int/2addr v0, p1

    .line 970
    .local v0, "next":I
    if-ltz v0, :cond_0

    iget-object v1, p0, Lcom/lvteam/OverlayService;->thicknesses:[F

    array-length v1, v1

    if-lt v0, v1, :cond_1

    :cond_0
    goto :goto_0

    .line 971
    :cond_1
    iput v0, p0, Lcom/lvteam/OverlayService;->thicknessIndex:I

    .line 972
    iget-object v1, p0, Lcom/lvteam/OverlayService;->thicknessLabel:Landroid/widget/TextView;

    iget-object v2, p0, Lcom/lvteam/OverlayService;->thicknesses:[F

    iget v3, p0, Lcom/lvteam/OverlayService;->thicknessIndex:I

    aget v2, v2, v3

    invoke-static {v2}, Ljava/lang/String;->valueOf(F)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 973
    iget-object v1, p0, Lcom/lvteam/OverlayService;->circleOverlay:Landroid/view/View;

    if-eqz v1, :cond_2

    iget-object v1, p0, Lcom/lvteam/OverlayService;->circleOverlay:Landroid/view/View;

    invoke-direct {p0}, Lcom/lvteam/OverlayService;->circleBackground()Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 974
    :cond_2
    invoke-direct {p0}, Lcom/lvteam/OverlayService;->updateBoxStyle()V

    .line 975
    return-void

    .line 970
    :goto_0
    return-void
.end method

.method private circleBackground()Landroid/graphics/drawable/GradientDrawable;
    .locals 5

    .line 1302
    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v0}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 1303
    .local v0, "bg":Landroid/graphics/drawable/GradientDrawable;
    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    .line 1304
    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 1305
    iget-object v1, p0, Lcom/lvteam/OverlayService;->thicknesses:[F

    iget v2, p0, Lcom/lvteam/OverlayService;->thicknessIndex:I

    aget v1, v1, v2

    .line 1306
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v2

    iget v2, v2, Landroid/util/DisplayMetrics;->density:F

    mul-float/2addr v1, v2

    .line 1305
    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    iget-object v2, p0, Lcom/lvteam/OverlayService;->colors:[I

    iget-object v3, p0, Lcom/lvteam/OverlayService;->elementColor:[I

    const/4 v4, 0x4

    aget v3, v3, v4

    aget v2, v2, v3

    invoke-virtual {v0, v1, v2}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 1307
    return-object v0
.end method

.method private dp(I)I
    .locals 2
    .param p1, "value"    # I

    .line 1311
    int-to-float v0, p1

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v1

    iget v1, v1, Landroid/util/DisplayMetrics;->density:F

    mul-float/2addr v0, v1

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    return v0
.end method

.method private enableEspMaster()V
    .locals 3

    .line 670
    iget-boolean v0, p0, Lcom/lvteam/OverlayService;->espEnabled:Z

    if-eqz v0, :cond_0

    return-void

    .line 671
    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/lvteam/OverlayService;->espEnabled:Z

    .line 672
    iget-object v1, p0, Lcom/lvteam/OverlayService;->espMasterBox:Landroid/widget/FrameLayout;

    if-nez v1, :cond_1

    return-void

    .line 673
    :cond_1
    iget-object v1, p0, Lcom/lvteam/OverlayService;->espMasterBox:Landroid/widget/FrameLayout;

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 674
    iget-object v1, p0, Lcom/lvteam/OverlayService;->espMasterBox:Landroid/widget/FrameLayout;

    invoke-direct {p0, v1, v0}, Lcom/lvteam/OverlayService;->applyCheckboxStyle(Landroid/widget/FrameLayout;Z)V

    .line 675
    return-void
.end method

.method private highlightTab(I)V
    .locals 8
    .param p1, "tab"    # I

    .line 415
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_0
    const/4 v1, 0x5

    if-ge v0, v1, :cond_7

    .line 416
    const/4 v1, 0x1

    const/4 v2, 0x0

    if-ne v0, p1, :cond_0

    move v3, v1

    goto :goto_1

    :cond_0
    move v3, v2

    .line 417
    .local v3, "on":Z
    :goto_1
    iget-object v4, p0, Lcom/lvteam/OverlayService;->sidebarIcons:[Landroid/widget/TextView;

    aget-object v4, v4, v0

    const v5, -0x827a70

    const v6, -0xd6490a

    if-eqz v3, :cond_1

    move v7, v6

    goto :goto_2

    :cond_1
    move v7, v5

    :goto_2
    invoke-virtual {v4, v7}, Landroid/widget/TextView;->setTextColor(I)V

    .line 418
    iget-object v4, p0, Lcom/lvteam/OverlayService;->sidebarLabels:[Landroid/widget/TextView;

    aget-object v4, v4, v0

    if-eqz v3, :cond_2

    move v5, v6

    :cond_2
    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setTextColor(I)V

    .line 419
    iget-object v4, p0, Lcom/lvteam/OverlayService;->sidebarItems:[Landroid/widget/LinearLayout;

    aget-object v4, v4, v0

    invoke-virtual {v4}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/graphics/drawable/GradientDrawable;

    .line 420
    .local v4, "bg":Landroid/graphics/drawable/GradientDrawable;
    if-eqz v3, :cond_3

    const v5, -0xe9ddcc

    goto :goto_3

    :cond_3
    move v5, v2

    :goto_3
    invoke-virtual {v4, v5}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 421
    if-eqz v3, :cond_4

    invoke-direct {p0, v1}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v1

    goto :goto_4

    :cond_4
    move v1, v2

    :goto_4
    if-eqz v3, :cond_5

    const v5, 0x662196f3

    goto :goto_5

    :cond_5
    move v5, v2

    :goto_5
    invoke-virtual {v4, v1, v5}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 422
    iget-object v1, p0, Lcom/lvteam/OverlayService;->sidebarAccents:[Landroid/view/View;

    aget-object v1, v1, v0

    invoke-virtual {v1}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v1

    check-cast v1, Landroid/graphics/drawable/GradientDrawable;

    .line 423
    if-eqz v3, :cond_6

    move v2, v6

    :cond_6
    invoke-virtual {v1, v2}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 415
    .end local v3    # "on":Z
    .end local v4    # "bg":Landroid/graphics/drawable/GradientDrawable;
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_7
    nop

    .line 425
    .end local v0    # "i":I
    return-void
.end method

.method private initShiftOverlayIfNeeded()V
    .locals 1

    .line 1257
    sget-object v0, Lcom/lvteam/LvShiftOverlay;->ctx:Landroid/content/Context;

    if-nez v0, :cond_0

    invoke-static {p0}, Lcom/lvteam/LvShiftOverlay;->init(Landroid/content/Context;)V

    .line 1258
    :cond_0
    return-void
.end method

.method private killApp(Ljava/lang/String;)V
    .locals 4
    .param p1, "message"    # Ljava/lang/String;

    .line 1285
    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v1, 0x1

    invoke-static {v0, p1, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    .line 1286
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 1287
    :goto_0
    goto :goto_1

    :catch_0
    move-exception v0

    goto :goto_0

    .line 1288
    :goto_1
    invoke-virtual {p0}, Landroid/app/Service;->stopSelf()V

    .line 1289
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v1, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda26;

    invoke-direct {v1}, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda26;-><init>()V

    const-wide/16 v2, 0x5dc

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 1293
    return-void
.end method

.method private static synthetic lambda$addDropdownRow$20([Ljava/lang/String;Landroid/widget/TextView;Lcom/lvteam/OverlayService$DropdownCallback;Landroid/view/View;)V
    .locals 3
    .param p0, "options"    # [Ljava/lang/String;
    .param p1, "dd"    # Landroid/widget/TextView;
    .param p2, "cb"    # Lcom/lvteam/OverlayService$DropdownCallback;
    .param p3, "v"    # Landroid/view/View;

    .line 759
    invoke-virtual {p3}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    add-int/lit8 v0, v0, 0x1

    array-length v1, p0

    rem-int/2addr v0, v1

    .line 760
    .local v0, "idx":I
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {p3, v1}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 761
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    aget-object v2, p0, v0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "  \u25bc"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 762
    if-eqz p2, :cond_0

    invoke-interface {p2, v0}, Lcom/lvteam/OverlayService$DropdownCallback;->onSelect(I)V

    .line 763
    :cond_0
    return-void
.end method

.method private synthetic lambda$addEspToggle$17(Lcom/lvteam/OverlayService$ToggleCallback;Landroid/view/View;)V
    .locals 2
    .param p1, "cb"    # Lcom/lvteam/OverlayService$ToggleCallback;
    .param p2, "v"    # Landroid/view/View;

    .line 684
    invoke-static {}, Lcom/lvteam/LvSession;->get()Lcom/lvteam/LvSession;

    move-result-object v0

    invoke-virtual {v0}, Lcom/lvteam/LvSession;->isActive()Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    .line 685
    :cond_0
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {p2}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/Boolean;->equals(Ljava/lang/Object;)Z

    move-result v0

    xor-int/lit8 v0, v0, 0x1

    .line 686
    .local v0, "on":Z
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {p2, v1}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 687
    move-object v1, p2

    check-cast v1, Landroid/widget/FrameLayout;

    invoke-direct {p0, v1, v0}, Lcom/lvteam/OverlayService;->applyCheckboxStyle(Landroid/widget/FrameLayout;Z)V

    .line 688
    invoke-interface {p1, v0}, Lcom/lvteam/OverlayService$ToggleCallback;->onToggle(Z)V

    .line 689
    return-void
.end method

.method private synthetic lambda$addFeatureToggle$16(Lcom/lvteam/OverlayService$ToggleCallback;Landroid/view/View;)V
    .locals 2
    .param p1, "cb"    # Lcom/lvteam/OverlayService$ToggleCallback;
    .param p2, "v"    # Landroid/view/View;

    .line 657
    invoke-static {}, Lcom/lvteam/LvSession;->get()Lcom/lvteam/LvSession;

    move-result-object v0

    invoke-virtual {v0}, Lcom/lvteam/LvSession;->isActive()Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    .line 658
    :cond_0
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {p2}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/Boolean;->equals(Ljava/lang/Object;)Z

    move-result v0

    xor-int/lit8 v0, v0, 0x1

    .line 659
    .local v0, "on":Z
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {p2, v1}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 660
    move-object v1, p2

    check-cast v1, Landroid/widget/FrameLayout;

    invoke-direct {p0, v1, v0}, Lcom/lvteam/OverlayService;->applyCheckboxStyle(Landroid/widget/FrameLayout;Z)V

    .line 661
    invoke-interface {p1, v0}, Lcom/lvteam/OverlayService$ToggleCallback;->onToggle(Z)V

    .line 662
    return-void
.end method

.method private synthetic lambda$addShiftToggle$19(ILandroid/view/View;)V
    .locals 2
    .param p1, "shiftId"    # I
    .param p2, "v"    # Landroid/view/View;

    .line 724
    invoke-static {}, Lcom/lvteam/LvSession;->get()Lcom/lvteam/LvSession;

    move-result-object v0

    invoke-virtual {v0}, Lcom/lvteam/LvSession;->isActive()Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    .line 725
    :cond_0
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {p2}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/Boolean;->equals(Ljava/lang/Object;)Z

    move-result v0

    xor-int/lit8 v0, v0, 0x1

    .line 726
    .local v0, "on":Z
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {p2, v1}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 727
    move-object v1, p2

    check-cast v1, Landroid/widget/FrameLayout;

    invoke-direct {p0, v1, v0}, Lcom/lvteam/OverlayService;->applyCheckboxStyle(Landroid/widget/FrameLayout;Z)V

    .line 728
    invoke-direct {p0}, Lcom/lvteam/OverlayService;->initShiftOverlayIfNeeded()V

    .line 729
    packed-switch p1, :pswitch_data_0

    goto :goto_0

    .line 734
    :pswitch_0
    invoke-static {v0}, Lcom/lvteam/LvShiftOverlay;->setWallVisible(Z)V

    goto :goto_0

    .line 733
    :pswitch_1
    invoke-static {v0}, Lcom/lvteam/LvShiftOverlay;->setTpBaseVisible(Z)V

    goto :goto_0

    .line 732
    :pswitch_2
    invoke-static {v0}, Lcom/lvteam/LvShiftOverlay;->setTatuVisible(Z)V

    goto :goto_0

    .line 731
    :pswitch_3
    invoke-static {v0}, Lcom/lvteam/LvShiftOverlay;->setGhostVisible(Z)V

    goto :goto_0

    .line 730
    :pswitch_4
    invoke-static {v0}, Lcom/lvteam/LvShiftOverlay;->setMagnetVisible(Z)V

    .line 736
    :goto_0
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method private static synthetic lambda$addSliderRow$21(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 2
    .param p0, "v"    # Landroid/view/View;
    .param p1, "ev"    # Landroid/view/MotionEvent;

    .line 801
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    const/4 v1, 0x1

    invoke-interface {v0, v1}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    .line 802
    const/4 v0, 0x0

    return v0
.end method

.method private synthetic lambda$buildAimTab$4(I)V
    .locals 0
    .param p1, "val"    # I

    .line 468
    iput p1, p0, Lcom/lvteam/OverlayService;->fovPercent:I

    .line 469
    invoke-direct {p0}, Lcom/lvteam/OverlayService;->updateCircleSize()V

    .line 470
    return-void
.end method

.method private static synthetic lambda$buildAimTab$5(Z)V
    .locals 0
    .param p0, "enabled"    # Z

    .line 471
    return-void
.end method

.method private static synthetic lambda$buildAimTab$6(Z)V
    .locals 0
    .param p0, "enabled"    # Z

    .line 472
    return-void
.end method

.method private synthetic lambda$buildHeader$1(Landroid/view/View;)V
    .locals 1
    .param p1, "v"    # Landroid/view/View;

    .line 333
    const/4 v0, 0x1

    invoke-direct {p0, v0}, Lcom/lvteam/OverlayService;->setMinimized(Z)V

    return-void
.end method

.method private synthetic lambda$buildPlayersTab$14(Landroid/view/View;)V
    .locals 1
    .param p1, "v"    # Landroid/view/View;

    .line 536
    iget-object v0, p0, Lcom/lvteam/OverlayService;->ignoredIds:Ljava/util/Set;

    invoke-interface {v0}, Ljava/util/Set;->clear()V

    .line 537
    invoke-direct {p0}, Lcom/lvteam/OverlayService;->syncIgnoredSlots()V

    .line 538
    invoke-direct {p0}, Lcom/lvteam/OverlayService;->refreshPlayerList()V

    .line 539
    return-void
.end method

.method private synthetic lambda$buildSettingsTab$15(Landroid/view/View;)V
    .locals 1
    .param p1, "v"    # Landroid/view/View;

    .line 613
    const-string v0, "Saindo..."

    invoke-direct {p0, v0}, Lcom/lvteam/OverlayService;->killApp(Ljava/lang/String;)V

    return-void
.end method

.method private synthetic lambda$buildSidebar$2(ILandroid/view/View;)V
    .locals 0
    .param p1, "tab"    # I
    .param p2, "v"    # Landroid/view/View;

    .line 391
    invoke-direct {p0, p1}, Lcom/lvteam/OverlayService;->switchTab(I)V

    return-void
.end method

.method private static synthetic lambda$buildTabPanel$3(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 2
    .param p0, "v"    # Landroid/view/View;
    .param p1, "ev"    # Landroid/view/MotionEvent;

    .line 431
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    const/4 v1, 0x1

    invoke-interface {v0, v1}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    .line 432
    const/4 v0, 0x0

    return v0
.end method

.method private synthetic lambda$buildThicknessPicker$22(Landroid/view/View;)V
    .locals 1
    .param p1, "v"    # Landroid/view/View;

    .line 912
    const/4 v0, -0x1

    invoke-direct {p0, v0}, Lcom/lvteam/OverlayService;->changeThickness(I)V

    return-void
.end method

.method private synthetic lambda$buildThicknessPicker$23(Landroid/view/View;)V
    .locals 1
    .param p1, "v"    # Landroid/view/View;

    .line 924
    const/4 v0, 0x1

    invoke-direct {p0, v0}, Lcom/lvteam/OverlayService;->changeThickness(I)V

    return-void
.end method

.method private synthetic lambda$buildViewsTab$10(Z)V
    .locals 0
    .param p1, "enabled"    # Z

    .line 491
    iput-boolean p1, p0, Lcom/lvteam/OverlayService;->drawName:Z

    .line 492
    if-eqz p1, :cond_0

    invoke-direct {p0}, Lcom/lvteam/OverlayService;->enableEspMaster()V

    .line 493
    :cond_0
    invoke-direct {p0}, Lcom/lvteam/OverlayService;->updateEspOverlay()V

    .line 494
    return-void
.end method

.method private synthetic lambda$buildViewsTab$11(Z)V
    .locals 0
    .param p1, "enabled"    # Z

    .line 496
    iput-boolean p1, p0, Lcom/lvteam/OverlayService;->drawDistance:Z

    .line 497
    if-eqz p1, :cond_0

    invoke-direct {p0}, Lcom/lvteam/OverlayService;->enableEspMaster()V

    .line 498
    :cond_0
    invoke-direct {p0}, Lcom/lvteam/OverlayService;->updateEspOverlay()V

    .line 499
    return-void
.end method

.method private synthetic lambda$buildViewsTab$12(I)V
    .locals 0
    .param p1, "val"    # I

    .line 500
    iput p1, p0, Lcom/lvteam/OverlayService;->maxDistanceM:I

    return-void
.end method

.method private synthetic lambda$buildViewsTab$13(Z)V
    .locals 0
    .param p1, "enabled"    # Z

    .line 503
    iput-boolean p1, p0, Lcom/lvteam/OverlayService;->enemyCounterEnabled:Z

    .line 504
    invoke-direct {p0}, Lcom/lvteam/OverlayService;->updateEspOverlay()V

    .line 505
    return-void
.end method

.method private synthetic lambda$buildViewsTab$7(Z)V
    .locals 0
    .param p1, "enabled"    # Z

    .line 477
    iput-boolean p1, p0, Lcom/lvteam/OverlayService;->espEnabled:Z

    .line 478
    invoke-direct {p0}, Lcom/lvteam/OverlayService;->updateEspOverlay()V

    .line 479
    return-void
.end method

.method private synthetic lambda$buildViewsTab$8(Z)V
    .locals 0
    .param p1, "enabled"    # Z

    .line 481
    iput-boolean p1, p0, Lcom/lvteam/OverlayService;->drawLine:Z

    .line 482
    if-eqz p1, :cond_0

    invoke-direct {p0}, Lcom/lvteam/OverlayService;->enableEspMaster()V

    .line 483
    :cond_0
    invoke-direct {p0}, Lcom/lvteam/OverlayService;->updateEspOverlay()V

    .line 484
    return-void
.end method

.method private synthetic lambda$buildViewsTab$9(Z)V
    .locals 0
    .param p1, "enabled"    # Z

    .line 486
    iput-boolean p1, p0, Lcom/lvteam/OverlayService;->boxEnabled:Z

    .line 487
    if-eqz p1, :cond_0

    invoke-direct {p0}, Lcom/lvteam/OverlayService;->enableEspMaster()V

    .line 488
    :cond_0
    invoke-direct {p0}, Lcom/lvteam/OverlayService;->updateEspOverlay()V

    .line 489
    return-void
.end method

.method private static synthetic lambda$killApp$26()V
    .locals 1

    .line 1290
    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v0

    invoke-static {v0}, Landroid/os/Process;->killProcess(I)V

    .line 1291
    const/4 v0, 0x0

    invoke-static {v0}, Ljava/lang/System;->exit(I)V

    .line 1292
    return-void
.end method

.method private synthetic lambda$makeSwatch$18(ILandroid/graphics/drawable/GradientDrawable;Landroid/view/View;)V
    .locals 3
    .param p1, "element"    # I
    .param p2, "bg"    # Landroid/graphics/drawable/GradientDrawable;
    .param p3, "v"    # Landroid/view/View;

    .line 703
    iget-object v0, p0, Lcom/lvteam/OverlayService;->elementColor:[I

    iget-object v1, p0, Lcom/lvteam/OverlayService;->elementColor:[I

    aget v1, v1, p1

    add-int/lit8 v1, v1, 0x1

    iget-object v2, p0, Lcom/lvteam/OverlayService;->colors:[I

    array-length v2, v2

    rem-int/2addr v1, v2

    aput v1, v0, p1

    .line 704
    iget-object v0, p0, Lcom/lvteam/OverlayService;->colors:[I

    iget-object v1, p0, Lcom/lvteam/OverlayService;->elementColor:[I

    aget v1, v1, p1

    aget v0, v0, v1

    invoke-virtual {p2, v0}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 705
    const/4 v0, 0x4

    if-ne p1, v0, :cond_0

    .line 706
    iget-object v0, p0, Lcom/lvteam/OverlayService;->circleOverlay:Landroid/view/View;

    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/lvteam/OverlayService;->circleOverlay:Landroid/view/View;

    invoke-direct {p0}, Lcom/lvteam/OverlayService;->circleBackground()Landroid/graphics/drawable/GradientDrawable;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    goto :goto_0

    .line 708
    :cond_0
    invoke-direct {p0}, Lcom/lvteam/OverlayService;->updateBoxStyle()V

    .line 710
    :cond_1
    :goto_0
    return-void
.end method

.method private synthetic lambda$refreshPlayerList$24(ILandroid/view/View;)V
    .locals 0
    .param p1, "entityId"    # I
    .param p2, "v"    # Landroid/view/View;

    .line 1128
    invoke-direct {p0, p1}, Lcom/lvteam/OverlayService;->toggleIgnored(I)V

    return-void
.end method

.method private synthetic lambda$refreshPlayerList$25(ILandroid/view/View;)V
    .locals 0
    .param p1, "entityId"    # I
    .param p2, "v"    # Landroid/view/View;

    .line 1150
    invoke-direct {p0, p1}, Lcom/lvteam/OverlayService;->toggleIgnored(I)V

    return-void
.end method

.method private synthetic lambda$showOverlay$0(Landroid/view/View;)V
    .locals 1
    .param p1, "v"    # Landroid/view/View;

    .line 259
    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lcom/lvteam/OverlayService;->setMinimized(Z)V

    return-void
.end method

.method private makeCheckbox()Landroid/widget/FrameLayout;
    .locals 4

    .line 823
    new-instance v0, Landroid/widget/FrameLayout;

    invoke-direct {v0, p0}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    .line 825
    .local v0, "cb":Landroid/widget/FrameLayout;
    new-instance v1, Landroid/widget/TextView;

    invoke-direct {v1, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 826
    .local v1, "check":Landroid/widget/TextView;
    const-string v2, "\u2713"

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 827
    const/high16 v2, 0x41700000    # 15.0f

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextSize(F)V

    .line 828
    sget-object v2, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 829
    const/16 v2, 0x11

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setGravity(I)V

    .line 830
    new-instance v2, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v3, -0x1

    invoke-direct {v2, v3, v3}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 834
    const/4 v2, 0x0

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    invoke-virtual {v0, v3}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 835
    invoke-direct {p0, v0, v2}, Lcom/lvteam/OverlayService;->applyCheckboxStyle(Landroid/widget/FrameLayout;Z)V

    .line 836
    return-object v0
.end method

.method private makeSwatch(I)Landroid/view/View;
    .locals 4
    .param p1, "element"    # I

    .line 696
    new-instance v0, Landroid/view/View;

    invoke-direct {v0, p0}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 697
    .local v0, "swatch":Landroid/view/View;
    new-instance v1, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v1}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 698
    .local v1, "bg":Landroid/graphics/drawable/GradientDrawable;
    const/4 v2, 0x7

    invoke-direct {p0, v2}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v2

    int-to-float v2, v2

    invoke-virtual {v1, v2}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 699
    iget-object v2, p0, Lcom/lvteam/OverlayService;->colors:[I

    iget-object v3, p0, Lcom/lvteam/OverlayService;->elementColor:[I

    aget v3, v3, p1

    aget v2, v2, v3

    invoke-virtual {v1, v2}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 700
    const/4 v2, 0x1

    invoke-direct {p0, v2}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v2

    const v3, -0xcbc3b6

    invoke-virtual {v1, v2, v3}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 701
    invoke-virtual {v0, v1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 702
    new-instance v2, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda20;

    invoke-direct {v2, p0, p1, v1}, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda20;-><init>(Lcom/lvteam/OverlayService;ILandroid/graphics/drawable/GradientDrawable;)V

    invoke-virtual {v0, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 711
    return-object v0
.end method

.method private menuHeight()I
    .locals 4

    .line 291
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->heightPixels:I

    .line 292
    .local v0, "sh":I
    const/16 v1, 0x15e

    invoke-direct {p0, v1}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v1

    const/16 v2, 0x104

    invoke-direct {p0, v2}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v2

    const/16 v3, 0x24

    invoke-direct {p0, v3}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v3

    sub-int v3, v0, v3

    invoke-static {v2, v3}, Ljava/lang/Math;->max(II)I

    move-result v2

    invoke-static {v1, v2}, Ljava/lang/Math;->min(II)I

    move-result v1

    return v1
.end method

.method private menuWidth()I
    .locals 4

    .line 286
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->widthPixels:I

    .line 287
    .local v0, "sw":I
    const/16 v1, 0x14a

    invoke-direct {p0, v1}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v1

    const/16 v2, 0x122

    invoke-direct {p0, v2}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v2

    const/16 v3, 0x24

    invoke-direct {p0, v3}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v3

    sub-int v3, v0, v3

    invoke-static {v2, v3}, Ljava/lang/Math;->max(II)I

    move-result v2

    invoke-static {v1, v2}, Ljava/lang/Math;->min(II)I

    move-result v1

    return v1
.end method

.method private newRow(Landroid/widget/LinearLayout;Ljava/lang/String;)Landroid/widget/LinearLayout;
    .locals 7
    .param p1, "parent"    # Landroid/widget/LinearLayout;
    .param p2, "name"    # Ljava/lang/String;

    .line 628
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 629
    .local v0, "row":Landroid/widget/LinearLayout;
    const/16 v1, 0x10

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 630
    invoke-direct {p0, v1}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v2

    const/16 v3, 0xe

    invoke-direct {p0, v3}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v3

    const/4 v4, 0x0

    invoke-virtual {v0, v2, v4, v3, v4}, Landroid/view/View;->setPadding(IIII)V

    .line 632
    new-instance v2, Landroid/widget/TextView;

    invoke-direct {v2, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 633
    .local v2, "label":Landroid/widget/TextView;
    invoke-virtual {v2, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 634
    const v3, -0x19120d

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setTextColor(I)V

    .line 635
    const/high16 v3, 0x41600000    # 14.0f

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setTextSize(F)V

    .line 636
    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setGravity(I)V

    .line 637
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v3, 0x2e

    invoke-direct {p0, v3}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v5

    const/high16 v6, 0x3f800000    # 1.0f

    invoke-direct {v1, v4, v5, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, v2, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 639
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    .line 640
    invoke-direct {p0, v3}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v3

    const/4 v4, -0x1

    invoke-direct {v1, v4, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 639
    invoke-virtual {p1, v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 641
    return-object v0
.end method

.method private refreshPlayerList()V
    .locals 16

    .line 1111
    move-object/from16 v0, p0

    iget-object v1, v0, Lcom/lvteam/OverlayService;->playerListContainer:Landroid/widget/LinearLayout;

    if-nez v1, :cond_0

    return-void

    .line 1112
    :cond_0
    iget-object v1, v0, Lcom/lvteam/OverlayService;->lastProjected:Ljava/util/List;

    .line 1113
    .local v1, "entities":Ljava/util/List;, "Ljava/util/List<Lcom/lvteam/EspOverlayView$Entity;>;"
    iget-object v2, v0, Lcom/lvteam/OverlayService;->playerListContainer:Landroid/widget/LinearLayout;

    invoke-virtual {v2}, Landroid/view/ViewGroup;->removeAllViews()V

    .line 1114
    const/4 v2, 0x0

    if-eqz v1, :cond_1

    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_2

    :cond_1
    goto/16 :goto_5

    .line 1118
    :cond_2
    iget-object v3, v0, Lcom/lvteam/OverlayService;->playerEmptyLabel:Landroid/widget/TextView;

    if-eqz v3, :cond_3

    iget-object v3, v0, Lcom/lvteam/OverlayService;->playerEmptyLabel:Landroid/widget/TextView;

    const/16 v4, 0x8

    invoke-virtual {v3, v4}, Landroid/view/View;->setVisibility(I)V

    .line 1119
    :cond_3
    const/4 v3, 0x0

    .line 1120
    .local v3, "idx":I
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_0
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    nop

    if-eqz v5, :cond_8

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/lvteam/EspOverlayView$Entity;

    .line 1121
    .local v5, "e":Lcom/lvteam/EspOverlayView$Entity;
    add-int/lit8 v3, v3, 0x1

    const/16 v6, 0x14

    if-le v3, v6, :cond_4

    goto/16 :goto_4

    .line 1122
    :cond_4
    iget v6, v5, Lcom/lvteam/EspOverlayView$Entity;->id:I

    .line 1123
    .local v6, "entityId":I
    iget-object v7, v0, Lcom/lvteam/OverlayService;->ignoredIds:Ljava/util/Set;

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-interface {v7, v8}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v7

    .line 1125
    .local v7, "ignored":Z
    new-instance v8, Landroid/widget/LinearLayout;

    invoke-direct {v8, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 1126
    .local v8, "row":Landroid/widget/LinearLayout;
    const/16 v9, 0x10

    invoke-virtual {v8, v9}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 1127
    invoke-direct {v0, v9}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v9

    const/16 v10, 0xe

    invoke-direct {v0, v10}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v10

    invoke-virtual {v8, v9, v2, v10, v2}, Landroid/view/View;->setPadding(IIII)V

    .line 1128
    new-instance v9, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda15;

    invoke-direct {v9, v0, v6}, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda15;-><init>(Lcom/lvteam/OverlayService;I)V

    invoke-virtual {v8, v9}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1130
    new-instance v9, Landroid/widget/TextView;

    invoke-direct {v9, v0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 1131
    .local v9, "nameTv":Landroid/widget/TextView;
    iget-object v10, v5, Lcom/lvteam/EspOverlayView$Entity;->name:Ljava/lang/String;

    if-eqz v10, :cond_5

    iget-object v10, v5, Lcom/lvteam/EspOverlayView$Entity;->name:Ljava/lang/String;

    goto :goto_1

    :cond_5
    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string v11, "Enemy "

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    :goto_1
    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1132
    const v10, -0x827a70

    if-eqz v7, :cond_6

    move v11, v10

    goto :goto_2

    :cond_6
    const v11, -0x19120d

    :goto_2
    invoke-virtual {v9, v11}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1133
    const/high16 v11, 0x41400000    # 12.0f

    invoke-virtual {v9, v11}, Landroid/widget/TextView;->setTextSize(F)V

    .line 1134
    const/4 v12, 0x1

    invoke-virtual {v9, v12}, Landroid/widget/TextView;->setSingleLine(Z)V

    .line 1135
    new-instance v12, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v13, 0x26

    invoke-direct {v0, v13}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v14

    const/high16 v15, 0x3f800000    # 1.0f

    invoke-direct {v12, v2, v14, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v8, v9, v12}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1137
    new-instance v12, Landroid/widget/TextView;

    invoke-direct {v12, v0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 1138
    .local v12, "distTv":Landroid/widget/TextView;
    new-instance v14, Ljava/lang/StringBuilder;

    invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V

    iget v15, v5, Lcom/lvteam/EspOverlayView$Entity;->distanceMeters:F

    invoke-static {v15}, Ljava/lang/Math;->round(F)I

    move-result v15

    invoke-virtual {v14, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v15, "m"

    invoke-virtual {v14, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v12, v14}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1139
    if-eqz v7, :cond_7

    goto :goto_3

    :cond_7
    const v10, -0xd6490a

    :goto_3
    invoke-virtual {v12, v10}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1140
    invoke-virtual {v12, v11}, Landroid/widget/TextView;->setTextSize(F)V

    .line 1141
    sget-object v10, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v12, v10}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 1142
    const v10, 0x800015

    invoke-virtual {v12, v10}, Landroid/widget/TextView;->setGravity(I)V

    .line 1143
    new-instance v10, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v11, 0x2a

    invoke-direct {v0, v11}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v11

    invoke-direct {v0, v13}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v14

    invoke-direct {v10, v11, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 1144
    .local v10, "distLp":Landroid/widget/LinearLayout$LayoutParams;
    const/16 v11, 0xc

    invoke-direct {v0, v11}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v11

    invoke-virtual {v10, v2, v2, v11, v2}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 1145
    invoke-virtual {v8, v12, v10}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1147
    invoke-direct/range {p0 .. p0}, Lcom/lvteam/OverlayService;->makeCheckbox()Landroid/widget/FrameLayout;

    move-result-object v11

    .line 1148
    .local v11, "box":Landroid/widget/FrameLayout;
    invoke-static {v7}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v14

    invoke-virtual {v11, v14}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 1149
    invoke-direct {v0, v11, v7}, Lcom/lvteam/OverlayService;->applyCheckboxStyle(Landroid/widget/FrameLayout;Z)V

    .line 1150
    new-instance v14, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda16;

    invoke-direct {v14, v0, v6}, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda16;-><init>(Lcom/lvteam/OverlayService;I)V

    invoke-virtual {v11, v14}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1151
    new-instance v14, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v15, 0x16

    invoke-direct {v0, v15}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v2

    invoke-direct {v0, v15}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v15

    invoke-direct {v14, v2, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v8, v11, v14}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1153
    iget-object v2, v0, Lcom/lvteam/OverlayService;->playerListContainer:Landroid/widget/LinearLayout;

    new-instance v14, Landroid/widget/LinearLayout$LayoutParams;

    .line 1154
    invoke-direct {v0, v13}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v13

    const/4 v15, -0x1

    invoke-direct {v14, v15, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 1153
    invoke-virtual {v2, v8, v14}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1156
    iget-object v2, v0, Lcom/lvteam/OverlayService;->playerListContainer:Landroid/widget/LinearLayout;

    invoke-direct {v0, v2}, Lcom/lvteam/OverlayService;->addRowLine(Landroid/widget/LinearLayout;)V

    .line 1157
    .end local v5    # "e":Lcom/lvteam/EspOverlayView$Entity;
    .end local v6    # "entityId":I
    .end local v7    # "ignored":Z
    .end local v8    # "row":Landroid/widget/LinearLayout;
    .end local v9    # "nameTv":Landroid/widget/TextView;
    .end local v10    # "distLp":Landroid/widget/LinearLayout$LayoutParams;
    .end local v11    # "box":Landroid/widget/FrameLayout;
    .end local v12    # "distTv":Landroid/widget/TextView;
    const/4 v2, 0x0

    goto/16 :goto_0

    .line 1158
    :cond_8
    :goto_4
    return-void

    .line 1115
    .end local v3    # "idx":I
    :goto_5
    iget-object v2, v0, Lcom/lvteam/OverlayService;->playerEmptyLabel:Landroid/widget/TextView;

    if-eqz v2, :cond_9

    iget-object v2, v0, Lcom/lvteam/OverlayService;->playerEmptyLabel:Landroid/widget/TextView;

    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Landroid/view/View;->setVisibility(I)V

    .line 1116
    :cond_9
    return-void
.end method

.method private removeBox()V
    .locals 2

    .line 1073
    invoke-static {}, Landroid/view/Choreographer;->getInstance()Landroid/view/Choreographer;

    move-result-object v0

    iget-object v1, p0, Lcom/lvteam/OverlayService;->espFrame:Landroid/view/Choreographer$FrameCallback;

    invoke-virtual {v0, v1}, Landroid/view/Choreographer;->removeFrameCallback(Landroid/view/Choreographer$FrameCallback;)V

    .line 1074
    iget-object v0, p0, Lcom/lvteam/OverlayService;->boxOverlay:Lcom/lvteam/EspOverlayView;

    if-eqz v0, :cond_0

    .line 1075
    iget-object v0, p0, Lcom/lvteam/OverlayService;->windowManager:Landroid/view/WindowManager;

    iget-object v1, p0, Lcom/lvteam/OverlayService;->boxOverlay:Lcom/lvteam/EspOverlayView;

    invoke-interface {v0, v1}, Landroid/view/ViewManager;->removeView(Landroid/view/View;)V

    .line 1076
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/lvteam/OverlayService;->boxOverlay:Lcom/lvteam/EspOverlayView;

    .line 1078
    :cond_0
    return-void
.end method

.method private removeCircle()V
    .locals 2

    .line 1013
    iget-object v0, p0, Lcom/lvteam/OverlayService;->circleOverlay:Landroid/view/View;

    if-eqz v0, :cond_0

    .line 1014
    iget-object v0, p0, Lcom/lvteam/OverlayService;->windowManager:Landroid/view/WindowManager;

    iget-object v1, p0, Lcom/lvteam/OverlayService;->circleOverlay:Landroid/view/View;

    invoke-interface {v0, v1}, Landroid/view/ViewManager;->removeView(Landroid/view/View;)V

    .line 1015
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/lvteam/OverlayService;->circleOverlay:Landroid/view/View;

    .line 1016
    iput-object v0, p0, Lcom/lvteam/OverlayService;->circleParams:Landroid/view/WindowManager$LayoutParams;

    .line 1018
    :cond_0
    return-void
.end method

.method private removeEnemyCounter()V
    .locals 2

    .line 1204
    iget-object v0, p0, Lcom/lvteam/OverlayService;->enemyCounterOverlay:Landroid/widget/LinearLayout;

    if-eqz v0, :cond_0

    .line 1205
    iget-object v0, p0, Lcom/lvteam/OverlayService;->windowManager:Landroid/view/WindowManager;

    iget-object v1, p0, Lcom/lvteam/OverlayService;->enemyCounterOverlay:Landroid/widget/LinearLayout;

    invoke-interface {v0, v1}, Landroid/view/ViewManager;->removeView(Landroid/view/View;)V

    .line 1206
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/lvteam/OverlayService;->enemyCounterOverlay:Landroid/widget/LinearLayout;

    .line 1207
    iput-object v0, p0, Lcom/lvteam/OverlayService;->enemyValue:Landroid/widget/TextView;

    .line 1209
    :cond_0
    return-void
.end method

.method private removeTeamTitle()V
    .locals 2

    .line 1248
    iget-object v0, p0, Lcom/lvteam/OverlayService;->teamTitleOverlay:Landroid/widget/TextView;

    if-eqz v0, :cond_0

    .line 1249
    iget-object v0, p0, Lcom/lvteam/OverlayService;->windowManager:Landroid/view/WindowManager;

    iget-object v1, p0, Lcom/lvteam/OverlayService;->teamTitleOverlay:Landroid/widget/TextView;

    invoke-virtual {v1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    check-cast v1, Landroid/view/View;

    invoke-interface {v0, v1}, Landroid/view/ViewManager;->removeView(Landroid/view/View;)V

    .line 1250
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/lvteam/OverlayService;->teamTitleOverlay:Landroid/widget/TextView;

    .line 1252
    :cond_0
    return-void
.end method

.method private setCircleEnabled(Z)V
    .locals 8
    .param p1, "enabled"    # Z

    .line 981
    if-eqz p1, :cond_2

    iget-object v0, p0, Lcom/lvteam/OverlayService;->circleOverlay:Landroid/view/View;

    if-nez v0, :cond_2

    .line 982
    new-instance v0, Landroid/view/View;

    invoke-direct {v0, p0}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcom/lvteam/OverlayService;->circleOverlay:Landroid/view/View;

    .line 983
    iget-object v0, p0, Lcom/lvteam/OverlayService;->circleOverlay:Landroid/view/View;

    invoke-direct {p0}, Lcom/lvteam/OverlayService;->circleBackground()Landroid/graphics/drawable/GradientDrawable;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 984
    const/16 v0, 0x78

    invoke-direct {p0, v0}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v0

    iget v1, p0, Lcom/lvteam/OverlayService;->fovPercent:I

    mul-int/2addr v0, v1

    div-int/lit8 v0, v0, 0x64

    .line 985
    .local v0, "size":I
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1a

    if-lt v1, v2, :cond_0

    .line 986
    const/16 v1, 0x7f6

    move v4, v1

    goto :goto_0

    .line 987
    :cond_0
    const/16 v1, 0x7d2

    move v4, v1

    :goto_0
    nop

    .line 988
    .local v4, "type":I
    new-instance v7, Landroid/view/WindowManager$LayoutParams;

    const/16 v5, 0x318

    const/4 v6, -0x3

    move-object v1, v7

    move v2, v0

    move v3, v0

    invoke-direct/range {v1 .. v6}, Landroid/view/WindowManager$LayoutParams;-><init>(IIIII)V

    iput-object v7, p0, Lcom/lvteam/OverlayService;->circleParams:Landroid/view/WindowManager$LayoutParams;

    .line 995
    iget-object v1, p0, Lcom/lvteam/OverlayService;->circleParams:Landroid/view/WindowManager$LayoutParams;

    const/16 v2, 0x11

    iput v2, v1, Landroid/view/WindowManager$LayoutParams;->gravity:I

    .line 996
    iget-object v1, p0, Lcom/lvteam/OverlayService;->windowManager:Landroid/view/WindowManager;

    iget-object v2, p0, Lcom/lvteam/OverlayService;->circleOverlay:Landroid/view/View;

    iget-object v3, p0, Lcom/lvteam/OverlayService;->circleParams:Landroid/view/WindowManager$LayoutParams;

    invoke-interface {v1, v2, v3}, Landroid/view/ViewManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 997
    .end local v0    # "size":I
    .end local v4    # "type":I
    :cond_1
    goto :goto_1

    :cond_2
    if-nez p1, :cond_1

    .line 998
    invoke-direct {p0}, Lcom/lvteam/OverlayService;->removeCircle()V

    .line 1000
    :goto_1
    return-void
.end method

.method private setEnemyCounterEnabled(Z)V
    .locals 9
    .param p1, "enabled"    # Z

    .line 1164
    if-eqz p1, :cond_0

    iget-object v0, p0, Lcom/lvteam/OverlayService;->boxOverlay:Lcom/lvteam/EspOverlayView;

    if-nez v0, :cond_0

    return-void

    .line 1165
    :cond_0
    if-eqz p1, :cond_3

    iget-object v0, p0, Lcom/lvteam/OverlayService;->enemyCounterOverlay:Landroid/widget/LinearLayout;

    if-nez v0, :cond_3

    .line 1166
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcom/lvteam/OverlayService;->enemyCounterOverlay:Landroid/widget/LinearLayout;

    .line 1167
    iget-object v0, p0, Lcom/lvteam/OverlayService;->enemyCounterOverlay:Landroid/widget/LinearLayout;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 1168
    iget-object v0, p0, Lcom/lvteam/OverlayService;->enemyCounterOverlay:Landroid/widget/LinearLayout;

    const/16 v2, 0x11

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 1169
    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v0}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 1170
    .local v0, "bg":Landroid/graphics/drawable/GradientDrawable;
    const v3, -0x55efefd8

    invoke-virtual {v0, v3}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 1171
    const/16 v3, 0xa

    invoke-direct {p0, v3}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v4

    int-to-float v4, v4

    invoke-virtual {v0, v4}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 1172
    invoke-direct {p0, v1}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v1

    const v4, 0x4000e5ff

    invoke-virtual {v0, v1, v4}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 1173
    iget-object v1, p0, Lcom/lvteam/OverlayService;->enemyCounterOverlay:Landroid/widget/LinearLayout;

    invoke-virtual {v1, v0}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1174
    iget-object v1, p0, Lcom/lvteam/OverlayService;->enemyCounterOverlay:Landroid/widget/LinearLayout;

    invoke-direct {p0, v3}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v4

    const/4 v5, 0x2

    invoke-direct {p0, v5}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v6

    invoke-direct {p0, v3}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v3

    invoke-direct {p0, v5}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v5

    invoke-virtual {v1, v4, v6, v3, v5}, Landroid/view/View;->setPadding(IIII)V

    .line 1176
    new-instance v1, Landroid/widget/TextView;

    invoke-direct {v1, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    iput-object v1, p0, Lcom/lvteam/OverlayService;->enemyValue:Landroid/widget/TextView;

    .line 1177
    iget-object v1, p0, Lcom/lvteam/OverlayService;->enemyValue:Landroid/widget/TextView;

    const-string v3, "Enemy 0"

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1178
    iget-object v1, p0, Lcom/lvteam/OverlayService;->enemyValue:Landroid/widget/TextView;

    const/4 v3, -0x1

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1179
    iget-object v1, p0, Lcom/lvteam/OverlayService;->enemyValue:Landroid/widget/TextView;

    const/high16 v3, 0x41500000    # 13.0f

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setTextSize(F)V

    .line 1180
    iget-object v1, p0, Lcom/lvteam/OverlayService;->enemyValue:Landroid/widget/TextView;

    sget-object v3, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 1181
    iget-object v1, p0, Lcom/lvteam/OverlayService;->enemyValue:Landroid/widget/TextView;

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setGravity(I)V

    .line 1182
    iget-object v1, p0, Lcom/lvteam/OverlayService;->enemyCounterOverlay:Landroid/widget/LinearLayout;

    iget-object v2, p0, Lcom/lvteam/OverlayService;->enemyValue:Landroid/widget/TextView;

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    .line 1183
    const/16 v4, 0x16

    invoke-direct {p0, v4}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v4

    const/4 v5, -0x2

    invoke-direct {v3, v5, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 1182
    invoke-virtual {v1, v2, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1185
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1a

    if-lt v1, v2, :cond_1

    .line 1186
    const/16 v1, 0x7f6

    move v6, v1

    goto :goto_0

    .line 1187
    :cond_1
    const/16 v1, 0x7d2

    move v6, v1

    :goto_0
    nop

    .line 1188
    .local v6, "type":I
    new-instance v1, Landroid/view/WindowManager$LayoutParams;

    .line 1189
    invoke-direct {p0, v2}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v5

    const/16 v7, 0x318

    const/4 v8, -0x3

    const/4 v4, -0x2

    move-object v3, v1

    invoke-direct/range {v3 .. v8}, Landroid/view/WindowManager$LayoutParams;-><init>(IIIII)V

    .line 1195
    .local v1, "p":Landroid/view/WindowManager$LayoutParams;
    const/16 v2, 0x31

    iput v2, v1, Landroid/view/WindowManager$LayoutParams;->gravity:I

    .line 1196
    const/16 v2, 0x3a

    invoke-direct {p0, v2}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v2

    iput v2, v1, Landroid/view/WindowManager$LayoutParams;->y:I

    .line 1197
    iget-object v2, p0, Lcom/lvteam/OverlayService;->windowManager:Landroid/view/WindowManager;

    iget-object v3, p0, Lcom/lvteam/OverlayService;->enemyCounterOverlay:Landroid/widget/LinearLayout;

    invoke-interface {v2, v3, v1}, Landroid/view/ViewManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1198
    .end local v0    # "bg":Landroid/graphics/drawable/GradientDrawable;
    .end local v1    # "p":Landroid/view/WindowManager$LayoutParams;
    .end local v6    # "type":I
    :cond_2
    goto :goto_1

    :cond_3
    if-nez p1, :cond_2

    .line 1199
    invoke-direct {p0}, Lcom/lvteam/OverlayService;->removeEnemyCounter()V

    .line 1201
    :goto_1
    return-void
.end method

.method private setMinimized(Z)V
    .locals 5
    .param p1, "m"    # Z

    .line 947
    iput-boolean p1, p0, Lcom/lvteam/OverlayService;->minimized:Z

    .line 948
    const/4 v0, 0x0

    if-eqz p1, :cond_0

    .line 949
    iget-object v1, p0, Lcom/lvteam/OverlayService;->overlay:Landroid/view/View;

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 950
    iget-object v1, p0, Lcom/lvteam/OverlayService;->overlay:Landroid/view/View;

    invoke-virtual {v1, v0}, Landroid/view/View;->setClipToOutline(Z)V

    goto :goto_0

    .line 952
    :cond_0
    iget-object v1, p0, Lcom/lvteam/OverlayService;->overlayBackground:Landroid/graphics/drawable/GradientDrawable;

    const v2, -0xff2eee9

    invoke-virtual {v1, v2}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 953
    iget-object v1, p0, Lcom/lvteam/OverlayService;->overlayBackground:Landroid/graphics/drawable/GradientDrawable;

    const/16 v2, 0x10

    invoke-direct {p0, v2}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v2

    int-to-float v2, v2

    invoke-virtual {v1, v2}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 954
    iget-object v1, p0, Lcom/lvteam/OverlayService;->overlayBackground:Landroid/graphics/drawable/GradientDrawable;

    const/4 v2, 0x1

    invoke-direct {p0, v2}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v3

    const v4, -0xcbc3b6

    invoke-virtual {v1, v3, v4}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 955
    iget-object v1, p0, Lcom/lvteam/OverlayService;->overlay:Landroid/view/View;

    iget-object v3, p0, Lcom/lvteam/OverlayService;->overlayBackground:Landroid/graphics/drawable/GradientDrawable;

    invoke-virtual {v1, v3}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 956
    iget-object v1, p0, Lcom/lvteam/OverlayService;->overlay:Landroid/view/View;

    invoke-virtual {v1, v2}, Landroid/view/View;->setClipToOutline(Z)V

    .line 958
    :goto_0
    iget-object v1, p0, Lcom/lvteam/OverlayService;->headerContainer:Landroid/widget/LinearLayout;

    const/16 v2, 0x8

    if-eqz p1, :cond_1

    move v3, v2

    goto :goto_1

    :cond_1
    move v3, v0

    :goto_1
    invoke-virtual {v1, v3}, Landroid/view/View;->setVisibility(I)V

    .line 959
    iget-object v1, p0, Lcom/lvteam/OverlayService;->bodyContainer:Landroid/widget/LinearLayout;

    if-eqz p1, :cond_2

    move v3, v2

    goto :goto_2

    :cond_2
    move v3, v0

    :goto_2
    invoke-virtual {v1, v3}, Landroid/view/View;->setVisibility(I)V

    .line 960
    iget-object v1, p0, Lcom/lvteam/OverlayService;->appIcon:Landroid/widget/ImageView;

    if-eqz p1, :cond_3

    goto :goto_3

    :cond_3
    move v0, v2

    :goto_3
    invoke-virtual {v1, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 961
    iget-object v0, p0, Lcom/lvteam/OverlayService;->overlayParams:Landroid/view/WindowManager$LayoutParams;

    const/16 v1, 0x38

    if-eqz p1, :cond_4

    invoke-direct {p0, v1}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v2

    goto :goto_4

    :cond_4
    invoke-direct {p0}, Lcom/lvteam/OverlayService;->menuWidth()I

    move-result v2

    :goto_4
    iput v2, v0, Landroid/view/WindowManager$LayoutParams;->width:I

    .line 962
    iget-object v0, p0, Lcom/lvteam/OverlayService;->overlayParams:Landroid/view/WindowManager$LayoutParams;

    if-eqz p1, :cond_5

    invoke-direct {p0, v1}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v1

    goto :goto_5

    :cond_5
    invoke-direct {p0}, Lcom/lvteam/OverlayService;->menuHeight()I

    move-result v1

    :goto_5
    iput v1, v0, Landroid/view/WindowManager$LayoutParams;->height:I

    .line 963
    iget-object v0, p0, Lcom/lvteam/OverlayService;->windowManager:Landroid/view/WindowManager;

    iget-object v1, p0, Lcom/lvteam/OverlayService;->overlay:Landroid/view/View;

    iget-object v2, p0, Lcom/lvteam/OverlayService;->overlayParams:Landroid/view/WindowManager$LayoutParams;

    invoke-interface {v0, v1, v2}, Landroid/view/ViewManager;->updateViewLayout(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 964
    return-void
.end method

.method private showOverlay()V
    .locals 13
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ClickableViewAccessibility"
        }
    .end annotation

    .line 209
    iget-object v0, p0, Lcom/lvteam/OverlayService;->overlay:Landroid/view/View;

    if-eqz v0, :cond_0

    return-void

    .line 210
    :cond_0
    const-string v0, "window"

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/WindowManager;

    iput-object v0, p0, Lcom/lvteam/OverlayService;->windowManager:Landroid/view/WindowManager;

    .line 212
    new-instance v0, Lcom/lvteam/OverlayService$DraggableLayout;

    invoke-direct {v0, p0, p0}, Lcom/lvteam/OverlayService$DraggableLayout;-><init>(Lcom/lvteam/OverlayService;Landroid/content/Context;)V

    .line 213
    .local v0, "root":Lcom/lvteam/OverlayService$DraggableLayout;
    new-instance v1, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v1}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    iput-object v1, p0, Lcom/lvteam/OverlayService;->overlayBackground:Landroid/graphics/drawable/GradientDrawable;

    .line 214
    iget-object v1, p0, Lcom/lvteam/OverlayService;->overlayBackground:Landroid/graphics/drawable/GradientDrawable;

    const v2, -0xff2eee9

    invoke-virtual {v1, v2}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 215
    iget-object v1, p0, Lcom/lvteam/OverlayService;->overlayBackground:Landroid/graphics/drawable/GradientDrawable;

    const/16 v2, 0x10

    invoke-direct {p0, v2}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v2

    int-to-float v2, v2

    invoke-virtual {v1, v2}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 216
    iget-object v1, p0, Lcom/lvteam/OverlayService;->overlayBackground:Landroid/graphics/drawable/GradientDrawable;

    const/4 v2, 0x1

    invoke-direct {p0, v2}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v3

    const v4, -0xcbc3b6

    invoke-virtual {v1, v3, v4}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 217
    iget-object v1, p0, Lcom/lvteam/OverlayService;->overlayBackground:Landroid/graphics/drawable/GradientDrawable;

    invoke-virtual {v0, v1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 218
    invoke-virtual {v0, v2}, Landroid/view/View;->setClipToOutline(Z)V

    .line 220
    new-instance v1, Landroid/widget/LinearLayout;

    invoke-direct {v1, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 221
    .local v1, "column":Landroid/widget/LinearLayout;
    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 223
    invoke-direct {p0}, Lcom/lvteam/OverlayService;->buildHeader()Landroid/widget/LinearLayout;

    move-result-object v3

    iput-object v3, p0, Lcom/lvteam/OverlayService;->headerContainer:Landroid/widget/LinearLayout;

    .line 224
    iget-object v3, p0, Lcom/lvteam/OverlayService;->headerContainer:Landroid/widget/LinearLayout;

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v6, -0x2

    const/4 v7, -0x1

    invoke-direct {v5, v7, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v3, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 228
    new-instance v3, Landroid/widget/LinearLayout;

    invoke-direct {v3, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    iput-object v3, p0, Lcom/lvteam/OverlayService;->bodyContainer:Landroid/widget/LinearLayout;

    .line 229
    iget-object v3, p0, Lcom/lvteam/OverlayService;->bodyContainer:Landroid/widget/LinearLayout;

    const/4 v5, 0x0

    invoke-virtual {v3, v5}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 231
    invoke-direct {p0}, Lcom/lvteam/OverlayService;->buildSidebar()Landroid/widget/LinearLayout;

    move-result-object v3

    .line 232
    .local v3, "sidebar":Landroid/widget/LinearLayout;
    iget-object v6, p0, Lcom/lvteam/OverlayService;->bodyContainer:Landroid/widget/LinearLayout;

    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    .line 233
    const/16 v9, 0x62

    invoke-direct {p0, v9}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v9

    invoke-direct {v8, v9, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 232
    invoke-virtual {v6, v3, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 235
    new-instance v6, Landroid/view/View;

    invoke-direct {v6, p0}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 236
    .local v6, "sep":Landroid/view/View;
    invoke-virtual {v6, v4}, Landroid/view/View;->setBackgroundColor(I)V

    .line 237
    iget-object v4, p0, Lcom/lvteam/OverlayService;->bodyContainer:Landroid/widget/LinearLayout;

    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    .line 238
    invoke-direct {p0, v2}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v2

    invoke-direct {v8, v2, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 237
    invoke-virtual {v4, v6, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 240
    new-instance v2, Landroid/widget/FrameLayout;

    invoke-direct {v2, p0}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    .line 241
    .local v2, "contentFrame":Landroid/widget/FrameLayout;
    const v4, -0xeee7e0

    invoke-virtual {v2, v4}, Landroid/view/View;->setBackgroundColor(I)V

    .line 242
    const/4 v4, 0x0

    .local v4, "i":I
    :goto_0
    const/4 v8, 0x5

    const/16 v9, 0x8

    if-ge v4, v8, :cond_2

    .line 243
    iget-object v8, p0, Lcom/lvteam/OverlayService;->tabPanels:[Landroid/widget/LinearLayout;

    invoke-direct {p0, v4}, Lcom/lvteam/OverlayService;->buildTabPanel(I)Landroid/widget/LinearLayout;

    move-result-object v10

    aput-object v10, v8, v4

    .line 244
    iget-object v8, p0, Lcom/lvteam/OverlayService;->tabPanels:[Landroid/widget/LinearLayout;

    aget-object v8, v8, v4

    iget v10, p0, Lcom/lvteam/OverlayService;->activeTab:I

    if-ne v4, v10, :cond_1

    move v9, v5

    :cond_1
    invoke-virtual {v8, v9}, Landroid/view/View;->setVisibility(I)V

    .line 245
    iget-object v8, p0, Lcom/lvteam/OverlayService;->tabPanels:[Landroid/widget/LinearLayout;

    aget-object v8, v8, v4

    new-instance v9, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v9, v7, v7}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v2, v8, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 242
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_2
    nop

    .line 249
    .end local v4    # "i":I
    iget-object v4, p0, Lcom/lvteam/OverlayService;->bodyContainer:Landroid/widget/LinearLayout;

    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v10, 0x3f800000    # 1.0f

    invoke-direct {v8, v5, v7, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v4, v2, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 252
    iget-object v4, p0, Lcom/lvteam/OverlayService;->bodyContainer:Landroid/widget/LinearLayout;

    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v8, v7, v5, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v1, v4, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 255
    new-instance v4, Landroid/widget/ImageView;

    invoke-direct {v4, p0}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    iput-object v4, p0, Lcom/lvteam/OverlayService;->appIcon:Landroid/widget/ImageView;

    .line 256
    iget-object v4, p0, Lcom/lvteam/OverlayService;->appIcon:Landroid/widget/ImageView;

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v8

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v11

    invoke-virtual {v8, v11}, Landroid/content/pm/PackageItemInfo;->loadIcon(Landroid/content/pm/PackageManager;)Landroid/graphics/drawable/Drawable;

    move-result-object v8

    invoke-virtual {v4, v8}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 257
    iget-object v4, p0, Lcom/lvteam/OverlayService;->appIcon:Landroid/widget/ImageView;

    sget-object v8, Landroid/widget/ImageView$ScaleType;->FIT_CENTER:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v4, v8}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    .line 258
    iget-object v4, p0, Lcom/lvteam/OverlayService;->appIcon:Landroid/widget/ImageView;

    invoke-virtual {v4, v9}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 259
    iget-object v4, p0, Lcom/lvteam/OverlayService;->appIcon:Landroid/widget/ImageView;

    new-instance v8, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda17;

    invoke-direct {v8, p0}, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda17;-><init>(Lcom/lvteam/OverlayService;)V

    invoke-virtual {v4, v8}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 260
    iget-object v4, p0, Lcom/lvteam/OverlayService;->appIcon:Landroid/widget/ImageView;

    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v8, v7, v5, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v1, v4, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 263
    new-instance v4, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v4, v7, v7}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 267
    iput-object v0, p0, Lcom/lvteam/OverlayService;->overlay:Landroid/view/View;

    .line 268
    iget v4, p0, Lcom/lvteam/OverlayService;->activeTab:I

    invoke-direct {p0, v4}, Lcom/lvteam/OverlayService;->highlightTab(I)V

    .line 270
    sget v4, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v5, 0x1a

    if-lt v4, v5, :cond_3

    .line 271
    const/16 v4, 0x7f6

    move v10, v4

    goto :goto_1

    .line 272
    :cond_3
    const/16 v4, 0x7d2

    move v10, v4

    :goto_1
    nop

    .line 273
    .local v10, "type":I
    new-instance v4, Landroid/view/WindowManager$LayoutParams;

    .line 274
    invoke-direct {p0}, Lcom/lvteam/OverlayService;->menuWidth()I

    move-result v8

    invoke-direct {p0}, Lcom/lvteam/OverlayService;->menuHeight()I

    move-result v9

    const/16 v11, 0x8

    const/4 v12, -0x3

    move-object v7, v4

    invoke-direct/range {v7 .. v12}, Landroid/view/WindowManager$LayoutParams;-><init>(IIIII)V

    iput-object v4, p0, Lcom/lvteam/OverlayService;->overlayParams:Landroid/view/WindowManager$LayoutParams;

    .line 277
    iget-object v4, p0, Lcom/lvteam/OverlayService;->overlayParams:Landroid/view/WindowManager$LayoutParams;

    const v5, 0x800033

    iput v5, v4, Landroid/view/WindowManager$LayoutParams;->gravity:I

    .line 278
    iget-object v4, p0, Lcom/lvteam/OverlayService;->overlayParams:Landroid/view/WindowManager$LayoutParams;

    const/16 v5, 0xa

    invoke-direct {p0, v5}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v5

    iput v5, v4, Landroid/view/WindowManager$LayoutParams;->x:I

    .line 279
    iget-object v4, p0, Lcom/lvteam/OverlayService;->overlayParams:Landroid/view/WindowManager$LayoutParams;

    const/16 v5, 0x28

    invoke-direct {p0, v5}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v5

    iput v5, v4, Landroid/view/WindowManager$LayoutParams;->y:I

    .line 280
    iget-object v4, p0, Lcom/lvteam/OverlayService;->windowManager:Landroid/view/WindowManager;

    iget-object v5, p0, Lcom/lvteam/OverlayService;->overlay:Landroid/view/View;

    iget-object v7, p0, Lcom/lvteam/OverlayService;->overlayParams:Landroid/view/WindowManager$LayoutParams;

    invoke-interface {v4, v5, v7}, Landroid/view/ViewManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 281
    return-void
.end method

.method private showTeamTitle()V
    .locals 8

    .line 1219
    iget-object v0, p0, Lcom/lvteam/OverlayService;->teamTitleOverlay:Landroid/widget/TextView;

    if-eqz v0, :cond_0

    return-void

    .line 1220
    :cond_0
    new-instance v0, Landroid/widget/FrameLayout;

    invoke-direct {v0, p0}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    .line 1221
    .local v0, "frame":Landroid/widget/FrameLayout;
    new-instance v1, Landroid/widget/TextView;

    invoke-direct {v1, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    iput-object v1, p0, Lcom/lvteam/OverlayService;->teamTitleOverlay:Landroid/widget/TextView;

    .line 1222
    iget-object v1, p0, Lcom/lvteam/OverlayService;->teamTitleOverlay:Landroid/widget/TextView;

    sget v2, Lcom/lvteam/R$string;->title_lv_team:I

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(I)V

    .line 1223
    iget-object v1, p0, Lcom/lvteam/OverlayService;->teamTitleOverlay:Landroid/widget/TextView;

    const v2, -0x44ff1a01

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1224
    iget-object v1, p0, Lcom/lvteam/OverlayService;->teamTitleOverlay:Landroid/widget/TextView;

    const/high16 v2, 0x41300000    # 11.0f

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextSize(F)V

    .line 1225
    iget-object v1, p0, Lcom/lvteam/OverlayService;->teamTitleOverlay:Landroid/widget/TextView;

    const-string v2, "sans-serif-medium"

    const/4 v3, 0x1

    invoke-static {v2, v3}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 1226
    iget-object v1, p0, Lcom/lvteam/OverlayService;->teamTitleOverlay:Landroid/widget/TextView;

    const v2, 0x3e4ccccd    # 0.2f

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setLetterSpacing(F)V

    .line 1227
    iget-object v1, p0, Lcom/lvteam/OverlayService;->teamTitleOverlay:Landroid/widget/TextView;

    const/16 v2, 0x11

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setGravity(I)V

    .line 1228
    iget-object v1, p0, Lcom/lvteam/OverlayService;->teamTitleOverlay:Landroid/widget/TextView;

    const/high16 v2, 0x3f800000    # 1.0f

    const/high16 v3, -0x80000000

    const/high16 v4, 0x40800000    # 4.0f

    const/4 v5, 0x0

    invoke-virtual {v1, v4, v5, v2, v3}, Landroid/widget/TextView;->setShadowLayer(FFFI)V

    .line 1229
    iget-object v1, p0, Lcom/lvteam/OverlayService;->teamTitleOverlay:Landroid/widget/TextView;

    new-instance v2, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v3, -0x1

    invoke-direct {v2, v3, v3}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1232
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1a

    if-lt v1, v2, :cond_1

    .line 1233
    const/16 v1, 0x7f6

    move v5, v1

    goto :goto_0

    .line 1234
    :cond_1
    const/16 v1, 0x7d2

    move v5, v1

    :goto_0
    nop

    .line 1235
    .local v5, "type":I
    new-instance v1, Landroid/view/WindowManager$LayoutParams;

    .line 1236
    const/16 v2, 0x8c

    invoke-direct {p0, v2}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v3

    const/16 v2, 0x14

    invoke-direct {p0, v2}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v4

    const/16 v6, 0x318

    const/4 v7, -0x3

    move-object v2, v1

    invoke-direct/range {v2 .. v7}, Landroid/view/WindowManager$LayoutParams;-><init>(IIIII)V

    .line 1242
    .local v1, "p":Landroid/view/WindowManager$LayoutParams;
    const/16 v2, 0x31

    iput v2, v1, Landroid/view/WindowManager$LayoutParams;->gravity:I

    .line 1243
    const/16 v2, 0x10

    invoke-direct {p0, v2}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v2

    iput v2, v1, Landroid/view/WindowManager$LayoutParams;->y:I

    .line 1244
    iget-object v2, p0, Lcom/lvteam/OverlayService;->windowManager:Landroid/view/WindowManager;

    invoke-interface {v2, v0, v1}, Landroid/view/ViewManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1245
    return-void
.end method

.method private startAsForegroundService()V
    .locals 3

    .line 162
    const-string v0, "LV Team overlay"

    const/4 v1, 0x2

    const-string v2, "lv_team_overlay"

    invoke-static {v2, v0, v1}, Lcom/lvteam/OverlayService$$ExternalSyntheticApiModelOutline2;->m(Ljava/lang/String;Ljava/lang/CharSequence;I)Landroid/app/NotificationChannel;

    move-result-object v0

    .line 164
    .local v0, "channel":Landroid/app/NotificationChannel;
    const-class v1, Landroid/app/NotificationManager;

    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/app/NotificationManager;

    invoke-static {v1, v0}, Lcom/lvteam/OverlayService$$ExternalSyntheticApiModelOutline0;->m(Landroid/app/NotificationManager;Landroid/app/NotificationChannel;)V

    .line 165
    invoke-static {p0, v2}, Lcom/lvteam/OverlayService$$ExternalSyntheticApiModelOutline3;->m(Landroid/content/Context;Ljava/lang/String;)Landroid/app/Notification$Builder;

    move-result-object v1

    .line 166
    const v2, 0x1080057

    invoke-virtual {v1, v2}, Landroid/app/Notification$Builder;->setSmallIcon(I)Landroid/app/Notification$Builder;

    move-result-object v1

    .line 167
    const-string v2, "LV Team"

    invoke-virtual {v1, v2}, Landroid/app/Notification$Builder;->setContentTitle(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    move-result-object v1

    .line 168
    const-string v2, "Overlay ativo"

    invoke-virtual {v1, v2}, Landroid/app/Notification$Builder;->setContentText(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    move-result-object v1

    .line 169
    invoke-virtual {v1}, Landroid/app/Notification$Builder;->build()Landroid/app/Notification;

    move-result-object v1

    .line 170
    .local v1, "notification":Landroid/app/Notification;
    const/4 v2, 0x1

    invoke-virtual {p0, v2, v1}, Landroid/app/Service;->startForeground(ILandroid/app/Notification;)V

    .line 171
    return-void
.end method

.method private startPlayerListUpdater()V
    .locals 4

    .line 1083
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lcom/lvteam/OverlayService;->playerUpdateHandler:Landroid/os/Handler;

    .line 1084
    iget-object v0, p0, Lcom/lvteam/OverlayService;->playerUpdateHandler:Landroid/os/Handler;

    new-instance v1, Lcom/lvteam/OverlayService$3;

    invoke-direct {v1, p0}, Lcom/lvteam/OverlayService$3;-><init>(Lcom/lvteam/OverlayService;)V

    const-wide/16 v2, 0x1f4

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 1092
    return-void
.end method

.method private startSessionCheck()V
    .locals 4

    .line 1261
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lcom/lvteam/OverlayService;->sessionCheckHandler:Landroid/os/Handler;

    .line 1262
    iget-object v0, p0, Lcom/lvteam/OverlayService;->sessionCheckHandler:Landroid/os/Handler;

    new-instance v1, Lcom/lvteam/OverlayService$4;

    invoke-direct {v1, p0}, Lcom/lvteam/OverlayService$4;-><init>(Lcom/lvteam/OverlayService;)V

    const-wide/32 v2, 0x1d4c0

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 1281
    return-void
.end method

.method private styledArrow(Ljava/lang/String;)Landroid/widget/TextView;
    .locals 4
    .param p1, "arrow"    # Ljava/lang/String;

    .line 931
    new-instance v0, Landroid/widget/TextView;

    invoke-direct {v0, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 932
    .local v0, "v":Landroid/widget/TextView;
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 933
    const v1, -0xd6490a

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 934
    const/high16 v1, 0x41700000    # 15.0f

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextSize(F)V

    .line 935
    const/16 v1, 0x11

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setGravity(I)V

    .line 936
    new-instance v1, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v1}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 937
    .local v1, "bg":Landroid/graphics/drawable/GradientDrawable;
    const/4 v2, 0x7

    invoke-direct {p0, v2}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v2

    int-to-float v2, v2

    invoke-virtual {v1, v2}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 938
    const v2, -0xe3dccd

    invoke-virtual {v1, v2}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 939
    const/4 v2, 0x1

    invoke-direct {p0, v2}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v2

    const v3, -0xcbc3b6

    invoke-virtual {v1, v2, v3}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 940
    invoke-virtual {v0, v1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 941
    return-object v0
.end method

.method private swatchParams()Landroid/widget/LinearLayout$LayoutParams;
    .locals 3

    .line 715
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v1, 0x1a

    invoke-direct {p0, v1}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v2

    invoke-direct {p0, v1}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v1

    invoke-direct {v0, v2, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 716
    .local v0, "lp":Landroid/widget/LinearLayout$LayoutParams;
    const/16 v1, 0xa

    invoke-direct {p0, v1}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v1

    const/4 v2, 0x0

    invoke-virtual {v0, v2, v2, v1, v2}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 717
    return-object v0
.end method

.method private switchTab(I)V
    .locals 2
    .param p1, "tab"    # I

    .line 407
    iget v0, p0, Lcom/lvteam/OverlayService;->activeTab:I

    if-ne p1, v0, :cond_0

    return-void

    .line 408
    :cond_0
    iget-object v0, p0, Lcom/lvteam/OverlayService;->tabPanels:[Landroid/widget/LinearLayout;

    iget v1, p0, Lcom/lvteam/OverlayService;->activeTab:I

    aget-object v0, v0, v1

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 409
    iput p1, p0, Lcom/lvteam/OverlayService;->activeTab:I

    .line 410
    iget-object v0, p0, Lcom/lvteam/OverlayService;->tabPanels:[Landroid/widget/LinearLayout;

    iget v1, p0, Lcom/lvteam/OverlayService;->activeTab:I

    aget-object v0, v0, v1

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 411
    invoke-direct {p0, p1}, Lcom/lvteam/OverlayService;->highlightTab(I)V

    .line 412
    return-void
.end method

.method private syncIgnoredSlots()V
    .locals 5

    .line 1096
    new-instance v0, Ljava/util/ArrayList;

    iget-object v1, p0, Lcom/lvteam/OverlayService;->ignoredIds:Ljava/util/Set;

    invoke-interface {v1}, Ljava/util/Set;->size()I

    move-result v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 1097
    .local v0, "slots":Ljava/util/List;, "Ljava/util/List<Ljava/lang/Integer;>;"
    iget-object v1, p0, Lcom/lvteam/OverlayService;->ignoredIds:Ljava/util/Set;

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Integer;

    .line 1098
    .local v2, "id":Ljava/lang/Integer;
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v3

    invoke-static {v3}, Lcom/lvteam/EntityState;->slotOfRenderId(I)I

    move-result v3

    .line 1099
    .local v3, "slot":I
    if-lez v3, :cond_0

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v0, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 1100
    .end local v2    # "id":Ljava/lang/Integer;
    .end local v3    # "slot":I
    :cond_0
    goto :goto_0

    .line 1101
    :cond_1
    invoke-static {v0}, Lcom/lvteam/LvTeamShift;->setIgnoredSlots(Ljava/util/Collection;)V

    .line 1102
    return-void
.end method

.method private toggleIgnored(I)V
    .locals 2
    .param p1, "entityId"    # I

    .line 1105
    iget-object v0, p0, Lcom/lvteam/OverlayService;->ignoredIds:Ljava/util/Set;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Lcom/lvteam/OverlayService;->ignoredIds:Ljava/util/Set;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 1106
    :cond_0
    invoke-direct {p0}, Lcom/lvteam/OverlayService;->syncIgnoredSlots()V

    .line 1107
    invoke-direct {p0}, Lcom/lvteam/OverlayService;->refreshPlayerList()V

    .line 1108
    return-void
.end method

.method private updateBoxOptions()V
    .locals 7

    .line 1064
    iget-object v0, p0, Lcom/lvteam/OverlayService;->boxOverlay:Lcom/lvteam/EspOverlayView;

    if-eqz v0, :cond_4

    .line 1065
    iget-object v0, p0, Lcom/lvteam/OverlayService;->boxOverlay:Lcom/lvteam/EspOverlayView;

    iget-boolean v1, p0, Lcom/lvteam/OverlayService;->espEnabled:Z

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v1, :cond_0

    iget-boolean v1, p0, Lcom/lvteam/OverlayService;->boxEnabled:Z

    if-eqz v1, :cond_0

    move v1, v3

    goto :goto_0

    :cond_0
    move v1, v2

    :goto_0
    iget-boolean v4, p0, Lcom/lvteam/OverlayService;->espEnabled:Z

    if-eqz v4, :cond_1

    iget-boolean v4, p0, Lcom/lvteam/OverlayService;->drawLine:Z

    if-eqz v4, :cond_1

    move v4, v3

    goto :goto_1

    :cond_1
    move v4, v2

    :goto_1
    iget-boolean v5, p0, Lcom/lvteam/OverlayService;->espEnabled:Z

    if-eqz v5, :cond_2

    iget-boolean v5, p0, Lcom/lvteam/OverlayService;->drawDistance:Z

    if-eqz v5, :cond_2

    move v5, v3

    goto :goto_2

    :cond_2
    move v5, v2

    :goto_2
    iget-boolean v6, p0, Lcom/lvteam/OverlayService;->espEnabled:Z

    if-eqz v6, :cond_3

    iget-boolean v6, p0, Lcom/lvteam/OverlayService;->drawName:Z

    if-eqz v6, :cond_3

    move v2, v3

    :cond_3
    invoke-virtual {v0, v1, v4, v5, v2}, Lcom/lvteam/EspOverlayView;->setDrawOptions(ZZZZ)V

    .line 1070
    :cond_4
    return-void
.end method

.method private updateBoxStyle()V
    .locals 7

    .line 1057
    iget-object v0, p0, Lcom/lvteam/OverlayService;->boxOverlay:Lcom/lvteam/EspOverlayView;

    if-nez v0, :cond_0

    return-void

    .line 1058
    :cond_0
    iget-object v0, p0, Lcom/lvteam/OverlayService;->boxOverlay:Lcom/lvteam/EspOverlayView;

    iget-object v1, p0, Lcom/lvteam/OverlayService;->colors:[I

    iget-object v2, p0, Lcom/lvteam/OverlayService;->elementColor:[I

    const/4 v3, 0x0

    aget v2, v2, v3

    aget v1, v1, v2

    iget-object v2, p0, Lcom/lvteam/OverlayService;->colors:[I

    iget-object v3, p0, Lcom/lvteam/OverlayService;->elementColor:[I

    const/4 v4, 0x1

    aget v3, v3, v4

    aget v2, v2, v3

    iget-object v3, p0, Lcom/lvteam/OverlayService;->colors:[I

    iget-object v4, p0, Lcom/lvteam/OverlayService;->elementColor:[I

    const/4 v5, 0x2

    aget v4, v4, v5

    aget v3, v3, v4

    iget-object v4, p0, Lcom/lvteam/OverlayService;->colors:[I

    iget-object v5, p0, Lcom/lvteam/OverlayService;->elementColor:[I

    const/4 v6, 0x3

    aget v5, v5, v6

    aget v4, v4, v5

    invoke-virtual {v0, v1, v2, v3, v4}, Lcom/lvteam/EspOverlayView;->setColors(IIII)V

    .line 1060
    iget-object v0, p0, Lcom/lvteam/OverlayService;->boxOverlay:Lcom/lvteam/EspOverlayView;

    iget-object v1, p0, Lcom/lvteam/OverlayService;->thicknesses:[F

    iget v2, p0, Lcom/lvteam/OverlayService;->thicknessIndex:I

    aget v1, v1, v2

    invoke-virtual {v0, v1}, Lcom/lvteam/EspOverlayView;->setThickness(F)V

    .line 1061
    return-void
.end method

.method private updateCircleSize()V
    .locals 4

    .line 1003
    iget-object v0, p0, Lcom/lvteam/OverlayService;->circleOverlay:Landroid/view/View;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/lvteam/OverlayService;->circleParams:Landroid/view/WindowManager$LayoutParams;

    if-eqz v0, :cond_0

    .line 1004
    const/16 v0, 0x78

    invoke-direct {p0, v0}, Lcom/lvteam/OverlayService;->dp(I)I

    move-result v0

    iget v1, p0, Lcom/lvteam/OverlayService;->fovPercent:I

    mul-int/2addr v0, v1

    div-int/lit8 v0, v0, 0x64

    .line 1005
    .local v0, "size":I
    iget-object v1, p0, Lcom/lvteam/OverlayService;->circleParams:Landroid/view/WindowManager$LayoutParams;

    iput v0, v1, Landroid/view/WindowManager$LayoutParams;->width:I

    .line 1006
    iget-object v1, p0, Lcom/lvteam/OverlayService;->circleParams:Landroid/view/WindowManager$LayoutParams;

    iput v0, v1, Landroid/view/WindowManager$LayoutParams;->height:I

    .line 1007
    iget-object v1, p0, Lcom/lvteam/OverlayService;->circleOverlay:Landroid/view/View;

    invoke-direct {p0}, Lcom/lvteam/OverlayService;->circleBackground()Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1008
    iget-object v1, p0, Lcom/lvteam/OverlayService;->windowManager:Landroid/view/WindowManager;

    iget-object v2, p0, Lcom/lvteam/OverlayService;->circleOverlay:Landroid/view/View;

    iget-object v3, p0, Lcom/lvteam/OverlayService;->circleParams:Landroid/view/WindowManager$LayoutParams;

    invoke-interface {v1, v2, v3}, Landroid/view/ViewManager;->updateViewLayout(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1010
    .end local v0    # "size":I
    :cond_0
    return-void
.end method

.method private updateEnemyCounter(I)V
    .locals 3
    .param p1, "count"    # I

    .line 1212
    iget-object v0, p0, Lcom/lvteam/OverlayService;->enemyValue:Landroid/widget/TextView;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/lvteam/OverlayService;->enemyValue:Landroid/widget/TextView;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Enemy "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1213
    :cond_0
    return-void
.end method

.method private updateEspOverlay()V
    .locals 9

    .line 1024
    iget-boolean v0, p0, Lcom/lvteam/OverlayService;->espEnabled:Z

    const/4 v1, 0x1

    if-nez v0, :cond_0

    iget-boolean v0, p0, Lcom/lvteam/OverlayService;->enemyCounterEnabled:Z

    if-eqz v0, :cond_1

    :cond_0
    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    goto :goto_1

    :goto_0
    move v0, v1

    .line 1025
    .local v0, "needed":Z
    :goto_1
    if-eqz v0, :cond_5

    iget-object v2, p0, Lcom/lvteam/OverlayService;->boxOverlay:Lcom/lvteam/EspOverlayView;

    if-nez v2, :cond_5

    .line 1026
    new-instance v2, Lcom/lvteam/EspOverlayView;

    invoke-direct {v2, p0}, Lcom/lvteam/EspOverlayView;-><init>(Landroid/content/Context;)V

    iput-object v2, p0, Lcom/lvteam/OverlayService;->boxOverlay:Lcom/lvteam/EspOverlayView;

    .line 1027
    invoke-direct {p0}, Lcom/lvteam/OverlayService;->updateBoxStyle()V

    .line 1028
    invoke-direct {p0}, Lcom/lvteam/OverlayService;->updateBoxOptions()V

    .line 1029
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x1a

    if-lt v2, v3, :cond_2

    .line 1030
    const/16 v2, 0x7f6

    move v6, v2

    goto :goto_2

    .line 1031
    :cond_2
    const/16 v2, 0x7d2

    move v6, v2

    :goto_2
    nop

    .line 1032
    .local v6, "type":I
    new-instance v2, Landroid/view/WindowManager$LayoutParams;

    const/16 v7, 0x318

    const/4 v8, -0x3

    const/4 v4, -0x1

    const/4 v5, -0x1

    move-object v3, v2

    invoke-direct/range {v3 .. v8}, Landroid/view/WindowManager$LayoutParams;-><init>(IIIII)V

    .line 1041
    .local v2, "p":Landroid/view/WindowManager$LayoutParams;
    const v3, 0x800033

    iput v3, v2, Landroid/view/WindowManager$LayoutParams;->gravity:I

    .line 1042
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v4, 0x1c

    if-lt v3, v4, :cond_3

    .line 1043
    invoke-static {v2, v1}, Lcom/lvteam/OverlayService$$ExternalSyntheticApiModelOutline1;->m(Landroid/view/WindowManager$LayoutParams;I)V

    .line 1046
    :cond_3
    iget-object v3, p0, Lcom/lvteam/OverlayService;->windowManager:Landroid/view/WindowManager;

    iget-object v4, p0, Lcom/lvteam/OverlayService;->boxOverlay:Lcom/lvteam/EspOverlayView;

    invoke-interface {v3, v4, v2}, Landroid/view/ViewManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1047
    invoke-static {}, Landroid/view/Choreographer;->getInstance()Landroid/view/Choreographer;

    move-result-object v3

    iget-object v4, p0, Lcom/lvteam/OverlayService;->espFrame:Landroid/view/Choreographer$FrameCallback;

    invoke-virtual {v3, v4}, Landroid/view/Choreographer;->postFrameCallback(Landroid/view/Choreographer$FrameCallback;)V

    .line 1048
    .end local v2    # "p":Landroid/view/WindowManager$LayoutParams;
    .end local v6    # "type":I
    :cond_4
    goto :goto_3

    :cond_5
    if-nez v0, :cond_4

    .line 1049
    invoke-direct {p0}, Lcom/lvteam/OverlayService;->removeBox()V

    .line 1051
    :goto_3
    invoke-direct {p0}, Lcom/lvteam/OverlayService;->updateBoxOptions()V

    .line 1052
    iget-boolean v2, p0, Lcom/lvteam/OverlayService;->enemyCounterEnabled:Z

    if-eqz v2, :cond_6

    invoke-direct {p0, v1}, Lcom/lvteam/OverlayService;->setEnemyCounterEnabled(Z)V

    goto :goto_4

    .line 1053
    :cond_6
    invoke-direct {p0}, Lcom/lvteam/OverlayService;->removeEnemyCounter()V

    .line 1054
    :goto_4
    return-void
.end method


# virtual methods
.method public entityState()Lcom/lvteam/EntityState;
    .locals 1

    .line 1297
    iget-object v0, p0, Lcom/lvteam/OverlayService;->entityState:Lcom/lvteam/EntityState;

    return-object v0
.end method

.method public espEngine()Lcom/lvteam/EspEngine;
    .locals 1

    .line 1295
    iget-object v0, p0, Lcom/lvteam/OverlayService;->espEngine:Lcom/lvteam/EspEngine;

    return-object v0
.end method

.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 1
    .param p1, "intent"    # Landroid/content/Intent;

    .line 173
    const/4 v0, 0x0

    return-object v0
.end method

.method public onDestroy()V
    .locals 3

    .line 177
    iget-object v0, p0, Lcom/lvteam/OverlayService;->sessionCheckHandler:Landroid/os/Handler;

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    .line 178
    iget-object v0, p0, Lcom/lvteam/OverlayService;->sessionCheckHandler:Landroid/os/Handler;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    .line 179
    iput-object v1, p0, Lcom/lvteam/OverlayService;->sessionCheckHandler:Landroid/os/Handler;

    .line 181
    :cond_0
    iget-object v0, p0, Lcom/lvteam/OverlayService;->playerUpdateHandler:Landroid/os/Handler;

    if-eqz v0, :cond_1

    .line 182
    iget-object v0, p0, Lcom/lvteam/OverlayService;->playerUpdateHandler:Landroid/os/Handler;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    .line 183
    iput-object v1, p0, Lcom/lvteam/OverlayService;->playerUpdateHandler:Landroid/os/Handler;

    .line 185
    :cond_1
    invoke-direct {p0}, Lcom/lvteam/OverlayService;->removeCircle()V

    .line 186
    invoke-direct {p0}, Lcom/lvteam/OverlayService;->removeBox()V

    .line 187
    invoke-direct {p0}, Lcom/lvteam/OverlayService;->removeEnemyCounter()V

    .line 188
    invoke-direct {p0}, Lcom/lvteam/OverlayService;->removeTeamTitle()V

    .line 189
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_0
    const/4 v2, 0x5

    if-ge v0, v2, :cond_2

    invoke-static {v0}, Lcom/lvteam/LvShiftOverlay;->hideBtn(I)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 190
    .end local v0    # "i":I
    :cond_2
    iget-object v0, p0, Lcom/lvteam/OverlayService;->overlay:Landroid/view/View;

    if-eqz v0, :cond_3

    .line 191
    iget-object v0, p0, Lcom/lvteam/OverlayService;->windowManager:Landroid/view/WindowManager;

    iget-object v2, p0, Lcom/lvteam/OverlayService;->overlay:Landroid/view/View;

    invoke-interface {v0, v2}, Landroid/view/ViewManager;->removeView(Landroid/view/View;)V

    .line 192
    iput-object v1, p0, Lcom/lvteam/OverlayService;->overlay:Landroid/view/View;

    .line 194
    :cond_3
    invoke-super {p0}, Landroid/app/Service;->onDestroy()V

    .line 195
    return-void
.end method

.method public onStartCommand(Landroid/content/Intent;II)I
    .locals 2
    .param p1, "intent"    # Landroid/content/Intent;
    .param p2, "flags"    # I
    .param p3, "startId"    # I

    .line 152
    invoke-static {}, Lcom/lvteam/LvSession;->get()Lcom/lvteam/LvSession;

    move-result-object v0

    invoke-virtual {v0}, Lcom/lvteam/LvSession;->isActive()Z

    move-result v0

    const/4 v1, 0x2

    if-nez v0, :cond_0

    invoke-virtual {p0}, Landroid/app/Service;->stopSelf()V

    return v1

    .line 153
    :cond_0
    invoke-direct {p0}, Lcom/lvteam/OverlayService;->startAsForegroundService()V

    .line 154
    invoke-direct {p0}, Lcom/lvteam/OverlayService;->showOverlay()V

    .line 155
    invoke-direct {p0}, Lcom/lvteam/OverlayService;->showTeamTitle()V

    .line 156
    invoke-direct {p0}, Lcom/lvteam/OverlayService;->startSessionCheck()V

    .line 157
    invoke-direct {p0}, Lcom/lvteam/OverlayService;->startPlayerListUpdater()V

    .line 158
    return v1
.end method

.method public onTaskRemoved(Landroid/content/Intent;)V
    .locals 1
    .param p1, "rootIntent"    # Landroid/content/Intent;

    .line 199
    invoke-virtual {p0}, Landroid/app/Service;->stopSelf()V

    .line 200
    invoke-super {p0, p1}, Landroid/app/Service;->onTaskRemoved(Landroid/content/Intent;)V

    .line 201
    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v0

    invoke-static {v0}, Landroid/os/Process;->killProcess(I)V

    .line 202
    return-void
.end method
