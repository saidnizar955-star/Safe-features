.class public final Lcom/lvteam/ObfStrings;
.super Ljava/lang/Object;
.source "ObfStrings.java"


# direct methods
.method public static channel()Ljava/lang/String;
    .locals 1

    const/16 v0, 0x35

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    invoke-static {v0}, Lcom/lvteam/Obs;->d([B)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :array_0
    .array-data 1
        0x24t
        0x22t
        0x20t
        0x35t
        0x32t
        0x77t
        0x63t
        0x79t
        0x23t
        0x2dt
        0x20t
        0x39t
        0x3ft
        0x37t
        0x24t
        0x35t
        0x6ft
        0x2et
        0x23t
        0x3bt
        0x7bt
        0x26t
        0x29t
        0x2ct
        0x22t
        0x38t
        0x31t
        0x29t
        0x6et
        0x7dt
        0x7ct
        0x64t
        0x6dt
        0x13t
        0x23t
        0x75t
        0x75t
        0x3at
        0x36t
        0x11t
        0x70t
        0x5t
        0x3ft
        0x26t
        0x2ct
        0x29t
        0x13t
        0x26t
        0x3ct
        0x0t
        0x2t
        0x77t
        0x23t
    .end array-data
.end method

.method public static getKey()Ljava/lang/String;
    .locals 1

    const/16 v0, 0x7

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    invoke-static {v0}, Lcom/lvteam/Obs;->d([B)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :array_0
    .array-data 1
        0xbt
        0x33t
        0x20t
        0x65t
        0xat
        0x28t
        0x35t
    .end array-data
.end method

.method public static invalidJson()Ljava/lang/String;
    .locals 1

    const/16 v0, 0x17

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    invoke-static {v0}, Lcom/lvteam/Obs;->d([B)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :array_0
    .array-data 1
        0x37t
        0x74t
        0x31t
        0x37t
        0x33t
        0x22t
        0x3et
        0x74t
        0x6et
        0x67t
        0x28t
        0x23t
        0x3at
        0x37t
        0x38t
        0x2ct
        0x25t
        0x12t
        0x27t
        0x33t
        0x2dt
        0x67t
        0x3ct
    .end array-data
.end method

.method public static invalidMessage()Ljava/lang/String;
    .locals 1

    const/16 v0, 0xf

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    invoke-static {v0}, Lcom/lvteam/Obs;->d([B)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :array_0
    .array-data 1
        0xft
        0x3et
        0x35t
        0x33t
        0x24t
        0x6dt
        0x25t
        0x38t
        0x22t
        0x24t
        0x2dt
        0x24t
        0x28t
        0x37t
        0x75t
    .end array-data
.end method

.method public static password()Ljava/lang/String;
    .locals 1

    const/16 v0, 0x6

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    invoke-static {v0}, Lcom/lvteam/Obs;->d([B)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :array_0
    .array-data 1
        0x0t
        0x3ft
        0x20t
        0x2at
        0x9t
        0x35t
    .end array-data
.end method

.method public static success()Ljava/lang/String;
    .locals 1

    const/16 v0, 0x32

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    invoke-static {v0}, Lcom/lvteam/Obs;->d([B)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :array_0
    .array-data 1
        0x37t
        0x74t
        0x30t
        0x24t
        0x38t
        0x3et
        0x6et
        0x6ct
        0x67t
        0x73t
        0x74t
        0x61t
        0x6et
        0x3dt
        0x31t
        0x3ct
        0x4t
        0x35t
        0x3ct
        0x3ft
        0x26t
        0x20t
        0x32t
        0xct
        0x38t
        0x74t
        0x6et
        0x67t
        0x73t
        0x7dt
        0x75t
        0x6ft
        0x79t
        0x74t
        0x73t
        0x60t
        0x7ft
        0x67t
        0x0t
        0x77t
        0x72t
        0x77t
        0x79t
        0x6ft
        0x6et
        0x70t
        0x78t
        0x17t
        0x6et
        0x2bt
    .end array-data
.end method

.method public static successMessage()Ljava/lang/String;
    .locals 1

    const/16 v0, 0x1d

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    invoke-static {v0}, Lcom/lvteam/Obs;->d([B)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :array_0
    .array-data 1
        0xdt
        0x23t
        0x20t
        0x20t
        0x2ft
        0x39t
        0x25t
        0x35t
        0x35t
        0x21t
        0x2et
        0x6ct
        0x6ct
        0x12t
        0x3dt
        0x24t
        0x32t
        0x6dt
        0x3et
        0x33t
        0x27t
        0x31t
        0x20t
        0x23t
        0x38t
        0x33t
        0x27t
        0x7ft
        0x61t
    .end array-data
.end method
