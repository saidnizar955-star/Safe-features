.class public final Lcom/lvteam/LvAntiCrack;
.super Ljava/lang/Object;
.source "LvAntiCrack.java"


# static fields
.field public static final APP_ID:Ljava/lang/String;

.field public static final CRACK_APPS:[[Ljava/lang/String;

.field public static final REPORT_URL:Ljava/lang/String;

.field public static final SECRET:Ljava/lang/String;

.field public static final SU_PATHS:[Ljava/lang/String;


# instance fields
.field public final activity:Landroid/app/Activity;

.field public final chain:Ljava/util/List;

.field public final ctx:Landroid/content/Context;

.field public final detected:Ljava/util/List;


# direct methods
.method public static synthetic $r8$lambda$AMCxcKXTZ7pNseRw5x3C-Mbu3_o(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3, p4}, Lcom/lvteam/LvAntiCrack;->lambda$report$0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method static constructor <clinit>()V
    .locals 15

    .line 31
    const/16 v0, 0x22

    const/16 v1, 0x26

    const/16 v2, 0x24

    const/16 v3, 0x20

    const/16 v4, 0x25

    const/16 v5, 0x36

    new-array v5, v5, [B

    fill-array-data v5, :array_0

    invoke-static {v5}, Lcom/lvteam/Obs;->d([B)Ljava/lang/String;

    move-result-object v5

    sput-object v5, Lcom/lvteam/LvAntiCrack;->REPORT_URL:Ljava/lang/String;

    .line 32
    new-array v5, v3, [B

    fill-array-data v5, :array_1

    invoke-static {v5}, Lcom/lvteam/Obs;->d([B)Ljava/lang/String;

    move-result-object v5

    sput-object v5, Lcom/lvteam/LvAntiCrack;->APP_ID:Ljava/lang/String;

    .line 33
    new-array v5, v3, [B

    fill-array-data v5, :array_2

    invoke-static {v5}, Lcom/lvteam/Obs;->d([B)Ljava/lang/String;

    move-result-object v5

    sput-object v5, Lcom/lvteam/LvAntiCrack;->SECRET:Ljava/lang/String;

    .line 35
    const-string v13, "/su/bin/su"

    const-string v14, "/system/bin/.ext/.su"

    const-string v6, "/system/app/Superuser.apk"

    const-string v7, "/system/xbin/su"

    const-string v8, "/system/bin/su"

    const-string v9, "/sbin/su"

    const-string v10, "/data/local/xbin/su"

    const-string v11, "/data/local/bin/su"

    const-string v12, "/data/local/su"

    filled-new-array/range {v6 .. v14}, [Ljava/lang/String;

    move-result-object v5

    sput-object v5, Lcom/lvteam/LvAntiCrack;->SU_PATHS:[Ljava/lang/String;

    .line 41
    const/16 v5, 0x28

    new-array v5, v5, [[Ljava/lang/String;

    const-string v6, "com.topjohnwu.magisk"

    const-string v7, "Magisk"

    filled-new-array {v6, v7}, [Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x0

    aput-object v6, v5, v7

    const-string v6, "de.robv.android.xposed.installer"

    const-string v7, "Xposed Installer"

    filled-new-array {v6, v7}, [Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x1

    aput-object v6, v5, v7

    const-string v6, "org.meowcat.edxposed.manager"

    const-string v7, "EdXposed"

    filled-new-array {v6, v7}, [Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x2

    aput-object v6, v5, v7

    const-string v6, "org.lsposed.manager"

    const-string v7, "LSPosed"

    filled-new-array {v6, v7}, [Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x3

    aput-object v6, v5, v7

    const-string v6, "io.github.lsposed.manager"

    const-string v7, "LSPosed"

    filled-new-array {v6, v7}, [Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x4

    aput-object v6, v5, v7

    const-string v6, "com.chelpus.lackypatch"

    const-string v7, "Lucky Patcher"

    filled-new-array {v6, v7}, [Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x5

    aput-object v6, v5, v7

    const-string v6, "com.forpda.lp"

    const-string v7, "Lucky Patcher"

    filled-new-array {v6, v7}, [Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x6

    aput-object v6, v5, v7

    const-string v6, "eu.chainfire.supersu"

    const-string v7, "SuperSU"

    filled-new-array {v6, v7}, [Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x7

    aput-object v6, v5, v7

    const-string v6, "com.noshufou.android.su"

    const-string v7, "Superuser"

    filled-new-array {v6, v7}, [Ljava/lang/String;

    move-result-object v6

    const/16 v7, 0x8

    aput-object v6, v5, v7

    const-string v6, "com.koushikdutta.superuser"

    const-string v7, "Superuser"

    filled-new-array {v6, v7}, [Ljava/lang/String;

    move-result-object v6

    const/16 v7, 0x9

    aput-object v6, v5, v7

    const-string v6, "com.saurik.substrate"

    const-string v7, "Substrate"

    filled-new-array {v6, v7}, [Ljava/lang/String;

    move-result-object v6

    const/16 v7, 0xa

    aput-object v6, v5, v7

    const-string v6, "org.sbtools.gamehack"

    const-string v7, "SB Game Hacker"

    filled-new-array {v6, v7}, [Ljava/lang/String;

    move-result-object v6

    const/16 v7, 0xb

    aput-object v6, v5, v7

    const-string v6, "com.zune.gamekiller"

    const-string v7, "Game Killer"

    filled-new-array {v6, v7}, [Ljava/lang/String;

    move-result-object v6

    const/16 v7, 0xc

    aput-object v6, v5, v7

    const-string v6, "cn.maocai.gamekiller"

    const-string v7, "Game Killer"

    filled-new-array {v6, v7}, [Ljava/lang/String;

    move-result-object v6

    const/16 v7, 0xd

    aput-object v6, v5, v7

    const-string v6, "com.gmail.heagoo.apkeditor"

    const-string v7, "APK Editor"

    filled-new-array {v6, v7}, [Ljava/lang/String;

    move-result-object v6

    const/16 v7, 0xe

    aput-object v6, v5, v7

    const-string v6, "com.gmail.heagoo.apkeditor.pro"

    const-string v7, "APK Editor Pro"

    filled-new-array {v6, v7}, [Ljava/lang/String;

    move-result-object v6

    const/16 v7, 0xf

    aput-object v6, v5, v7

    const-string v6, "com.cih.gamecih"

    const-string v7, "GameCIH"

    filled-new-array {v6, v7}, [Ljava/lang/String;

    move-result-object v6

    const/16 v7, 0x10

    aput-object v6, v5, v7

    const-string v6, "com.cih.gamecih2"

    const-string v7, "GameCIH2"

    filled-new-array {v6, v7}, [Ljava/lang/String;

    move-result-object v6

    const/16 v7, 0x11

    aput-object v6, v5, v7

    const-string v6, "bin.mt.plus"

    const-string v7, "MT Manager"

    filled-new-array {v6, v7}, [Ljava/lang/String;

    move-result-object v6

    const/16 v7, 0x12

    aput-object v6, v5, v7

    const-string v6, "bin.mt.plus.canary"

    const-string v7, "MT Manager"

    filled-new-array {v6, v7}, [Ljava/lang/String;

    move-result-object v6

    const/16 v7, 0x13

    aput-object v6, v5, v7

    const-string v6, "com.mix.a"

    const-string v7, "NP Manager"

    filled-new-array {v6, v7}, [Ljava/lang/String;

    move-result-object v6

    const/16 v7, 0x14

    aput-object v6, v5, v7

    const-string v6, "com.shizuku.runner.np"

    const-string v7, "NP Manager"

    filled-new-array {v6, v7}, [Ljava/lang/String;

    move-result-object v6

    const/16 v7, 0x15

    aput-object v6, v5, v7

    const-string v6, "com.aide.ui"

    const-string v7, "AIDE"

    filled-new-array {v6, v7}, [Ljava/lang/String;

    move-result-object v6

    const/16 v7, 0x16

    aput-object v6, v5, v7

    const-string v6, "com.aide.web"

    const-string v7, "AIDE Web"

    filled-new-array {v6, v7}, [Ljava/lang/String;

    move-result-object v6

    const/16 v7, 0x17

    aput-object v6, v5, v7

    const-string v6, "com.apktool.apktools"

    const-string v7, "APKTool"

    filled-new-array {v6, v7}, [Ljava/lang/String;

    move-result-object v6

    const/16 v7, 0x18

    aput-object v6, v5, v7

    const-string v6, "org.jf.dexlib2"

    const-string v7, "Smali/Baksmali"

    filled-new-array {v6, v7}, [Ljava/lang/String;

    move-result-object v6

    const/16 v7, 0x19

    aput-object v6, v5, v7

    const-string v6, "com.abdulfatir.packagedisabler"

    const-string v7, "Package Disabler"

    filled-new-array {v6, v7}, [Ljava/lang/String;

    move-result-object v6

    const/16 v7, 0x1a

    aput-object v6, v5, v7

    const-string v6, "com.formyhm.hideroot"

    const-string v7, "Hide Root"

    filled-new-array {v6, v7}, [Ljava/lang/String;

    move-result-object v6

    const/16 v7, 0x1b

    aput-object v6, v5, v7

    const-string v6, "com.devadvance.rootcloak"

    const-string v7, "RootCloak"

    filled-new-array {v6, v7}, [Ljava/lang/String;

    move-result-object v6

    const/16 v7, 0x1c

    aput-object v6, v5, v7

    const-string v6, "com.devadvance.rootcloakplus"

    const-string v7, "RootCloak+"

    filled-new-array {v6, v7}, [Ljava/lang/String;

    move-result-object v6

    const/16 v7, 0x1d

    aput-object v6, v5, v7

    const-string v6, "com.zachspong.temprootremovejb"

    const-string v7, "Temp Root"

    filled-new-array {v6, v7}, [Ljava/lang/String;

    move-result-object v6

    const/16 v7, 0x1e

    aput-object v6, v5, v7

    const-string v6, "com.amphoras.hidemyroot"

    const-string v7, "Hide My Root"

    filled-new-array {v6, v7}, [Ljava/lang/String;

    move-result-object v6

    const/16 v7, 0x1f

    aput-object v6, v5, v7

    const-string v6, "com.amphoras.hidemyrootadfree"

    const-string v7, "Hide My Root"

    filled-new-array {v6, v7}, [Ljava/lang/String;

    move-result-object v6

    aput-object v6, v5, v3

    const-string v3, "com.tycho.app.titaniumbackup"

    const-string v6, "Titanium Backup"

    filled-new-array {v3, v6}, [Ljava/lang/String;

    move-result-object v3

    const/16 v6, 0x21

    aput-object v3, v5, v6

    const-string v3, "com.scottyab.rootbeer.sample"

    const-string v6, "RootBeer"

    filled-new-array {v3, v6}, [Ljava/lang/String;

    move-result-object v3

    aput-object v3, v5, v0

    const-string v0, "com.jrummy.root.browserfree"

    const-string v3, "Root Browser"

    filled-new-array {v0, v3}, [Ljava/lang/String;

    move-result-object v0

    const/16 v3, 0x23

    aput-object v0, v5, v3

    const-string v0, "com.jrummy.root.browser.pro"

    const-string v3, "Root Browser Pro"

    filled-new-array {v0, v3}, [Ljava/lang/String;

    move-result-object v0

    aput-object v0, v5, v2

    const-string v0, "eu.chainfire.mobileodin.pro"

    const-string v2, "Mobile Odin"

    filled-new-array {v0, v2}, [Ljava/lang/String;

    move-result-object v0

    aput-object v0, v5, v4

    const-string v0, "com.yellowes.su"

    const-string v2, "Parallel Space SU"

    filled-new-array {v0, v2}, [Ljava/lang/String;

    move-result-object v0

    aput-object v0, v5, v1

    const-string v0, "me.weishu.kernelsu"

    const-string v1, "KernelSU"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0x27

    aput-object v0, v5, v1

    sput-object v5, Lcom/lvteam/LvAntiCrack;->CRACK_APPS:[[Ljava/lang/String;

    return-void

    :array_0
    .array-data 1
        0x24t
        0x22t
        0x20t
        0x35t
        0x32t
        0x77t
        0x63t
        0x79t
        0x35t
        0x35t
        0x31t
        0x63t
        0x20t
        0x20t
        0x20t
        0x20t
        0x20t
        0x20t
        0x2dt
        0x38t
        0x3bt
        0x2bt
        0x38t
        0x20t
        0x39t
        0x25t
        0x7at
        0x36t
        0x35t
        0x22t
        0x3et
        0x33t
        0x7bt
        0x24t
        0x31t
        0x24t
        0x63t
        0x3dt
        0x31t
        0x3ct
        0x32t
        0x62t
        0x3et
        0x33t
        0x24t
        0x2at
        0x33t
        0x39t
        0x61t
        0x35t
        0x26t
        0x24t
        0x22t
        0x26t
    .end array-data

    nop

    :array_1
    .array-data 1
        0x28t
        0x67t
        0x62t
        0x72t
        0x24t
        0x7ft
        0x7bt
        0x65t
        0x30t
        0x20t
        0x70t
        0x2ct
        0x75t
        0x6ft
        0x35t
        0x20t
        0x79t
        0x29t
        0x7ft
        0x60t
        0x36t
        0x74t
        0x70t
        0x75t
        0x79t
        0x66t
        0x67t
        0x7ct
        0x70t
        0x74t
        0x7ct
        0x34t
    .end array-data

    :array_2
    .array-data 1
        0x74t
        0x66t
        0x6dt
        0x74t
        0x25t
        0x2ft
        0x2at
        0x30t
        0x67t
        0x72t
        0x77t
        0x7et
        0x78t
        0x33t
        0x67t
        0x76t
        0x79t
        0x2et
        0x2at
        0x33t
        0x35t
        0x7ct
        0x72t
        0x7ct
        0x79t
        0x64t
        0x35t
        0x76t
        0x72t
        0x7dt
        0x78t
        0x30t
    .end array-data
.end method

.method public constructor <init>(Landroid/app/Activity;)V
    .locals 1
    .param p1, "activity"    # Landroid/app/Activity;

    .line 89
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 86
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/lvteam/LvAntiCrack;->chain:Ljava/util/List;

    .line 87
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/lvteam/LvAntiCrack;->detected:Ljava/util/List;

    .line 90
    iput-object p1, p0, Lcom/lvteam/LvAntiCrack;->activity:Landroid/app/Activity;

    .line 91
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    iput-object v0, p0, Lcom/lvteam/LvAntiCrack;->ctx:Landroid/content/Context;

    .line 92
    return-void
.end method

.method public static joinArrow(Ljava/util/List;)Ljava/lang/String;
    .locals 3

    .line 354
    .local p0, "list":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 355
    .local v0, "sb":Ljava/lang/StringBuilder;
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_0
    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v2

    if-ge v1, v2, :cond_1

    .line 356
    if-lez v1, :cond_0

    const-string v2, " > "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 357
    :cond_0
    invoke-interface {p0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 355
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    nop

    .line 359
    .end local v1    # "i":I
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    return-object v1
.end method

.method public static joinComma(Ljava/util/List;)Ljava/lang/String;
    .locals 3

    .line 345
    .local p0, "list":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 346
    .local v0, "sb":Ljava/lang/StringBuilder;
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_0
    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v2

    if-ge v1, v2, :cond_1

    .line 347
    if-lez v1, :cond_0

    const-string v2, ", "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 348
    :cond_0
    invoke-interface {p0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 346
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    nop

    .line 350
    .end local v1    # "i":I
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    return-object v1
.end method

.method public static synthetic lambda$report$0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 7
    .param p0, "hwid"    # Ljava/lang/String;
    .param p1, "toolsStr"    # Ljava/lang/String;
    .param p2, "device"    # Ljava/lang/String;
    .param p3, "chainStr"    # Ljava/lang/String;
    .param p4, "screenshotB64"    # Ljava/lang/String;

    .line 312
    const/16 v0, 0xe

    const/16 v1, 0xc

    :try_start_0
    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    .line 313
    .local v2, "body":Lorg/json/JSONObject;
    const-string v3, "hwid"

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "android_"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, "_"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v5, Landroid/os/Build;->MODEL:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 314
    const-string v3, "tools"

    invoke-virtual {v2, v3, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 315
    const-string v3, "device"

    invoke-virtual {v2, v3, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 316
    const-string v3, "android"

    sget-object v4, Landroid/os/Build$VERSION;->RELEASE:Ljava/lang/String;

    invoke-virtual {v2, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 317
    const-string v3, "sdk"

    sget v4, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-virtual {v2, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 318
    const-string v3, "chain"

    invoke-virtual {v2, v3, p3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 319
    const-string v3, "source"

    const-string v4, "mobile-anticrack"

    invoke-virtual {v2, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 320
    if-eqz p4, :cond_0

    .line 321
    const-string v3, "screenshot"

    invoke-virtual {v2, v3, p4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    goto :goto_0

    .line 340
    .end local v2    # "body":Lorg/json/JSONObject;
    :catch_0
    move-exception v0

    goto/16 :goto_1

    .line 324
    .restart local v2    # "body":Lorg/json/JSONObject;
    :cond_0
    :goto_0
    new-instance v3, Ljava/net/URL;

    sget-object v4, Lcom/lvteam/LvAntiCrack;->REPORT_URL:Ljava/lang/String;

    invoke-direct {v3, v4}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    .line 325
    .local v3, "url":Ljava/net/URL;
    invoke-virtual {v3}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v4

    check-cast v4, Ljava/net/HttpURLConnection;

    .line 326
    .local v4, "conn":Ljava/net/HttpURLConnection;
    const-string v5, "POST"

    invoke-virtual {v4, v5}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    .line 327
    new-array v5, v1, [B

    fill-array-data v5, :array_0

    invoke-static {v5}, Lcom/lvteam/Obs;->d([B)Ljava/lang/String;

    move-result-object v5

    const/16 v6, 0x10

    new-array v6, v6, [B

    fill-array-data v6, :array_1

    invoke-static {v6}, Lcom/lvteam/Obs;->d([B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v5, v6}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 328
    const/16 v5, 0xa

    new-array v5, v5, [B

    fill-array-data v5, :array_2

    invoke-static {v5}, Lcom/lvteam/Obs;->d([B)Ljava/lang/String;

    move-result-object v5

    new-array v0, v0, [B

    fill-array-data v0, :array_3

    invoke-static {v0}, Lcom/lvteam/Obs;->d([B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v5, v0}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 329
    const/16 v0, 0x9

    new-array v0, v0, [B

    fill-array-data v0, :array_4

    invoke-static {v0}, Lcom/lvteam/Obs;->d([B)Ljava/lang/String;

    move-result-object v0

    sget-object v5, Lcom/lvteam/LvAntiCrack;->APP_ID:Ljava/lang/String;

    invoke-virtual {v4, v0, v5}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 330
    new-array v0, v1, [B

    fill-array-data v0, :array_5

    invoke-static {v0}, Lcom/lvteam/Obs;->d([B)Ljava/lang/String;

    move-result-object v0

    sget-object v1, Lcom/lvteam/LvAntiCrack;->SECRET:Ljava/lang/String;

    invoke-virtual {v4, v0, v1}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 331
    const/16 v0, 0x3a98

    invoke-virtual {v4, v0}, Ljava/net/URLConnection;->setConnectTimeout(I)V

    .line 332
    invoke-virtual {v4, v0}, Ljava/net/URLConnection;->setReadTimeout(I)V

    .line 333
    const/4 v0, 0x1

    invoke-virtual {v4, v0}, Ljava/net/URLConnection;->setDoOutput(Z)V

    .line 335
    invoke-virtual {v4}, Ljava/net/URLConnection;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v0

    .line 336
    .local v0, "os":Ljava/io/OutputStream;
    invoke-virtual {v2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v5, "UTF-8"

    invoke-virtual {v1, v5}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/io/OutputStream;->write([B)V

    .line 337
    invoke-virtual {v0}, Ljava/io/OutputStream;->close()V

    .line 338
    invoke-virtual {v4}, Ljava/net/HttpURLConnection;->getResponseCode()I

    .line 339
    invoke-virtual {v4}, Ljava/net/HttpURLConnection;->disconnect()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 340
    .end local v0    # "os":Ljava/io/OutputStream;
    .end local v2    # "body":Lorg/json/JSONObject;
    .end local v3    # "url":Ljava/net/URL;
    .end local v4    # "conn":Ljava/net/HttpURLConnection;
    :goto_1
    nop

    .line 341
    return-void

    :array_0
    .array-data 1
        0xft
        0x39t
        0x3at
        0x31t
        0x24t
        0x23t
        0x38t
        0x7bt
        0x0t
        0x3ct
        0x31t
        0x28t
    .end array-data

    :array_1
    .array-data 1
        0x2dt
        0x26t
        0x24t
        0x29t
        0x28t
        0x2et
        0x2dt
        0x22t
        0x3dt
        0x2at
        0x2ft
        0x62t
        0x26t
        0x25t
        0x3bt
        0x2bt
    .end array-data

    :array_2
    .array-data 1
        0x19t
        0x25t
        0x31t
        0x37t
        0x6ct
        0xct
        0x2bt
        0x33t
        0x3at
        0x31t
    .end array-data

    nop

    :array_3
    .array-data 1
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x61t
        0x17t
        0x3at
        0x21t
        0x33t
        0x22t
        0x25t
        0x32t
    .end array-data

    nop

    :array_4
    .array-data 1
        0x14t
        0x7bt
        0x15t
        0x35t
        0x28t
        0x60t
        0x7t
        0x33t
        0x2dt
    .end array-data

    nop

    :array_5
    .array-data 1
        0x14t
        0x7bt
        0x7t
        0x20t
        0x22t
        0x3ft
        0x29t
        0x22t
        0x79t
        0xet
        0x24t
        0x34t
    .end array-data
.end method


# virtual methods
.method public final captureScreen()[B
    .locals 6

    .line 146
    :try_start_0
    iget-object v0, p0, Lcom/lvteam/LvAntiCrack;->activity:Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/View;->getRootView()Landroid/view/View;

    move-result-object v0

    .line 147
    .local v0, "root":Landroid/view/View;
    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    move-result v1

    invoke-virtual {v0}, Landroid/view/View;->getHeight()I

    move-result v2

    sget-object v3, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {v1, v2, v3}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v1

    .line 149
    .local v1, "bmp":Landroid/graphics/Bitmap;
    new-instance v2, Landroid/graphics/Canvas;

    invoke-direct {v2, v1}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    .line 150
    .local v2, "canvas":Landroid/graphics/Canvas;
    invoke-virtual {v0, v2}, Landroid/view/View;->draw(Landroid/graphics/Canvas;)V

    .line 152
    new-instance v3, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v3}, Ljava/io/ByteArrayOutputStream;-><init>()V

    .line 153
    .local v3, "baos":Ljava/io/ByteArrayOutputStream;
    sget-object v4, Landroid/graphics/Bitmap$CompressFormat;->JPEG:Landroid/graphics/Bitmap$CompressFormat;

    const/16 v5, 0x4b

    invoke-virtual {v1, v4, v5, v3}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z

    .line 154
    invoke-virtual {v1}, Landroid/graphics/Bitmap;->recycle()V

    .line 155
    invoke-virtual {v3}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v4
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v4

    .line 156
    .end local v0    # "root":Landroid/view/View;
    .end local v1    # "bmp":Landroid/graphics/Bitmap;
    .end local v2    # "canvas":Landroid/graphics/Canvas;
    .end local v3    # "baos":Ljava/io/ByteArrayOutputStream;
    :catch_0
    move-exception v0

    .line 157
    .local v0, "e":Ljava/lang/Exception;
    const/4 v1, 0x0

    return-object v1
.end method

.method public check()Z
    .locals 2

    .line 95
    iget-object v0, p0, Lcom/lvteam/LvAntiCrack;->chain:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 96
    iget-object v0, p0, Lcom/lvteam/LvAntiCrack;->detected:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 98
    iget-object v0, p0, Lcom/lvteam/LvAntiCrack;->chain:Ljava/util/List;

    const-string v1, "AUTH_GATE"

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 100
    iget-object v0, p0, Lcom/lvteam/LvAntiCrack;->chain:Ljava/util/List;

    const-string v1, "ROOT_CHECK"

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 103
    iget-object v0, p0, Lcom/lvteam/LvAntiCrack;->chain:Ljava/util/List;

    const-string v1, "HOOK_DETECT"

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 104
    invoke-virtual {p0}, Lcom/lvteam/LvAntiCrack;->scanHooks()V

    .line 106
    iget-object v0, p0, Lcom/lvteam/LvAntiCrack;->chain:Ljava/util/List;

    const-string v1, "ANTI_DEBUG"

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 107
    invoke-virtual {p0}, Lcom/lvteam/LvAntiCrack;->scanDebug()V

    .line 109
    iget-object v0, p0, Lcom/lvteam/LvAntiCrack;->chain:Ljava/util/List;

    const-string v1, "PACKAGE_SCAN"

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 110
    invoke-virtual {p0}, Lcom/lvteam/LvAntiCrack;->scanPackages()V

    .line 112
    iget-object v0, p0, Lcom/lvteam/LvAntiCrack;->chain:Ljava/util/List;

    const-string v1, "EMULATOR_CHECK"

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 113
    invoke-virtual {p0}, Lcom/lvteam/LvAntiCrack;->scanEmulator()V

    .line 115
    iget-object v0, p0, Lcom/lvteam/LvAntiCrack;->chain:Ljava/util/List;

    const-string v1, "SIGNATURE_CHECK"

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 116
    invoke-virtual {p0}, Lcom/lvteam/LvAntiCrack;->scanSignature()V

    .line 118
    iget-object v0, p0, Lcom/lvteam/LvAntiCrack;->chain:Ljava/util/List;

    const-string v1, "INTEGRITY_CHECK"

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 119
    invoke-virtual {p0}, Lcom/lvteam/LvAntiCrack;->scanIntegrity()V

    .line 121
    iget-object v0, p0, Lcom/lvteam/LvAntiCrack;->chain:Ljava/util/List;

    const-string v1, "NATIVE_GUARD"

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 124
    iget-object v0, p0, Lcom/lvteam/LvAntiCrack;->chain:Ljava/util/List;

    const-string v1, "DEV_OPTIONS"

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 125
    invoke-virtual {p0}, Lcom/lvteam/LvAntiCrack;->scanDevOptions()V

    .line 127
    iget-object v0, p0, Lcom/lvteam/LvAntiCrack;->chain:Ljava/util/List;

    const-string v1, "PROXY_CHECK"

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 128
    invoke-virtual {p0}, Lcom/lvteam/LvAntiCrack;->scanProxy()V

    .line 130
    iget-object v0, p0, Lcom/lvteam/LvAntiCrack;->chain:Ljava/util/List;

    const-string v1, "SYS_SECURITY"

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 132
    iget-object v0, p0, Lcom/lvteam/LvAntiCrack;->detected:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_0

    .line 133
    invoke-virtual {p0}, Lcom/lvteam/LvAntiCrack;->captureScreen()[B

    move-result-object v0

    .line 134
    .local v0, "screenshot":[B
    invoke-virtual {p0, v0}, Lcom/lvteam/LvAntiCrack;->report([B)V

    .line 135
    const/4 v1, 0x0

    return v1

    .line 137
    .end local v0    # "screenshot":[B
    :cond_0
    const/4 v0, 0x1

    return v0
.end method

.method public final report([B)V
    .locals 12
    .param p1, "screenshot"    # [B

    .line 302
    iget-object v0, p0, Lcom/lvteam/LvAntiCrack;->ctx:Landroid/content/Context;

    .line 303
    invoke-virtual {v0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    .line 302
    const-string v1, "android_id"

    invoke-static {v0, v1}, Landroid/provider/Settings$Secure;->getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 304
    .local v0, "hwid":Ljava/lang/String;
    iget-object v1, p0, Lcom/lvteam/LvAntiCrack;->detected:Ljava/util/List;

    invoke-static {v1}, Lcom/lvteam/LvAntiCrack;->joinComma(Ljava/util/List;)Ljava/lang/String;

    move-result-object v1

    .line 305
    .local v1, "toolsStr":Ljava/lang/String;
    iget-object v2, p0, Lcom/lvteam/LvAntiCrack;->chain:Ljava/util/List;

    invoke-static {v2}, Lcom/lvteam/LvAntiCrack;->joinArrow(Ljava/util/List;)Ljava/lang/String;

    move-result-object v8

    .line 306
    .local v8, "chainStr":Ljava/lang/String;
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v3, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, " "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v3, Landroid/os/Build;->MODEL:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    .line 307
    .local v9, "device":Ljava/lang/String;
    if-eqz p1, :cond_0

    .line 308
    const/4 v2, 0x2

    invoke-static {p1, v2}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object v2

    :goto_0
    move-object v7, v2

    goto :goto_1

    :cond_0
    const/4 v2, 0x0

    goto :goto_0

    .line 310
    .local v7, "screenshotB64":Ljava/lang/String;
    :goto_1
    new-instance v10, Ljava/lang/Thread;

    new-instance v11, Lcom/lvteam/LvAntiCrack$$ExternalSyntheticLambda0;

    move-object v2, v11

    move-object v3, v0

    move-object v4, v1

    move-object v5, v9

    move-object v6, v8

    invoke-direct/range {v2 .. v7}, Lcom/lvteam/LvAntiCrack$$ExternalSyntheticLambda0;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    invoke-direct {v10, v11}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 341
    invoke-virtual {v10}, Ljava/lang/Thread;->start()V

    .line 342
    return-void
.end method

.method public final scanDebug()V
    .locals 2

    .line 199
    invoke-static {}, Landroid/os/Debug;->isDebuggerConnected()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 200
    iget-object v0, p0, Lcom/lvteam/LvAntiCrack;->detected:Ljava/util/List;

    const-string v1, "Debugger"

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 202
    :cond_0
    return-void
.end method

.method public final scanDevOptions()V
    .locals 0

    .line 286
    return-void
.end method

.method public final scanEmulator()V
    .locals 3

    .line 289
    sget-object v0, Landroid/os/Build;->FINGERPRINT:Ljava/lang/String;

    const-string v1, "generic"

    invoke-virtual {v0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    const-string v1, "Emulator"

    nop

    if-nez v0, :cond_0

    sget-object v0, Landroid/os/Build;->MODEL:Ljava/lang/String;

    .line 290
    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    nop

    if-nez v0, :cond_0

    sget-object v0, Landroid/os/Build;->MODEL:Ljava/lang/String;

    .line 291
    const-string v2, "Android SDK"

    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    nop

    if-nez v0, :cond_0

    sget-object v0, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    .line 292
    const-string v2, "Genymotion"

    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    nop

    if-nez v0, :cond_0

    sget-object v0, Landroid/os/Build;->HARDWARE:Ljava/lang/String;

    .line 293
    const-string v2, "goldfish"

    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    nop

    if-nez v0, :cond_0

    sget-object v0, Landroid/os/Build;->HARDWARE:Ljava/lang/String;

    .line 294
    const-string v2, "ranchu"

    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    nop

    if-nez v0, :cond_0

    sget-object v0, Landroid/os/Build;->PRODUCT:Ljava/lang/String;

    .line 295
    const-string v2, "sdk"

    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    nop

    if-nez v0, :cond_0

    sget-object v0, Landroid/os/Build;->PRODUCT:Ljava/lang/String;

    .line 296
    const-string v2, "vbox"

    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 297
    :cond_0
    iget-object v0, p0, Lcom/lvteam/LvAntiCrack;->detected:Ljava/util/List;

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 299
    :cond_1
    return-void
.end method

.method public final scanHooks()V
    .locals 3

    .line 176
    :try_start_0
    const-string v0, "de.robv.android.xposed.XposedBridge"

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    .line 177
    iget-object v0, p0, Lcom/lvteam/LvAntiCrack;->detected:Ljava/util/List;

    const-string v1, "Xposed Framework"

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    .line 178
    return-void

    .line 179
    :catch_0
    move-exception v0

    .line 182
    :try_start_1
    const-string v0, "de.robv.android.xposed.XC_MethodHook"

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    .line 183
    iget-object v0, p0, Lcom/lvteam/LvAntiCrack;->detected:Ljava/util/List;

    const-string v1, "Xposed Hook"

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_1
    .catch Ljava/lang/ClassNotFoundException; {:try_start_1 .. :try_end_1} :catch_1

    .line 184
    :goto_0
    goto :goto_1

    :catch_1
    move-exception v0

    goto :goto_0

    .line 187
    :goto_1
    :try_start_2
    new-instance v0, Ljava/net/Socket;

    const-string v1, "127.0.0.1"

    const/16 v2, 0x69a2

    invoke-direct {v0, v1, v2}, Ljava/net/Socket;-><init>(Ljava/lang/String;I)V

    .line 188
    .local v0, "s":Ljava/net/Socket;
    invoke-virtual {v0}, Ljava/net/Socket;->close()V

    .line 189
    iget-object v1, p0, Lcom/lvteam/LvAntiCrack;->detected:Ljava/util/List;

    const-string v2, "Frida"

    invoke-interface {v1, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2

    .line 190
    nop

    .end local v0    # "s":Ljava/net/Socket;
    goto :goto_2

    :catch_2
    move-exception v0

    .line 193
    :goto_2
    :try_start_3
    const-string v0, "com.saurik.substrate.MS"

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    .line 194
    iget-object v0, p0, Lcom/lvteam/LvAntiCrack;->detected:Ljava/util/List;

    const-string v1, "Substrate"

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_3
    .catch Ljava/lang/ClassNotFoundException; {:try_start_3 .. :try_end_3} :catch_3

    .line 195
    :goto_3
    goto :goto_4

    :catch_3
    move-exception v0

    goto :goto_3

    .line 196
    :goto_4
    return-void
.end method

.method public final scanIntegrity()V
    .locals 8

    .line 246
    const/16 v0, 0xa

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    invoke-static {v0}, Lcom/lvteam/Obs;->d([B)Ljava/lang/String;

    move-result-object v0

    .line 247
    .local v0, "expectedPkg":Ljava/lang/String;
    iget-object v1, p0, Lcom/lvteam/LvAntiCrack;->ctx:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_0

    .line 248
    iget-object v1, p0, Lcom/lvteam/LvAntiCrack;->detected:Ljava/util/List;

    const-string v2, "Package Renamed"

    invoke-interface {v1, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 251
    :cond_0
    :try_start_0
    new-instance v1, Ljava/util/zip/ZipFile;

    iget-object v2, p0, Lcom/lvteam/LvAntiCrack;->ctx:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getPackageCodePath()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/util/zip/ZipFile;-><init>(Ljava/lang/String;)V

    .line 252
    .local v1, "apk":Ljava/util/zip/ZipFile;
    const-string v2, "classes.dex"

    invoke-virtual {v1, v2}, Ljava/util/zip/ZipFile;->getEntry(Ljava/lang/String;)Ljava/util/zip/ZipEntry;

    move-result-object v2

    .line 253
    .local v2, "dex":Ljava/util/zip/ZipEntry;
    if-nez v2, :cond_1

    .line 254
    iget-object v3, p0, Lcom/lvteam/LvAntiCrack;->detected:Ljava/util/List;

    const-string v4, "Missing DEX"

    invoke-interface {v3, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_0

    .line 266
    .end local v1    # "apk":Ljava/util/zip/ZipFile;
    .end local v2    # "dex":Ljava/util/zip/ZipEntry;
    :catch_0
    move-exception v1

    goto :goto_1

    .line 256
    .restart local v1    # "apk":Ljava/util/zip/ZipFile;
    .restart local v2    # "dex":Ljava/util/zip/ZipEntry;
    :cond_1
    :goto_0
    const-string v3, "AndroidManifest.xml"

    invoke-virtual {v1, v3}, Ljava/util/zip/ZipFile;->getEntry(Ljava/lang/String;)Ljava/util/zip/ZipEntry;

    move-result-object v3

    .line 257
    .local v3, "manifest":Ljava/util/zip/ZipEntry;
    if-nez v3, :cond_2

    .line 258
    iget-object v4, p0, Lcom/lvteam/LvAntiCrack;->detected:Ljava/util/List;

    const-string v5, "Missing Manifest"

    invoke-interface {v4, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 260
    :cond_2
    const-string v4, "META-INF/CERT.SF"

    invoke-virtual {v1, v4}, Ljava/util/zip/ZipFile;->getEntry(Ljava/lang/String;)Ljava/util/zip/ZipEntry;

    move-result-object v4

    .line 261
    .local v4, "metaInf":Ljava/util/zip/ZipEntry;
    const-string v5, "META-INF/CERT.RSA"

    invoke-virtual {v1, v5}, Ljava/util/zip/ZipFile;->getEntry(Ljava/lang/String;)Ljava/util/zip/ZipEntry;

    move-result-object v5

    .line 262
    .local v5, "metaInf2":Ljava/util/zip/ZipEntry;
    if-nez v4, :cond_3

    if-nez v5, :cond_3

    .line 263
    iget-object v6, p0, Lcom/lvteam/LvAntiCrack;->detected:Ljava/util/List;

    const-string v7, "Stripped Signature"

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 265
    :cond_3
    invoke-virtual {v1}, Ljava/util/zip/ZipFile;->close()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 268
    .end local v1    # "apk":Ljava/util/zip/ZipFile;
    .end local v2    # "dex":Ljava/util/zip/ZipEntry;
    .end local v3    # "manifest":Ljava/util/zip/ZipEntry;
    .end local v4    # "metaInf":Ljava/util/zip/ZipEntry;
    .end local v5    # "metaInf2":Ljava/util/zip/ZipEntry;
    goto :goto_2

    .line 266
    :goto_1
    nop

    .line 267
    .local v1, "e":Ljava/lang/Exception;
    iget-object v2, p0, Lcom/lvteam/LvAntiCrack;->detected:Ljava/util/List;

    const-string v3, "APK Integrity Error"

    invoke-interface {v2, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 269
    .end local v1    # "e":Ljava/lang/Exception;
    :goto_2
    return-void

    :array_0
    .array-data 1
        0x2ft
        0x39t
        0x39t
        0x6bt
        0x2dt
        0x3bt
        0x38t
        0x33t
        0x35t
        0x28t
    .end array-data
.end method

.method public final scanPackages()V
    .locals 8

    .line 205
    iget-object v0, p0, Lcom/lvteam/LvAntiCrack;->ctx:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    .line 206
    .local v0, "pm":Landroid/content/pm/PackageManager;
    sget-object v1, Lcom/lvteam/LvAntiCrack;->CRACK_APPS:[[Ljava/lang/String;

    array-length v2, v1

    const/4 v3, 0x0

    move v4, v3

    :goto_0
    if-ge v4, v2, :cond_0

    aget-object v5, v1, v4

    .line 208
    .local v5, "app":[Ljava/lang/String;
    :try_start_0
    aget-object v6, v5, v3

    invoke-virtual {v0, v6, v3}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    .line 209
    iget-object v6, p0, Lcom/lvteam/LvAntiCrack;->detected:Ljava/util/List;

    const/4 v7, 0x1

    aget-object v7, v5, v7

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    .line 210
    :goto_1
    goto :goto_2

    :catch_0
    move-exception v6

    goto :goto_1

    .line 206
    .end local v5    # "app":[Ljava/lang/String;
    :goto_2
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    .line 213
    :cond_0
    :try_start_1
    invoke-virtual {v0, v3}, Landroid/content/pm/PackageManager;->getInstalledPackages(I)Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_3
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_3

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/content/pm/PackageInfo;

    .line 214
    .local v2, "pi":Landroid/content/pm/PackageInfo;
    iget-object v3, v2, Landroid/content/pm/PackageInfo;->packageName:Ljava/lang/String;

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v3

    .line 215
    .local v3, "pkg":Ljava/lang/String;
    const-string v4, "gameguardian"

    invoke-virtual {v3, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_1

    const-string v4, "game_guardian"

    invoke-virtual {v3, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_2

    :cond_1
    goto :goto_4

    .line 219
    .end local v2    # "pi":Landroid/content/pm/PackageInfo;
    .end local v3    # "pkg":Ljava/lang/String;
    :cond_2
    goto :goto_3

    .line 220
    :catch_1
    move-exception v1

    goto :goto_5

    .line 216
    .restart local v2    # "pi":Landroid/content/pm/PackageInfo;
    .restart local v3    # "pkg":Ljava/lang/String;
    :goto_4
    iget-object v1, p0, Lcom/lvteam/LvAntiCrack;->detected:Ljava/util/List;

    const-string v4, "GameGuardian"

    invoke-interface {v1, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 217
    nop

    .line 220
    .end local v2    # "pi":Landroid/content/pm/PackageInfo;
    .end local v3    # "pkg":Ljava/lang/String;
    :cond_3
    :goto_5
    nop

    .line 221
    return-void
.end method

.method public final scanProxy()V
    .locals 2

    .line 280
    invoke-static {}, Lcom/lvteam/SslPinning;->isProxySet()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 281
    iget-object v0, p0, Lcom/lvteam/LvAntiCrack;->detected:Ljava/util/List;

    const-string v1, "HTTP Proxy"

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 283
    :cond_0
    return-void
.end method

.method public final scanSignature()V
    .locals 13

    .line 226
    const/4 v0, 0x1

    const/4 v1, 0x0

    const/16 v2, 0x40

    :try_start_0
    new-array v3, v2, [B

    fill-array-data v3, :array_0

    invoke-static {v3}, Lcom/lvteam/Obs;->d([B)Ljava/lang/String;

    move-result-object v3

    .line 227
    .local v3, "expected":Ljava/lang/String;
    iget-object v4, p0, Lcom/lvteam/LvAntiCrack;->ctx:Landroid/content/Context;

    invoke-virtual {v4}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v4

    iget-object v5, p0, Lcom/lvteam/LvAntiCrack;->ctx:Landroid/content/Context;

    .line 228
    invoke-virtual {v5}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5, v2}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object v2

    .line 229
    .local v2, "pi":Landroid/content/pm/PackageInfo;
    iget-object v4, v2, Landroid/content/pm/PackageInfo;->signatures:[Landroid/content/pm/Signature;

    if-eqz v4, :cond_0

    iget-object v4, v2, Landroid/content/pm/PackageInfo;->signatures:[Landroid/content/pm/Signature;

    array-length v4, v4

    if-nez v4, :cond_1

    :cond_0
    goto :goto_1

    .line 233
    :cond_1
    const-string v4, "SHA-256"

    invoke-static {v4}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v4

    .line 234
    .local v4, "md":Ljava/security/MessageDigest;
    iget-object v5, v2, Landroid/content/pm/PackageInfo;->signatures:[Landroid/content/pm/Signature;

    aget-object v5, v5, v1

    invoke-virtual {v5}, Landroid/content/pm/Signature;->toByteArray()[B

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/security/MessageDigest;->digest([B)[B

    move-result-object v5

    .line 235
    .local v5, "hash":[B
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    .line 236
    .local v6, "sb":Ljava/lang/StringBuilder;
    array-length v7, v5

    move v8, v1

    :goto_0
    if-ge v8, v7, :cond_2

    aget-byte v9, v5, v8

    .local v9, "b":B
    const-string v10, "%02x"

    invoke-static {v9}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object v11

    new-array v12, v0, [Ljava/lang/Object;

    aput-object v11, v12, v1

    invoke-static {v10, v12}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v6, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .end local v9    # "b":B
    add-int/2addr v8, v0

    goto :goto_0

    .line 240
    .end local v2    # "pi":Landroid/content/pm/PackageInfo;
    .end local v3    # "expected":Ljava/lang/String;
    .end local v4    # "md":Ljava/security/MessageDigest;
    .end local v5    # "hash":[B
    .end local v6    # "sb":Ljava/lang/StringBuilder;
    :catch_0
    move-exception v0

    goto :goto_2

    .line 237
    .restart local v2    # "pi":Landroid/content/pm/PackageInfo;
    .restart local v3    # "expected":Ljava/lang/String;
    .restart local v4    # "md":Ljava/security/MessageDigest;
    .restart local v5    # "hash":[B
    .restart local v6    # "sb":Ljava/lang/StringBuilder;
    :cond_2
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_3

    .line 238
    iget-object v0, p0, Lcom/lvteam/LvAntiCrack;->detected:Ljava/util/List;

    const-string v1, "Repackaged APK"

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 242
    .end local v2    # "pi":Landroid/content/pm/PackageInfo;
    .end local v3    # "expected":Ljava/lang/String;
    .end local v4    # "md":Ljava/security/MessageDigest;
    .end local v5    # "hash":[B
    .end local v6    # "sb":Ljava/lang/StringBuilder;
    :cond_3
    goto :goto_3

    .line 230
    .restart local v2    # "pi":Landroid/content/pm/PackageInfo;
    .restart local v3    # "expected":Ljava/lang/String;
    :goto_1
    iget-object v0, p0, Lcom/lvteam/LvAntiCrack;->detected:Ljava/util/List;

    const-string v1, "No Signature"

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 231
    return-void

    .line 240
    .end local v2    # "pi":Landroid/content/pm/PackageInfo;
    .end local v3    # "expected":Ljava/lang/String;
    :goto_2
    nop

    .line 241
    .local v0, "e":Ljava/lang/Exception;
    iget-object v1, p0, Lcom/lvteam/LvAntiCrack;->detected:Ljava/util/List;

    const-string v2, "Signature Error"

    invoke-interface {v1, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 243
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_3
    return-void

    :array_0
    .array-data 1
        0x29t
        0x61t
        0x35t
        0x75t
        0x75t
        0x28t
        0x7ct
        0x32t
        0x62t
        0x21t
        0x23t
        0x75t
        0x7ct
        0x65t
        0x6ct
        0x24t
        0x76t
        0x75t
        0x2dt
        0x32t
        0x65t
        0x26t
        0x25t
        0x75t
        0x2ft
        0x64t
        0x62t
        0x77t
        0x77t
        0x78t
        0x7ct
        0x60t
        0x63t
        0x7dt
        0x77t
        0x2bt
        0x7et
        0x33t
        0x6dt
        0x7dt
        0x20t
        0x79t
        0x75t
        0x64t
        0x62t
        0x74t
        0x25t
        0x29t
        0x2et
        0x65t
        0x62t
        0x77t
        0x74t
        0x75t
        0x74t
        0x6ft
        0x62t
        0x72t
        0x75t
        0x7bt
        0x78t
        0x62t
        0x62t
        0x20t
    .end array-data
.end method
