.class public final Lcom/lvteam/PacketCaptureService$UdpFlow;
.super Ljava/lang/Object;
.source "PacketCaptureService.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/lvteam/PacketCaptureService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x11
    name = "UdpFlow"
.end annotation


# instance fields
.field public final key:Lcom/lvteam/PacketCaptureService$FlowKey;

.field public volatile lastActivityMillis:J

.field public final socket:Ljava/net/DatagramSocket;

.field public final synthetic this$0:Lcom/lvteam/PacketCaptureService;


# direct methods
.method public constructor <init>(Lcom/lvteam/PacketCaptureService;Lcom/lvteam/PacketCaptureService$FlowKey;Ljava/net/DatagramSocket;)V
    .locals 2
    .param p2, "key"    # Lcom/lvteam/PacketCaptureService$FlowKey;
    .param p3, "socket"    # Ljava/net/DatagramSocket;

    .line 482
    iput-object p1, p0, Lcom/lvteam/PacketCaptureService$UdpFlow;->this$0:Lcom/lvteam/PacketCaptureService;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 483
    iput-object p2, p0, Lcom/lvteam/PacketCaptureService$UdpFlow;->key:Lcom/lvteam/PacketCaptureService$FlowKey;

    .line 484
    iput-object p3, p0, Lcom/lvteam/PacketCaptureService$UdpFlow;->socket:Ljava/net/DatagramSocket;

    .line 485
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    iput-wide v0, p0, Lcom/lvteam/PacketCaptureService$UdpFlow;->lastActivityMillis:J

    .line 486
    return-void
.end method


# virtual methods
.method public close()V
    .locals 1

    .line 532
    iget-object v0, p0, Lcom/lvteam/PacketCaptureService$UdpFlow;->socket:Ljava/net/DatagramSocket;

    invoke-virtual {v0}, Ljava/net/DatagramSocket;->close()V

    .line 533
    return-void
.end method

.method public isIdle(J)Z
    .locals 4
    .param p1, "now"    # J

    .line 536
    iget-wide v0, p0, Lcom/lvteam/PacketCaptureService$UdpFlow;->lastActivityMillis:J

    sub-long v0, p1, v0

    const-wide/16 v2, 0x7530

    cmp-long v0, v0, v2

    if-ltz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final removeAndClose()V
    .locals 3

    .line 540
    iget-object v0, p0, Lcom/lvteam/PacketCaptureService$UdpFlow;->socket:Ljava/net/DatagramSocket;

    invoke-virtual {v0}, Ljava/net/DatagramSocket;->close()V

    .line 541
    iget-object v0, p0, Lcom/lvteam/PacketCaptureService$UdpFlow;->this$0:Lcom/lvteam/PacketCaptureService;

    invoke-static {v0}, Lcom/lvteam/PacketCaptureService;->-$$Nest$fgetflowLock(Lcom/lvteam/PacketCaptureService;)Ljava/lang/Object;

    move-result-object v0

    monitor-enter v0

    .line 542
    :try_start_0
    iget-object v1, p0, Lcom/lvteam/PacketCaptureService$UdpFlow;->this$0:Lcom/lvteam/PacketCaptureService;

    invoke-static {v1}, Lcom/lvteam/PacketCaptureService;->-$$Nest$fgetflows(Lcom/lvteam/PacketCaptureService;)Ljava/util/Map;

    move-result-object v1

    iget-object v2, p0, Lcom/lvteam/PacketCaptureService$UdpFlow;->key:Lcom/lvteam/PacketCaptureService$FlowKey;

    invoke-interface {v1, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    if-ne v1, p0, :cond_0

    iget-object v1, p0, Lcom/lvteam/PacketCaptureService$UdpFlow;->this$0:Lcom/lvteam/PacketCaptureService;

    invoke-static {v1}, Lcom/lvteam/PacketCaptureService;->-$$Nest$fgetflows(Lcom/lvteam/PacketCaptureService;)Ljava/util/Map;

    move-result-object v1

    iget-object v2, p0, Lcom/lvteam/PacketCaptureService$UdpFlow;->key:Lcom/lvteam/PacketCaptureService$FlowKey;

    invoke-interface {v1, v2}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_0

    .line 543
    :catchall_0
    move-exception v1

    goto :goto_1

    :cond_0
    :goto_0
    monitor-exit v0

    .line 544
    return-void

    .line 543
    :goto_1
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v1
.end method

.method public run()V
    .locals 13

    .line 500
    const v0, 0xffff

    new-array v1, v0, [B

    .line 501
    .local v1, "buffer":[B
    new-instance v2, Ljava/net/DatagramPacket;

    array-length v3, v1

    invoke-direct {v2, v1, v3}, Ljava/net/DatagramPacket;-><init>([BI)V

    .line 503
    .local v2, "response":Ljava/net/DatagramPacket;
    :goto_0
    :try_start_0
    iget-object v3, p0, Lcom/lvteam/PacketCaptureService$UdpFlow;->this$0:Lcom/lvteam/PacketCaptureService;

    invoke-static {v3}, Lcom/lvteam/PacketCaptureService;->-$$Nest$fgetrelayRunning(Lcom/lvteam/PacketCaptureService;)Z

    move-result v3

    if-eqz v3, :cond_1

    iget-object v3, p0, Lcom/lvteam/PacketCaptureService$UdpFlow;->socket:Ljava/net/DatagramSocket;

    invoke-virtual {v3}, Ljava/net/DatagramSocket;->isClosed()Z

    move-result v3

    if-nez v3, :cond_1

    .line 504
    array-length v3, v1

    invoke-virtual {v2, v3}, Ljava/net/DatagramPacket;->setLength(I)V

    .line 505
    iget-object v3, p0, Lcom/lvteam/PacketCaptureService$UdpFlow;->socket:Ljava/net/DatagramSocket;

    invoke-virtual {v3, v2}, Ljava/net/DatagramSocket;->receive(Ljava/net/DatagramPacket;)V

    .line 506
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    iput-wide v3, p0, Lcom/lvteam/PacketCaptureService$UdpFlow;->lastActivityMillis:J

    .line 507
    invoke-virtual {v2}, Ljava/net/DatagramPacket;->getLength()I

    move-result v3

    new-array v3, v3, [B

    .line 508
    .local v3, "payload":[B
    invoke-virtual {v2}, Ljava/net/DatagramPacket;->getData()[B

    move-result-object v4

    invoke-virtual {v2}, Ljava/net/DatagramPacket;->getOffset()I

    move-result v5

    array-length v6, v3

    const/4 v7, 0x0

    invoke-static {v4, v5, v3, v7, v6}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 510
    :try_start_1
    iget-object v4, p0, Lcom/lvteam/PacketCaptureService$UdpFlow;->this$0:Lcom/lvteam/PacketCaptureService;

    invoke-static {v4}, Lcom/lvteam/PacketCaptureService;->-$$Nest$fgetframeDecoder(Lcom/lvteam/PacketCaptureService;)Lcom/lvteam/RawFrameDecoder;

    move-result-object v4

    array-length v5, v3

    iget-object v6, p0, Lcom/lvteam/PacketCaptureService$UdpFlow;->key:Lcom/lvteam/PacketCaptureService$FlowKey;

    iget-object v6, v6, Lcom/lvteam/PacketCaptureService$FlowKey;->destinationAddress:Ljava/net/InetAddress;

    iget-object v7, p0, Lcom/lvteam/PacketCaptureService$UdpFlow;->key:Lcom/lvteam/PacketCaptureService$FlowKey;

    iget v7, v7, Lcom/lvteam/PacketCaptureService$FlowKey;->destinationPort:I

    invoke-virtual {v4, v3, v5, v6, v7}, Lcom/lvteam/RawFrameDecoder;->acceptUdpPayload([BILjava/net/InetAddress;I)V

    .line 512
    iget-object v4, p0, Lcom/lvteam/PacketCaptureService$UdpFlow;->this$0:Lcom/lvteam/PacketCaptureService;

    invoke-static {v4}, Lcom/lvteam/PacketCaptureService;->-$$Nest$fgetframeDecoder(Lcom/lvteam/PacketCaptureService;)Lcom/lvteam/RawFrameDecoder;

    move-result-object v4

    array-length v5, v3

    iget-object v6, p0, Lcom/lvteam/PacketCaptureService$UdpFlow;->key:Lcom/lvteam/PacketCaptureService$FlowKey;

    iget-object v6, v6, Lcom/lvteam/PacketCaptureService$FlowKey;->destinationAddress:Ljava/net/InetAddress;

    iget-object v7, p0, Lcom/lvteam/PacketCaptureService$UdpFlow;->key:Lcom/lvteam/PacketCaptureService$FlowKey;

    iget v7, v7, Lcom/lvteam/PacketCaptureService$FlowKey;->destinationPort:I

    invoke-virtual {v4, v3, v5, v6, v7}, Lcom/lvteam/RawFrameDecoder;->shiftDownlink([BILjava/net/InetAddress;I)[B

    move-result-object v4
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    move-object v3, v4

    .line 516
    goto :goto_1

    .line 527
    .end local v3    # "payload":[B
    :catchall_0
    move-exception v0

    goto/16 :goto_7

    .line 514
    .restart local v3    # "payload":[B
    :catch_0
    move-exception v4

    nop

    .line 515
    .local v4, "e":Ljava/lang/Exception;
    :try_start_2
    const-string v5, "PacketCapture"

    const-string v6, "shift error"

    invoke-static {v5, v6, v4}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 517
    .end local v4    # "e":Ljava/lang/Exception;
    :goto_1
    iget-object v4, p0, Lcom/lvteam/PacketCaptureService$UdpFlow;->key:Lcom/lvteam/PacketCaptureService$FlowKey;

    iget-object v7, v4, Lcom/lvteam/PacketCaptureService$FlowKey;->destinationAddress:Ljava/net/InetAddress;

    iget-object v4, p0, Lcom/lvteam/PacketCaptureService$UdpFlow;->key:Lcom/lvteam/PacketCaptureService$FlowKey;

    iget v8, v4, Lcom/lvteam/PacketCaptureService$FlowKey;->destinationPort:I

    iget-object v4, p0, Lcom/lvteam/PacketCaptureService$UdpFlow;->key:Lcom/lvteam/PacketCaptureService$FlowKey;

    iget-object v9, v4, Lcom/lvteam/PacketCaptureService$FlowKey;->sourceAddress:Ljava/net/InetAddress;

    iget-object v4, p0, Lcom/lvteam/PacketCaptureService$UdpFlow;->key:Lcom/lvteam/PacketCaptureService$FlowKey;

    iget v10, v4, Lcom/lvteam/PacketCaptureService$FlowKey;->sourcePort:I

    iget-object v4, p0, Lcom/lvteam/PacketCaptureService$UdpFlow;->this$0:Lcom/lvteam/PacketCaptureService;

    invoke-static {v4}, Lcom/lvteam/PacketCaptureService;->-$$Nest$fgetpacketIdentification(Lcom/lvteam/PacketCaptureService;)Ljava/util/concurrent/atomic/AtomicInteger;

    move-result-object v4

    .line 519
    invoke-virtual {v4}, Ljava/util/concurrent/atomic/AtomicInteger;->incrementAndGet()I

    move-result v4

    and-int v12, v4, v0

    .line 517
    move-object v11, v3

    invoke-static/range {v7 .. v12}, Lcom/lvteam/Ipv4UdpPacket;->response(Ljava/net/InetAddress;ILjava/net/InetAddress;I[BI)[B

    move-result-object v4

    .line 520
    .local v4, "frame":[B
    iget-object v5, p0, Lcom/lvteam/PacketCaptureService$UdpFlow;->this$0:Lcom/lvteam/PacketCaptureService;

    invoke-static {v5}, Lcom/lvteam/PacketCaptureService;->-$$Nest$fgetoutputLock(Lcom/lvteam/PacketCaptureService;)Ljava/lang/Object;

    move-result-object v5

    monitor-enter v5
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_1
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 521
    :try_start_3
    iget-object v6, p0, Lcom/lvteam/PacketCaptureService$UdpFlow;->this$0:Lcom/lvteam/PacketCaptureService;

    invoke-static {v6}, Lcom/lvteam/PacketCaptureService;->-$$Nest$fgetrelayRunning(Lcom/lvteam/PacketCaptureService;)Z

    move-result v6

    if-eqz v6, :cond_0

    iget-object v6, p0, Lcom/lvteam/PacketCaptureService$UdpFlow;->this$0:Lcom/lvteam/PacketCaptureService;

    invoke-static {v6}, Lcom/lvteam/PacketCaptureService;->-$$Nest$fgettunnelOutput(Lcom/lvteam/PacketCaptureService;)Ljava/io/FileOutputStream;

    move-result-object v6

    if-eqz v6, :cond_0

    iget-object v6, p0, Lcom/lvteam/PacketCaptureService$UdpFlow;->this$0:Lcom/lvteam/PacketCaptureService;

    invoke-static {v6}, Lcom/lvteam/PacketCaptureService;->-$$Nest$fgettunnelOutput(Lcom/lvteam/PacketCaptureService;)Ljava/io/FileOutputStream;

    move-result-object v6

    invoke-virtual {v6, v4}, Ljava/io/FileOutputStream;->write([B)V

    goto :goto_2

    .line 522
    :catchall_1
    move-exception v0

    goto :goto_3

    :cond_0
    :goto_2
    monitor-exit v5

    .line 523
    .end local v3    # "payload":[B
    .end local v4    # "frame":[B
    goto/16 :goto_0

    .line 522
    .restart local v3    # "payload":[B
    .restart local v4    # "frame":[B
    :goto_3
    monitor-exit v5
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .end local v1    # "buffer":[B
    .end local v2    # "response":Ljava/net/DatagramPacket;
    :try_start_4
    throw v0
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_1
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    .line 524
    .end local v3    # "payload":[B
    .end local v4    # "frame":[B
    .restart local v1    # "buffer":[B
    .restart local v2    # "response":Ljava/net/DatagramPacket;
    :catch_1
    move-exception v0

    goto :goto_5

    .line 527
    :cond_1
    :goto_4
    invoke-virtual {p0}, Lcom/lvteam/PacketCaptureService$UdpFlow;->removeAndClose()V

    .line 528
    goto :goto_6

    .line 524
    :goto_5
    nop

    .line 525
    .local v0, "e":Ljava/io/IOException;
    :try_start_5
    iget-object v3, p0, Lcom/lvteam/PacketCaptureService$UdpFlow;->this$0:Lcom/lvteam/PacketCaptureService;

    invoke-static {v3}, Lcom/lvteam/PacketCaptureService;->-$$Nest$fgetrelayRunning(Lcom/lvteam/PacketCaptureService;)Z

    move-result v3

    if-eqz v3, :cond_1

    iget-object v3, p0, Lcom/lvteam/PacketCaptureService$UdpFlow;->socket:Ljava/net/DatagramSocket;

    invoke-virtual {v3}, Ljava/net/DatagramSocket;->isClosed()Z

    move-result v3

    if-nez v3, :cond_1

    const-string v3, "PacketCapture"

    const-string v4, "UDP receive failed"

    invoke-static {v3, v4, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    goto :goto_4

    .line 529
    .end local v0    # "e":Ljava/io/IOException;
    :goto_6
    return-void

    .line 527
    :goto_7
    invoke-virtual {p0}, Lcom/lvteam/PacketCaptureService$UdpFlow;->removeAndClose()V

    .line 528
    throw v0
.end method

.method public send([B)V
    .locals 3
    .param p1, "payload"    # [B

    .line 490
    :try_start_0
    iget-object v0, p0, Lcom/lvteam/PacketCaptureService$UdpFlow;->socket:Ljava/net/DatagramSocket;

    new-instance v1, Ljava/net/DatagramPacket;

    array-length v2, p1

    invoke-direct {v1, p1, v2}, Ljava/net/DatagramPacket;-><init>([BI)V

    invoke-virtual {v0, v1}, Ljava/net/DatagramSocket;->send(Ljava/net/DatagramPacket;)V

    .line 491
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    iput-wide v0, p0, Lcom/lvteam/PacketCaptureService$UdpFlow;->lastActivityMillis:J
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 495
    goto :goto_0

    .line 492
    :catch_0
    move-exception v0

    .line 493
    .local v0, "e":Ljava/io/IOException;
    const-string v1, "PacketCapture"

    const-string v2, "UDP send failed"

    invoke-static {v1, v2, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 494
    invoke-virtual {p0}, Lcom/lvteam/PacketCaptureService$UdpFlow;->removeAndClose()V

    .line 496
    .end local v0    # "e":Ljava/io/IOException;
    :goto_0
    return-void
.end method
