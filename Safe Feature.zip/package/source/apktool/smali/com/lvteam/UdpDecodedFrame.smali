.class public final Lcom/lvteam/UdpDecodedFrame;
.super Ljava/lang/Object;
.source "UdpDecodedFrame.java"


# instance fields
.field public final declaredPayloadLength:I

.field public final flags:I

.field public final orderId:I

.field public final payload:[B

.field public final reliable:Z

.field public final sendOption:I

.field public final tag:I


# direct methods
.method public constructor <init>(I[BZIIII)V
    .locals 1
    .param p1, "tag"    # I
    .param p2, "payload"    # [B
    .param p3, "reliable"    # Z
    .param p4, "sendOption"    # I
    .param p5, "orderId"    # I
    .param p6, "flags"    # I
    .param p7, "declaredPayloadLength"    # I

    .line 16
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 17
    iput p1, p0, Lcom/lvteam/UdpDecodedFrame;->tag:I

    .line 18
    array-length v0, p2

    invoke-static {p2, v0}, Ljava/util/Arrays;->copyOf([BI)[B

    move-result-object v0

    iput-object v0, p0, Lcom/lvteam/UdpDecodedFrame;->payload:[B

    .line 19
    iput-boolean p3, p0, Lcom/lvteam/UdpDecodedFrame;->reliable:Z

    .line 20
    iput p4, p0, Lcom/lvteam/UdpDecodedFrame;->sendOption:I

    .line 21
    iput p5, p0, Lcom/lvteam/UdpDecodedFrame;->orderId:I

    .line 22
    iput p6, p0, Lcom/lvteam/UdpDecodedFrame;->flags:I

    .line 23
    iput p7, p0, Lcom/lvteam/UdpDecodedFrame;->declaredPayloadLength:I

    .line 24
    return-void
.end method
