.class public final Lcom/lvteam/UdpFrameUnwrapper;
.super Ljava/lang/Object;
.source "UdpFrameUnwrapper.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/lvteam/UdpFrameUnwrapper$Field;,
        Lcom/lvteam/UdpFrameUnwrapper$Configuration;
    }
.end annotation


# instance fields
.field public compressedFrames:J

.field public datagramsOffered:J

.field public decryptFailures:J

.field public encryptedFrames:J

.field public invalidCrcs:J

.field public invalidHeaders:J

.field public invalidLengths:J

.field public lastTelemetryMs:J

.field public unconfiguredFrames:J

.field public final verifiedTags:Ljava/util/Map;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 53
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 42
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lcom/lvteam/UdpFrameUnwrapper;->verifiedTags:Ljava/util/Map;

    .line 54
    return-void
.end method

.method public static varargs configuration(I[B[Lcom/lvteam/UdpFrameUnwrapper$Field;)Lcom/lvteam/UdpFrameUnwrapper$Configuration;
    .locals 2
    .param p0, "mask"    # I
    .param p1, "key"    # [B
    .param p2, "order"    # [Lcom/lvteam/UdpFrameUnwrapper$Field;

    .line 78
    new-instance v0, Lcom/lvteam/UdpFrameUnwrapper$Configuration;

    const/4 v1, 0x0

    invoke-direct {v0, p0, p1, p2, v1}, Lcom/lvteam/UdpFrameUnwrapper$Configuration;-><init>(I[B[Lcom/lvteam/UdpFrameUnwrapper$Field;Lcom/lvteam/UdpFrameUnwrapper$Configuration-IA;)V

    return-object v0
.end method

.method public static crc8([BII)I
    .locals 5
    .param p0, "data"    # [B
    .param p1, "offset"    # I
    .param p2, "length"    # I

    .line 391
    const/4 v0, 0x0

    .line 392
    .local v0, "crc":I
    add-int v1, p1, p2

    .line 393
    .local v1, "end":I
    add-int/lit8 v2, p1, 0x2

    .local v2, "i":I
    :goto_0
    if-ge v2, v1, :cond_0

    .line 394
    shl-int/lit8 v3, v0, 0x1

    aget-byte v4, p0, v2

    and-int/lit16 v4, v4, 0xff

    xor-int/2addr v3, v4

    invoke-static {v3}, Lcom/lvteam/UdpFrameUnwrapper;->crcTable(I)I

    move-result v0

    .line 393
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    nop

    .line 396
    .end local v2    # "i":I
    return v0
.end method

.method public static crcTable(I)I
    .locals 3
    .param p0, "value"    # I

    .line 400
    and-int/lit16 p0, p0, 0xff

    .line 401
    const/4 v0, 0x0

    .local v0, "bit":I
    :goto_0
    const/16 v1, 0x8

    if-ge v0, v1, :cond_1

    .line 402
    and-int/lit16 v1, p0, 0x80

    .line 403
    .local v1, "highBit":I
    shl-int/lit8 v2, p0, 0x1

    and-int/lit16 p0, v2, 0xff

    .line 404
    if-eqz v1, :cond_0

    xor-int/lit8 p0, p0, 0x12

    .line 401
    .end local v1    # "highBit":I
    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    nop

    .line 406
    .end local v0    # "bit":I
    ushr-int/lit8 v0, p0, 0x1

    return v0
.end method

.method public static decryptLegacy([B[B)[B
    .locals 14
    .param p0, "encrypted"    # [B
    .param p1, "key"    # [B

    .line 298
    const/4 v0, 0x0

    if-eqz p1, :cond_0

    array-length v1, p0

    const/16 v2, 0x10

    if-lt v1, v2, :cond_0

    array-length v1, p0

    and-int/lit8 v1, v1, 0x7

    if-eqz v1, :cond_1

    :cond_0
    goto/16 :goto_5

    .line 299
    :cond_1
    const/4 v1, 0x4

    new-array v1, v1, [I

    .line 300
    .local v1, "words":[I
    const/4 v2, 0x0

    .local v2, "index":I
    :goto_0
    array-length v3, v1

    if-ge v2, v3, :cond_2

    mul-int/lit8 v3, v2, 0x4

    invoke-static {p1, v3}, Lcom/lvteam/UdpFrameUnwrapper;->readIntLe([BI)I

    move-result v3

    aput v3, v1, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    .line 302
    .end local v2    # "index":I
    :cond_2
    array-length v2, p0

    new-array v2, v2, [B

    .line 303
    .local v2, "decoded":[B
    const/16 v3, 0x8

    new-array v4, v3, [B

    .line 304
    .local v4, "previousDecoded":[B
    new-array v5, v3, [B

    .line 305
    .local v5, "previousCiphertext":[B
    new-array v6, v3, [B

    .line 306
    .local v6, "block":[B
    new-array v7, v3, [B

    .line 307
    .local v7, "decryptedBlock":[B
    const/4 v8, 0x0

    .local v8, "offset":I
    :goto_1
    array-length v9, p0

    const/4 v10, 0x0

    if-ge v8, v9, :cond_5

    .line 308
    const/4 v9, 0x0

    .local v9, "index":I
    :goto_2
    if-ge v9, v3, :cond_3

    .line 309
    add-int v11, v8, v9

    aget-byte v11, p0, v11

    aget-byte v12, v4, v9

    xor-int/2addr v11, v12

    int-to-byte v11, v11

    aput-byte v11, v6, v9

    .line 308
    add-int/lit8 v9, v9, 0x1

    goto :goto_2

    :cond_3
    nop

    .line 311
    .end local v9    # "index":I
    invoke-static {v1, v6, v7}, Lcom/lvteam/UdpFrameUnwrapper;->decryptTeaBlock([I[B[B)V

    .line 312
    const/4 v9, 0x0

    .restart local v9    # "index":I
    :goto_3
    if-ge v9, v3, :cond_4

    .line 313
    add-int v11, v8, v9

    aget-byte v12, v7, v9

    aget-byte v13, v5, v9

    xor-int/2addr v12, v13

    int-to-byte v12, v12

    aput-byte v12, v2, v11

    .line 312
    add-int/lit8 v9, v9, 0x1

    goto :goto_3

    :cond_4
    nop

    .line 315
    .end local v9    # "index":I
    invoke-static {v7, v10, v4, v10, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 316
    invoke-static {p0, v8, v5, v10, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 307
    add-int/lit8 v8, v8, 0x8

    goto :goto_1

    :cond_5
    nop

    .line 319
    .end local v8    # "offset":I
    aget-byte v3, v2, v10

    and-int/lit8 v3, v3, 0x7

    add-int/lit8 v3, v3, 0x3

    .line 320
    .local v3, "start":I
    array-length v8, v2

    add-int/lit8 v8, v8, -0x7

    .line 321
    .local v8, "end":I
    if-ge v8, v3, :cond_6

    return-object v0

    .line 322
    :cond_6
    move v9, v8

    .restart local v9    # "index":I
    :goto_4
    array-length v10, v2

    if-ge v9, v10, :cond_8

    aget-byte v10, v2, v9

    if-eqz v10, :cond_7

    return-object v0

    :cond_7
    add-int/lit8 v9, v9, 0x1

    goto :goto_4

    .line 323
    .end local v9    # "index":I
    :cond_8
    invoke-static {v2, v3, v8}, Ljava/util/Arrays;->copyOfRange([BII)[B

    move-result-object v0

    return-object v0

    .line 298
    .end local v1    # "words":[I
    .end local v2    # "decoded":[B
    .end local v3    # "start":I
    .end local v4    # "previousDecoded":[B
    .end local v5    # "previousCiphertext":[B
    .end local v6    # "block":[B
    .end local v7    # "decryptedBlock":[B
    .end local v8    # "end":I
    :goto_5
    return-object v0
.end method

.method public static decryptTeaBlock([I[B[B)V
    .locals 9
    .param p0, "key"    # [I
    .param p1, "input"    # [B
    .param p2, "output"    # [B

    .line 352
    const/4 v0, 0x0

    invoke-static {p1, v0}, Lcom/lvteam/UdpFrameUnwrapper;->readIntLe([BI)I

    move-result v1

    .line 353
    .local v1, "y":I
    const/4 v2, 0x4

    invoke-static {p1, v2}, Lcom/lvteam/UdpFrameUnwrapper;->readIntLe([BI)I

    move-result v3

    .line 354
    .local v3, "z":I
    const v4, -0x1c886470

    .line 355
    .local v4, "sum":I
    const/4 v5, 0x0

    .local v5, "round":I
    :goto_0
    const/16 v6, 0x10

    if-ge v5, v6, :cond_0

    .line 356
    shl-int/lit8 v6, v1, 0x4

    const/4 v7, 0x2

    aget v7, p0, v7

    add-int/2addr v6, v7

    add-int v7, v1, v4

    xor-int/2addr v6, v7

    ushr-int/lit8 v7, v1, 0x5

    const/4 v8, 0x3

    aget v8, p0, v8

    add-int/2addr v7, v8

    xor-int/2addr v6, v7

    sub-int/2addr v3, v6

    .line 357
    shl-int/lit8 v6, v3, 0x4

    aget v7, p0, v0

    add-int/2addr v6, v7

    add-int v7, v3, v4

    xor-int/2addr v6, v7

    ushr-int/lit8 v7, v3, 0x5

    const/4 v8, 0x1

    aget v8, p0, v8

    add-int/2addr v7, v8

    xor-int/2addr v6, v7

    sub-int/2addr v1, v6

    .line 358
    const v6, 0x61c88647

    add-int/2addr v4, v6

    .line 355
    add-int/lit8 v5, v5, 0x1

    goto :goto_0

    :cond_0
    nop

    .line 360
    .end local v5    # "round":I
    invoke-static {p2, v0, v1}, Lcom/lvteam/UdpFrameUnwrapper;->writeIntLe([BII)V

    .line 361
    invoke-static {p2, v2, v3}, Lcom/lvteam/UdpFrameUnwrapper;->writeIntLe([BII)V

    .line 362
    return-void
.end method

.method public static encryptLegacy([B[B)[B
    .locals 17
    .param p0, "plain"    # [B
    .param p1, "key"    # [B

    .line 327
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    if-nez v1, :cond_0

    const/4 v2, 0x0

    return-object v2

    .line 328
    :cond_0
    array-length v2, v0

    add-int/lit8 v2, v2, 0xa

    and-int/lit8 v2, v2, 0x7

    const/16 v3, 0x8

    rsub-int/lit8 v2, v2, 0x8

    and-int/lit8 v2, v2, 0x7

    .line 329
    .local v2, "padding":I
    array-length v4, v0

    add-int/2addr v4, v2

    add-int/lit8 v4, v4, 0xa

    new-array v4, v4, [B

    .line 330
    .local v4, "padded":[B
    int-to-byte v5, v2

    const/4 v6, 0x0

    aput-byte v5, v4, v6

    .line 331
    add-int/lit8 v5, v2, 0x3

    array-length v7, v0

    invoke-static {v0, v6, v4, v5, v7}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 332
    const/4 v5, 0x4

    new-array v5, v5, [I

    .line 333
    .local v5, "words":[I
    const/4 v7, 0x0

    .local v7, "index":I
    :goto_0
    array-length v8, v5

    if-ge v7, v8, :cond_1

    mul-int/lit8 v8, v7, 0x4

    invoke-static {v1, v8}, Lcom/lvteam/UdpFrameUnwrapper;->readIntLe([BI)I

    move-result v8

    aput v8, v5, v7

    add-int/lit8 v7, v7, 0x1

    goto :goto_0

    .line 334
    .end local v7    # "index":I
    :cond_1
    array-length v7, v4

    new-array v7, v7, [B

    .line 335
    .local v7, "encrypted":[B
    new-array v8, v3, [B

    .line 336
    .local v8, "previousPlain":[B
    new-array v9, v3, [B

    .line 337
    .local v9, "previousCiphertext":[B
    new-array v10, v3, [B

    .line 338
    .local v10, "block":[B
    new-array v11, v3, [B

    .line 339
    .local v11, "encryptedBlock":[B
    const/4 v12, 0x0

    .local v12, "offset":I
    :goto_1
    array-length v13, v4

    if-ge v12, v13, :cond_4

    .line 340
    const/4 v13, 0x0

    .local v13, "index":I
    :goto_2
    if-ge v13, v3, :cond_2

    add-int v14, v12, v13

    aget-byte v14, v4, v14

    aget-byte v15, v9, v13

    xor-int/2addr v14, v15

    int-to-byte v14, v14

    aput-byte v14, v10, v13

    add-int/lit8 v13, v13, 0x1

    goto :goto_2

    .line 342
    .end local v13    # "index":I
    :cond_2
    invoke-static {v5, v10, v11}, Lcom/lvteam/UdpFrameUnwrapper;->encryptTeaBlock([I[B[B)V

    .line 343
    const/4 v13, 0x0

    .restart local v13    # "index":I
    :goto_3
    if-ge v13, v3, :cond_3

    add-int v14, v12, v13

    aget-byte v15, v11, v13

    aget-byte v16, v8, v13

    xor-int v15, v15, v16

    int-to-byte v15, v15

    aput-byte v15, v7, v14

    add-int/lit8 v13, v13, 0x1

    goto :goto_3

    .line 345
    .end local v13    # "index":I
    :cond_3
    invoke-static {v10, v6, v8, v6, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 346
    invoke-static {v7, v12, v9, v6, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 339
    add-int/lit8 v12, v12, 0x8

    goto :goto_1

    :cond_4
    nop

    .line 348
    .end local v12    # "offset":I
    return-object v7
.end method

.method public static encryptTeaBlock([I[B[B)V
    .locals 9
    .param p0, "key"    # [I
    .param p1, "input"    # [B
    .param p2, "output"    # [B

    .line 365
    const/4 v0, 0x0

    invoke-static {p1, v0}, Lcom/lvteam/UdpFrameUnwrapper;->readIntLe([BI)I

    move-result v1

    .line 366
    .local v1, "y":I
    const/4 v2, 0x4

    invoke-static {p1, v2}, Lcom/lvteam/UdpFrameUnwrapper;->readIntLe([BI)I

    move-result v3

    .line 367
    .local v3, "z":I
    const/4 v4, 0x0

    .line 368
    .local v4, "sum":I
    const/4 v5, 0x0

    .local v5, "round":I
    :goto_0
    const/16 v6, 0x10

    if-ge v5, v6, :cond_0

    .line 369
    const v6, 0x61c88647

    sub-int/2addr v4, v6

    .line 370
    shl-int/lit8 v6, v3, 0x4

    aget v7, p0, v0

    add-int/2addr v6, v7

    add-int v7, v3, v4

    xor-int/2addr v6, v7

    ushr-int/lit8 v7, v3, 0x5

    const/4 v8, 0x1

    aget v8, p0, v8

    add-int/2addr v7, v8

    xor-int/2addr v6, v7

    add-int/2addr v1, v6

    .line 371
    shl-int/lit8 v6, v1, 0x4

    const/4 v7, 0x2

    aget v7, p0, v7

    add-int/2addr v6, v7

    add-int v7, v1, v4

    xor-int/2addr v6, v7

    ushr-int/lit8 v7, v1, 0x5

    const/4 v8, 0x3

    aget v8, p0, v8

    add-int/2addr v7, v8

    xor-int/2addr v6, v7

    add-int/2addr v3, v6

    .line 368
    add-int/lit8 v5, v5, 0x1

    goto :goto_0

    :cond_0
    nop

    .line 373
    .end local v5    # "round":I
    invoke-static {p2, v0, v1}, Lcom/lvteam/UdpFrameUnwrapper;->writeIntLe([BII)V

    .line 374
    invoke-static {p2, v2, v3}, Lcom/lvteam/UdpFrameUnwrapper;->writeIntLe([BII)V

    .line 375
    return-void
.end method

.method public static headerLength(I)I
    .locals 2
    .param p0, "sendOption"    # I

    .line 279
    const/16 v0, 0x5a

    const/16 v1, 0x64

    if-lt p0, v0, :cond_0

    if-ge p0, v1, :cond_0

    const/16 v0, 0xa

    goto :goto_0

    .line 280
    :cond_0
    if-lt p0, v1, :cond_1

    const/16 v0, 0x6e

    if-gt p0, v0, :cond_1

    const/16 v0, 0x8

    goto :goto_0

    :cond_1
    const/4 v0, -0x1

    .line 279
    :goto_0
    return v0
.end method

.method public static readByte([BIII)I
    .locals 1
    .param p0, "data"    # [B
    .param p1, "base"    # I
    .param p2, "fieldOffset"    # I
    .param p3, "mask"    # I

    .line 284
    add-int v0, p1, p2

    aget-byte v0, p0, v0

    and-int/lit16 v0, v0, 0xff

    xor-int/2addr v0, p3

    return v0
.end method

.method public static readIntLe([BI)I
    .locals 2
    .param p0, "data"    # [B
    .param p1, "offset"    # I

    .line 378
    aget-byte v0, p0, p1

    and-int/lit16 v0, v0, 0xff

    add-int/lit8 v1, p1, 0x1

    aget-byte v1, p0, v1

    and-int/lit16 v1, v1, 0xff

    shl-int/lit8 v1, v1, 0x8

    or-int/2addr v0, v1

    add-int/lit8 v1, p1, 0x2

    aget-byte v1, p0, v1

    and-int/lit16 v1, v1, 0xff

    shl-int/lit8 v1, v1, 0x10

    or-int/2addr v0, v1

    add-int/lit8 v1, p1, 0x3

    aget-byte v1, p0, v1

    and-int/lit16 v1, v1, 0xff

    shl-int/lit8 v1, v1, 0x18

    or-int/2addr v0, v1

    return v0
.end method

.method public static readShort([BIII)I
    .locals 2
    .param p0, "data"    # [B
    .param p1, "base"    # I
    .param p2, "fieldOffset"    # I
    .param p3, "mask"    # I

    .line 288
    invoke-static {p0, p1, p2, p3}, Lcom/lvteam/UdpFrameUnwrapper;->readByte([BIII)I

    move-result v0

    add-int/lit8 v1, p2, 0x1

    .line 289
    invoke-static {p0, p1, v1, p3}, Lcom/lvteam/UdpFrameUnwrapper;->readByte([BIII)I

    move-result v1

    shl-int/lit8 v1, v1, 0x8

    or-int/2addr v0, v1

    .line 288
    return v0
.end method

.method public static writeIntLe([BII)V
    .locals 2
    .param p0, "data"    # [B
    .param p1, "offset"    # I
    .param p2, "value"    # I

    .line 383
    int-to-byte v0, p2

    aput-byte v0, p0, p1

    .line 384
    add-int/lit8 v0, p1, 0x1

    ushr-int/lit8 v1, p2, 0x8

    int-to-byte v1, v1

    aput-byte v1, p0, v0

    .line 385
    add-int/lit8 v0, p1, 0x2

    ushr-int/lit8 v1, p2, 0x10

    int-to-byte v1, v1

    aput-byte v1, p0, v0

    .line 386
    add-int/lit8 v0, p1, 0x3

    ushr-int/lit8 v1, p2, 0x18

    int-to-byte v1, v1

    aput-byte v1, p0, v0

    .line 387
    return-void
.end method

.method public static writeShort([BIII)V
    .locals 2
    .param p0, "data"    # [B
    .param p1, "fieldOffset"    # I
    .param p2, "value"    # I
    .param p3, "mask"    # I

    .line 293
    and-int/lit16 v0, p2, 0xff

    xor-int/2addr v0, p3

    int-to-byte v0, v0

    aput-byte v0, p0, p1

    .line 294
    add-int/lit8 v0, p1, 0x1

    ushr-int/lit8 v1, p2, 0x8

    and-int/lit16 v1, v1, 0xff

    xor-int/2addr v1, p3

    int-to-byte v1, v1

    aput-byte v1, p0, v0

    .line 295
    return-void
.end method


# virtual methods
.method public final formatTags()Ljava/lang/String;
    .locals 5

    .line 269
    iget-object v0, p0, Lcom/lvteam/UdpFrameUnwrapper;->verifiedTags:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    const-string v0, "{}"

    return-object v0

    .line 270
    :cond_0
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "{"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 271
    .local v0, "result":Ljava/lang/StringBuilder;
    iget-object v1, p0, Lcom/lvteam/UdpFrameUnwrapper;->verifiedTags:Ljava/util/Map;

    invoke-interface {v1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map$Entry;

    .line 272
    .local v2, "entry":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Ljava/lang/Integer;Ljava/lang/Long;>;"
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result v3

    const/4 v4, 0x1

    if-le v3, v4, :cond_1

    const/16 v3, 0x2c

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 273
    :cond_1
    const-string v3, "0x"

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v3, 0x3d

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 274
    .end local v2    # "entry":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Ljava/lang/Integer;Ljava/lang/Long;>;"
    goto :goto_0

    .line 275
    :cond_2
    const/16 v1, 0x7d

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    return-object v1
.end method

.method public declared-synchronized peekTag([BIILcom/lvteam/UdpFrameUnwrapper$Configuration;)I
    .locals 5
    .param p1, "datagram"    # [B
    .param p2, "offset"    # I
    .param p3, "length"    # I
    .param p4, "configuration"    # Lcom/lvteam/UdpFrameUnwrapper$Configuration;

    monitor-enter p0

    .line 133
    const/4 v0, -0x1

    if-eqz p4, :cond_6

    if-eqz p1, :cond_6

    if-ltz p2, :cond_6

    const/16 v1, 0x8

    if-lt p3, v1, :cond_6

    :try_start_0
    array-length v1, p1

    sub-int/2addr v1, p3

    if-le p2, v1, :cond_0

    goto :goto_4

    .line 135
    :cond_0
    aget-byte v1, p1, p2

    and-int/lit16 v1, v1, 0xff

    invoke-static {v1}, Lcom/lvteam/UdpFrameUnwrapper;->headerLength(I)I

    move-result v1

    .line 136
    .local v1, "headerLength":I
    if-eq v1, v0, :cond_5

    if-ge p3, v1, :cond_1

    goto :goto_2

    .line 137
    :cond_1
    add-int/lit8 v2, p2, 0x1

    aget-byte v2, p1, v2

    and-int/lit16 v2, v2, 0xff

    invoke-static {p1, p2, p3}, Lcom/lvteam/UdpFrameUnwrapper;->crc8([BII)I

    move-result v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eq v2, v3, :cond_2

    monitor-exit p0

    return v0

    .line 138
    :cond_2
    const/16 v0, 0xa

    if-ne v1, v0, :cond_3

    const/4 v0, 0x1

    goto :goto_0

    :cond_3
    const/4 v0, 0x0

    .line 139
    .local v0, "reliable":Z
    :goto_0
    if-eqz v0, :cond_4

    :try_start_1
    invoke-static {p4}, Lcom/lvteam/UdpFrameUnwrapper$Configuration;->-$$Nest$fgetreliableOffsets(Lcom/lvteam/UdpFrameUnwrapper$Configuration;)[I

    move-result-object v2

    goto :goto_1

    .line 132
    .end local v0    # "reliable":Z
    .end local v1    # "headerLength":I
    .end local p0    # "this":Lcom/lvteam/UdpFrameUnwrapper;
    .end local p1    # "datagram":[B
    .end local p2    # "offset":I
    .end local p3    # "length":I
    .end local p4    # "configuration":Lcom/lvteam/UdpFrameUnwrapper$Configuration;
    :catchall_0
    move-exception p1

    goto :goto_3

    .line 139
    .restart local v0    # "reliable":Z
    .restart local v1    # "headerLength":I
    .restart local p1    # "datagram":[B
    .restart local p2    # "offset":I
    .restart local p3    # "length":I
    .restart local p4    # "configuration":Lcom/lvteam/UdpFrameUnwrapper$Configuration;
    :cond_4
    invoke-static {p4}, Lcom/lvteam/UdpFrameUnwrapper$Configuration;->-$$Nest$fgetunreliableOffsets(Lcom/lvteam/UdpFrameUnwrapper$Configuration;)[I

    move-result-object v2

    :goto_1
    nop

    .line 140
    .local v2, "offsets":[I
    sget-object v3, Lcom/lvteam/UdpFrameUnwrapper$Field;->TAG:Lcom/lvteam/UdpFrameUnwrapper$Field;

    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    move-result v3

    aget v3, v2, v3

    invoke-static {p4}, Lcom/lvteam/UdpFrameUnwrapper$Configuration;->-$$Nest$fgetmask(Lcom/lvteam/UdpFrameUnwrapper$Configuration;)I

    move-result v4

    invoke-static {p1, p2, v3, v4}, Lcom/lvteam/UdpFrameUnwrapper;->readShort([BIII)I

    move-result v3
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    monitor-exit p0

    return v3

    .line 136
    .end local v0    # "reliable":Z
    .end local v2    # "offsets":[I
    :cond_5
    :goto_2
    monitor-exit p0

    return v0

    .line 132
    .end local v1    # "headerLength":I
    .end local p1    # "datagram":[B
    .end local p2    # "offset":I
    .end local p3    # "length":I
    .end local p4    # "configuration":Lcom/lvteam/UdpFrameUnwrapper$Configuration;
    :goto_3
    :try_start_2
    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw p1

    .line 134
    .restart local p1    # "datagram":[B
    .restart local p2    # "offset":I
    .restart local p3    # "length":I
    .restart local p4    # "configuration":Lcom/lvteam/UdpFrameUnwrapper$Configuration;
    :cond_6
    :goto_4
    monitor-exit p0

    return v0
.end method

.method public declared-synchronized rebuild([BIILcom/lvteam/UdpFrameUnwrapper$Configuration;Lcom/lvteam/UdpDecodedFrame;[B)[B
    .locals 16
    .param p1, "datagram"    # [B
    .param p2, "offset"    # I
    .param p3, "length"    # I
    .param p4, "configuration"    # Lcom/lvteam/UdpFrameUnwrapper$Configuration;
    .param p5, "decoded"    # Lcom/lvteam/UdpDecodedFrame;
    .param p6, "plainPayload"    # [B

    move-object/from16 v0, p1

    move/from16 v1, p2

    move/from16 v2, p3

    move-object/from16 v3, p5

    move-object/from16 v4, p6

    monitor-enter p0

    .line 217
    if-eqz v3, :cond_b

    if-eqz v4, :cond_b

    if-eqz p4, :cond_b

    :try_start_0
    iget v6, v3, Lcom/lvteam/UdpDecodedFrame;->flags:I

    and-int/lit8 v6, v6, 0x2

    if-nez v6, :cond_b

    if-eqz v0, :cond_b

    if-ltz v1, :cond_b

    const/16 v6, 0x8

    if-lt v2, v6, :cond_b

    array-length v6, v0

    sub-int/2addr v6, v2

    if-le v1, v6, :cond_0

    goto/16 :goto_7

    .line 222
    :cond_0
    aget-byte v6, v0, v1

    and-int/lit16 v6, v6, 0xff

    invoke-static {v6}, Lcom/lvteam/UdpFrameUnwrapper;->headerLength(I)I

    move-result v6

    .line 223
    .local v6, "headerLength":I
    const/4 v7, -0x1

    if-eq v6, v7, :cond_a

    if-lt v2, v6, :cond_a

    add-int/lit8 v7, v1, 0x1

    aget-byte v7, v0, v7

    and-int/lit16 v7, v7, 0xff

    .line 224
    invoke-static/range {p1 .. p3}, Lcom/lvteam/UdpFrameUnwrapper;->crc8([BII)I

    move-result v8

    if-eq v7, v8, :cond_1

    goto/16 :goto_5

    .line 225
    :cond_1
    const/16 v7, 0xa

    const/4 v8, 0x0

    if-ne v6, v7, :cond_2

    const/4 v7, 0x1

    goto :goto_0

    :cond_2
    move v7, v8

    .line 226
    .local v7, "reliable":Z
    :goto_0
    if-eqz v7, :cond_3

    invoke-static/range {p4 .. p4}, Lcom/lvteam/UdpFrameUnwrapper$Configuration;->-$$Nest$fgetreliableOffsets(Lcom/lvteam/UdpFrameUnwrapper$Configuration;)[I

    move-result-object v10

    goto :goto_1

    .line 216
    .end local v6    # "headerLength":I
    .end local v7    # "reliable":Z
    .end local p0    # "this":Lcom/lvteam/UdpFrameUnwrapper;
    .end local p1    # "datagram":[B
    .end local p2    # "offset":I
    .end local p3    # "length":I
    .end local p4    # "configuration":Lcom/lvteam/UdpFrameUnwrapper$Configuration;
    .end local p5    # "decoded":Lcom/lvteam/UdpDecodedFrame;
    .end local p6    # "plainPayload":[B
    :catchall_0
    move-exception v0

    goto/16 :goto_6

    .line 226
    .restart local v6    # "headerLength":I
    .restart local v7    # "reliable":Z
    .restart local p1    # "datagram":[B
    .restart local p2    # "offset":I
    .restart local p3    # "length":I
    .restart local p4    # "configuration":Lcom/lvteam/UdpFrameUnwrapper$Configuration;
    .restart local p5    # "decoded":Lcom/lvteam/UdpDecodedFrame;
    .restart local p6    # "plainPayload":[B
    :cond_3
    invoke-static/range {p4 .. p4}, Lcom/lvteam/UdpFrameUnwrapper$Configuration;->-$$Nest$fgetunreliableOffsets(Lcom/lvteam/UdpFrameUnwrapper$Configuration;)[I

    move-result-object v10

    :goto_1
    nop

    .line 227
    .local v10, "offsets":[I
    sget-object v11, Lcom/lvteam/UdpFrameUnwrapper$Field;->TAG:Lcom/lvteam/UdpFrameUnwrapper$Field;

    invoke-virtual {v11}, Ljava/lang/Enum;->ordinal()I

    move-result v11

    aget v11, v10, v11

    invoke-static/range {p4 .. p4}, Lcom/lvteam/UdpFrameUnwrapper$Configuration;->-$$Nest$fgetmask(Lcom/lvteam/UdpFrameUnwrapper$Configuration;)I

    move-result v12

    invoke-static {v0, v1, v11, v12}, Lcom/lvteam/UdpFrameUnwrapper;->readShort([BIII)I

    move-result v11

    .line 228
    .local v11, "tag":I
    sget-object v12, Lcom/lvteam/UdpFrameUnwrapper$Field;->FLAGS:Lcom/lvteam/UdpFrameUnwrapper$Field;

    invoke-virtual {v12}, Ljava/lang/Enum;->ordinal()I

    move-result v12

    aget v12, v10, v12

    invoke-static/range {p4 .. p4}, Lcom/lvteam/UdpFrameUnwrapper$Configuration;->-$$Nest$fgetmask(Lcom/lvteam/UdpFrameUnwrapper$Configuration;)I

    move-result v13

    invoke-static {v0, v1, v12, v13}, Lcom/lvteam/UdpFrameUnwrapper;->readByte([BIII)I

    move-result v12

    .line 229
    .local v12, "flags":I
    sget-object v13, Lcom/lvteam/UdpFrameUnwrapper$Field;->DATA_LENGTH:Lcom/lvteam/UdpFrameUnwrapper$Field;

    invoke-virtual {v13}, Ljava/lang/Enum;->ordinal()I

    move-result v13

    aget v13, v10, v13

    invoke-static/range {p4 .. p4}, Lcom/lvteam/UdpFrameUnwrapper$Configuration;->-$$Nest$fgetmask(Lcom/lvteam/UdpFrameUnwrapper$Configuration;)I

    move-result v14

    invoke-static {v0, v1, v13, v14}, Lcom/lvteam/UdpFrameUnwrapper;->readShort([BIII)I

    move-result v13

    .line 230
    .local v13, "declaredLength":I
    iget-boolean v14, v3, Lcom/lvteam/UdpDecodedFrame;->reliable:Z

    if-ne v7, v14, :cond_4

    iget v14, v3, Lcom/lvteam/UdpDecodedFrame;->tag:I

    if-ne v11, v14, :cond_4

    iget v14, v3, Lcom/lvteam/UdpDecodedFrame;->flags:I

    if-ne v12, v14, :cond_4

    iget v14, v3, Lcom/lvteam/UdpDecodedFrame;->declaredPayloadLength:I

    if-ne v13, v14, :cond_4

    sub-int v14, v2, v6

    if-le v13, v14, :cond_5

    :cond_4
    goto :goto_4

    .line 234
    :cond_5
    and-int/lit8 v14, v12, 0x1

    if-nez v14, :cond_6

    move-object v14, v4

    goto :goto_2

    .line 235
    :cond_6
    invoke-static/range {p4 .. p4}, Lcom/lvteam/UdpFrameUnwrapper$Configuration;->-$$Nest$fgetkey(Lcom/lvteam/UdpFrameUnwrapper$Configuration;)[B

    move-result-object v14

    invoke-static {v4, v14}, Lcom/lvteam/UdpFrameUnwrapper;->encryptLegacy([B[B)[B

    move-result-object v14

    :goto_2
    nop

    .line 236
    .local v14, "encoded":[B
    if-eqz v14, :cond_7

    array-length v15, v14

    const v5, 0xffff

    if-le v15, v5, :cond_8

    :cond_7
    goto :goto_3

    .line 237
    :cond_8
    sub-int v5, v2, v6

    sub-int/2addr v5, v13

    .line 238
    .local v5, "tailLength":I
    array-length v15, v14

    add-int/2addr v15, v6

    add-int/2addr v15, v5

    new-array v15, v15, [B

    .line 239
    .local v15, "rebuilt":[B
    invoke-static {v0, v1, v15, v8, v6}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 240
    array-length v9, v14

    invoke-static {v14, v8, v15, v6, v9}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 241
    if-lez v5, :cond_9

    add-int v9, v1, v6

    add-int/2addr v9, v13

    array-length v8, v14

    add-int/2addr v8, v6

    invoke-static {v0, v9, v15, v8, v5}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 243
    :cond_9
    sget-object v8, Lcom/lvteam/UdpFrameUnwrapper$Field;->DATA_LENGTH:Lcom/lvteam/UdpFrameUnwrapper$Field;

    invoke-virtual {v8}, Ljava/lang/Enum;->ordinal()I

    move-result v8

    aget v8, v10, v8

    array-length v9, v14

    invoke-static/range {p4 .. p4}, Lcom/lvteam/UdpFrameUnwrapper$Configuration;->-$$Nest$fgetmask(Lcom/lvteam/UdpFrameUnwrapper$Configuration;)I

    move-result v0

    invoke-static {v15, v8, v9, v0}, Lcom/lvteam/UdpFrameUnwrapper;->writeShort([BIII)V

    .line 244
    array-length v0, v15

    const/4 v8, 0x0

    invoke-static {v15, v8, v0}, Lcom/lvteam/UdpFrameUnwrapper;->crc8([BII)I

    move-result v0

    int-to-byte v0, v0

    const/4 v8, 0x1

    aput-byte v0, v15, v8
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 245
    monitor-exit p0

    return-object v15

    .line 236
    .end local v5    # "tailLength":I
    .end local v15    # "rebuilt":[B
    :goto_3
    monitor-exit p0

    const/4 v0, 0x0

    return-object v0

    .line 232
    .end local v14    # "encoded":[B
    :goto_4
    monitor-exit p0

    const/4 v0, 0x0

    return-object v0

    .line 224
    .end local v7    # "reliable":Z
    .end local v10    # "offsets":[I
    .end local v11    # "tag":I
    .end local v12    # "flags":I
    .end local v13    # "declaredLength":I
    :cond_a
    :goto_5
    monitor-exit p0

    const/4 v0, 0x0

    return-object v0

    .line 216
    .end local v6    # "headerLength":I
    .end local p1    # "datagram":[B
    .end local p2    # "offset":I
    .end local p3    # "length":I
    .end local p4    # "configuration":Lcom/lvteam/UdpFrameUnwrapper$Configuration;
    .end local p5    # "decoded":Lcom/lvteam/UdpDecodedFrame;
    .end local p6    # "plainPayload":[B
    :goto_6
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0

    .line 220
    .restart local p1    # "datagram":[B
    .restart local p2    # "offset":I
    .restart local p3    # "length":I
    .restart local p4    # "configuration":Lcom/lvteam/UdpFrameUnwrapper$Configuration;
    .restart local p5    # "decoded":Lcom/lvteam/UdpDecodedFrame;
    .restart local p6    # "plainPayload":[B
    :cond_b
    :goto_7
    monitor-exit p0

    const/4 v0, 0x0

    return-object v0
.end method

.method public declared-synchronized recordDatagramOffered()V
    .locals 4

    monitor-enter p0

    .line 120
    :try_start_0
    iget-wide v0, p0, Lcom/lvteam/UdpFrameUnwrapper;->datagramsOffered:J

    const-wide/16 v2, 0x1

    add-long/2addr v0, v2

    iput-wide v0, p0, Lcom/lvteam/UdpFrameUnwrapper;->datagramsOffered:J

    .line 121
    invoke-virtual {p0}, Lcom/lvteam/UdpFrameUnwrapper;->reportTelemetryIfDue()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 122
    monitor-exit p0

    return-void

    .line 119
    .end local p0    # "this":Lcom/lvteam/UdpFrameUnwrapper;
    :catchall_0
    move-exception v0

    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method

.method public final reportTelemetryIfDue()V
    .locals 8

    .line 249
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    .line 250
    .local v0, "now":J
    iget-wide v2, p0, Lcom/lvteam/UdpFrameUnwrapper;->lastTelemetryMs:J

    sub-long v2, v0, v2

    const-wide/16 v4, 0x1388

    cmp-long v2, v2, v4

    if-ltz v2, :cond_0

    iget-wide v2, p0, Lcom/lvteam/UdpFrameUnwrapper;->datagramsOffered:J

    const-wide/16 v4, 0x0

    cmp-long v2, v2, v4

    if-nez v2, :cond_1

    :cond_0
    goto/16 :goto_0

    .line 251
    :cond_1
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "udp offered="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v6, p0, Lcom/lvteam/UdpFrameUnwrapper;->datagramsOffered:J

    invoke-virtual {v2, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v3, " unconfigured="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v6, p0, Lcom/lvteam/UdpFrameUnwrapper;->unconfiguredFrames:J

    invoke-virtual {v2, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v3, " invalidHeader="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v6, p0, Lcom/lvteam/UdpFrameUnwrapper;->invalidHeaders:J

    invoke-virtual {v2, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v3, " invalidCrc="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v6, p0, Lcom/lvteam/UdpFrameUnwrapper;->invalidCrcs:J

    invoke-virtual {v2, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v3, " invalidLength="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v6, p0, Lcom/lvteam/UdpFrameUnwrapper;->invalidLengths:J

    invoke-virtual {v2, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v3, " encrypted="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v6, p0, Lcom/lvteam/UdpFrameUnwrapper;->encryptedFrames:J

    invoke-virtual {v2, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v3, " compressed="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v6, p0, Lcom/lvteam/UdpFrameUnwrapper;->compressedFrames:J

    invoke-virtual {v2, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v3, " decryptFailed="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v6, p0, Lcom/lvteam/UdpFrameUnwrapper;->decryptFailures:J

    invoke-virtual {v2, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v3, " verifiedTags="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 255
    invoke-virtual {p0}, Lcom/lvteam/UdpFrameUnwrapper;->formatTags()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 251
    const-string v3, "UdpFrameUnwrapper"

    invoke-static {v3, v2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 256
    iput-wide v4, p0, Lcom/lvteam/UdpFrameUnwrapper;->datagramsOffered:J

    .line 257
    iput-wide v4, p0, Lcom/lvteam/UdpFrameUnwrapper;->unconfiguredFrames:J

    .line 258
    iput-wide v4, p0, Lcom/lvteam/UdpFrameUnwrapper;->invalidHeaders:J

    .line 259
    iput-wide v4, p0, Lcom/lvteam/UdpFrameUnwrapper;->invalidCrcs:J

    .line 260
    iput-wide v4, p0, Lcom/lvteam/UdpFrameUnwrapper;->invalidLengths:J

    .line 261
    iput-wide v4, p0, Lcom/lvteam/UdpFrameUnwrapper;->encryptedFrames:J

    .line 262
    iput-wide v4, p0, Lcom/lvteam/UdpFrameUnwrapper;->compressedFrames:J

    .line 263
    iput-wide v4, p0, Lcom/lvteam/UdpFrameUnwrapper;->decryptFailures:J

    .line 264
    iget-object v2, p0, Lcom/lvteam/UdpFrameUnwrapper;->verifiedTags:Ljava/util/Map;

    invoke-interface {v2}, Ljava/util/Map;->clear()V

    .line 265
    iput-wide v0, p0, Lcom/lvteam/UdpFrameUnwrapper;->lastTelemetryMs:J

    .line 266
    return-void

    .line 250
    :goto_0
    return-void
.end method

.method public declared-synchronized unwrap([BIILcom/lvteam/UdpFrameUnwrapper$Configuration;)Lcom/lvteam/UdpDecodedFrame;
    .locals 21
    .param p1, "datagram"    # [B
    .param p2, "offset"    # I
    .param p3, "length"    # I
    .param p4, "configuration"    # Lcom/lvteam/UdpFrameUnwrapper$Configuration;

    move-object/from16 v1, p0

    move-object/from16 v0, p1

    move/from16 v2, p2

    move/from16 v3, p3

    monitor-enter p0

    .line 146
    const/4 v4, 0x0

    const-wide/16 v5, 0x1

    if-nez p4, :cond_0

    .line 147
    :try_start_0
    iget-wide v7, v1, Lcom/lvteam/UdpFrameUnwrapper;->unconfiguredFrames:J

    add-long/2addr v7, v5

    iput-wide v7, v1, Lcom/lvteam/UdpFrameUnwrapper;->unconfiguredFrames:J

    .line 148
    invoke-virtual/range {p0 .. p0}, Lcom/lvteam/UdpFrameUnwrapper;->reportTelemetryIfDue()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 149
    monitor-exit p0

    return-object v4

    .line 145
    .end local p0    # "this":Lcom/lvteam/UdpFrameUnwrapper;
    .end local p1    # "datagram":[B
    .end local p2    # "offset":I
    .end local p3    # "length":I
    .end local p4    # "configuration":Lcom/lvteam/UdpFrameUnwrapper$Configuration;
    :catchall_0
    move-exception v0

    goto/16 :goto_6

    .line 151
    .restart local p1    # "datagram":[B
    .restart local p2    # "offset":I
    .restart local p3    # "length":I
    .restart local p4    # "configuration":Lcom/lvteam/UdpFrameUnwrapper$Configuration;
    :cond_0
    if-eqz v0, :cond_1

    if-ltz v2, :cond_1

    const/16 v7, 0x8

    if-lt v3, v7, :cond_1

    :try_start_1
    array-length v7, v0

    sub-int/2addr v7, v3

    if-le v2, v7, :cond_2

    :cond_1
    goto/16 :goto_5

    .line 158
    :cond_2
    aget-byte v7, v0, v2

    and-int/lit16 v7, v7, 0xff

    invoke-static {v7}, Lcom/lvteam/UdpFrameUnwrapper;->headerLength(I)I

    move-result v7

    .line 159
    .local v7, "headerLength":I
    const/4 v8, -0x1

    if-ne v7, v8, :cond_3

    .line 160
    iget-wide v8, v1, Lcom/lvteam/UdpFrameUnwrapper;->invalidHeaders:J

    add-long/2addr v8, v5

    iput-wide v8, v1, Lcom/lvteam/UdpFrameUnwrapper;->invalidHeaders:J

    .line 161
    invoke-virtual/range {p0 .. p0}, Lcom/lvteam/UdpFrameUnwrapper;->reportTelemetryIfDue()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 162
    monitor-exit p0

    return-object v4

    .line 164
    :cond_3
    const/16 v9, 0xa

    if-ne v7, v9, :cond_4

    const/4 v9, 0x1

    goto :goto_0

    :cond_4
    const/4 v9, 0x0

    .line 165
    .local v9, "reliable":Z
    :goto_0
    if-ge v3, v7, :cond_5

    .line 166
    :try_start_2
    iget-wide v10, v1, Lcom/lvteam/UdpFrameUnwrapper;->invalidLengths:J

    add-long/2addr v10, v5

    iput-wide v10, v1, Lcom/lvteam/UdpFrameUnwrapper;->invalidLengths:J

    .line 167
    invoke-virtual/range {p0 .. p0}, Lcom/lvteam/UdpFrameUnwrapper;->reportTelemetryIfDue()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 168
    monitor-exit p0

    return-object v4

    .line 170
    :cond_5
    add-int/lit8 v10, v2, 0x1

    :try_start_3
    aget-byte v10, v0, v10

    and-int/lit16 v10, v10, 0xff

    invoke-static/range {p1 .. p3}, Lcom/lvteam/UdpFrameUnwrapper;->crc8([BII)I

    move-result v11

    if-eq v10, v11, :cond_6

    .line 171
    iget-wide v10, v1, Lcom/lvteam/UdpFrameUnwrapper;->invalidCrcs:J

    add-long/2addr v10, v5

    iput-wide v10, v1, Lcom/lvteam/UdpFrameUnwrapper;->invalidCrcs:J

    .line 172
    invoke-virtual/range {p0 .. p0}, Lcom/lvteam/UdpFrameUnwrapper;->reportTelemetryIfDue()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 173
    monitor-exit p0

    return-object v4

    .line 176
    :cond_6
    nop

    nop

    if-eqz v9, :cond_7

    :try_start_4
    invoke-static/range {p4 .. p4}, Lcom/lvteam/UdpFrameUnwrapper$Configuration;->-$$Nest$fgetreliableOffsets(Lcom/lvteam/UdpFrameUnwrapper$Configuration;)[I

    move-result-object v10

    goto :goto_1

    :cond_7
    invoke-static/range {p4 .. p4}, Lcom/lvteam/UdpFrameUnwrapper$Configuration;->-$$Nest$fgetunreliableOffsets(Lcom/lvteam/UdpFrameUnwrapper$Configuration;)[I

    move-result-object v10

    :goto_1
    move-object/from16 v18, v10

    .line 177
    .local v18, "offsets":[I
    sget-object v10, Lcom/lvteam/UdpFrameUnwrapper$Field;->SEND_OPTION:Lcom/lvteam/UdpFrameUnwrapper$Field;

    invoke-virtual {v10}, Ljava/lang/Enum;->ordinal()I

    move-result v10

    aget v10, v18, v10

    invoke-static/range {p4 .. p4}, Lcom/lvteam/UdpFrameUnwrapper$Configuration;->-$$Nest$fgetmask(Lcom/lvteam/UdpFrameUnwrapper$Configuration;)I

    move-result v11

    invoke-static {v0, v2, v10, v11}, Lcom/lvteam/UdpFrameUnwrapper;->readByte([BIII)I

    move-result v14

    .line 178
    .local v14, "sendOption":I
    sget-object v10, Lcom/lvteam/UdpFrameUnwrapper$Field;->TAG:Lcom/lvteam/UdpFrameUnwrapper$Field;

    invoke-virtual {v10}, Ljava/lang/Enum;->ordinal()I

    move-result v10

    aget v10, v18, v10

    invoke-static/range {p4 .. p4}, Lcom/lvteam/UdpFrameUnwrapper$Configuration;->-$$Nest$fgetmask(Lcom/lvteam/UdpFrameUnwrapper$Configuration;)I

    move-result v11

    invoke-static {v0, v2, v10, v11}, Lcom/lvteam/UdpFrameUnwrapper;->readShort([BIII)I

    move-result v11

    .line 179
    .local v11, "tag":I
    if-eqz v9, :cond_8

    sget-object v8, Lcom/lvteam/UdpFrameUnwrapper$Field;->ORDER_ID:Lcom/lvteam/UdpFrameUnwrapper$Field;

    invoke-virtual {v8}, Ljava/lang/Enum;->ordinal()I

    move-result v8

    aget v8, v18, v8

    invoke-static/range {p4 .. p4}, Lcom/lvteam/UdpFrameUnwrapper$Configuration;->-$$Nest$fgetmask(Lcom/lvteam/UdpFrameUnwrapper$Configuration;)I

    move-result v10

    invoke-static {v0, v2, v8, v10}, Lcom/lvteam/UdpFrameUnwrapper;->readShort([BIII)I

    move-result v8

    :cond_8
    move v15, v8

    nop

    .line 180
    .local v15, "orderId":I
    sget-object v8, Lcom/lvteam/UdpFrameUnwrapper$Field;->FLAGS:Lcom/lvteam/UdpFrameUnwrapper$Field;

    invoke-virtual {v8}, Ljava/lang/Enum;->ordinal()I

    move-result v8

    aget v8, v18, v8

    invoke-static/range {p4 .. p4}, Lcom/lvteam/UdpFrameUnwrapper$Configuration;->-$$Nest$fgetmask(Lcom/lvteam/UdpFrameUnwrapper$Configuration;)I

    move-result v10

    invoke-static {v0, v2, v8, v10}, Lcom/lvteam/UdpFrameUnwrapper;->readByte([BIII)I

    move-result v8

    .line 181
    .local v8, "flags":I
    sget-object v10, Lcom/lvteam/UdpFrameUnwrapper$Field;->DATA_LENGTH:Lcom/lvteam/UdpFrameUnwrapper$Field;

    invoke-virtual {v10}, Ljava/lang/Enum;->ordinal()I

    move-result v10

    aget v10, v18, v10

    invoke-static/range {p4 .. p4}, Lcom/lvteam/UdpFrameUnwrapper$Configuration;->-$$Nest$fgetmask(Lcom/lvteam/UdpFrameUnwrapper$Configuration;)I

    move-result v12

    invoke-static {v0, v2, v10, v12}, Lcom/lvteam/UdpFrameUnwrapper;->readShort([BIII)I

    move-result v10

    move v13, v10

    .line 182
    .local v13, "declaredPayloadLength":I
    and-int/lit8 v10, v8, 0x1

    if-eqz v10, :cond_9

    iget-wide v4, v1, Lcom/lvteam/UdpFrameUnwrapper;->encryptedFrames:J

    const-wide/16 v16, 0x1

    add-long v4, v4, v16

    iput-wide v4, v1, Lcom/lvteam/UdpFrameUnwrapper;->encryptedFrames:J

    .line 183
    :cond_9
    and-int/lit8 v4, v8, 0x2

    if-eqz v4, :cond_a

    iget-wide v4, v1, Lcom/lvteam/UdpFrameUnwrapper;->compressedFrames:J

    const-wide/16 v16, 0x1

    add-long v4, v4, v16

    iput-wide v4, v1, Lcom/lvteam/UdpFrameUnwrapper;->compressedFrames:J

    .line 185
    :cond_a
    sub-int v4, v3, v7

    .line 186
    .local v4, "payloadLength":I
    if-le v13, v4, :cond_b

    .line 187
    iget-wide v5, v1, Lcom/lvteam/UdpFrameUnwrapper;->invalidLengths:J

    const-wide/16 v16, 0x1

    add-long v5, v5, v16

    iput-wide v5, v1, Lcom/lvteam/UdpFrameUnwrapper;->invalidLengths:J

    .line 188
    invoke-virtual/range {p0 .. p0}, Lcom/lvteam/UdpFrameUnwrapper;->reportTelemetryIfDue()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    .line 189
    monitor-exit p0

    const/4 v5, 0x0

    return-object v5

    .line 191
    :cond_b
    add-int v5, v2, v7

    add-int v6, v2, v7

    add-int/2addr v6, v13

    :try_start_5
    invoke-static {v0, v5, v6}, Ljava/util/Arrays;->copyOfRange([BII)[B

    move-result-object v5

    .line 193
    .local v5, "payload":[B
    and-int/lit8 v6, v8, 0x2

    if-eqz v6, :cond_c

    .line 194
    invoke-virtual/range {p0 .. p0}, Lcom/lvteam/UdpFrameUnwrapper;->reportTelemetryIfDue()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    .line 195
    monitor-exit p0

    const/4 v6, 0x0

    return-object v6

    .line 197
    :cond_c
    and-int/lit8 v6, v8, 0x1

    if-eqz v6, :cond_e

    .line 198
    :try_start_6
    invoke-static/range {p4 .. p4}, Lcom/lvteam/UdpFrameUnwrapper$Configuration;->-$$Nest$fgetkey(Lcom/lvteam/UdpFrameUnwrapper$Configuration;)[B

    move-result-object v6

    invoke-static {v5, v6}, Lcom/lvteam/UdpFrameUnwrapper;->decryptLegacy([B[B)[B

    move-result-object v6

    move-object v5, v6

    .line 199
    if-nez v5, :cond_d

    .line 200
    move v6, v11

    .end local v11    # "tag":I
    .local v6, "tag":I
    iget-wide v10, v1, Lcom/lvteam/UdpFrameUnwrapper;->decryptFailures:J

    const-wide/16 v16, 0x1

    add-long v10, v10, v16

    iput-wide v10, v1, Lcom/lvteam/UdpFrameUnwrapper;->decryptFailures:J

    .line 201
    invoke-virtual/range {p0 .. p0}, Lcom/lvteam/UdpFrameUnwrapper;->reportTelemetryIfDue()V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    .line 202
    monitor-exit p0

    const/4 v10, 0x0

    return-object v10

    .line 199
    .end local v6    # "tag":I
    .restart local v11    # "tag":I
    :cond_d
    move v6, v11

    .end local v11    # "tag":I
    .restart local v6    # "tag":I
    goto :goto_2

    .line 197
    .end local v6    # "tag":I
    .restart local v11    # "tag":I
    :cond_e
    move v6, v11

    .line 205
    .end local v11    # "tag":I
    .restart local v6    # "tag":I
    :goto_2
    :try_start_7
    iget-object v10, v1, Lcom/lvteam/UdpFrameUnwrapper;->verifiedTags:Ljava/util/Map;

    invoke-interface {v10}, Ljava/util/Map;->size()I

    move-result v10

    const/16 v11, 0x20

    if-lt v10, v11, :cond_f

    iget-object v10, v1, Lcom/lvteam/UdpFrameUnwrapper;->verifiedTags:Ljava/util/Map;

    move v11, v6

    .end local v6    # "tag":I
    .restart local v11    # "tag":I
    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-interface {v10, v6}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_11

    goto :goto_3

    .end local v11    # "tag":I
    .restart local v6    # "tag":I
    :cond_f
    move v11, v6

    .line 206
    .end local v6    # "tag":I
    .restart local v11    # "tag":I
    :goto_3
    iget-object v6, v1, Lcom/lvteam/UdpFrameUnwrapper;->verifiedTags:Ljava/util/Map;

    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-interface {v6, v10}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/Long;

    .line 207
    .local v6, "count":Ljava/lang/Long;
    iget-object v10, v1, Lcom/lvteam/UdpFrameUnwrapper;->verifiedTags:Ljava/util/Map;

    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    if-nez v6, :cond_10

    const-wide/16 v16, 0x1

    goto :goto_4

    :cond_10
    invoke-virtual {v6}, Ljava/lang/Long;->longValue()J

    move-result-wide v19

    const-wide/16 v16, 0x1

    add-long v16, v19, v16

    :goto_4
    invoke-static/range {v16 .. v17}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    invoke-interface {v10, v12, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 209
    .end local v6    # "count":Ljava/lang/Long;
    :cond_11
    invoke-virtual/range {p0 .. p0}, Lcom/lvteam/UdpFrameUnwrapper;->reportTelemetryIfDue()V

    .line 210
    new-instance v0, Lcom/lvteam/UdpDecodedFrame;

    move-object v10, v0

    move-object v12, v5

    move v6, v13

    .end local v13    # "declaredPayloadLength":I
    .local v6, "declaredPayloadLength":I
    move v13, v9

    move/from16 v16, v8

    move/from16 v17, v6

    invoke-direct/range {v10 .. v17}, Lcom/lvteam/UdpDecodedFrame;-><init>(I[BZIIII)V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_0

    monitor-exit p0

    return-object v0

    .line 153
    .end local v4    # "payloadLength":I
    .end local v5    # "payload":[B
    .end local v6    # "declaredPayloadLength":I
    .end local v7    # "headerLength":I
    .end local v8    # "flags":I
    .end local v9    # "reliable":Z
    .end local v11    # "tag":I
    .end local v14    # "sendOption":I
    .end local v15    # "orderId":I
    .end local v18    # "offsets":[I
    :goto_5
    :try_start_8
    iget-wide v4, v1, Lcom/lvteam/UdpFrameUnwrapper;->invalidLengths:J

    const-wide/16 v6, 0x1

    add-long/2addr v4, v6

    iput-wide v4, v1, Lcom/lvteam/UdpFrameUnwrapper;->invalidLengths:J

    .line 154
    invoke-virtual/range {p0 .. p0}, Lcom/lvteam/UdpFrameUnwrapper;->reportTelemetryIfDue()V
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_0

    .line 155
    monitor-exit p0

    const/4 v0, 0x0

    return-object v0

    .line 145
    .end local p1    # "datagram":[B
    .end local p2    # "offset":I
    .end local p3    # "length":I
    .end local p4    # "configuration":Lcom/lvteam/UdpFrameUnwrapper$Configuration;
    :goto_6
    :try_start_9
    monitor-exit p0
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_0

    throw v0
.end method
