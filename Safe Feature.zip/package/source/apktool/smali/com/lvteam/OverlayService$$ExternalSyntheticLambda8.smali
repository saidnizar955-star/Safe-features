.class public final synthetic Lcom/lvteam/OverlayService$$ExternalSyntheticLambda8;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Lcom/lvteam/OverlayService$SliderCallback;


# instance fields
.field public final synthetic f$0:Lcom/lvteam/OverlayService;


# direct methods
.method public synthetic constructor <init>(Lcom/lvteam/OverlayService;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda8;->f$0:Lcom/lvteam/OverlayService;

    return-void
.end method


# virtual methods
.method public final onChange(I)V
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/lvteam/OverlayService$$ExternalSyntheticLambda8;->f$0:Lcom/lvteam/OverlayService;

    invoke-static {v0, p1}, Lcom/lvteam/OverlayService;->$r8$lambda$mx-g_u6T1stoRigZCyuat24fnnw(Lcom/lvteam/OverlayService;I)V

    return-void
.end method
