.class public final Lcom/lvteam/RawFrameDecoder$Cursor;
.super Ljava/lang/Object;
.source "RawFrameDecoder.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/lvteam/RawFrameDecoder;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Cursor"
.end annotation


# instance fields
.field public final bytes:[B

.field public position:I


# direct methods
.method public constructor <init>([B)V
    .locals 0
    .param p1, "bytes"    # [B

    .line 683
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 684
    iput-object p1, p0, Lcom/lvteam/RawFrameDecoder$Cursor;->bytes:[B

    .line 685
    return-void
.end method


# virtual methods
.method public readByte()I
    .locals 3

    .line 703
    iget v0, p0, Lcom/lvteam/RawFrameDecoder$Cursor;->position:I

    iget-object v1, p0, Lcom/lvteam/RawFrameDecoder$Cursor;->bytes:[B

    array-length v1, v1

    if-eq v0, v1, :cond_0

    .line 704
    iget-object v0, p0, Lcom/lvteam/RawFrameDecoder$Cursor;->bytes:[B

    iget v1, p0, Lcom/lvteam/RawFrameDecoder$Cursor;->position:I

    add-int/lit8 v2, v1, 0x1

    iput v2, p0, Lcom/lvteam/RawFrameDecoder$Cursor;->position:I

    aget-byte v0, v0, v1

    and-int/lit16 v0, v0, 0xff

    return v0

    .line 703
    :cond_0
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Truncated byte"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public readString()Ljava/lang/String;
    .locals 9

    .line 716
    invoke-virtual {p0}, Lcom/lvteam/RawFrameDecoder$Cursor;->readUnsigned()J

    move-result-wide v0

    .line 717
    .local v0, "encodedLength":J
    invoke-static {v0, v1}, Lcom/lvteam/VarintReader;->zigZag(J)J

    move-result-wide v2

    .line 718
    .local v2, "length":J
    const-wide/16 v4, 0x0

    cmp-long v4, v2, v4

    if-ltz v4, :cond_0

    const-wide/16 v4, 0x40

    cmp-long v4, v2, v4

    if-gtz v4, :cond_0

    iget v4, p0, Lcom/lvteam/RawFrameDecoder$Cursor;->position:I

    int-to-long v4, v4

    iget-object v6, p0, Lcom/lvteam/RawFrameDecoder$Cursor;->bytes:[B

    array-length v6, v6

    int-to-long v6, v6

    sub-long/2addr v6, v2

    cmp-long v4, v4, v6

    if-gtz v4, :cond_0

    .line 721
    new-instance v4, Ljava/lang/String;

    iget-object v5, p0, Lcom/lvteam/RawFrameDecoder$Cursor;->bytes:[B

    iget v6, p0, Lcom/lvteam/RawFrameDecoder$Cursor;->position:I

    long-to-int v7, v2

    sget-object v8, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {v4, v5, v6, v7, v8}, Ljava/lang/String;-><init>([BIILjava/nio/charset/Charset;)V

    .line 722
    .local v4, "value":Ljava/lang/String;
    iget v5, p0, Lcom/lvteam/RawFrameDecoder$Cursor;->position:I

    long-to-int v6, v2

    add-int/2addr v5, v6

    iput v5, p0, Lcom/lvteam/RawFrameDecoder$Cursor;->position:I

    .line 723
    return-object v4

    .line 719
    .end local v4    # "value":Ljava/lang/String;
    :cond_0
    new-instance v4, Ljava/lang/IllegalArgumentException;

    const-string v5, "Invalid string"

    invoke-direct {v4, v5}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v4
.end method

.method public readUnsigned()J
    .locals 6

    .line 688
    const-wide/16 v0, 0x0

    .line 689
    .local v0, "value":J
    const/4 v2, 0x0

    .local v2, "shift":I
    :goto_0
    const/16 v3, 0x40

    if-ge v2, v3, :cond_2

    .line 690
    iget v3, p0, Lcom/lvteam/RawFrameDecoder$Cursor;->position:I

    iget-object v4, p0, Lcom/lvteam/RawFrameDecoder$Cursor;->bytes:[B

    array-length v4, v4

    if-eq v3, v4, :cond_1

    .line 691
    iget-object v3, p0, Lcom/lvteam/RawFrameDecoder$Cursor;->bytes:[B

    iget v4, p0, Lcom/lvteam/RawFrameDecoder$Cursor;->position:I

    add-int/lit8 v5, v4, 0x1

    iput v5, p0, Lcom/lvteam/RawFrameDecoder$Cursor;->position:I

    aget-byte v3, v3, v4

    and-int/lit16 v3, v3, 0xff

    .line 692
    .local v3, "next":I
    and-int/lit8 v4, v3, 0x7f

    int-to-long v4, v4

    shl-long/2addr v4, v2

    or-long/2addr v0, v4

    .line 693
    and-int/lit16 v4, v3, 0x80

    if-nez v4, :cond_0

    return-wide v0

    .line 689
    .end local v3    # "next":I
    :cond_0
    add-int/lit8 v2, v2, 0x7

    goto :goto_0

    .line 690
    :cond_1
    new-instance v3, Ljava/lang/IllegalArgumentException;

    const-string v4, "Truncated varint"

    invoke-direct {v3, v4}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v3

    .line 689
    :cond_2
    nop

    .line 695
    .end local v2    # "shift":I
    new-instance v2, Ljava/lang/IllegalArgumentException;

    const-string v3, "Malformed varint"

    invoke-direct {v2, v3}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v2
.end method

.method public readZigZag()F
    .locals 2

    .line 699
    invoke-virtual {p0}, Lcom/lvteam/RawFrameDecoder$Cursor;->readUnsigned()J

    move-result-wide v0

    invoke-static {v0, v1}, Lcom/lvteam/VarintReader;->zigZag(J)J

    move-result-wide v0

    long-to-float v0, v0

    return v0
.end method

.method public requireEnd()V
    .locals 2

    .line 727
    iget v0, p0, Lcom/lvteam/RawFrameDecoder$Cursor;->position:I

    iget-object v1, p0, Lcom/lvteam/RawFrameDecoder$Cursor;->bytes:[B

    array-length v1, v1

    if-ne v0, v1, :cond_0

    .line 728
    return-void

    .line 727
    :cond_0
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Trailing data"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method
