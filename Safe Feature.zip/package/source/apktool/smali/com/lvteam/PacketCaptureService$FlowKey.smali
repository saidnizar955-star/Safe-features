.class public final Lcom/lvteam/PacketCaptureService$FlowKey;
.super Ljava/lang/Object;
.source "PacketCaptureService.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/lvteam/PacketCaptureService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "FlowKey"
.end annotation


# instance fields
.field public final destinationAddress:Ljava/net/InetAddress;

.field public final destinationPort:I

.field public final sourceAddress:Ljava/net/InetAddress;

.field public final sourcePort:I


# direct methods
.method public constructor <init>(Ljava/net/InetAddress;ILjava/net/InetAddress;I)V
    .locals 0
    .param p1, "sourceAddress"    # Ljava/net/InetAddress;
    .param p2, "sourcePort"    # I
    .param p3, "destinationAddress"    # Ljava/net/InetAddress;
    .param p4, "destinationPort"    # I

    .line 834
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 835
    iput-object p1, p0, Lcom/lvteam/PacketCaptureService$FlowKey;->sourceAddress:Ljava/net/InetAddress;

    .line 836
    iput p2, p0, Lcom/lvteam/PacketCaptureService$FlowKey;->sourcePort:I

    .line 837
    iput-object p3, p0, Lcom/lvteam/PacketCaptureService$FlowKey;->destinationAddress:Ljava/net/InetAddress;

    .line 838
    iput p4, p0, Lcom/lvteam/PacketCaptureService$FlowKey;->destinationPort:I

    .line 839
    return-void
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .locals 4
    .param p1, "other"    # Ljava/lang/Object;

    .line 843
    instance-of v0, p1, Lcom/lvteam/PacketCaptureService$FlowKey;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    .line 844
    :cond_0
    move-object v0, p1

    check-cast v0, Lcom/lvteam/PacketCaptureService$FlowKey;

    .line 845
    .local v0, "that":Lcom/lvteam/PacketCaptureService$FlowKey;
    iget v2, p0, Lcom/lvteam/PacketCaptureService$FlowKey;->sourcePort:I

    iget v3, v0, Lcom/lvteam/PacketCaptureService$FlowKey;->sourcePort:I

    if-ne v2, v3, :cond_1

    iget v2, p0, Lcom/lvteam/PacketCaptureService$FlowKey;->destinationPort:I

    iget v3, v0, Lcom/lvteam/PacketCaptureService$FlowKey;->destinationPort:I

    if-ne v2, v3, :cond_1

    iget-object v2, p0, Lcom/lvteam/PacketCaptureService$FlowKey;->sourceAddress:Ljava/net/InetAddress;

    iget-object v3, v0, Lcom/lvteam/PacketCaptureService$FlowKey;->sourceAddress:Ljava/net/InetAddress;

    .line 846
    invoke-virtual {v2, v3}, Ljava/net/InetAddress;->equals(Ljava/lang/Object;)Z

    move-result v2

    nop

    if-eqz v2, :cond_1

    iget-object v2, p0, Lcom/lvteam/PacketCaptureService$FlowKey;->destinationAddress:Ljava/net/InetAddress;

    iget-object v3, v0, Lcom/lvteam/PacketCaptureService$FlowKey;->destinationAddress:Ljava/net/InetAddress;

    .line 847
    invoke-virtual {v2, v3}, Ljava/net/InetAddress;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_1

    const/4 v1, 0x1

    goto :goto_0

    :cond_1
    nop

    .line 845
    :goto_0
    return v1
.end method

.method public hashCode()I
    .locals 3

    .line 852
    iget-object v0, p0, Lcom/lvteam/PacketCaptureService$FlowKey;->sourceAddress:Ljava/net/InetAddress;

    invoke-virtual {v0}, Ljava/net/InetAddress;->hashCode()I

    move-result v0

    .line 853
    .local v0, "result":I
    mul-int/lit8 v1, v0, 0x1f

    iget v2, p0, Lcom/lvteam/PacketCaptureService$FlowKey;->sourcePort:I

    add-int/2addr v1, v2

    .line 854
    .end local v0    # "result":I
    .local v1, "result":I
    mul-int/lit8 v0, v1, 0x1f

    iget-object v2, p0, Lcom/lvteam/PacketCaptureService$FlowKey;->destinationAddress:Ljava/net/InetAddress;

    invoke-virtual {v2}, Ljava/net/InetAddress;->hashCode()I

    move-result v2

    add-int/2addr v0, v2

    .line 855
    .end local v1    # "result":I
    .restart local v0    # "result":I
    mul-int/lit8 v1, v0, 0x1f

    iget v2, p0, Lcom/lvteam/PacketCaptureService$FlowKey;->destinationPort:I

    add-int/2addr v1, v2

    return v1
.end method
