.class public final Lcom/lvteam/EntityState$Position;
.super Ljava/lang/Object;
.source "EntityState.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/lvteam/EntityState;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Position"
.end annotation


# instance fields
.field public final updatedAt:J

.field public final x:F

.field public final y:F

.field public final z:F


# direct methods
.method public constructor <init>(FFFJ)V
    .locals 0
    .param p1, "x"    # F
    .param p2, "y"    # F
    .param p3, "z"    # F
    .param p4, "updatedAt"    # J

    .line 273
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 274
    iput p1, p0, Lcom/lvteam/EntityState$Position;->x:F

    .line 275
    iput p2, p0, Lcom/lvteam/EntityState$Position;->y:F

    .line 276
    iput p3, p0, Lcom/lvteam/EntityState$Position;->z:F

    .line 277
    iput-wide p4, p0, Lcom/lvteam/EntityState$Position;->updatedAt:J

    .line 278
    return-void
.end method
