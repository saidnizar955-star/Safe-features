.class public abstract Lcom/lvteam/LvUpdateChecker;
.super Ljava/lang/Object;
.source "LvUpdateChecker.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/lvteam/LvUpdateChecker$Callback;
    }
.end annotation


# static fields
.field public static final CHECK_URL:Ljava/lang/String;


# direct methods
.method public static synthetic $r8$lambda$0YoxoJllgPyau1-YCb3SjaQqiEk(Landroid/app/Activity;Landroid/content/DialogInterface;I)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2}, Lcom/lvteam/LvUpdateChecker;->lambda$showUpdateDialog$3(Landroid/app/Activity;Landroid/content/DialogInterface;I)V

    return-void
.end method

.method public static synthetic $r8$lambda$HlT-dF1vj0JsWd8jddYXKZ6Wy38(ZLjava/lang/String;Landroid/app/Activity;Ljava/lang/String;Lcom/lvteam/LvUpdateChecker$Callback;)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3, p4}, Lcom/lvteam/LvUpdateChecker;->lambda$check$0(ZLjava/lang/String;Landroid/app/Activity;Ljava/lang/String;Lcom/lvteam/LvUpdateChecker$Callback;)V

    return-void
.end method

.method public static synthetic $r8$lambda$TPK-eX04JWZ6ta75AdAEAHlE6Fs(Ljava/lang/String;Landroid/app/Activity;Lcom/lvteam/LvUpdateChecker$Callback;)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2}, Lcom/lvteam/LvUpdateChecker;->lambda$check$1(Ljava/lang/String;Landroid/app/Activity;Lcom/lvteam/LvUpdateChecker$Callback;)V

    return-void
.end method

.method public static synthetic $r8$lambda$zvkfMhKd7ApX5m0Bc0PWXiUb_Cc(Landroid/app/Activity;Ljava/lang/String;Landroid/content/DialogInterface;I)V
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3}, Lcom/lvteam/LvUpdateChecker;->lambda$showUpdateDialog$2(Landroid/app/Activity;Ljava/lang/String;Landroid/content/DialogInterface;I)V

    return-void
.end method

.method static constructor <clinit>()V
    .locals 1

    .line 21
    const/16 v0, 0x3c

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    invoke-static {v0}, Lcom/lvteam/Obs;->d([B)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/lvteam/LvUpdateChecker;->CHECK_URL:Ljava/lang/String;

    return-void

    :array_0
    .array-data 1
        0x24t
        0x22t
        0x20t
        0x35t
        0x32t
        0x77t
        0x63t
        0x79t
        0x35t
        0x35t
        0x31t
        0x63t
        0x20t
        0x20t
        0x20t
        0x20t
        0x20t
        0x20t
        0x2dt
        0x38t
        0x3bt
        0x2bt
        0x38t
        0x20t
        0x39t
        0x25t
        0x7at
        0x36t
        0x35t
        0x22t
        0x3et
        0x33t
        0x7bt
        0x24t
        0x31t
        0x24t
        0x63t
        0x26t
        0x21t
        0x27t
        0x2dt
        0x24t
        0x2ft
        0x79t
        0x35t
        0x35t
        0x2at
        0x62t
        0x2ft
        0x3et
        0x31t
        0x26t
        0x2at
        0x60t
        0x39t
        0x26t
        0x30t
        0x24t
        0x35t
        0x28t
    .end array-data
.end method

.method public static check(Landroid/app/Activity;Lcom/lvteam/LvUpdateChecker$Callback;)V
    .locals 1
    .param p0, "activity"    # Landroid/app/Activity;
    .param p1, "callback"    # Lcom/lvteam/LvUpdateChecker$Callback;

    const/4 v0, 0x0

    invoke-interface {p1, v0}, Lcom/lvteam/LvUpdateChecker$Callback;->onResult(Z)V

    return-void
.end method

.method public static getApkSha256(Landroid/app/Activity;)Ljava/lang/String;
    .locals 15
    .param p0, "activity"    # Landroid/app/Activity;

    .line 29
    const/4 v0, 0x1

    const/4 v1, 0x0

    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getPackageCodePath()Ljava/lang/String;

    move-result-object v2

    .line 30
    .local v2, "apkPath":Ljava/lang/String;
    const-string v3, "SHA-256"

    invoke-static {v3}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v3

    .line 31
    .local v3, "md":Ljava/security/MessageDigest;
    new-instance v4, Ljava/io/FileInputStream;

    invoke-direct {v4, v2}, Ljava/io/FileInputStream;-><init>(Ljava/lang/String;)V

    .line 32
    .local v4, "fis":Ljava/io/FileInputStream;
    const/16 v5, 0x2000

    new-array v5, v5, [B

    .line 34
    .local v5, "buffer":[B
    :goto_0
    invoke-virtual {v4, v5}, Ljava/io/FileInputStream;->read([B)I

    move-result v6

    move v7, v6

    .local v7, "read":I
    const/4 v8, -0x1

    if-eq v6, v8, :cond_0

    .line 35
    invoke-virtual {v3, v5, v1, v7}, Ljava/security/MessageDigest;->update([BII)V

    goto :goto_0

    .line 42
    .end local v2    # "apkPath":Ljava/lang/String;
    .end local v3    # "md":Ljava/security/MessageDigest;
    .end local v4    # "fis":Ljava/io/FileInputStream;
    .end local v5    # "buffer":[B
    .end local v7    # "read":I
    :catch_0
    move-exception v0

    goto :goto_2

    .line 37
    .restart local v2    # "apkPath":Ljava/lang/String;
    .restart local v3    # "md":Ljava/security/MessageDigest;
    .restart local v4    # "fis":Ljava/io/FileInputStream;
    .restart local v5    # "buffer":[B
    .restart local v7    # "read":I
    :cond_0
    invoke-virtual {v4}, Ljava/io/FileInputStream;->close()V

    .line 38
    invoke-virtual {v3}, Ljava/security/MessageDigest;->digest()[B

    move-result-object v6

    .line 39
    .local v6, "hash":[B
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    .line 40
    .local v8, "sb":Ljava/lang/StringBuilder;
    array-length v9, v6

    move v10, v1

    :goto_1
    if-ge v10, v9, :cond_1

    aget-byte v11, v6, v10

    .local v11, "b":B
    const-string v12, "%02x"

    invoke-static {v11}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object v13

    new-array v14, v0, [Ljava/lang/Object;

    aput-object v13, v14, v1

    invoke-static {v12, v14}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v8, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .end local v11    # "b":B
    add-int/2addr v10, v0

    goto :goto_1

    .line 41
    :cond_1
    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    .line 42
    .end local v2    # "apkPath":Ljava/lang/String;
    .end local v3    # "md":Ljava/security/MessageDigest;
    .end local v4    # "fis":Ljava/io/FileInputStream;
    .end local v5    # "buffer":[B
    .end local v6    # "hash":[B
    .end local v7    # "read":I
    .end local v8    # "sb":Ljava/lang/StringBuilder;
    :goto_2
    nop

    .line 43
    .local v0, "e":Ljava/lang/Exception;
    const-string v1, ""

    return-object v1
.end method

.method public static synthetic lambda$check$0(ZLjava/lang/String;Landroid/app/Activity;Ljava/lang/String;Lcom/lvteam/LvUpdateChecker$Callback;)V
    .locals 1
    .param p0, "update"    # Z
    .param p1, "dlUrl"    # Ljava/lang/String;
    .param p2, "activity"    # Landroid/app/Activity;
    .param p3, "verName"    # Ljava/lang/String;
    .param p4, "callback"    # Lcom/lvteam/LvUpdateChecker$Callback;

    .line 86
    if-eqz p0, :cond_0

    if-eqz p1, :cond_0

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_0

    .line 87
    invoke-static {p2, p3, p1, p4}, Lcom/lvteam/LvUpdateChecker;->showUpdateDialog(Landroid/app/Activity;Ljava/lang/String;Ljava/lang/String;Lcom/lvteam/LvUpdateChecker$Callback;)V

    goto :goto_0

    .line 89
    :cond_0
    const/4 v0, 0x0

    invoke-interface {p4, v0}, Lcom/lvteam/LvUpdateChecker$Callback;->onResult(Z)V

    .line 91
    :goto_0
    return-void
.end method

.method public static synthetic lambda$check$1(Ljava/lang/String;Landroid/app/Activity;Lcom/lvteam/LvUpdateChecker$Callback;)V
    .locals 12
    .param p0, "apkHash"    # Ljava/lang/String;
    .param p1, "activity"    # Landroid/app/Activity;
    .param p2, "callback"    # Lcom/lvteam/LvUpdateChecker$Callback;

    .line 51
    const/4 v0, 0x0

    const/4 v1, 0x0

    .line 52
    .local v1, "needsUpdate":Z
    const/4 v2, 0x0

    .line 53
    .local v2, "downloadUrl":Ljava/lang/String;
    const/4 v3, 0x0

    .line 56
    .local v3, "versionName":Ljava/lang/String;
    :try_start_0
    new-instance v4, Ljava/net/URL;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v6, Lcom/lvteam/LvUpdateChecker;->CHECK_URL:Ljava/lang/String;

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v6, "?hash="

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v4, v5}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    .line 57
    .local v4, "url":Ljava/net/URL;
    invoke-virtual {v4}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v5

    check-cast v5, Ljava/net/HttpURLConnection;

    .line 58
    .local v5, "c":Ljava/net/HttpURLConnection;
    const-string v6, "GET"

    invoke-virtual {v5, v6}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    .line 59
    const/16 v6, 0xa

    new-array v6, v6, [B

    fill-array-data v6, :array_0

    invoke-static {v6}, Lcom/lvteam/Obs;->d([B)Ljava/lang/String;

    move-result-object v6

    const/16 v7, 0xe

    new-array v7, v7, [B

    fill-array-data v7, :array_1

    invoke-static {v7}, Lcom/lvteam/Obs;->d([B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v6, v7}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 60
    const/16 v6, 0x2710

    invoke-virtual {v5, v6}, Ljava/net/URLConnection;->setConnectTimeout(I)V

    .line 61
    invoke-virtual {v5, v6}, Ljava/net/URLConnection;->setReadTimeout(I)V

    .line 63
    invoke-virtual {v5}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v6

    .line 64
    .local v6, "code":I
    const/16 v7, 0xc8

    if-lt v6, v7, :cond_1

    const/16 v7, 0x12c

    if-ge v6, v7, :cond_1

    .line 65
    new-instance v7, Ljava/io/BufferedReader;

    new-instance v8, Ljava/io/InputStreamReader;

    .line 66
    invoke-virtual {v5}, Ljava/net/URLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v9

    const-string v10, "UTF-8"

    invoke-direct {v8, v9, v10}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/lang/String;)V

    invoke-direct {v7, v8}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    .line 67
    .local v7, "br":Ljava/io/BufferedReader;
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    .line 69
    .local v8, "sb":Ljava/lang/StringBuilder;
    :goto_0
    invoke-virtual {v7}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v9

    move-object v10, v9

    .local v10, "line":Ljava/lang/String;
    if-eqz v9, :cond_0

    invoke-virtual {v8, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_0

    .line 78
    .end local v4    # "url":Ljava/net/URL;
    .end local v5    # "c":Ljava/net/HttpURLConnection;
    .end local v6    # "code":I
    .end local v7    # "br":Ljava/io/BufferedReader;
    .end local v8    # "sb":Ljava/lang/StringBuilder;
    .end local v10    # "line":Ljava/lang/String;
    :catch_0
    move-exception v0

    goto :goto_1

    .line 70
    .restart local v4    # "url":Ljava/net/URL;
    .restart local v5    # "c":Ljava/net/HttpURLConnection;
    .restart local v6    # "code":I
    .restart local v7    # "br":Ljava/io/BufferedReader;
    .restart local v8    # "sb":Ljava/lang/StringBuilder;
    .restart local v10    # "line":Ljava/lang/String;
    :cond_0
    invoke-virtual {v7}, Ljava/io/BufferedReader;->close()V

    .line 72
    new-instance v9, Lorg/json/JSONObject;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-direct {v9, v11}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 73
    .local v9, "json":Lorg/json/JSONObject;
    const-string v11, "update"

    invoke-virtual {v9, v11, v0}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result v0

    move v1, v0

    .line 74
    const-string v0, "downloadUrl"

    const/4 v11, 0x0

    invoke-virtual {v9, v0, v11}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    move-object v2, v0

    .line 75
    const-string v0, "versionName"

    const-string v11, ""

    invoke-virtual {v9, v0, v11}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    move-object v3, v0

    .line 77
    .end local v7    # "br":Ljava/io/BufferedReader;
    .end local v8    # "sb":Ljava/lang/StringBuilder;
    .end local v9    # "json":Lorg/json/JSONObject;
    .end local v10    # "line":Ljava/lang/String;
    :cond_1
    invoke-virtual {v5}, Ljava/net/HttpURLConnection;->disconnect()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 79
    .end local v4    # "url":Ljava/net/URL;
    .end local v5    # "c":Ljava/net/HttpURLConnection;
    .end local v6    # "code":I
    nop

    .line 81
    :goto_1
    move v5, v1

    .line 82
    .local v5, "update":Z
    move-object v6, v2

    .line 83
    .local v6, "dlUrl":Ljava/lang/String;
    move-object v8, v3

    .line 85
    .local v8, "verName":Ljava/lang/String;
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v4

    invoke-direct {v0, v4}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v10, Lcom/lvteam/LvUpdateChecker$$ExternalSyntheticLambda1;

    move-object v4, v10

    move-object v7, p1

    move-object v9, p2

    invoke-direct/range {v4 .. v9}, Lcom/lvteam/LvUpdateChecker$$ExternalSyntheticLambda1;-><init>(ZLjava/lang/String;Landroid/app/Activity;Ljava/lang/String;Lcom/lvteam/LvUpdateChecker$Callback;)V

    invoke-virtual {v0, v10}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 92
    return-void

    nop

    :array_0
    .array-data 1
        0x19t
        0x25t
        0x31t
        0x37t
        0x6ct
        0xct
        0x2bt
        0x33t
        0x3at
        0x31t
    .end array-data

    nop

    :array_1
    .array-data 1
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x61t
        0x17t
        0x3at
        0x21t
        0x33t
        0x22t
        0x25t
        0x32t
    .end array-data
.end method

.method public static synthetic lambda$showUpdateDialog$2(Landroid/app/Activity;Ljava/lang/String;Landroid/content/DialogInterface;I)V
    .locals 3
    .param p0, "activity"    # Landroid/app/Activity;
    .param p1, "downloadUrl"    # Ljava/lang/String;
    .param p2, "d"    # Landroid/content/DialogInterface;
    .param p3, "w"    # I

    .line 107
    :try_start_0
    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.intent.action.VIEW"

    .line 108
    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v2

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 107
    invoke-virtual {p0, v0}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 110
    goto :goto_0

    .line 109
    :catch_0
    move-exception v0

    .line 111
    :goto_0
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    .line 112
    return-void
.end method

.method public static synthetic lambda$showUpdateDialog$3(Landroid/app/Activity;Landroid/content/DialogInterface;I)V
    .locals 0
    .param p0, "activity"    # Landroid/app/Activity;
    .param p1, "d"    # Landroid/content/DialogInterface;
    .param p2, "w"    # I

    .line 113
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    return-void
.end method

.method public static showUpdateDialog(Landroid/app/Activity;Ljava/lang/String;Ljava/lang/String;Lcom/lvteam/LvUpdateChecker$Callback;)V
    .locals 3
    .param p0, "activity"    # Landroid/app/Activity;
    .param p1, "version"    # Ljava/lang/String;
    .param p2, "downloadUrl"    # Ljava/lang/String;
    .param p3, "callback"    # Lcom/lvteam/LvUpdateChecker$Callback;

    .line 100
    new-instance v0, Landroid/app/AlertDialog$Builder;

    const/4 v1, 0x4

    invoke-direct {v0, p0, v1}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;I)V

    .line 101
    const-string v1, "Atualiza\u00e7\u00e3o Necess\u00e1ria"

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Nova vers\u00e3o (v"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ") dispon\u00edvel.\n\nAtualize para continuar usando."

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 102
    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    .line 104
    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setCancelable(Z)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    new-instance v1, Lcom/lvteam/LvUpdateChecker$$ExternalSyntheticLambda2;

    invoke-direct {v1, p0, p2}, Lcom/lvteam/LvUpdateChecker$$ExternalSyntheticLambda2;-><init>(Landroid/app/Activity;Ljava/lang/String;)V

    .line 105
    const-string v2, "Atualizar"

    invoke-virtual {v0, v2, v1}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    new-instance v1, Lcom/lvteam/LvUpdateChecker$$ExternalSyntheticLambda3;

    invoke-direct {v1, p0}, Lcom/lvteam/LvUpdateChecker$$ExternalSyntheticLambda3;-><init>(Landroid/app/Activity;)V

    .line 113
    const-string v2, "Sair"

    invoke-virtual {v0, v2, v1}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    .line 114
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 115
    return-void
.end method
