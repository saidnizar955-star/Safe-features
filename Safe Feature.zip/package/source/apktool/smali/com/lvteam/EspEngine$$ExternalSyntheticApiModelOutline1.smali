.class public abstract synthetic Lcom/lvteam/EspEngine$$ExternalSyntheticApiModelOutline1;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"


# direct methods
.method public static bridge synthetic m(Ljava/util/ArrayList;Ljava/util/Comparator;)V
    .locals 0

    .line 0
    invoke-virtual {p0, p1}, Ljava/util/ArrayList;->sort(Ljava/util/Comparator;)V

    return-void
.end method
