.class public final Lcom/lvteam/EspOverlayView$Entity;
.super Ljava/lang/Object;
.source "EspOverlayView.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/lvteam/EspOverlayView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Entity"
.end annotation


# instance fields
.field public final distanceMeters:F

.field public final health:F

.field public final height:F

.field public final id:I

.field public final left:F

.field public final name:Ljava/lang/String;

.field public final top:F

.field public final width:F


# direct methods
.method public constructor <init>(ILjava/lang/String;FFFFFF)V
    .locals 0
    .param p1, "id"    # I
    .param p2, "name"    # Ljava/lang/String;
    .param p3, "left"    # F
    .param p4, "top"    # F
    .param p5, "width"    # F
    .param p6, "height"    # F
    .param p7, "health"    # F
    .param p8, "distanceMeters"    # F

    .line 125
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 126
    iput p1, p0, Lcom/lvteam/EspOverlayView$Entity;->id:I

    .line 127
    iput-object p2, p0, Lcom/lvteam/EspOverlayView$Entity;->name:Ljava/lang/String;

    .line 128
    iput p3, p0, Lcom/lvteam/EspOverlayView$Entity;->left:F

    .line 129
    iput p4, p0, Lcom/lvteam/EspOverlayView$Entity;->top:F

    .line 130
    iput p5, p0, Lcom/lvteam/EspOverlayView$Entity;->width:F

    .line 131
    iput p6, p0, Lcom/lvteam/EspOverlayView$Entity;->height:F

    .line 132
    iput p7, p0, Lcom/lvteam/EspOverlayView$Entity;->health:F

    .line 133
    iput p8, p0, Lcom/lvteam/EspOverlayView$Entity;->distanceMeters:F

    .line 134
    return-void
.end method
