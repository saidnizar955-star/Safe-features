.class public Lcom/lvteam/MainActivity$1$2;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/lvteam/MainActivity$1;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic this$1:Lcom/lvteam/MainActivity$1;


# direct methods
.method public constructor <init>(Lcom/lvteam/MainActivity$1;)V
    .locals 0
    .param p1, "this$1"    # Lcom/lvteam/MainActivity$1;

    .line 304
    iput-object p1, p0, Lcom/lvteam/MainActivity$1$2;->this$1:Lcom/lvteam/MainActivity$1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    .line 307
    iget-object v0, p0, Lcom/lvteam/MainActivity$1$2;->this$1:Lcom/lvteam/MainActivity$1;

    iget-object v0, v0, Lcom/lvteam/MainActivity$1;->this$0:Lcom/lvteam/MainActivity;

    iget-object v1, p0, Lcom/lvteam/MainActivity$1$2;->this$1:Lcom/lvteam/MainActivity$1;

    iget-object v1, v1, Lcom/lvteam/MainActivity$1;->val$key:Ljava/lang/String;

    const/4 v2, -0x1

    const-string v3, ""

    invoke-static {v0, v1, v2, v3}, Lcom/lvteam/MainActivity;->-$$Nest$monAuthResult(Lcom/lvteam/MainActivity;Ljava/lang/String;ILjava/lang/String;)V

    .line 308
    return-void
.end method
