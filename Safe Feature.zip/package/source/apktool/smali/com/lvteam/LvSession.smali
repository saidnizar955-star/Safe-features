.class public final Lcom/lvteam/LvSession;
.super Ljava/lang/Object;
.source "LvSession.java"


# static fields
.field public static final INSTANCE:Lcom/lvteam/LvSession;


# instance fields
.field public volatile activationTime:J

.field public volatile authDays:I

.field public volatile authTimestamp:J

.field public volatile authToken:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 6
    new-instance v0, Lcom/lvteam/LvSession;

    invoke-direct {v0}, Lcom/lvteam/LvSession;-><init>()V

    sput-object v0, Lcom/lvteam/LvSession;->INSTANCE:Lcom/lvteam/LvSession;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 14
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static get()Lcom/lvteam/LvSession;
    .locals 1

    .line 16
    sget-object v0, Lcom/lvteam/LvSession;->INSTANCE:Lcom/lvteam/LvSession;

    return-object v0
.end method


# virtual methods
.method public activate(Ljava/lang/String;ILjava/lang/String;)V
    .locals 11
    .param p1, "key"    # Ljava/lang/String;
    .param p2, "days"    # I
    .param p3, "serverResponse"    # Ljava/lang/String;

    .line 20
    const/4 v0, 0x1

    const/4 v1, 0x0

    const-string v2, "UTF-8"

    :try_start_0
    const-string v3, "SHA-256"

    invoke-static {v3}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v3

    .line 21
    .local v3, "md":Ljava/security/MessageDigest;
    invoke-virtual {p1, v2}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/security/MessageDigest;->update([B)V

    .line 22
    invoke-virtual {p3, v2}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/security/MessageDigest;->update([B)V

    .line 23
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    invoke-static {v4, v5}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object v2

    invoke-virtual {v3, v2}, Ljava/security/MessageDigest;->update([B)V

    .line 24
    invoke-virtual {v3}, Ljava/security/MessageDigest;->digest()[B

    move-result-object v2

    .line 25
    .local v2, "hash":[B
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    .line 26
    .local v4, "sb":Ljava/lang/StringBuilder;
    array-length v5, v2

    move v6, v1

    :goto_0
    if-ge v6, v5, :cond_0

    aget-byte v7, v2, v6

    .local v7, "b":B
    const-string v8, "%02x"

    invoke-static {v7}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object v9

    new-array v10, v0, [Ljava/lang/Object;

    aput-object v9, v10, v1

    invoke-static {v8, v10}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .end local v7    # "b":B
    add-int/2addr v6, v0

    goto :goto_0

    .line 28
    .end local v2    # "hash":[B
    .end local v3    # "md":Ljava/security/MessageDigest;
    .end local v4    # "sb":Ljava/lang/StringBuilder;
    :catch_0
    move-exception v0

    goto :goto_1

    .line 27
    .restart local v2    # "hash":[B
    .restart local v3    # "md":Ljava/security/MessageDigest;
    .restart local v4    # "sb":Ljava/lang/StringBuilder;
    :cond_0
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/lvteam/LvSession;->authToken:Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 31
    .end local v2    # "hash":[B
    .end local v3    # "md":Ljava/security/MessageDigest;
    .end local v4    # "sb":Ljava/lang/StringBuilder;
    nop

    .line 32
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    iput-wide v0, p0, Lcom/lvteam/LvSession;->authTimestamp:J

    .line 33
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    iput-wide v0, p0, Lcom/lvteam/LvSession;->activationTime:J

    .line 34
    iput p2, p0, Lcom/lvteam/LvSession;->authDays:I

    .line 35
    return-void

    .line 28
    :goto_1
    nop

    .line 29
    .local v0, "e":Ljava/lang/Exception;
    const/4 v1, 0x0

    iput-object v1, p0, Lcom/lvteam/LvSession;->authToken:Ljava/lang/String;

    .line 30
    return-void
.end method

.method public invalidate()V
    .locals 2

    .line 38
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/lvteam/LvSession;->authToken:Ljava/lang/String;

    .line 39
    const-wide/16 v0, 0x0

    iput-wide v0, p0, Lcom/lvteam/LvSession;->authTimestamp:J

    .line 40
    const/4 v0, 0x0

    iput v0, p0, Lcom/lvteam/LvSession;->authDays:I

    .line 41
    return-void
.end method

.method public isActive()Z
    .locals 8

    .line 44
    iget-object v0, p0, Lcom/lvteam/LvSession;->authToken:Ljava/lang/String;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    .line 45
    :cond_0
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    iget-wide v4, p0, Lcom/lvteam/LvSession;->authTimestamp:J

    sub-long/2addr v2, v4

    const-wide/32 v4, 0x2932e00

    cmp-long v0, v2, v4

    if-lez v0, :cond_1

    .line 46
    invoke-virtual {p0}, Lcom/lvteam/LvSession;->invalidate()V

    .line 47
    return v1

    .line 49
    :cond_1
    iget v0, p0, Lcom/lvteam/LvSession;->authDays:I

    if-lez v0, :cond_2

    iget-wide v2, p0, Lcom/lvteam/LvSession;->activationTime:J

    const-wide/16 v4, 0x0

    cmp-long v0, v2, v4

    if-lez v0, :cond_2

    .line 50
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    iget-wide v4, p0, Lcom/lvteam/LvSession;->activationTime:J

    sub-long/2addr v2, v4

    .line 51
    .local v2, "elapsed":J
    iget v0, p0, Lcom/lvteam/LvSession;->authDays:I

    int-to-long v4, v0

    const-wide/16 v6, 0x18

    mul-long/2addr v4, v6

    const-wide/16 v6, 0x3c

    mul-long/2addr v4, v6

    mul-long/2addr v4, v6

    const-wide/16 v6, 0x3e8

    mul-long/2addr v4, v6

    cmp-long v0, v2, v4

    if-lez v0, :cond_2

    .line 52
    invoke-virtual {p0}, Lcom/lvteam/LvSession;->invalidate()V

    .line 53
    return v1

    .line 56
    .end local v2    # "elapsed":J
    :cond_2
    const/4 v0, 0x1

    return v0
.end method
