.class public final synthetic Lcom/lvteam/PacketCaptureService$TcpFlow$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/lvteam/PacketCaptureService$TcpFlow;


# direct methods
.method public synthetic constructor <init>(Lcom/lvteam/PacketCaptureService$TcpFlow;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/lvteam/PacketCaptureService$TcpFlow$$ExternalSyntheticLambda1;->f$0:Lcom/lvteam/PacketCaptureService$TcpFlow;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/lvteam/PacketCaptureService$TcpFlow$$ExternalSyntheticLambda1;->f$0:Lcom/lvteam/PacketCaptureService$TcpFlow;

    invoke-static {v0}, Lcom/lvteam/PacketCaptureService$TcpFlow;->$r8$lambda$4t-jINYqvDL3FQY8N1o0okRsSF8(Lcom/lvteam/PacketCaptureService$TcpFlow;)V

    return-void
.end method
