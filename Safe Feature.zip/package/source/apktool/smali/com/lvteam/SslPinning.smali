.class public abstract Lcom/lvteam/SslPinning;
.super Ljava/lang/Object;
.source "SslPinning.java"


# direct methods
.method public static isProxySet()Z
    .locals 4

    .line 31
    :try_start_0
    const-string v0, "http.proxyHost"

    invoke-static {v0}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 32
    .local v0, "host":Ljava/lang/String;
    const-string v1, "http.proxyPort"

    invoke-static {v1}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 33
    .local v1, "port":Ljava/lang/String;
    const/4 v2, 0x1

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_0

    return v2

    .line 36
    .end local v0    # "host":Ljava/lang/String;
    .end local v1    # "port":Ljava/lang/String;
    :catch_0
    move-exception v0

    goto :goto_0

    .line 34
    .restart local v0    # "host":Ljava/lang/String;
    .restart local v1    # "port":Ljava/lang/String;
    :cond_0
    const-string v3, "https.proxyHost"

    invoke-static {v3}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    move-object v0, v3

    .line 35
    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v3
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    if-nez v3, :cond_1

    return v2

    .line 36
    .end local v0    # "host":Ljava/lang/String;
    .end local v1    # "port":Ljava/lang/String;
    :cond_1
    :goto_0
    nop

    .line 37
    const/4 v0, 0x0

    return v0
.end method
