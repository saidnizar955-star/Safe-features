.class public final synthetic Lcom/lvteam/EspEngine$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/util/function/ToDoubleFunction;


# direct methods
.method public synthetic constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final applyAsDouble(Ljava/lang/Object;)D
    .locals 2

    .line 0
    check-cast p1, Lcom/lvteam/EspOverlayView$Entity;

    invoke-static {p1}, Lcom/lvteam/EspEngine;->$r8$lambda$alW9ZeXJdl64mycoNSS_jRLppKk(Lcom/lvteam/EspOverlayView$Entity;)D

    move-result-wide v0

    return-wide v0
.end method
