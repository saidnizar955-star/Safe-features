.class public Lcom/lvteam/OverlayService$2;
.super Ljava/lang/Object;
.source "OverlayService.java"

# interfaces
.implements Landroid/widget/SeekBar$OnSeekBarChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/lvteam/OverlayService;->addSliderRow(Landroid/widget/LinearLayout;Ljava/lang/String;Ljava/lang/String;IIILcom/lvteam/OverlayService$SliderCallback;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic this$0:Lcom/lvteam/OverlayService;

.field public final synthetic val$cb:Lcom/lvteam/OverlayService$SliderCallback;

.field public final synthetic val$min:I

.field public final synthetic val$suffix:Ljava/lang/String;

.field public final synthetic val$valueLabel:Landroid/widget/TextView;


# direct methods
.method public constructor <init>(Lcom/lvteam/OverlayService;ILandroid/widget/TextView;Ljava/lang/String;Lcom/lvteam/OverlayService$SliderCallback;)V
    .locals 0
    .param p1, "this$0"    # Lcom/lvteam/OverlayService;

    .line 804
    iput-object p1, p0, Lcom/lvteam/OverlayService$2;->this$0:Lcom/lvteam/OverlayService;

    iput p2, p0, Lcom/lvteam/OverlayService$2;->val$min:I

    iput-object p3, p0, Lcom/lvteam/OverlayService$2;->val$valueLabel:Landroid/widget/TextView;

    iput-object p4, p0, Lcom/lvteam/OverlayService$2;->val$suffix:Ljava/lang/String;

    iput-object p5, p0, Lcom/lvteam/OverlayService$2;->val$cb:Lcom/lvteam/OverlayService$SliderCallback;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onProgressChanged(Landroid/widget/SeekBar;IZ)V
    .locals 4
    .param p1, "sb"    # Landroid/widget/SeekBar;
    .param p2, "progress"    # I
    .param p3, "fromUser"    # Z

    .line 806
    iget v0, p0, Lcom/lvteam/OverlayService$2;->val$min:I

    add-int/2addr v0, p2

    .line 807
    .local v0, "val":I
    iget-object v1, p0, Lcom/lvteam/OverlayService$2;->val$valueLabel:Landroid/widget/TextView;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    iget-object v3, p0, Lcom/lvteam/OverlayService$2;->val$suffix:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 808
    iget-object v1, p0, Lcom/lvteam/OverlayService$2;->val$cb:Lcom/lvteam/OverlayService$SliderCallback;

    if-eqz v1, :cond_0

    iget-object v1, p0, Lcom/lvteam/OverlayService$2;->val$cb:Lcom/lvteam/OverlayService$SliderCallback;

    invoke-interface {v1, v0}, Lcom/lvteam/OverlayService$SliderCallback;->onChange(I)V

    .line 809
    :cond_0
    return-void
.end method

.method public onStartTrackingTouch(Landroid/widget/SeekBar;)V
    .locals 0
    .param p1, "sb"    # Landroid/widget/SeekBar;

    .line 810
    return-void
.end method

.method public onStopTrackingTouch(Landroid/widget/SeekBar;)V
    .locals 0
    .param p1, "sb"    # Landroid/widget/SeekBar;

    .line 811
    return-void
.end method
