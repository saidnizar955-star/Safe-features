.class public final Lcom/lvteam/PacketCaptureService;
.super Landroid/net/VpnService;
.source "PacketCaptureService.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/lvteam/PacketCaptureService$FlowKey;,
        Lcom/lvteam/PacketCaptureService$UdpFlow;,
        Lcom/lvteam/PacketCaptureService$HeldUdpPacket;,
        Lcom/lvteam/PacketCaptureService$TcpFlow;
    }
.end annotation


# static fields
.field public static final ACTION_ENABLE_FULL_IPV4_ROUTE:Ljava/lang/String; = "com.lvteam.action.ENABLE_FULL_IPV4_ROUTE"

.field private static final FULL_ROUTE_STARTUP_TIMEOUT_MS:J = 0x2710L

.field private static final MAX_PACKET_SIZE:I = 0xffff

.field private static final MAX_TCP_FLOWS:I = 0x80

.field private static final MAX_UDP_FLOWS:I = 0x80

.field private static final TAG:Ljava/lang/String; = "PacketCapture"

.field private static final TARGET_PACKAGE:Ljava/lang/String; = "com.dts.freefireth"

.field private static final TCP_CLOSING_TIMEOUT_MS:I = 0x2710

.field private static final TCP_CONNECT_TIMEOUT_MS:I = 0x2710

.field private static final TCP_IDLE_TIMEOUT_MS:I = 0x493e0

.field private static final TCP_PENDING_DATA_LIMIT:I = 0x40000

.field private static final TCP_SEGMENT_SIZE:I = 0x4b0

.field private static final TCP_WARNING_INTERVAL_MS:J = 0x7530L

.field private static final TP_MAX_HELD:I = 0x1388

.field private static final UDP_IDLE_TIMEOUT_MS:I = 0x7530

.field private static final VPN_MTU:I = 0x500


# instance fields
.field private final flowLock:Ljava/lang/Object;

.field private final flows:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Lcom/lvteam/PacketCaptureService$FlowKey;",
            "Lcom/lvteam/PacketCaptureService$UdpFlow;",
            ">;"
        }
    .end annotation
.end field

.field private final frameDecoder:Lcom/lvteam/RawFrameDecoder;

.field private fullRouteStartupPending:Z

.field private final heldUplinkPackets:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcom/lvteam/PacketCaptureService$HeldUdpPacket;",
            ">;"
        }
    .end annotation
.end field

.field private volatile inputRelayInitialized:Z

.field private lastTcpWarningAtMillis:J

.field private final outputLock:Ljava/lang/Object;

.field private volatile outputRelayInitialized:Z

.field private final packetIdentification:Ljava/util/concurrent/atomic/AtomicInteger;

.field private relayExecutor:Ljava/util/concurrent/ExecutorService;

.field private volatile relayReaderStarted:Z

.field private volatile relayRunning:Z

.field private final startupWatchdog:Ljava/util/concurrent/ScheduledExecutorService;

.field private startupWatchdogFuture:Ljava/util/concurrent/ScheduledFuture;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/ScheduledFuture<",
            "*>;"
        }
    .end annotation
.end field

.field private final tcpFlows:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Lcom/lvteam/PacketCaptureService$FlowKey;",
            "Lcom/lvteam/PacketCaptureService$TcpFlow;",
            ">;"
        }
    .end annotation
.end field

.field private final tcpWarningLock:Ljava/lang/Object;

.field private volatile tpReplayStarted:Z

.field private tunnel:Landroid/os/ParcelFileDescriptor;

.field private tunnelInput:Ljava/io/FileInputStream;

.field private tunnelOutput:Ljava/io/FileOutputStream;


# direct methods
.method public static synthetic $r8$lambda$22ZcykSK9DJLQn173viR22GNXTo(Lcom/lvteam/PacketCaptureService;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/lvteam/PacketCaptureService;->failFullRouteStartup()V

    return-void
.end method

.method public static synthetic $r8$lambda$HrnKpG2dgcejA_VppD3GfqPgr78(Lcom/lvteam/PacketCaptureService;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/lvteam/PacketCaptureService;->enableFullIpv4Route()V

    return-void
.end method

.method public static synthetic $r8$lambda$TVOEat4rXvq7N5QXSBw-WpMqDDM(Lcom/lvteam/PacketCaptureService;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/lvteam/PacketCaptureService;->readTunPackets()V

    return-void
.end method

.method public static synthetic $r8$lambda$s7mnC69PDBLVEpj5a3nPDzwkOeM(Lcom/lvteam/PacketCaptureService;Ljava/util/List;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/lvteam/PacketCaptureService;->lambda$startTpReplay$0(Ljava/util/List;)V

    return-void
.end method

.method public static bridge synthetic -$$Nest$fgetflowLock(Lcom/lvteam/PacketCaptureService;)Ljava/lang/Object;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/lvteam/PacketCaptureService;->flowLock:Ljava/lang/Object;

    return-object p0
.end method

.method public static bridge synthetic -$$Nest$fgetflows(Lcom/lvteam/PacketCaptureService;)Ljava/util/Map;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/lvteam/PacketCaptureService;->flows:Ljava/util/Map;

    return-object p0
.end method

.method public static bridge synthetic -$$Nest$fgetframeDecoder(Lcom/lvteam/PacketCaptureService;)Lcom/lvteam/RawFrameDecoder;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/lvteam/PacketCaptureService;->frameDecoder:Lcom/lvteam/RawFrameDecoder;

    return-object p0
.end method

.method public static bridge synthetic -$$Nest$fgetoutputLock(Lcom/lvteam/PacketCaptureService;)Ljava/lang/Object;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/lvteam/PacketCaptureService;->outputLock:Ljava/lang/Object;

    return-object p0
.end method

.method public static bridge synthetic -$$Nest$fgetpacketIdentification(Lcom/lvteam/PacketCaptureService;)Ljava/util/concurrent/atomic/AtomicInteger;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/lvteam/PacketCaptureService;->packetIdentification:Ljava/util/concurrent/atomic/AtomicInteger;

    return-object p0
.end method

.method public static bridge synthetic -$$Nest$fgetrelayRunning(Lcom/lvteam/PacketCaptureService;)Z
    .locals 0

    .line 0
    iget-boolean p0, p0, Lcom/lvteam/PacketCaptureService;->relayRunning:Z

    return p0
.end method

.method public static bridge synthetic -$$Nest$fgetstartupWatchdog(Lcom/lvteam/PacketCaptureService;)Ljava/util/concurrent/ScheduledExecutorService;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/lvteam/PacketCaptureService;->startupWatchdog:Ljava/util/concurrent/ScheduledExecutorService;

    return-object p0
.end method

.method public static bridge synthetic -$$Nest$fgettcpFlows(Lcom/lvteam/PacketCaptureService;)Ljava/util/Map;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/lvteam/PacketCaptureService;->tcpFlows:Ljava/util/Map;

    return-object p0
.end method

.method public static bridge synthetic -$$Nest$fgettunnelOutput(Lcom/lvteam/PacketCaptureService;)Ljava/io/FileOutputStream;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/lvteam/PacketCaptureService;->tunnelOutput:Ljava/io/FileOutputStream;

    return-object p0
.end method

.method public static bridge synthetic -$$Nest$smcloseQuietly(Ljava/io/Closeable;)V
    .locals 0

    .line 0
    invoke-static {p0}, Lcom/lvteam/PacketCaptureService;->closeQuietly(Ljava/io/Closeable;)V

    return-void
.end method

.method public static bridge synthetic -$$Nest$smincrement(JI)J
    .locals 0

    .line 0
    invoke-static {p0, p1, p2}, Lcom/lvteam/PacketCaptureService;->increment(JI)J

    move-result-wide p0

    return-wide p0
.end method

.method public static bridge synthetic -$$Nest$smisAfter(JJ)Z
    .locals 0

    .line 0
    invoke-static {p0, p1, p2, p3}, Lcom/lvteam/PacketCaptureService;->isAfter(JJ)Z

    move-result p0

    return p0
.end method

.method public constructor <init>()V
    .locals 2

    .line 35
    invoke-direct {p0}, Landroid/net/VpnService;-><init>()V

    .line 56
    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadScheduledExecutor()Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object v0

    iput-object v0, p0, Lcom/lvteam/PacketCaptureService;->startupWatchdog:Ljava/util/concurrent/ScheduledExecutorService;

    .line 58
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lcom/lvteam/PacketCaptureService;->flowLock:Ljava/lang/Object;

    .line 59
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lcom/lvteam/PacketCaptureService;->outputLock:Ljava/lang/Object;

    .line 60
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lcom/lvteam/PacketCaptureService;->tcpWarningLock:Ljava/lang/Object;

    .line 61
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lcom/lvteam/PacketCaptureService;->flows:Ljava/util/Map;

    .line 62
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lcom/lvteam/PacketCaptureService;->tcpFlows:Ljava/util/Map;

    .line 63
    new-instance v0, Lcom/lvteam/RawFrameDecoder;

    invoke-static {}, Lcom/lvteam/EntityState;->shared()Lcom/lvteam/EntityState;

    move-result-object v1

    invoke-direct {v0, v1}, Lcom/lvteam/RawFrameDecoder;-><init>(Lcom/lvteam/EntityState;)V

    iput-object v0, p0, Lcom/lvteam/PacketCaptureService;->frameDecoder:Lcom/lvteam/RawFrameDecoder;

    .line 64
    new-instance v0, Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    iput-object v0, p0, Lcom/lvteam/PacketCaptureService;->packetIdentification:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 71
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/lvteam/PacketCaptureService;->heldUplinkPackets:Ljava/util/ArrayList;

    return-void
.end method

.method private areGenericRelaysInitialized()Z
    .locals 1

    .line 452
    iget-boolean v0, p0, Lcom/lvteam/PacketCaptureService;->relayRunning:Z

    if-eqz v0, :cond_0

    iget-boolean v0, p0, Lcom/lvteam/PacketCaptureService;->inputRelayInitialized:Z

    if-eqz v0, :cond_0

    iget-boolean v0, p0, Lcom/lvteam/PacketCaptureService;->outputRelayInitialized:Z

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method private static closeQuietly(Ljava/io/Closeable;)V
    .locals 1
    .param p0, "closeable"    # Ljava/io/Closeable;

    .line 470
    if-nez p0, :cond_0

    return-void

    .line 472
    :cond_0
    :try_start_0
    invoke-interface {p0}, Ljava/io/Closeable;->close()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 474
    goto :goto_0

    .line 473
    :catch_0
    move-exception v0

    .line 475
    :goto_0
    return-void
.end method

.method private declared-synchronized closeTunnel()V
    .locals 4

    monitor-enter p0

    .line 418
    const/4 v0, 0x0

    :try_start_0
    iput-boolean v0, p0, Lcom/lvteam/PacketCaptureService;->fullRouteStartupPending:Z

    .line 419
    iget-object v1, p0, Lcom/lvteam/PacketCaptureService;->startupWatchdogFuture:Ljava/util/concurrent/ScheduledFuture;

    const/4 v2, 0x0

    if-eqz v1, :cond_0

    .line 420
    iget-object v1, p0, Lcom/lvteam/PacketCaptureService;->startupWatchdogFuture:Ljava/util/concurrent/ScheduledFuture;

    invoke-interface {v1, v0}, Ljava/util/concurrent/Future;->cancel(Z)Z

    .line 421
    iput-object v2, p0, Lcom/lvteam/PacketCaptureService;->startupWatchdogFuture:Ljava/util/concurrent/ScheduledFuture;

    goto :goto_0

    .line 417
    .end local p0    # "this":Lcom/lvteam/PacketCaptureService;
    :catchall_0
    move-exception v0

    goto/16 :goto_5

    .line 423
    :cond_0
    :goto_0
    iput-boolean v0, p0, Lcom/lvteam/PacketCaptureService;->relayRunning:Z

    .line 424
    iput-boolean v0, p0, Lcom/lvteam/PacketCaptureService;->inputRelayInitialized:Z

    .line 425
    iput-boolean v0, p0, Lcom/lvteam/PacketCaptureService;->outputRelayInitialized:Z

    .line 426
    iput-boolean v0, p0, Lcom/lvteam/PacketCaptureService;->relayReaderStarted:Z

    .line 427
    iget-object v0, p0, Lcom/lvteam/PacketCaptureService;->flowLock:Ljava/lang/Object;

    monitor-enter v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 428
    :try_start_1
    iget-object v1, p0, Lcom/lvteam/PacketCaptureService;->flows:Ljava/util/Map;

    invoke-interface {v1}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/lvteam/PacketCaptureService$UdpFlow;

    .local v3, "flow":Lcom/lvteam/PacketCaptureService$UdpFlow;
    invoke-virtual {v3}, Lcom/lvteam/PacketCaptureService$UdpFlow;->close()V

    .end local v3    # "flow":Lcom/lvteam/PacketCaptureService$UdpFlow;
    goto :goto_1

    .line 432
    :catchall_1
    move-exception v1

    goto :goto_4

    .line 429
    :cond_1
    iget-object v1, p0, Lcom/lvteam/PacketCaptureService;->flows:Ljava/util/Map;

    invoke-interface {v1}, Ljava/util/Map;->clear()V

    .line 430
    iget-object v1, p0, Lcom/lvteam/PacketCaptureService;->tcpFlows:Ljava/util/Map;

    invoke-interface {v1}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_2
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_2

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/lvteam/PacketCaptureService$TcpFlow;

    .local v3, "flow":Lcom/lvteam/PacketCaptureService$TcpFlow;
    invoke-virtual {v3}, Lcom/lvteam/PacketCaptureService$TcpFlow;->close()V

    .end local v3    # "flow":Lcom/lvteam/PacketCaptureService$TcpFlow;
    goto :goto_2

    .line 431
    :cond_2
    iget-object v1, p0, Lcom/lvteam/PacketCaptureService;->tcpFlows:Ljava/util/Map;

    invoke-interface {v1}, Ljava/util/Map;->clear()V

    .line 432
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 433
    :try_start_2
    iget-object v0, p0, Lcom/lvteam/PacketCaptureService;->relayExecutor:Ljava/util/concurrent/ExecutorService;

    if-eqz v0, :cond_3

    .line 434
    iget-object v0, p0, Lcom/lvteam/PacketCaptureService;->relayExecutor:Ljava/util/concurrent/ExecutorService;

    invoke-interface {v0}, Ljava/util/concurrent/ExecutorService;->shutdownNow()Ljava/util/List;

    .line 435
    iput-object v2, p0, Lcom/lvteam/PacketCaptureService;->relayExecutor:Ljava/util/concurrent/ExecutorService;

    .line 437
    :cond_3
    iget-object v0, p0, Lcom/lvteam/PacketCaptureService;->tunnelInput:Ljava/io/FileInputStream;

    invoke-static {v0}, Lcom/lvteam/PacketCaptureService;->closeQuietly(Ljava/io/Closeable;)V

    .line 438
    iput-object v2, p0, Lcom/lvteam/PacketCaptureService;->tunnelInput:Ljava/io/FileInputStream;

    .line 439
    iget-object v0, p0, Lcom/lvteam/PacketCaptureService;->outputLock:Ljava/lang/Object;

    monitor-enter v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 440
    :try_start_3
    iget-object v1, p0, Lcom/lvteam/PacketCaptureService;->tunnelOutput:Ljava/io/FileOutputStream;

    invoke-static {v1}, Lcom/lvteam/PacketCaptureService;->closeQuietly(Ljava/io/Closeable;)V

    .line 441
    iput-object v2, p0, Lcom/lvteam/PacketCaptureService;->tunnelOutput:Ljava/io/FileOutputStream;

    .line 442
    monitor-exit v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    .line 443
    :try_start_4
    iget-object v0, p0, Lcom/lvteam/PacketCaptureService;->tunnel:Landroid/os/ParcelFileDescriptor;
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    if-nez v0, :cond_4

    monitor-exit p0

    return-void

    .line 445
    :cond_4
    :try_start_5
    iget-object v0, p0, Lcom/lvteam/PacketCaptureService;->tunnel:Landroid/os/ParcelFileDescriptor;

    invoke-virtual {v0}, Landroid/os/ParcelFileDescriptor;->close()V
    :try_end_5
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_5} :catch_0
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    .line 447
    goto :goto_3

    .line 446
    :catch_0
    move-exception v0

    .line 448
    :goto_3
    :try_start_6
    iput-object v2, p0, Lcom/lvteam/PacketCaptureService;->tunnel:Landroid/os/ParcelFileDescriptor;
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    .line 449
    monitor-exit p0

    return-void

    .line 442
    :catchall_2
    move-exception v1

    :try_start_7
    monitor-exit v0
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_2

    :try_start_8
    throw v1
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_0

    .line 432
    :goto_4
    :try_start_9
    monitor-exit v0
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_1

    :try_start_a
    throw v1

    .line 417
    :goto_5
    monitor-exit p0
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_0

    throw v0
.end method

.method private declared-synchronized completeFullRouteStartup()V
    .locals 2

    monitor-enter p0

    .line 456
    const/4 v0, 0x0

    :try_start_0
    iput-boolean v0, p0, Lcom/lvteam/PacketCaptureService;->fullRouteStartupPending:Z

    .line 457
    iget-object v1, p0, Lcom/lvteam/PacketCaptureService;->startupWatchdogFuture:Ljava/util/concurrent/ScheduledFuture;

    if-eqz v1, :cond_0

    .line 458
    iget-object v1, p0, Lcom/lvteam/PacketCaptureService;->startupWatchdogFuture:Ljava/util/concurrent/ScheduledFuture;

    invoke-interface {v1, v0}, Ljava/util/concurrent/Future;->cancel(Z)Z

    .line 459
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/lvteam/PacketCaptureService;->startupWatchdogFuture:Ljava/util/concurrent/ScheduledFuture;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 455
    .end local p0    # "this":Lcom/lvteam/PacketCaptureService;
    :catchall_0
    move-exception v0

    goto :goto_1

    .line 461
    :cond_0
    :goto_0
    monitor-exit p0

    return-void

    .line 455
    :goto_1
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method

.method private enableFullIpv4Route()V
    .locals 6

    .line 131
    invoke-direct {p0}, Lcom/lvteam/PacketCaptureService;->areGenericRelaysInitialized()Z

    move-result v0

    if-nez v0, :cond_1

    .line 133
    iget-object v0, p0, Lcom/lvteam/PacketCaptureService;->tunnel:Landroid/os/ParcelFileDescriptor;

    if-nez v0, :cond_0

    invoke-direct {p0}, Lcom/lvteam/PacketCaptureService;->establishRouteFreeVpn()V

    .line 134
    :cond_0
    invoke-direct {p0}, Lcom/lvteam/PacketCaptureService;->areGenericRelaysInitialized()Z

    move-result v0

    if-nez v0, :cond_1

    .line 135
    const-string v0, "PacketCapture"

    const-string v1, "Full-route startup waiting for generic relays"

    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 136
    iget-object v0, p0, Lcom/lvteam/PacketCaptureService;->startupWatchdog:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v1, Lcom/lvteam/PacketCaptureService$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0}, Lcom/lvteam/PacketCaptureService$$ExternalSyntheticLambda0;-><init>(Lcom/lvteam/PacketCaptureService;)V

    const-wide/16 v2, 0x96

    sget-object v4, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-interface {v0, v1, v2, v3, v4}, Ljava/util/concurrent/ScheduledExecutorService;->schedule(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;

    .line 137
    return-void

    .line 141
    :cond_1
    invoke-direct {p0}, Lcom/lvteam/PacketCaptureService;->closeTunnel()V

    .line 144
    :try_start_0
    new-instance v0, Landroid/net/VpnService$Builder;

    invoke-direct {v0, p0}, Landroid/net/VpnService$Builder;-><init>(Landroid/net/VpnService;)V

    const-string v1, "LV Team full IPv4 routing test"

    .line 145
    invoke-virtual {v0, v1}, Landroid/net/VpnService$Builder;->setSession(Ljava/lang/String;)Landroid/net/VpnService$Builder;

    move-result-object v0

    const-string v1, "10.17.0.2"

    .line 146
    const/16 v2, 0x20

    invoke-virtual {v0, v1, v2}, Landroid/net/VpnService$Builder;->addAddress(Ljava/lang/String;I)Landroid/net/VpnService$Builder;

    move-result-object v0

    .line 147
    const/16 v1, 0x500

    invoke-virtual {v0, v1}, Landroid/net/VpnService$Builder;->setMtu(I)Landroid/net/VpnService$Builder;

    move-result-object v0

    const-string v1, "0.0.0.0"

    .line 148
    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/net/VpnService$Builder;->addRoute(Ljava/lang/String;I)Landroid/net/VpnService$Builder;

    move-result-object v0

    sget v1, Landroid/system/OsConstants;->AF_INET6:I

    .line 150
    invoke-virtual {v0, v1}, Landroid/net/VpnService$Builder;->allowFamily(I)Landroid/net/VpnService$Builder;

    move-result-object v0

    const-string v1, "com.dts.freefireth"

    .line 152
    invoke-virtual {v0, v1}, Landroid/net/VpnService$Builder;->addAllowedApplication(Ljava/lang/String;)Landroid/net/VpnService$Builder;

    move-result-object v0

    .line 153
    invoke-virtual {v0}, Landroid/net/VpnService$Builder;->establish()Landroid/os/ParcelFileDescriptor;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    .line 158
    .local v0, "fullRouteTunnel":Landroid/os/ParcelFileDescriptor;
    nop

    .line 159
    if-nez v0, :cond_2

    .line 160
    const-string v1, "PacketCapture"

    const-string v2, "Full-route VPN establishment failed"

    invoke-static {v1, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 161
    invoke-direct {p0}, Lcom/lvteam/PacketCaptureService;->closeTunnel()V

    .line 162
    return-void

    .line 165
    :cond_2
    iput-object v0, p0, Lcom/lvteam/PacketCaptureService;->tunnel:Landroid/os/ParcelFileDescriptor;

    .line 166
    invoke-direct {p0}, Lcom/lvteam/PacketCaptureService;->startRelay()Z

    move-result v1

    if-nez v1, :cond_3

    .line 167
    const-string v1, "PacketCapture"

    const-string v2, "Full-route relay initialization failed"

    invoke-static {v1, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 168
    invoke-direct {p0}, Lcom/lvteam/PacketCaptureService;->closeTunnel()V

    .line 169
    return-void

    .line 172
    :cond_3
    monitor-enter p0

    .line 173
    const/4 v1, 0x1

    :try_start_1
    iput-boolean v1, p0, Lcom/lvteam/PacketCaptureService;->fullRouteStartupPending:Z

    .line 174
    iget-object v1, p0, Lcom/lvteam/PacketCaptureService;->startupWatchdog:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v2, Lcom/lvteam/PacketCaptureService$$ExternalSyntheticLambda1;

    invoke-direct {v2, p0}, Lcom/lvteam/PacketCaptureService$$ExternalSyntheticLambda1;-><init>(Lcom/lvteam/PacketCaptureService;)V

    sget-object v3, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v4, 0x2710

    invoke-interface {v1, v2, v4, v5, v3}, Ljava/util/concurrent/ScheduledExecutorService;->schedule(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;

    move-result-object v1

    iput-object v1, p0, Lcom/lvteam/PacketCaptureService;->startupWatchdogFuture:Ljava/util/concurrent/ScheduledFuture;

    .line 176
    iget-boolean v1, p0, Lcom/lvteam/PacketCaptureService;->relayReaderStarted:Z

    if-eqz v1, :cond_4

    invoke-direct {p0}, Lcom/lvteam/PacketCaptureService;->completeFullRouteStartup()V

    goto :goto_0

    .line 177
    :catchall_0
    move-exception v1

    goto :goto_1

    :cond_4
    :goto_0
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 178
    const-string v1, "PacketCapture"

    const-string v2, "Full IPv4 routing test started"

    invoke-static {v1, v2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 179
    return-void

    .line 177
    :goto_1
    :try_start_2
    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw v1

    .line 154
    .end local v0    # "fullRouteTunnel":Landroid/os/ParcelFileDescriptor;
    :catch_0
    move-exception v0

    goto :goto_2

    :catch_1
    move-exception v0

    .line 155
    .local v0, "e":Ljava/lang/Exception;
    :goto_2
    const-string v1, "PacketCapture"

    const-string v2, "Full-route VPN establishment failed"

    invoke-static {v1, v2, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 156
    invoke-direct {p0}, Lcom/lvteam/PacketCaptureService;->closeTunnel()V

    .line 157
    return-void
.end method

.method private establishRouteFreeVpn()V
    .locals 3

    .line 122
    new-instance v0, Landroid/net/VpnService$Builder;

    invoke-direct {v0, p0}, Landroid/net/VpnService$Builder;-><init>(Landroid/net/VpnService;)V

    .line 123
    const-string v1, "LV Team capture"

    invoke-virtual {v0, v1}, Landroid/net/VpnService$Builder;->setSession(Ljava/lang/String;)Landroid/net/VpnService$Builder;

    move-result-object v0

    .line 124
    const-string v1, "10.17.0.2"

    const/16 v2, 0x20

    invoke-virtual {v0, v1, v2}, Landroid/net/VpnService$Builder;->addAddress(Ljava/lang/String;I)Landroid/net/VpnService$Builder;

    move-result-object v0

    .line 125
    invoke-virtual {v0}, Landroid/net/VpnService$Builder;->establish()Landroid/os/ParcelFileDescriptor;

    move-result-object v0

    iput-object v0, p0, Lcom/lvteam/PacketCaptureService;->tunnel:Landroid/os/ParcelFileDescriptor;

    .line 126
    iget-object v0, p0, Lcom/lvteam/PacketCaptureService;->tunnel:Landroid/os/ParcelFileDescriptor;

    if-nez v0, :cond_0

    const-string v0, "VPN establishment failed"

    goto :goto_0

    :cond_0
    const-string v0, "VPN interface established"

    :goto_0
    const-string v1, "PacketCapture"

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 127
    iget-object v0, p0, Lcom/lvteam/PacketCaptureService;->tunnel:Landroid/os/ParcelFileDescriptor;

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/lvteam/PacketCaptureService;->startRelay()Z

    move-result v0

    if-nez v0, :cond_1

    invoke-direct {p0}, Lcom/lvteam/PacketCaptureService;->closeTunnel()V

    .line 128
    :cond_1
    return-void
.end method

.method private evictOldestTcpFlowLocked()Z
    .locals 7

    .line 396
    const/4 v0, 0x0

    .line 397
    .local v0, "oldest":Lcom/lvteam/PacketCaptureService$TcpFlow;
    iget-object v1, p0, Lcom/lvteam/PacketCaptureService;->tcpFlows:Ljava/util/Map;

    invoke-interface {v1}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/lvteam/PacketCaptureService$TcpFlow;

    .line 398
    .local v2, "flow":Lcom/lvteam/PacketCaptureService$TcpFlow;
    if-eqz v0, :cond_0

    invoke-static {v2}, Lcom/lvteam/PacketCaptureService$TcpFlow;->-$$Nest$fgetlastActivityMillis(Lcom/lvteam/PacketCaptureService$TcpFlow;)J

    move-result-wide v3

    invoke-static {v0}, Lcom/lvteam/PacketCaptureService$TcpFlow;->-$$Nest$fgetlastActivityMillis(Lcom/lvteam/PacketCaptureService$TcpFlow;)J

    move-result-wide v5

    cmp-long v3, v3, v5

    if-gez v3, :cond_1

    :cond_0
    move-object v0, v2

    .line 399
    .end local v2    # "flow":Lcom/lvteam/PacketCaptureService$TcpFlow;
    :cond_1
    goto :goto_0

    .line 400
    :cond_2
    if-nez v0, :cond_3

    const/4 v1, 0x0

    return v1

    .line 401
    :cond_3
    invoke-virtual {v0}, Lcom/lvteam/PacketCaptureService$TcpFlow;->resetAndClose()V

    .line 402
    iget-object v1, p0, Lcom/lvteam/PacketCaptureService;->tcpFlows:Ljava/util/Map;

    invoke-static {v0}, Lcom/lvteam/PacketCaptureService$TcpFlow;->-$$Nest$fgetkey(Lcom/lvteam/PacketCaptureService$TcpFlow;)Lcom/lvteam/PacketCaptureService$FlowKey;

    move-result-object v2

    invoke-interface {v1, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    if-ne v1, v0, :cond_4

    iget-object v1, p0, Lcom/lvteam/PacketCaptureService;->tcpFlows:Ljava/util/Map;

    invoke-static {v0}, Lcom/lvteam/PacketCaptureService$TcpFlow;->-$$Nest$fgetkey(Lcom/lvteam/PacketCaptureService$TcpFlow;)Lcom/lvteam/PacketCaptureService$FlowKey;

    move-result-object v2

    invoke-interface {v1, v2}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 403
    :cond_4
    const-string v1, "TCP flow limit reached; evicted oldest TCP flow"

    const/4 v2, 0x0

    invoke-direct {p0, v1, v2}, Lcom/lvteam/PacketCaptureService;->warnTcp(Ljava/lang/String;Ljava/lang/Exception;)V

    .line 404
    const/4 v1, 0x1

    return v1
.end method

.method private evictTcpFlowsLocked()V
    .locals 5

    .line 372
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    .line 373
    .local v0, "now":J
    iget-object v2, p0, Lcom/lvteam/PacketCaptureService;->tcpFlows:Ljava/util/Map;

    invoke-interface {v2}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    .line 374
    .local v2, "iterator":Ljava/util/Iterator;, "Ljava/util/Iterator<Ljava/util/Map$Entry<Lcom/lvteam/PacketCaptureService$FlowKey;Lcom/lvteam/PacketCaptureService$TcpFlow;>;>;"
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1

    .line 375
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/util/Map$Entry;

    invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/lvteam/PacketCaptureService$TcpFlow;

    .line 376
    .local v3, "flow":Lcom/lvteam/PacketCaptureService$TcpFlow;
    invoke-virtual {v3, v0, v1}, Lcom/lvteam/PacketCaptureService$TcpFlow;->isIdle(J)Z

    move-result v4

    if-eqz v4, :cond_0

    .line 377
    invoke-virtual {v3}, Lcom/lvteam/PacketCaptureService$TcpFlow;->resetAndClose()V

    .line 378
    invoke-interface {v2}, Ljava/util/Iterator;->remove()V

    .line 380
    .end local v3    # "flow":Lcom/lvteam/PacketCaptureService$TcpFlow;
    :cond_0
    goto :goto_0

    .line 381
    :cond_1
    return-void
.end method

.method private evictUdpFlowsLocked()V
    .locals 5

    .line 384
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    .line 385
    .local v0, "now":J
    iget-object v2, p0, Lcom/lvteam/PacketCaptureService;->flows:Ljava/util/Map;

    invoke-interface {v2}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    .line 386
    .local v2, "iterator":Ljava/util/Iterator;, "Ljava/util/Iterator<Ljava/util/Map$Entry<Lcom/lvteam/PacketCaptureService$FlowKey;Lcom/lvteam/PacketCaptureService$UdpFlow;>;>;"
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1

    .line 387
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/util/Map$Entry;

    invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/lvteam/PacketCaptureService$UdpFlow;

    .line 388
    .local v3, "flow":Lcom/lvteam/PacketCaptureService$UdpFlow;
    invoke-virtual {v3, v0, v1}, Lcom/lvteam/PacketCaptureService$UdpFlow;->isIdle(J)Z

    move-result v4

    if-eqz v4, :cond_0

    .line 389
    invoke-virtual {v3}, Lcom/lvteam/PacketCaptureService$UdpFlow;->close()V

    .line 390
    invoke-interface {v2}, Ljava/util/Iterator;->remove()V

    .line 392
    .end local v3    # "flow":Lcom/lvteam/PacketCaptureService$UdpFlow;
    :cond_0
    goto :goto_0

    .line 393
    :cond_1
    return-void
.end method

.method private declared-synchronized failFullRouteStartup()V
    .locals 2

    monitor-enter p0

    .line 464
    :try_start_0
    iget-boolean v0, p0, Lcom/lvteam/PacketCaptureService;->fullRouteStartupPending:Z

    if-eqz v0, :cond_1

    iget-boolean v0, p0, Lcom/lvteam/PacketCaptureService;->relayReaderStarted:Z

    if-nez v0, :cond_1

    invoke-direct {p0}, Lcom/lvteam/PacketCaptureService;->areGenericRelaysInitialized()Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    .line 465
    :cond_0
    const-string v0, "PacketCapture"

    const-string v1, "Full-route startup timed out; tearing down VPN"

    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 466
    invoke-direct {p0}, Lcom/lvteam/PacketCaptureService;->closeTunnel()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 467
    monitor-exit p0

    return-void

    .line 463
    .end local p0    # "this":Lcom/lvteam/PacketCaptureService;
    :catchall_0
    move-exception v0

    goto :goto_1

    .line 464
    :cond_1
    :goto_0
    monitor-exit p0

    return-void

    .line 463
    :goto_1
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method

.method private forward(Lcom/lvteam/Ipv4TcpPacket;)V
    .locals 12
    .param p1, "packet"    # Lcom/lvteam/Ipv4TcpPacket;

    .line 323
    new-instance v0, Lcom/lvteam/PacketCaptureService$FlowKey;

    iget-object v1, p1, Lcom/lvteam/Ipv4TcpPacket;->sourceAddress:Ljava/net/InetAddress;

    iget v2, p1, Lcom/lvteam/Ipv4TcpPacket;->sourcePort:I

    iget-object v3, p1, Lcom/lvteam/Ipv4TcpPacket;->destinationAddress:Ljava/net/InetAddress;

    iget v4, p1, Lcom/lvteam/Ipv4TcpPacket;->destinationPort:I

    invoke-direct {v0, v1, v2, v3, v4}, Lcom/lvteam/PacketCaptureService$FlowKey;-><init>(Ljava/net/InetAddress;ILjava/net/InetAddress;I)V

    .line 325
    .local v0, "key":Lcom/lvteam/PacketCaptureService$FlowKey;
    const/4 v1, 0x0

    .line 326
    .local v1, "flow":Lcom/lvteam/PacketCaptureService$TcpFlow;
    const/4 v2, 0x0

    .line 327
    .local v2, "created":Z
    iget-object v3, p0, Lcom/lvteam/PacketCaptureService;->flowLock:Ljava/lang/Object;

    monitor-enter v3

    .line 328
    :try_start_0
    iget-object v4, p0, Lcom/lvteam/PacketCaptureService;->tcpFlows:Ljava/util/Map;

    invoke-interface {v4, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/lvteam/PacketCaptureService$TcpFlow;

    move-object v1, v4

    .line 329
    if-eqz v1, :cond_0

    invoke-virtual {v1}, Lcom/lvteam/PacketCaptureService$TcpFlow;->isClosed()Z

    move-result v4

    if-eqz v4, :cond_0

    .line 330
    iget-object v4, p0, Lcom/lvteam/PacketCaptureService;->tcpFlows:Ljava/util/Map;

    invoke-interface {v4, v0}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 331
    const/4 v1, 0x0

    goto :goto_0

    .line 366
    :catchall_0
    move-exception v4

    goto/16 :goto_6

    .line 333
    :cond_0
    :goto_0
    if-nez v1, :cond_8

    .line 334
    iget v4, p1, Lcom/lvteam/Ipv4TcpPacket;->flags:I

    and-int/lit8 v4, v4, 0x12

    const/4 v5, 0x2

    if-eq v4, v5, :cond_1

    .line 335
    monitor-exit v3

    return-void

    .line 336
    :cond_1
    invoke-direct {p0}, Lcom/lvteam/PacketCaptureService;->evictTcpFlowsLocked()V

    .line 337
    invoke-direct {p0}, Lcom/lvteam/PacketCaptureService;->evictUdpFlowsLocked()V

    .line 338
    iget-boolean v4, p0, Lcom/lvteam/PacketCaptureService;->relayRunning:Z

    if-eqz v4, :cond_2

    iget-object v4, p0, Lcom/lvteam/PacketCaptureService;->relayExecutor:Ljava/util/concurrent/ExecutorService;

    if-nez v4, :cond_3

    :cond_2
    goto/16 :goto_4

    .line 339
    :cond_3
    iget-object v4, p0, Lcom/lvteam/PacketCaptureService;->tcpFlows:Ljava/util/Map;

    invoke-interface {v4}, Ljava/util/Map;->size()I

    move-result v4

    const/16 v5, 0x80

    const/4 v6, 0x0

    if-lt v4, v5, :cond_4

    .line 340
    invoke-direct {p0}, Lcom/lvteam/PacketCaptureService;->evictOldestTcpFlowLocked()Z

    move-result v4

    if-nez v4, :cond_4

    .line 341
    const-string v4, "TCP flow limit reached"

    invoke-direct {p0, v4, v6}, Lcom/lvteam/PacketCaptureService;->warnTcp(Ljava/lang/String;Ljava/lang/Exception;)V

    .line 342
    monitor-exit v3

    return-void

    .line 345
    :cond_4
    iget-object v4, p0, Lcom/lvteam/PacketCaptureService;->tcpFlows:Ljava/util/Map;

    invoke-interface {v4}, Ljava/util/Map;->size()I

    move-result v4

    if-lt v4, v5, :cond_5

    .line 346
    const-string v4, "TCP flow limit reached"

    invoke-direct {p0, v4, v6}, Lcom/lvteam/PacketCaptureService;->warnTcp(Ljava/lang/String;Ljava/lang/Exception;)V

    .line 347
    monitor-exit v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-void

    .line 349
    :cond_5
    const/4 v4, 0x0

    .line 351
    .local v4, "socket":Ljava/net/Socket;
    :try_start_1
    new-instance v5, Ljava/net/Socket;

    invoke-direct {v5}, Ljava/net/Socket;-><init>()V

    move-object v4, v5

    .line 352
    invoke-virtual {p0, v4}, Landroid/net/VpnService;->protect(Ljava/net/Socket;)Z

    move-result v5

    if-nez v5, :cond_6

    const-string v5, "TCP socket uses app VPN exclusion fallback"

    invoke-direct {p0, v5, v6}, Lcom/lvteam/PacketCaptureService;->warnTcp(Ljava/lang/String;Ljava/lang/Exception;)V

    goto :goto_1

    .line 359
    :catch_0
    move-exception v5

    goto :goto_2

    .line 353
    :cond_6
    :goto_1
    new-instance v11, Lcom/lvteam/PacketCaptureService$TcpFlow;

    iget-wide v9, p1, Lcom/lvteam/Ipv4TcpPacket;->sequenceNumber:J

    move-object v5, v11

    move-object v6, p0

    move-object v7, v0

    move-object v8, v4

    invoke-direct/range {v5 .. v10}, Lcom/lvteam/PacketCaptureService$TcpFlow;-><init>(Lcom/lvteam/PacketCaptureService;Lcom/lvteam/PacketCaptureService$FlowKey;Ljava/net/Socket;J)V

    move-object v1, v11

    .line 354
    iget-object v5, p0, Lcom/lvteam/PacketCaptureService;->tcpFlows:Ljava/util/Map;

    invoke-interface {v5, v0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 356
    invoke-static {v1}, Lcom/lvteam/PacketCaptureService$TcpFlow;->-$$Nest$memitSynAck(Lcom/lvteam/PacketCaptureService$TcpFlow;)V

    .line 357
    iget-object v5, p0, Lcom/lvteam/PacketCaptureService;->relayExecutor:Ljava/util/concurrent/ExecutorService;

    invoke-interface {v5, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 358
    const/4 v2, 0x1

    .line 364
    goto :goto_5

    .line 359
    :goto_2
    nop

    .line 360
    .local v5, "e":Ljava/lang/RuntimeException;
    if-eqz v1, :cond_7

    :try_start_2
    invoke-static {v1}, Lcom/lvteam/PacketCaptureService$TcpFlow;->-$$Nest$mremoveAndClose(Lcom/lvteam/PacketCaptureService$TcpFlow;)V

    goto :goto_3

    .line 361
    :cond_7
    invoke-static {v4}, Lcom/lvteam/PacketCaptureService;->closeQuietly(Ljava/io/Closeable;)V

    .line 362
    :goto_3
    const-string v6, "Could not create TCP flow"

    invoke-direct {p0, v6, v5}, Lcom/lvteam/PacketCaptureService;->warnTcp(Ljava/lang/String;Ljava/lang/Exception;)V

    .line 363
    monitor-exit v3

    return-void

    .line 338
    .end local v4    # "socket":Ljava/net/Socket;
    .end local v5    # "e":Ljava/lang/RuntimeException;
    :goto_4
    monitor-exit v3

    return-void

    .line 366
    :cond_8
    :goto_5
    monitor-exit v3
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 367
    if-eqz v2, :cond_9

    return-void

    .line 368
    :cond_9
    invoke-virtual {v1, p1}, Lcom/lvteam/PacketCaptureService$TcpFlow;->handle(Lcom/lvteam/Ipv4TcpPacket;)V

    .line 369
    return-void

    .line 366
    :goto_6
    :try_start_3
    monitor-exit v3
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    throw v4
.end method

.method private forward(Lcom/lvteam/Ipv4UdpPacket;)V
    .locals 8
    .param p1, "packet"    # Lcom/lvteam/Ipv4UdpPacket;

    .line 229
    new-instance v0, Lcom/lvteam/PacketCaptureService$FlowKey;

    iget-object v1, p1, Lcom/lvteam/Ipv4UdpPacket;->sourceAddress:Ljava/net/InetAddress;

    iget v2, p1, Lcom/lvteam/Ipv4UdpPacket;->sourcePort:I

    iget-object v3, p1, Lcom/lvteam/Ipv4UdpPacket;->destinationAddress:Ljava/net/InetAddress;

    iget v4, p1, Lcom/lvteam/Ipv4UdpPacket;->destinationPort:I

    invoke-direct {v0, v1, v2, v3, v4}, Lcom/lvteam/PacketCaptureService$FlowKey;-><init>(Ljava/net/InetAddress;ILjava/net/InetAddress;I)V

    .line 232
    .local v0, "key":Lcom/lvteam/PacketCaptureService$FlowKey;
    iget-object v1, p0, Lcom/lvteam/PacketCaptureService;->flowLock:Ljava/lang/Object;

    monitor-enter v1

    .line 233
    :try_start_0
    iget-boolean v2, p0, Lcom/lvteam/PacketCaptureService;->relayRunning:Z

    if-eqz v2, :cond_0

    iget-object v2, p0, Lcom/lvteam/PacketCaptureService;->relayExecutor:Ljava/util/concurrent/ExecutorService;

    if-nez v2, :cond_1

    :cond_0
    goto/16 :goto_7

    .line 234
    :cond_1
    iget-object v2, p0, Lcom/lvteam/PacketCaptureService;->flows:Ljava/util/Map;

    invoke-interface {v2, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/lvteam/PacketCaptureService$UdpFlow;

    .line 235
    .local v2, "flow":Lcom/lvteam/PacketCaptureService$UdpFlow;
    if-nez v2, :cond_4

    .line 236
    invoke-direct {p0}, Lcom/lvteam/PacketCaptureService;->evictUdpFlowsLocked()V

    .line 237
    iget-object v3, p0, Lcom/lvteam/PacketCaptureService;->flows:Ljava/util/Map;

    invoke-interface {v3}, Ljava/util/Map;->size()I

    move-result v3

    const/16 v4, 0x80

    if-lt v3, v4, :cond_2

    .line 238
    const-string v3, "PacketCapture"

    const-string v4, "UDP flow limit reached"

    invoke-static {v3, v4}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 239
    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-void

    .line 254
    .end local v2    # "flow":Lcom/lvteam/PacketCaptureService$UdpFlow;
    :catchall_0
    move-exception v2

    goto/16 :goto_8

    .line 242
    .restart local v2    # "flow":Lcom/lvteam/PacketCaptureService$UdpFlow;
    :cond_2
    :try_start_1
    new-instance v3, Ljava/net/DatagramSocket;

    invoke-direct {v3}, Ljava/net/DatagramSocket;-><init>()V

    .line 243
    .local v3, "socket":Ljava/net/DatagramSocket;
    invoke-virtual {p0, v3}, Landroid/net/VpnService;->protect(Ljava/net/DatagramSocket;)Z

    move-result v4

    if-nez v4, :cond_3

    const-string v4, "PacketCapture"

    const-string v5, "UDP socket uses app VPN exclusion fallback"

    invoke-static {v4, v5}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    .line 249
    .end local v3    # "socket":Ljava/net/DatagramSocket;
    :catch_0
    move-exception v3

    goto :goto_1

    .line 244
    .restart local v3    # "socket":Ljava/net/DatagramSocket;
    :cond_3
    :goto_0
    iget-object v4, p1, Lcom/lvteam/Ipv4UdpPacket;->destinationAddress:Ljava/net/InetAddress;

    iget v5, p1, Lcom/lvteam/Ipv4UdpPacket;->destinationPort:I

    invoke-virtual {v3, v4, v5}, Ljava/net/DatagramSocket;->connect(Ljava/net/InetAddress;I)V

    .line 245
    const/16 v4, 0x7530

    invoke-virtual {v3, v4}, Ljava/net/DatagramSocket;->setSoTimeout(I)V

    .line 246
    new-instance v4, Lcom/lvteam/PacketCaptureService$UdpFlow;

    invoke-direct {v4, p0, v0, v3}, Lcom/lvteam/PacketCaptureService$UdpFlow;-><init>(Lcom/lvteam/PacketCaptureService;Lcom/lvteam/PacketCaptureService$FlowKey;Ljava/net/DatagramSocket;)V

    move-object v2, v4

    .line 247
    iget-object v4, p0, Lcom/lvteam/PacketCaptureService;->flows:Ljava/util/Map;

    invoke-interface {v4, v0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 248
    iget-object v4, p0, Lcom/lvteam/PacketCaptureService;->relayExecutor:Ljava/util/concurrent/ExecutorService;

    invoke-interface {v4, v2}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V
    :try_end_1
    .catch Ljava/net/SocketException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 252
    .end local v3    # "socket":Ljava/net/DatagramSocket;
    goto :goto_2

    .line 249
    :goto_1
    nop

    .line 250
    .local v3, "e":Ljava/net/SocketException;
    :try_start_2
    const-string v4, "PacketCapture"

    const-string v5, "Could not create UDP flow"

    invoke-static {v4, v5, v3}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 251
    monitor-exit v1

    return-void

    .line 254
    .end local v3    # "e":Ljava/net/SocketException;
    :cond_4
    :goto_2
    monitor-exit v1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 255
    sget v1, Lcom/lvteam/LvTeamShift;->teleportBaseState:I

    .line 256
    .local v1, "tpState":I
    const/4 v3, 0x2

    const/4 v4, 0x1

    if-ne v1, v3, :cond_5

    iget-boolean v3, p0, Lcom/lvteam/PacketCaptureService;->tpReplayStarted:Z

    if-nez v3, :cond_5

    .line 257
    iput-boolean v4, p0, Lcom/lvteam/PacketCaptureService;->tpReplayStarted:Z

    .line 258
    invoke-direct {p0}, Lcom/lvteam/PacketCaptureService;->startTpReplay()V

    .line 260
    :cond_5
    if-nez v1, :cond_6

    iget-boolean v3, p0, Lcom/lvteam/PacketCaptureService;->tpReplayStarted:Z

    if-eqz v3, :cond_6

    .line 261
    const/4 v3, 0x0

    iput-boolean v3, p0, Lcom/lvteam/PacketCaptureService;->tpReplayStarted:Z

    .line 262
    iget-object v3, p0, Lcom/lvteam/PacketCaptureService;->heldUplinkPackets:Ljava/util/ArrayList;

    monitor-enter v3

    :try_start_3
    iget-object v5, p0, Lcom/lvteam/PacketCaptureService;->heldUplinkPackets:Ljava/util/ArrayList;

    invoke-virtual {v5}, Ljava/util/ArrayList;->clear()V

    monitor-exit v3

    goto :goto_3

    :catchall_1
    move-exception v4

    monitor-exit v3
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    throw v4

    .line 264
    :cond_6
    :goto_3
    if-eqz v1, :cond_9

    iget-object v3, p1, Lcom/lvteam/Ipv4UdpPacket;->payload:[B

    array-length v3, v3

    const/16 v5, 0x28

    if-lt v3, v5, :cond_9

    iget-object v3, p0, Lcom/lvteam/PacketCaptureService;->frameDecoder:Lcom/lvteam/RawFrameDecoder;

    iget-object v5, p1, Lcom/lvteam/Ipv4UdpPacket;->destinationAddress:Ljava/net/InetAddress;

    iget v6, p1, Lcom/lvteam/Ipv4UdpPacket;->destinationPort:I

    .line 266
    invoke-virtual {v3, v5, v6}, Lcom/lvteam/RawFrameDecoder;->isGameEndpoint(Ljava/net/InetAddress;I)Z

    move-result v3

    if-eqz v3, :cond_9

    .line 267
    if-ne v1, v4, :cond_8

    .line 268
    iget-object v3, p0, Lcom/lvteam/PacketCaptureService;->heldUplinkPackets:Ljava/util/ArrayList;

    monitor-enter v3

    .line 269
    :try_start_4
    iget-object v4, p0, Lcom/lvteam/PacketCaptureService;->heldUplinkPackets:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    const/16 v5, 0x1388

    if-ge v4, v5, :cond_7

    .line 270
    iget-object v4, p0, Lcom/lvteam/PacketCaptureService;->heldUplinkPackets:Ljava/util/ArrayList;

    new-instance v5, Lcom/lvteam/PacketCaptureService$HeldUdpPacket;

    iget-object v6, p1, Lcom/lvteam/Ipv4UdpPacket;->payload:[B

    invoke-direct {v5, v6, v2}, Lcom/lvteam/PacketCaptureService$HeldUdpPacket;-><init>([BLcom/lvteam/PacketCaptureService$UdpFlow;)V

    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_4

    .line 271
    :catchall_2
    move-exception v4

    goto :goto_5

    :cond_7
    :goto_4
    monitor-exit v3

    goto :goto_6

    :goto_5
    monitor-exit v3
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    throw v4

    .line 273
    :cond_8
    :goto_6
    return-void

    .line 276
    :cond_9
    iget-object v3, p0, Lcom/lvteam/PacketCaptureService;->frameDecoder:Lcom/lvteam/RawFrameDecoder;

    iget-object v4, p1, Lcom/lvteam/Ipv4UdpPacket;->payload:[B

    iget-object v5, p1, Lcom/lvteam/Ipv4UdpPacket;->payload:[B

    array-length v5, v5

    iget-object v6, p1, Lcom/lvteam/Ipv4UdpPacket;->destinationAddress:Ljava/net/InetAddress;

    iget v7, p1, Lcom/lvteam/Ipv4UdpPacket;->destinationPort:I

    invoke-virtual {v3, v4, v5, v6, v7}, Lcom/lvteam/RawFrameDecoder;->shiftUplink([BILjava/net/InetAddress;I)[B

    move-result-object v3

    .line 278
    .local v3, "uplinkPayload":[B
    invoke-virtual {v2, v3}, Lcom/lvteam/PacketCaptureService$UdpFlow;->send([B)V

    .line 279
    return-void

    .line 233
    .end local v1    # "tpState":I
    .end local v2    # "flow":Lcom/lvteam/PacketCaptureService$UdpFlow;
    .end local v3    # "uplinkPayload":[B
    :goto_7
    :try_start_5
    monitor-exit v1

    return-void

    .line 254
    :goto_8
    monitor-exit v1
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    throw v2
.end method

.method private static increment(JI)J
    .locals 4
    .param p0, "sequence"    # J
    .param p2, "amount"    # I

    .line 819
    int-to-long v0, p2

    add-long/2addr v0, p0

    const-wide v2, 0xffffffffL

    and-long/2addr v0, v2

    return-wide v0
.end method

.method private static isAfter(JJ)Z
    .locals 4
    .param p0, "sequence"    # J
    .param p2, "reference"    # J

    .line 823
    sub-long v0, p0, p2

    const-wide v2, 0xffffffffL

    and-long/2addr v0, v2

    .line 824
    .local v0, "difference":J
    const-wide/16 v2, 0x0

    cmp-long v2, v0, v2

    if-eqz v2, :cond_0

    const-wide v2, 0x80000000L

    cmp-long v2, v0, v2

    if-gez v2, :cond_0

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    :goto_0
    return v2
.end method

.method private synthetic lambda$startTpReplay$0(Ljava/util/List;)V
    .locals 14
    .param p1, "toReplay"    # Ljava/util/List;

    .line 298
    const/4 v0, 0x0

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/lvteam/PacketCaptureService$HeldUdpPacket;

    iget-wide v1, v1, Lcom/lvteam/PacketCaptureService$HeldUdpPacket;->capturedAt:J

    .line 299
    .local v1, "baseAt":J
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v3

    .line 300
    .local v3, "startedAt":J
    invoke-static {}, Lcom/lvteam/LvTeamShift;->getTeleportSpeed()I

    move-result v5

    int-to-float v5, v5

    const/high16 v6, 0x3f800000    # 1.0f

    invoke-static {v6, v5}, Ljava/lang/Math;->max(FF)F

    move-result v5

    .line 301
    .local v5, "speed":F
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :goto_0
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    nop

    if-eqz v7, :cond_2

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lcom/lvteam/PacketCaptureService$HeldUdpPacket;

    .line 302
    .local v7, "hp":Lcom/lvteam/PacketCaptureService$HeldUdpPacket;
    sget v8, Lcom/lvteam/LvTeamShift;->teleportBaseState:I

    const/4 v9, 0x2

    if-eq v8, v9, :cond_0

    goto :goto_3

    .line 304
    :cond_0
    :try_start_0
    iget-wide v8, v7, Lcom/lvteam/PacketCaptureService$HeldUdpPacket;->capturedAt:J

    sub-long/2addr v8, v1

    long-to-float v8, v8

    div-float/2addr v8, v5

    float-to-long v8, v8

    add-long/2addr v8, v3

    .line 305
    .local v8, "due":J
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v10

    sub-long v10, v8, v10

    .line 306
    .local v10, "wait":J
    const-wide/16 v12, 0x0

    cmp-long v12, v10, v12

    if-lez v12, :cond_1

    invoke-static {v10, v11}, Ljava/lang/Thread;->sleep(J)V

    goto :goto_1

    .line 308
    .end local v8    # "due":J
    .end local v10    # "wait":J
    :catch_0
    move-exception v6

    goto :goto_2

    .line 307
    .restart local v8    # "due":J
    .restart local v10    # "wait":J
    :cond_1
    :goto_1
    iget-object v12, v7, Lcom/lvteam/PacketCaptureService$HeldUdpPacket;->flow:Lcom/lvteam/PacketCaptureService$UdpFlow;

    iget-object v13, v7, Lcom/lvteam/PacketCaptureService$HeldUdpPacket;->payload:[B

    invoke-virtual {v12, v13}, Lcom/lvteam/PacketCaptureService$UdpFlow;->send([B)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 308
    .end local v8    # "due":J
    .end local v10    # "wait":J
    nop

    .line 309
    .end local v7    # "hp":Lcom/lvteam/PacketCaptureService$HeldUdpPacket;
    goto :goto_0

    .line 308
    .restart local v7    # "hp":Lcom/lvteam/PacketCaptureService$HeldUdpPacket;
    :goto_2
    nop

    .line 310
    .end local v7    # "hp":Lcom/lvteam/PacketCaptureService$HeldUdpPacket;
    :cond_2
    :goto_3
    sput v0, Lcom/lvteam/LvTeamShift;->teleportBaseState:I

    .line 311
    iput-boolean v0, p0, Lcom/lvteam/PacketCaptureService;->tpReplayStarted:Z

    .line 312
    invoke-static {}, Lcom/lvteam/LvShiftOverlay;->refreshTpBase()V

    .line 313
    return-void
.end method

.method private readTunPackets()V
    .locals 5

    .line 200
    monitor-enter p0

    .line 201
    const/4 v0, 0x1

    :try_start_0
    iput-boolean v0, p0, Lcom/lvteam/PacketCaptureService;->relayReaderStarted:Z

    .line 202
    iget-boolean v0, p0, Lcom/lvteam/PacketCaptureService;->fullRouteStartupPending:Z

    if-eqz v0, :cond_0

    invoke-direct {p0}, Lcom/lvteam/PacketCaptureService;->completeFullRouteStartup()V

    goto :goto_0

    .line 203
    :catchall_0
    move-exception v0

    goto :goto_5

    :cond_0
    :goto_0
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 204
    const v0, 0xffff

    new-array v0, v0, [B

    .line 206
    .local v0, "buffer":[B
    :goto_1
    :try_start_1
    iget-boolean v1, p0, Lcom/lvteam/PacketCaptureService;->relayRunning:Z

    if-eqz v1, :cond_5

    .line 207
    iget-object v1, p0, Lcom/lvteam/PacketCaptureService;->tunnelInput:Ljava/io/FileInputStream;

    invoke-virtual {v1, v0}, Ljava/io/FileInputStream;->read([B)I

    move-result v1

    .line 208
    .local v1, "length":I
    if-gtz v1, :cond_1

    goto :goto_1

    .line 209
    :cond_1
    invoke-static {}, Lcom/lvteam/LvSession;->get()Lcom/lvteam/LvSession;

    move-result-object v2

    invoke-virtual {v2}, Lcom/lvteam/LvSession;->isActive()Z

    move-result v2
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_1

    if-nez v2, :cond_2

    goto :goto_1

    .line 211
    :cond_2
    :try_start_2
    iget-object v2, p0, Lcom/lvteam/PacketCaptureService;->frameDecoder:Lcom/lvteam/RawFrameDecoder;

    invoke-virtual {v2, v0, v1}, Lcom/lvteam/RawFrameDecoder;->accept([BI)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    .line 214
    goto :goto_2

    .line 212
    :catch_0
    move-exception v2

    .line 213
    .local v2, "e":Ljava/lang/Exception;
    :try_start_3
    const-string v3, "PacketCapture"

    const-string v4, "accept error"

    invoke-static {v3, v4, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 215
    .end local v2    # "e":Ljava/lang/Exception;
    :goto_2
    invoke-static {v0, v1}, Lcom/lvteam/Ipv4UdpPacket;->parse([BI)Lcom/lvteam/Ipv4UdpPacket;

    move-result-object v2

    .line 216
    .local v2, "udpPacket":Lcom/lvteam/Ipv4UdpPacket;
    if-eqz v2, :cond_3

    .line 217
    invoke-direct {p0, v2}, Lcom/lvteam/PacketCaptureService;->forward(Lcom/lvteam/Ipv4UdpPacket;)V

    .line 218
    goto :goto_1

    .line 223
    .end local v1    # "length":I
    .end local v2    # "udpPacket":Lcom/lvteam/Ipv4UdpPacket;
    :catch_1
    move-exception v1

    goto :goto_3

    .line 220
    .restart local v1    # "length":I
    .restart local v2    # "udpPacket":Lcom/lvteam/Ipv4UdpPacket;
    :cond_3
    invoke-static {v0, v1}, Lcom/lvteam/Ipv4TcpPacket;->parse([BI)Lcom/lvteam/Ipv4TcpPacket;

    move-result-object v3

    .line 221
    .local v3, "tcpPacket":Lcom/lvteam/Ipv4TcpPacket;
    if-eqz v3, :cond_4

    invoke-direct {p0, v3}, Lcom/lvteam/PacketCaptureService;->forward(Lcom/lvteam/Ipv4TcpPacket;)V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_1

    .line 222
    .end local v1    # "length":I
    .end local v2    # "udpPacket":Lcom/lvteam/Ipv4UdpPacket;
    .end local v3    # "tcpPacket":Lcom/lvteam/Ipv4TcpPacket;
    :cond_4
    goto :goto_1

    .line 225
    :cond_5
    goto :goto_4

    .line 223
    :goto_3
    nop

    .line 224
    .local v1, "e":Ljava/io/IOException;
    iget-boolean v2, p0, Lcom/lvteam/PacketCaptureService;->relayRunning:Z

    if-eqz v2, :cond_6

    const-string v2, "PacketCapture"

    const-string v3, "TUN input stopped"

    invoke-static {v2, v3, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 226
    .end local v1    # "e":Ljava/io/IOException;
    :cond_6
    :goto_4
    return-void

    .line 203
    .end local v0    # "buffer":[B
    :goto_5
    :try_start_4
    monitor-exit p0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    throw v0
.end method

.method private declared-synchronized startRelay()Z
    .locals 4

    monitor-enter p0

    .line 182
    :try_start_0
    iget-boolean v0, p0, Lcom/lvteam/PacketCaptureService;->relayRunning:Z

    if-nez v0, :cond_1

    iget-object v0, p0, Lcom/lvteam/PacketCaptureService;->tunnel:Landroid/os/ParcelFileDescriptor;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-nez v0, :cond_0

    goto :goto_0

    .line 184
    :cond_0
    const/4 v0, 0x0

    :try_start_1
    new-instance v1, Ljava/io/FileInputStream;

    iget-object v2, p0, Lcom/lvteam/PacketCaptureService;->tunnel:Landroid/os/ParcelFileDescriptor;

    invoke-virtual {v2}, Landroid/os/ParcelFileDescriptor;->getFileDescriptor()Ljava/io/FileDescriptor;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/io/FileInputStream;-><init>(Ljava/io/FileDescriptor;)V

    iput-object v1, p0, Lcom/lvteam/PacketCaptureService;->tunnelInput:Ljava/io/FileInputStream;

    .line 185
    const/4 v1, 0x1

    iput-boolean v1, p0, Lcom/lvteam/PacketCaptureService;->inputRelayInitialized:Z

    .line 186
    new-instance v2, Ljava/io/FileOutputStream;

    iget-object v3, p0, Lcom/lvteam/PacketCaptureService;->tunnel:Landroid/os/ParcelFileDescriptor;

    invoke-virtual {v3}, Landroid/os/ParcelFileDescriptor;->getFileDescriptor()Ljava/io/FileDescriptor;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/io/FileOutputStream;-><init>(Ljava/io/FileDescriptor;)V

    iput-object v2, p0, Lcom/lvteam/PacketCaptureService;->tunnelOutput:Ljava/io/FileOutputStream;

    .line 187
    iput-boolean v1, p0, Lcom/lvteam/PacketCaptureService;->outputRelayInitialized:Z

    .line 188
    invoke-static {}, Ljava/util/concurrent/Executors;->newCachedThreadPool()Ljava/util/concurrent/ExecutorService;

    move-result-object v2

    iput-object v2, p0, Lcom/lvteam/PacketCaptureService;->relayExecutor:Ljava/util/concurrent/ExecutorService;

    .line 189
    iput-boolean v1, p0, Lcom/lvteam/PacketCaptureService;->relayRunning:Z

    .line 190
    iput-boolean v0, p0, Lcom/lvteam/PacketCaptureService;->relayReaderStarted:Z

    .line 191
    iget-object v2, p0, Lcom/lvteam/PacketCaptureService;->relayExecutor:Ljava/util/concurrent/ExecutorService;

    new-instance v3, Lcom/lvteam/PacketCaptureService$$ExternalSyntheticLambda3;

    invoke-direct {v3, p0}, Lcom/lvteam/PacketCaptureService$$ExternalSyntheticLambda3;-><init>(Lcom/lvteam/PacketCaptureService;)V

    invoke-interface {v2, v3}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 192
    monitor-exit p0

    return v1

    .line 181
    .end local p0    # "this":Lcom/lvteam/PacketCaptureService;
    :catchall_0
    move-exception v0

    goto :goto_1

    .line 193
    :catch_0
    move-exception v1

    nop

    .line 194
    .local v1, "e":Ljava/lang/RuntimeException;
    :try_start_2
    const-string v2, "PacketCapture"

    const-string v3, "Could not initialize generic relays"

    invoke-static {v2, v3, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 195
    monitor-exit p0

    return v0

    .line 182
    .end local v1    # "e":Ljava/lang/RuntimeException;
    :cond_1
    :goto_0
    :try_start_3
    invoke-direct {p0}, Lcom/lvteam/PacketCaptureService;->areGenericRelaysInitialized()Z

    move-result v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    monitor-exit p0

    return v0

    .line 181
    :goto_1
    :try_start_4
    monitor-exit p0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    throw v0
.end method

.method private startTpReplay()V
    .locals 4

    .line 283
    iget-object v0, p0, Lcom/lvteam/PacketCaptureService;->heldUplinkPackets:Ljava/util/ArrayList;

    monitor-enter v0

    .line 284
    :try_start_0
    iget-object v1, p0, Lcom/lvteam/PacketCaptureService;->heldUplinkPackets:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_0

    .line 285
    sput v2, Lcom/lvteam/LvTeamShift;->teleportBaseState:I

    .line 286
    iput-boolean v2, p0, Lcom/lvteam/PacketCaptureService;->tpReplayStarted:Z

    .line 287
    invoke-static {}, Lcom/lvteam/LvShiftOverlay;->refreshTpBase()V

    .line 288
    monitor-exit v0

    return-void

    .line 292
    :catchall_0
    move-exception v1

    goto :goto_1

    .line 290
    :cond_0
    new-instance v1, Ljava/util/ArrayList;

    iget-object v3, p0, Lcom/lvteam/PacketCaptureService;->heldUplinkPackets:Ljava/util/ArrayList;

    invoke-direct {v1, v3}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 291
    .local v1, "toReplay":Ljava/util/List;, "Ljava/util/List<Lcom/lvteam/PacketCaptureService$HeldUdpPacket;>;"
    iget-object v3, p0, Lcom/lvteam/PacketCaptureService;->heldUplinkPackets:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->clear()V

    .line 292
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 293
    iget-object v0, p0, Lcom/lvteam/PacketCaptureService;->relayExecutor:Ljava/util/concurrent/ExecutorService;

    if-eqz v0, :cond_1

    .line 294
    iget-object v0, p0, Lcom/lvteam/PacketCaptureService;->relayExecutor:Ljava/util/concurrent/ExecutorService;

    new-instance v2, Lcom/lvteam/PacketCaptureService$$ExternalSyntheticLambda2;

    invoke-direct {v2, p0, v1}, Lcom/lvteam/PacketCaptureService$$ExternalSyntheticLambda2;-><init>(Lcom/lvteam/PacketCaptureService;Ljava/util/List;)V

    invoke-interface {v0, v2}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    goto :goto_0

    .line 315
    :cond_1
    sput v2, Lcom/lvteam/LvTeamShift;->teleportBaseState:I

    .line 316
    iput-boolean v2, p0, Lcom/lvteam/PacketCaptureService;->tpReplayStarted:Z

    .line 317
    invoke-static {}, Lcom/lvteam/LvShiftOverlay;->refreshTpBase()V

    .line 319
    :goto_0
    return-void

    .line 292
    .end local v1    # "toReplay":Ljava/util/List;, "Ljava/util/List<Lcom/lvteam/PacketCaptureService$HeldUdpPacket;>;"
    :goto_1
    :try_start_1
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v1
.end method

.method private warnTcp(Ljava/lang/String;Ljava/lang/Exception;)V
    .locals 7
    .param p1, "message"    # Ljava/lang/String;
    .param p2, "error"    # Ljava/lang/Exception;

    .line 408
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    .line 409
    .local v0, "now":J
    iget-object v2, p0, Lcom/lvteam/PacketCaptureService;->tcpWarningLock:Ljava/lang/Object;

    monitor-enter v2

    .line 410
    :try_start_0
    iget-wide v3, p0, Lcom/lvteam/PacketCaptureService;->lastTcpWarningAtMillis:J

    sub-long v3, v0, v3

    const-wide/16 v5, 0x7530

    cmp-long v3, v3, v5

    if-gez v3, :cond_0

    monitor-exit v2

    return-void

    .line 412
    :catchall_0
    move-exception v3

    goto :goto_1

    .line 411
    :cond_0
    iput-wide v0, p0, Lcom/lvteam/PacketCaptureService;->lastTcpWarningAtMillis:J

    .line 412
    monitor-exit v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 413
    if-nez p2, :cond_1

    const-string v2, "PacketCapture"

    invoke-static {v2, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    .line 414
    :cond_1
    const-string v2, "PacketCapture"

    invoke-static {v2, p1, p2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 415
    :goto_0
    return-void

    .line 412
    :goto_1
    :try_start_1
    monitor-exit v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v3
.end method


# virtual methods
.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 1
    .param p1, "intent"    # Landroid/content/Intent;

    .line 861
    invoke-super {p0, p1}, Landroid/net/VpnService;->onBind(Landroid/content/Intent;)Landroid/os/IBinder;

    move-result-object v0

    return-object v0
.end method

.method public onDestroy()V
    .locals 1

    .line 106
    invoke-direct {p0}, Lcom/lvteam/PacketCaptureService;->closeTunnel()V

    .line 107
    iget-object v0, p0, Lcom/lvteam/PacketCaptureService;->startupWatchdog:Ljava/util/concurrent/ScheduledExecutorService;

    invoke-interface {v0}, Ljava/util/concurrent/ExecutorService;->shutdownNow()Ljava/util/List;

    .line 108
    invoke-super {p0}, Landroid/net/VpnService;->onDestroy()V

    .line 109
    return-void
.end method

.method public onRevoke()V
    .locals 2

    .line 99
    const-string v0, "PacketCapture"

    const-string v1, "VPN consent revoked"

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 100
    invoke-direct {p0}, Lcom/lvteam/PacketCaptureService;->closeTunnel()V

    .line 101
    invoke-super {p0}, Landroid/net/VpnService;->onRevoke()V

    .line 102
    return-void
.end method

.method public onStartCommand(Landroid/content/Intent;II)I
    .locals 2
    .param p1, "intent"    # Landroid/content/Intent;
    .param p2, "flags"    # I
    .param p3, "startId"    # I

    .line 89
    if-eqz p1, :cond_0

    const-string v0, "com.lvteam.action.ENABLE_FULL_IPV4_ROUTE"

    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 90
    invoke-direct {p0}, Lcom/lvteam/PacketCaptureService;->enableFullIpv4Route()V

    goto :goto_0

    .line 91
    :cond_0
    iget-object v0, p0, Lcom/lvteam/PacketCaptureService;->tunnel:Landroid/os/ParcelFileDescriptor;

    if-nez v0, :cond_1

    .line 92
    invoke-direct {p0}, Lcom/lvteam/PacketCaptureService;->establishRouteFreeVpn()V

    .line 94
    :cond_1
    :goto_0
    const/4 v0, 0x2

    return v0
.end method

.method public onTaskRemoved(Landroid/content/Intent;)V
    .locals 2
    .param p1, "rootIntent"    # Landroid/content/Intent;

    .line 113
    invoke-direct {p0}, Lcom/lvteam/PacketCaptureService;->closeTunnel()V

    .line 114
    invoke-virtual {p0}, Landroid/app/Service;->stopSelf()V

    .line 115
    :try_start_0
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/lvteam/OverlayService;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Landroid/content/Context;->stopService(Landroid/content/Intent;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    .line 116
    :goto_0
    invoke-super {p0, p1}, Landroid/net/VpnService;->onTaskRemoved(Landroid/content/Intent;)V

    .line 117
    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v0

    invoke-static {v0}, Landroid/os/Process;->killProcess(I)V

    .line 118
    return-void
.end method
